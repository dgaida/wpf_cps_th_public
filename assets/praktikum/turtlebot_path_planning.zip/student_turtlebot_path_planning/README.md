# Praktikum: Pfadplanung & Kartierung mit dem TurtleBot 4 (SLAM, Dijkstra & A\*)

> **Vom Belegen von Räumen zur autonom vorausplanenden Trajektorie: Kartierung mit SLAM Toolbox, Nav2-Navigation, Graphendiskretisierung der Karte und interaktive Visualisierung der Suchraum-Expansion mit Dijkstra und A\*.**

---

## 🎯 Überblick & Zielsetzung

In diesem Praktikum lernen die Studierenden die Grundlagen der autonomen mobilen Robotik und der globalen Pfadplanung kennen. Das Praktikum ist in zwei Hauptphasen gegliedert:

1. **Erstellung einer Umgebungskarte mit SLAM:** Mittels des ROS 2 Packages (`slam_toolbox`) wird das Versuchslabor während einer manuellen Tastatur-Steuerung (*Teleoperation*) kartiert und als Belegungsgitter (*Occupancy Grid*) gespeichert.  
2. **Diskretisierung & Pfadplanung (Dijkstra, A\* & Nav2):**  
   - **Teil A (Karten-Diskretisierung & Graphenkonstruktion):** Umwandlung des kontinuierlichen Occupancy Grids in einen diskreten Graphen $G = (V, E)$ unter Berücksichtigung von Auflösung, Hindernis-Aufblähung (*Inflation Radius*) und Nachbarschaftskonnektivität.  
   - **Teil B (Interaktive Visualisierung von Dijkstra vs. A\*):** Eigene Implementierung von Dijkstra und A\* in Python und Verständnis der Suchraum-Expansion durch schrittweise Visualisierung in RViz2. Studierende beobachten live, wie Dijkstra den Graphen radial in alle Richtungen durchsucht, während A\* mithilfe einer Admissiblen Heuristik ($h(n)$) den Graphen zielgerichtet erobert.  
   - **Teil C (Vergleich mit ROS 2 Nav2):** Gegenüberstellung der eigenen Python-Implementierungen mit den Nav2-Standardplanern (`nav2_navfn_planner` und `nav2_smac_planner`).  

---

## 📑 Detaillierte Aufgabenstellungen & Anleitungen

Die ausführlichen Schritt-für-Schritt-Anleitungen, Versuchsaufgaben und Protokollfragen finden Sie in den folgenden Dokumenten im Ordner [`docs/`](./docs/):

1. [📄 **Schritt 1: SLAM-Kartierung der Umgebung**](./docs/01_slam_kartierung.md)  
   - Kartierung des Versuchsraums mit `slam_toolbox` und Speichern der Karte (`map.yaml`, `map.pgm`).  
2. [📄 **Schritt 2: Graphendiskretisierung & Interaktive Pfadplanung (Dijkstra & A\*)**](./docs/02_graphendiskretisierung_pfadplanung.md)  
   - Hindernis-Inflation, Graphenaufbau, eigene Implementierung von Dijkstra und A\* mit Live-Visualisierung in RViz2 sowie Heuristik-Analyse.  
3. [📄 **Schritt 3: Vergleich mit ROS 2 Nav2 Standardplanern**](./docs/03_nav2_vergleich.md)  
   - Gegenüberstellung der Python-Eigenimplementierung mit den Nav2 Global Planners (`NavfnPlanner`, `SmacPlanner2D`).  

---

## 💡 Warum eine eigene Implementierung?

- Industrielle ROS 2 Packages (wie Nav2) führen die Pfadplanung in optimierten C++-Knoten aus und veröffentlichen standardmäßig **nur den finalen Pfad** als `nav_msgs/msg/Path` auf `/plan`.  
- Die Zwischenschritte der Knoten-Expansion (Open List, Closed List, Heuristik-Auswertung) werden nicht live in RViz2 veröffentlicht.  
- **Didaktischer Baustein:** Durch eine schlanke Python-Eigenimplementierung mit ROS 2 Marker-Publishing (`visualization_msgs/msg/MarkerArray`) wird die Such-Dynamik von Dijkstra (radiales Ausbreiten) und A\* (zielgerichteter Suchkegel) live in RViz2 sichtbar gemacht!  

---

## 🏗️ Systemarchitektur & Ablauf

```
 ┌────────────────────────────────────────────────────────────────────────┐
 │                          PHASE 1: SLAM-KARTIERUNG                      │
 │                                                                        │
 │  [ TurtleBot 4 LiDAR ] ────> ( slam_toolbox Node ) ────> [ map.pgm ]   │
 │  [ Teleop Keyboard   ] ───>  ( SLAM: slam_toolbox)       [ map.yaml  ] │
 └────────────────────────────────────────────────────────────────────────┘
                                    │
                                    ▼
 ┌────────────────────────────────────────────────────────────────────────┐
 │            PHASE 2: DISKRETISIERUNG, DIJKSTRA / A* & NAV2              │
 │                                                                        │
 │  Teil A & B: Graphenkonstruktion & Interaktive Visualisierung (Python) │
 │  1. Einlesen von map.yaml / map.pgm & Inflation (Robot radius)         │
 │  2. Erzeugung des Graphen G = (V, E) mit 4-/8-Nachbarschaft             │
 │  3. Schrittweise Expansion:                                            │
 │     - Dijkstra: f(n) = g(n)             ──> Radiales Wachstum         │
 │     - A*:       f(n) = g(n) + h(n)     ──> Zielgerichtete Eroberung   │
 │  4. Live-Publikation der Open/Closed Set ──> [ RViz2 MarkerArray ]    │
 │                                                                        │
 │  Teil C: Vergleich mit ROS 2 Nav2                                      │
 │  [ Goal Pose in RViz2 ] ──> ( Nav2 navfn / smac ) ──> TurtleBot Exec   │
 └────────────────────────────────────────────────────────────────────────┘
```

---

## 📐 Graphendiskretisierung der SLAM-Karte

Nach der Kartierung liegt die Umgebung als bildbasiertes Belegungsgitter (*Occupancy Grid*) vor. Um Algorithmen wie Dijkstra oder A\* anzuwenden, muss diese kontinuierliche bzw. rasterbasierte Karte in einen mathematischen Graphen $G = (V, E)$ überführt werden.

### 1. Koordinatentransformation & Rasterung
Eine SLAM-Karte wird durch Metadaten in `map.yaml` definiert:  
- **Auflösung ($r$):** z. B. $r = 0{,}05\text{ m/Pixel}$.  
- **Ursprung ($origin$):** Weltkoordinaten $(x_0, y_0, \theta)$ der unteren linken Ecke des Gitters.  
- **Zellwert:** Intensitätswert zwischen $0$ (frei) und $100$ (belegt); $-1$ steht für unbekannten Raum.  

Die Umrechnung zwischen Weltkoordinaten $(x_{w}, y_{w})$ und Gitterindizes $(i, j)$ lautet:

$$i = \left\lfloor \frac{x_{w} - x_0}{r} \right\rfloor, \quad j = \left\lfloor \frac{y_{w} - y_0}{r} \right\rfloor$$

$$x_{w} = x_0 + \left(i + 0{,}5\right) \cdot r, \quad y_{w} = y_0 + \left(j + 0{,}5\right) \cdot r$$

### 2. Hindernis-Aufblähung (Costmap Inflation)
Ein Punktroboter kann Kollisionen erleiden, wenn seine physikalischen Abmessungen nicht berücksichtigt werden. Daher wird jedes Hindernis im Gitter um den Sicherheitsradius des Roboters (beim TurtleBot 4: $r_{\text{robot}} = 0{,}18\text{ m}$ plus Sicherheitsmarge) aufgebläht (*Inflation Radius*). Alle Zellen innerhalb dieses Abstands werden als unpassierbar markiert oder mit hohen Bewegungskosten belegt.

### 3. Knoten- und Kanten-Definition  
- **Knoten Menge $V$:** Jede freie, nicht belegte Gitterzelle $(i, j)$ bildet einen Knoten $v \in V$.  
- **Kanten Menge $E$:** Verbindungen zwischen benachbarten freien Zellen:  
  - **4-Nachbarschaft (Manhattan):** Bewegungen nach Oben, Unten, Links, Rechts. Kantenkosten $c = 1{,}0$.  
  - **8-Nachbarschaft (Euklidisch):** Zusätzlich diagonale Bewegungen. Kantenkosten $c_{\text{ortho}} = 1{,}0$ und $c_{\text{diag}} = \sqrt{2} \approx 1{,}414$.  

---

## 🔍 Visualisierung & Funktionsweise: Dijkstra vs. A\*

Sowohl Dijkstra als auch A\* nutzen eine Prioritätswarteschlange (*Priority Queue* / *Open List*), um systematisch den Knoten mit den geringsten geschätzten Gesamtkosten $f(n)$ zu expandieren.

$$\text{Bewertungsfunktion: } f(n) = g(n) + w \cdot h(n)$$

Dabei gilt:  
- $g(n)$: Bisherige tatsächliche Pfadkosten vom Startknoten $s$ zum Knoten $n$.  
- $h(n)$: Geschätzte Restkosten vom Knoten $n$ zum Zielknoten $g$ (*Heuristik*).  
- $w$: Weighting-Faktor ($w = 0$ ergibt Dijkstra; $w = 1$ ergibt A\*).  

```
   DIJKSTRA-EXPANSION (Radial / Isotrop)            A*-EXPANSION (Zielgerichtet)

             .  :  *  :  .                                    .
          :  *  *  *  *  *  :                              :  *  :
       *  *  *  [START] *  *  *                      [START] *  *  ===>  [ZIEL]
          :  *  *  *  *  *  :                              :  *  :
             .  :  *  :  .                                    .
```

---

## 🛠️ Voraussetzungen & Vorbereitung

- **Hardware:** Zwei TurtleBot 4 (Namespaces `/robot_1`, `/robot_2`), angebunden über Fast DDS Discovery Server.  
- **Software:** ROS 2 Humble (Ubuntu 22.04). Die Launch-Argumente in den Docs beziehen sich auf `turtlebot4_navigation` 1.0.x für Humble.  
- **ROS 2 Pakete** (auf dem Praktikums-PC; `turtlebot4_navigation`, `slam_toolbox` und `nav2_bringup` sind dort aktuell **nicht** installiert):  
  ```bash
  sudo apt-get update
  sudo apt-get install ros-humble-turtlebot4-navigation \
                       ros-humble-turtlebot4-viz \
                       ros-humble-slam-toolbox \
                       ros-humble-navigation2 \
                       ros-humble-nav2-bringup \
                       ros-humble-teleop-twist-keyboard
  ```
  > ⚠️ **Kein CycloneDDS:** Der Discovery Server ist eine Fast-DDS-Funktion. `RMW_IMPLEMENTATION` muss `rmw_fastrtps_cpp` sein (wird von `/etc/turtlebot4_discovery/setup.bash` gesetzt). Ein `export RMW_IMPLEMENTATION=rmw_cyclonedds_cpp` in der Shell macht beide Roboter unsichtbar.  
- **Python-Bibliotheken:** `numpy`, `pillow` (`PIL`), `pyyaml`, `rclpy` (System-Python `/usr/bin/python3`, nicht eine Conda-Umgebung).  

---

## 🤖 Multi-Roboter-Setup mit Discovery Server (`robot_1` / `robot_2`)

Die beiden TurtleBots laufen nicht im Standard-Multicast-Discovery, sondern melden sich bei Fast DDS Discovery Servern an (`ROS_DISCOVERY_SERVER=192.168.0.221:11811;192.168.0.222:11811`). Der PC ist als *Super Client* konfiguriert und sieht beide Roboter. Jeder Roboter hat einen eigenen Namespace:

```
/robot_1/scan   /robot_1/odom   /robot_1/tf   /robot_1/cmd_vel   /robot_1/map ...
/robot_2/scan   /robot_2/odom   /robot_2/tf   /robot_2/cmd_vel   /robot_2/map ...
```

Daraus folgen die Regeln, die in allen Docs angewendet werden:

| Situation | Regel |
| :--- | :--- |
| Launch-Files (`slam`, `localization`, `nav2`, `view_robot`) | immer `namespace:=/robot_1` angeben |
| Einzelne Nodes (Teleop, eigener Planer) | `--ros-args -r __ns:=/robot_1` oder gezieltes Remap, z. B. `-r cmd_vel:=/robot_1/cmd_vel` |
| Karte speichern | `map_saver_cli -f ~/my_lab_map -t /robot_1/map` |
| TF-Frames | tragen **kein** Präfix (`map`, `odom`, `base_link`); pro Roboter eine eigene RViz2-Instanz mit `namespace:=` |
| Eigene Nodes | Topics **relativ** benennen (`search_expansion`, nicht `/search_expansion`), damit das Namespace-Remap greift |

### Checkliste vor dem Praktikum

1. **Zeitsynchronisation:** SLAM und Nav2 verwerfen Sensordaten, deren Zeitstempel stark von der PC-Uhr abweichen (`Message Filter dropping message`, leere Costmap). Prüfen:  
   ```bash
   date +%s; ros2 topic echo --once --qos-reliability best_effort /robot_1/scan --field header.stamp.sec
   ```
   Beide Werte müssen bis auf wenige Sekunden übereinstimmen; sonst wenden Sie sich an die Betreuenden.  
2. Beide Gruppen können gleichzeitig kartieren. Karten pro Roboter benennen (`my_lab_map_robot_1`, `my_lab_map_robot_2`).  

---

## 📚 Links & weiterführende Literatur

- [ROS 2 Nav2 Dokumentation](https://navigation.ros.org/)  
- [SLAM Toolbox ROS 2 Dokumentation](https://github.com/SteveMacenski/slam_toolbox)  
- [TurtleBot 4 Navigation Manual](https://turtlebot.github.io/turtlebot4-user-manual/software/navigation.html)  
- Hart, P. E., Nilsson, N. J., & Raphael, B. (1968). *A Formal Basis for the Heuristic Determination of Minimum Cost Paths*. IEEE Transactions on Systems Science and Cybernetics.  
- Dijkstra, E. W. (1959). *A note on two problems in connexion with graphs*. Numerische Mathematik.  
