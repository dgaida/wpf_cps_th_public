# Schritt 3: Vergleich mit ROS 2 Nav2 Standardplanern

Im letzten Teil des Praktikums vergleichen Sie die eigene Python-Implementierung von Dijkstra und A\* mit den professionellen C++ Nav2 Global Planners (`nav2_navfn_planner` und `nav2_smac_planner`).

> Wie in Schritt 1 gilt: Alle Befehle mit dem Namespace Ihres Roboters (`/robot_1` bzw. `/robot_2`) ausführen. Voraussetzung ist eine Karte aus Schritt 1 mit `free_thresh: 0.196`.

---

## 🛠️ Schritt-für-Schritt Anleitung

### 1. Lokalisierung und Nav2 starten

In `turtlebot4_navigation` (Humble) sind Lokalisierung (Map-Server + AMCL) und Navigation getrennte Launch-Files. Verwenden Sie `$HOME` statt `~`, da Launch-Argumente nicht von der Shell expandiert werden.

Terminal 1 – Lokalisierung mit Ihrer Karte:

```bash
ros2 launch turtlebot4_navigation localization.launch.py namespace:=/robot_1 map:=$HOME/my_lab_map.yaml
```

Terminal 2 – Nav2 (Planner, Controller, Behavior Tree):

```bash
ros2 launch turtlebot4_navigation nav2.launch.py namespace:=/robot_1
```

Terminal 3 – RViz2:

```bash
ros2 launch turtlebot4_viz view_robot.launch.py namespace:=/robot_1
```

### 2. Zielpose in RViz2 setzen

1. Setzen Sie die Startpose mit **2D Pose Estimate**, bis das Laserbild auf der Karte liegt.  
2. Setzen Sie ein Ziel mit dem Werkzeug **Nav2 Goal**.  
3. Fügen Sie ein `Path`-Display für `/robot_1/plan` hinzu, um den globalen Pfad zu sehen. Die Costmap liegt auf `/robot_1/global_costmap/costmap`.  

### 3. Planer wechseln (NavFn ↔ Smac)

Nav2 lädt den globalen Planer als Plugin aus der Parameterdatei. Kopieren Sie die Standardkonfiguration und ändern Sie nur den Abschnitt `planner_server`:

```bash
cp /opt/ros/humble/share/turtlebot4_navigation/config/nav2.yaml ~/nav2_planner.yaml
```

**Variante A – `NavfnPlanner`** (Standard; Dijkstra, mit `use_astar: true` A\*):

```yaml
planner_server:
  ros__parameters:
    expected_planner_frequency: 20.0
    planner_plugins: ["GridBased"]
    GridBased:
      plugin: "nav2_navfn_planner/NavfnPlanner"
      tolerance: 0.5
      use_astar: false      # true -> A*
      allow_unknown: true
```

**Variante B – `SmacPlanner2D`** (2D-A\* auf der Costmap mit Pfadglättung):

```yaml
planner_server:
  ros__parameters:
    expected_planner_frequency: 20.0
    planner_plugins: ["GridBased"]
    GridBased:
      plugin: "nav2_smac_planner/SmacPlanner2D"
      tolerance: 0.25
      allow_unknown: true
      max_iterations: 1000000
      max_on_approach_iterations: 1000
      max_planning_time: 2.0
      cost_travel_multiplier: 2.0
      use_final_approach_orientation: false
      smoother:
        max_iterations: 1000
        w_smooth: 0.3
        w_data: 0.2
        tolerance: 1.0e-10
```

Nav2 anschließend mit der angepassten Datei starten (Terminal 2 vorher beenden):

```bash
ros2 launch turtlebot4_navigation nav2.launch.py namespace:=/robot_1 params_file:=$HOME/nav2_planner.yaml
```

> **Hinweis:** `SmacPlanner2D` ist ein reiner 2D-A\*. Der *Hybrid-A\** für kinematisch fahrbare Kurven (Ackermann, Dubins, Reeds-Shepp) ist das separate Plugin `nav2_smac_planner/SmacPlannerHybrid`. Für den TurtleBot 4 (Differentialantrieb, drehbar auf der Stelle) ist `SmacPlanner2D` die passende Wahl.

### 4. Pfade gegenüberstellen

Starten Sie parallel Ihren Planer aus Schritt 2 im selben Namespace mit derselben Start- und Zielposition (Startpose aus `/robot_1/amcl_pose`, Ziel wie in RViz2 gesetzt). Beide Pfade erscheinen im selben `map`-Frame:

```bash
python3 planner.py --ros-args -r __ns:=/robot_1 \
    -p map_yaml:=$HOME/my_lab_map.yaml \
    -p start_x:=<x_amcl> -p start_y:=<y_amcl> -p goal_x:=<x_ziel> -p goal_y:=<y_ziel>
```

---

## 📝 Aufgabenstellung & Versuchsdurchführung

1. **Aufgabe 5: Evaluation gegen Nav2**  
   - Vergleichen Sie den Pfad Ihrer Python-Eigenimplementierung (`/robot_1/planned_path`) mit den Pfaden von `NavfnPlanner` (Dijkstra bzw. A\*) und `SmacPlanner2D` (`/robot_1/plan`).  
   - Bewerten Sie folgende Kriterien:  
     - Pfadlänge und Glätte der Trajektorie.  
     - Rechenzeit (Python-Log vs. Log des `planner_server`).  
     - Abstand zu Hindernissen: binäre Inflation (Python) vs. Kostenverlauf der Inflation-Layer (Nav2).  
   - Lassen Sie den Roboter einen Nav2-Pfad abfahren und beobachten Sie, wie der Controller lokal vom globalen Pfad abweicht.  

---

## ❓ Fragen zur Selbstkontrolle & Protokollierung

1. Warum reicht ein reiner 8-Nachbar-Rasterpfad oft nicht direkt für die Ansteuerung eines echten Roboters aus, und welche Aufgaben übernimmt hierbei der Nav2 Controller (z. B. DWB / MPPI)?  
2. Erklären Sie den Unterschied in der Performanz und Pfadqualität zwischen der vereinfachten Python-Raster-Implementierung und den Layered Costmaps in Nav2.  
3. Beide Roboter nutzen denselben Frame-Namen `map`, aber getrennte `/robot_1/tf`- und `/robot_2/tf`-Topics. Warum funktioniert das, und was würde passieren, wenn beide Roboter ohne Namespace auf `/tf` publizieren würden?  
