# Schritt 2: Graphendiskretisierung & Interaktive Pfadplanung (Dijkstra & A\*)

In diesem zweiten Teil des Praktikums überführen Sie die bildbasierte Karte in einen diskreten Graphen $G = (V, E)$, implementieren Dijkstra und A\* und visualisieren schrittweise die Suchraum-Expansion.

Dieser Teil läuft **ohne Roboter** auf dem PC. Ihr Planer-Node wird trotzdem in den Namespace Ihres Roboters gelegt, damit seine Ausgaben in derselben RViz2-Instanz wie die Live-Karte erscheinen.

---

## 💻 Ihr Planer-Node

Schreiben Sie einen ROS-2-Node in Python (`rclpy`), der

1. eine mit `map_saver_cli` gespeicherte Karte (`*.yaml` + `*.pgm`) einliest,  
2. Hindernisse um einen einstellbaren Radius aufbläht (Costmap Inflation),  
3. jede freie Zelle als Knoten eines Gitter-Graphen mit 4- oder 8-Nachbarschaft auffasst,  
4. Dijkstra bzw. (gewichtetes) A\* ausführt und dabei die expandierten Knoten **live** in RViz2 anzeigt,  
5. den gefundenen Pfad veröffentlicht und im Terminal expandierte Knoten, Pfadlänge und Rechenzeit ausgibt.  

Die Theorie dazu (Koordinatentransformation, Inflation, Knoten und Kanten, Bewertungsfunktion $f(n) = g(n) + w \cdot h(n)$) steht in der [README](../README.md#-graphendiskretisierung-der-slam-karte).

### Schnittstelle

Halten Sie sich an die folgende Schnittstelle. Dann funktionieren die RViz2-Konfiguration [`config/planner.rviz`](../config/planner.rviz) und der Vergleich in Schritt 3 ohne Anpassung.

**Parameter** (ROS-2-Parameter, z. B. `-p algorithm:=dijkstra`):

| Parameter | Standard | Bedeutung |
| :--- | :--- | :--- |
| `map_yaml` | – | Pfad zur Karten-YAML (Pflicht) |
| `inflation_radius` | `0.18` | Hindernis-Aufblähung in Metern |
| `allow_unknown` | `false` | Unbekannte Zellen befahrbar? |
| `start_x`, `start_y`, `goal_x`, `goal_y` | `0, 0, 1, 1` | Start/Ziel in Weltkoordinaten [m] im `map`-Frame |
| `algorithm` | `a_star` | `dijkstra` oder `a_star` |
| `heuristic` | `euclidean` | `euclidean`, `octile`, `manhattan` |
| `weight` | `1.0` | $w$ in $f(n) = g(n) + w \cdot h(n)$ |
| `connectivity` | `8` | `4` (Manhattan-Nachbarn) oder `8` (mit Diagonalen) |
| `viz_batch` | `100` | Knoten pro Marker-Update |
| `viz_delay` | `0.02` | Pause je Update in Sekunden (größer = langsamere Animation) |

**Topics** (relativ benannt, damit `-r __ns:=/robot_1` greift):

| Topic | Typ | Inhalt |
| :--- | :--- | :--- |
| `inflated_map` | `nav_msgs/OccupancyGrid` | Karte nach Inflation (belegt / unbekannt / frei) |
| `search_expansion` | `visualization_msgs/MarkerArray` | Expandierte Knoten (Closed Set), Start, Ziel und Pfad |
| `planned_path` | `nav_msgs/Path` | Gefundener Pfad |

**Aufruf**, z. B. mit Ihrem Skript `planner.py`:

```bash
python3 planner.py --ros-args -r __ns:=/robot_1 \
    -p map_yaml:=$HOME/my_lab_map.yaml \
    -p start_x:=0.0 -p start_y:=0.0 \
    -p goal_x:=3.0  -p goal_y:=1.5 \
    -p algorithm:=a_star -p heuristic:=euclidean -p weight:=1.0
```

Start- und Zielkoordinaten lesen Sie in RViz2 mit dem Werkzeug *Publish Point* ab (publiziert auf `/robot_1/clicked_point`, abhörbar mit `ros2 topic echo /robot_1/clicked_point`).

### Worauf Sie achten müssen

- **Kartenformat:** Bildzeile 0 der PGM-Datei ist der **obere** Kartenrand, der Ursprung (`origin`) liegt unten links. Die Belegungswahrscheinlichkeit eines Pixels ist $p = (255 - \text{Pixelwert}) / 255$; belegt ist $p > $ `occupied_thresh`, frei ist $p < $ `free_thresh`, sonst unbekannt. `map_saver_cli` speichert unbekannte Zellen als Grauwert 205 – prüfen Sie, wie Ihr Programm diese Zellen einordnet (siehe Schritt 1, Abschnitt 5).  
- **Prioritätswarteschlange:** `heapq` liefert immer das Element mit dem kleinsten $f$. Ein Knoten kann mehrfach in der Warteschlange stehen, wenn ein kürzerer Weg zu ihm gefunden wird.  
- **Visualisierung:** Veröffentlichen Sie die expandierten Knoten in Schüben (`viz_batch`) als `Marker.CUBE_LIST`, sonst wird RViz2 zu langsam. Die Live-Animation sehen Sie nur, wenn RViz2 schon läuft, bevor Sie planen.  
- **Spät gestartetes RViz2:** Mit der QoS-Durability *Transient Local* erhält auch ein später gestartetes RViz2 den Endzustand. Nach dem Planen sollte der Node aktiv bleiben (Beenden mit `Strg+C`).  
- **Unerreichbare Ziele:** Liegen Start oder Ziel außerhalb der Karte, in einem Hindernis oder im aufgeblähten Bereich, soll der Node eine verständliche Meldung ausgeben statt abzustürzen.  

---

## 🛠️ RViz2 einrichten

Am einfachsten starten Sie RViz2 mit der vorbereiteten Konfiguration [`config/planner.rviz`](../config/planner.rviz). Sie enthält die Displays der drei Topics bereits für `/robot_1` (für `robot_2` die Topics im Display-Panel anpassen oder die Datei kopieren und `robot_1` ersetzen):

```bash
rviz2 -d config/planner.rviz
```

Läuft bereits eine RViz2-Instanz über `view_robot.launch.py namespace:=/robot_1` (Schritt 1 oder 3), fügen Sie dort die Displays `Map` (`/robot_1/inflated_map`), `MarkerArray` (`/robot_1/search_expansion`) und `Path` (`/robot_1/planned_path`) hinzu (Fixed Frame: `map`).

Läuft parallel `localization.launch.py` (Schritt 3), liegt die Planer-Ausgabe passgenau über der Nav2-Karte, da beide denselben `map`-Frame nutzen.

### Mehrere Läufe vergleichen

Für einen direkten Vergleich zweier Algorithmen machen Sie Screenshots oder starten zwei Planer mit unterschiedlichem Node-Namen und eigenen Topics, z. B.:

```bash
python3 planner.py --ros-args -r __ns:=/robot_1 -r __node:=planner_dijkstra \
    -r search_expansion:=search_expansion_dijkstra -r planned_path:=planned_path_dijkstra \
    -p map_yaml:=$HOME/my_lab_map.yaml -p algorithm:=dijkstra \
    -p start_x:=0.0 -p start_y:=0.0 -p goal_x:=3.0 -p goal_y:=1.5
```

---

## 📝 Aufgabenstellung & Versuchsdurchführung

1. **Aufgabe 2: Graphendiskretisierung & Inflation**  
   - Implementieren Sie das Einlesen der Karte (Spiegelung der y-Achse, Schwellwerte, unbekannte Zellen), die Hindernis-Inflation und die Umrechnung zwischen Welt- und Gitterkoordinaten.  
   - Testen Sie verschiedene Inflationsradien über `-p inflation_radius:=0.10`, `0.18`, `0.30` und beobachten Sie `/robot_1/inflated_map` sowie die Anzahl befahrbarer Knoten $|V|$.  
   - Dokumentieren Sie: Was passiert bei zu großem Inflationsradius in schmalen Türdurchgängen oder Engpässen?  

2. **Aufgabe 3: Vergleichende Visualisierung von Dijkstra vs. A\***  
   - Implementieren Sie Dijkstra und A\* mit Live-Visualisierung der Expansion.  
   - Führen Sie die Pfadplanung für dieselbe Start- und Zielposition einmal mit `-p algorithm:=dijkstra` ($h(n) = 0$) und einmal mit `-p algorithm:=a_star -p heuristic:=euclidean` aus.  
   - Vergleichen Sie die Anzahl der expandierten Knoten, die Rechenzeit sowie die Form der Marker-Ausbreitung in RViz2 (radiale Ausbreitung vs. zielgerichtete Keule).  
   - Erstellen Sie Screenshots der Suchfronten für Ihr Praktikumsprotokoll.  

3. **Aufgabe 4: Heuristik-Analyse & Weighted A\***  
   - Implementieren Sie die Heuristiken `euclidean`, `octile` und `manhattan` und untersuchen Sie ihren Einfluss bei `connectivity:=8` und `connectivity:=4`.  
   - Gewichtetes A\* (*Weighted A\**): $f(n) = g(n) + w \cdot h(n)$ mit `-p weight:=1.0`, `1.5`, `3.0`.  
   - Vergleichen Sie jeweils expandierte Knoten, Rechenzeit und Pfadlänge. Wie verändern sich Berechnungszeit und Pfadoptimalität bei $w > 1$?  
   - Ist die Manhattan-Distanz bei 8-Nachbarschaft noch zulässig? Prüfen Sie Ihre Antwort an der Pfadlänge.  

---

## ❓ Fragen zur Selbstkontrolle & Protokollierung

1. Warum ist A\* auf einem 2D-Belegungsgitter deterministisch und optimal, während RRT probabilistisch ist?  
2. Unter welchen mathematischen Bedingungen degradiert A\* exakt zu Dijkstra?  
3. Was bedeutet die Eigenschaft der *Admissibilität* (Zulässigkeit) einer Heuristik $h(n)$ für die Garantien der Pfadplanung? Welche der drei Heuristiken ist bei 8-Nachbarschaft zulässig, welche nicht?  
4. Sollte ein diagonaler Schritt erlaubt sein, wenn eine der beiden orthogonalen Nachbarzellen belegt ist (*Corner Cutting*)? Begründen Sie Ihre Entscheidung und setzen Sie sie in Ihrem Planer um.  
