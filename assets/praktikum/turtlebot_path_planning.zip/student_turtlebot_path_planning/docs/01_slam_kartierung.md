# Schritt 1: SLAM-Kartierung der Umgebung mit dem TurtleBot 4

In diesem ersten Teil des Praktikums erstellen Sie mit dem TurtleBot 4 und dem ROS 2 Package `slam_toolbox` eine 2D-Umgebungskarte des Versuchsraums.

> **Multi-Roboter-Setup:** Im Labor sind zwei TurtleBots über einen *Fast DDS Discovery Server* erreichbar. Alle Topics liegen in den Namespaces `/robot_1` bzw. `/robot_2`. **Jeder Befehl unten muss den Namespace Ihres Roboters enthalten.** Die Beispiele verwenden `/robot_1`; die zweite Gruppe ersetzt überall `robot_1` durch `robot_2`. Hintergrund und Checkliste: siehe [README, Abschnitt Multi-Roboter-Setup](../README.md#-multi-roboter-setup-mit-discovery-server-robot_1--robot_2).

---

## 🛠️ Schritt-für-Schritt Anleitung zur Kartierung

### 0. Verbindung prüfen

Öffnen Sie ein Terminal (die Discovery-Server-Umgebung wird über `~/.bashrc` automatisch geladen) und prüfen Sie, dass Ihr Roboter sichtbar ist:

```bash
ros2 topic list | grep robot_1
ros2 topic hz /robot_1/scan
```

Es müssen u. a. `/robot_1/scan`, `/robot_1/odom`, `/robot_1/tf` und `/robot_1/cmd_vel` erscheinen. Fehlen Topics, obwohl der Roboter läuft: `ros2 daemon stop` ausführen und erneut auflisten.

### 1. SLAM starten

Starten Sie `slam_toolbox` auf dem PC im Namespace Ihres Roboters:

```bash
ros2 launch turtlebot4_navigation slam.launch.py namespace:=/robot_1
```

Der Launch-File remappt `/scan`, `/tf` und `/map` automatisch in den Namespace. Die Karte erscheint auf `/robot_1/map`.

### 2. Visualisierung in RViz2

Starten Sie RViz2 ebenfalls mit Namespace (dadurch werden `/tf` und `/tf_static` korrekt remappt):

```bash
ros2 launch turtlebot4_viz view_robot.launch.py namespace:=/robot_1
```

Fügen Sie ein Display vom Typ `Map` mit dem Topic `/robot_1/map` hinzu (Durability *Transient Local*). Fixed Frame: `map`.

> Die TurtleBot-4-Frames (`map`, `odom`, `base_link`, …) tragen **kein** Namespace-Präfix. Deshalb braucht jeder Roboter seine eigene RViz2-Instanz mit passendem `namespace:=`.

### 3. Umgebung manuell abfahren (Teleoperation)

Steuern Sie den Roboter vorsichtig durch den Raum, bis alle wesentlichen Hindernisse und Wände erfasst sind. Das Teleop-Programm muss auf `/robot_1/cmd_vel` publizieren:

```bash
ros2 run teleop_twist_keyboard teleop_twist_keyboard --ros-args -r cmd_vel:=/robot_1/cmd_vel
```

Fahren Sie langsam (Linear ≤ 0,3 m/s) und schließen Sie Schleifen, damit `slam_toolbox` *Loop Closures* finden kann.

### 4. Karte speichern

Speichern Sie die Karte vom Topic `/robot_1/map`:

```bash
ros2 run nav2_map_server map_saver_cli -f ~/my_lab_map -t /robot_1/map
```

Dies erzeugt `~/my_lab_map.yaml` und `~/my_lab_map.pgm`.

### 5. Karte für Nav2 nachbearbeiten (wichtig)

`map_saver_cli` speichert unbekannte Zellen als Grauwert 205 und schreibt `free_thresh: 0.25`. Damit lädt der Nav2-Map-Server diese Zellen als **frei** (Belegung 0,196 < 0,25). Setzen Sie in `~/my_lab_map.yaml` deshalb:

```yaml
free_thresh: 0.196
```

Damit werden unbekannte Bereiche in Nav2 wieder als unbekannt (−1) behandelt. Ihr eigener Planer in Schritt 2 sollte den Grauwert 205 ebenfalls als unbekannt erkennen.

---

## 📝 Aufgabenstellung & Versuchsdurchführung

1. **Aufgabe 1: Kartenerstellung**  
   - Kartieren Sie das Versuchslabor vollständig mit `slam_toolbox`.  
   - Speichern Sie die Ergebnisdateien als `my_lab_map.yaml` und `my_lab_map.pgm` (bei zwei Gruppen z. B. `my_lab_map_robot_1` / `my_lab_map_robot_2`).  
   - Überprüfen Sie das erzeugte Bild (`.pgm`) und die Metadaten (`.yaml`) auf Vollständigkeit und Sinnhaftigkeit der Auflösung.  
   - Notieren Sie `resolution`, `origin` und die Bildgröße in Pixeln.  

---

## ❓ Fragen zur Selbstkontrolle & Protokollierung

1. Erklären Sie den mathematischen und praktischen Zusammenhang zwischen der Kartenauflösung (z. B. $r = 0{,}05\text{ m/Pixel}$) und der Anzahl der Pixel/Zellen im Belegungsgitter.  
2. Warum werden unbekannte Bereiche im Belegungsgitter mit dem Wert $-1$ gekennzeichnet und wie unterscheiden sich freie ($0$) von belegten ($100$) Zellen?  
3. Die PGM-Datei hat Bildzeile 0 am **oberen** Rand, der Ursprung (`origin`) des Belegungsgitters liegt aber **unten links**. Welche Konsequenz hat das beim Einlesen der Karte in ein eigenes Programm?  
