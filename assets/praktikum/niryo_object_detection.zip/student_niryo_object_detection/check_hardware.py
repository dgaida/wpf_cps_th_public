"""Provided script: check robot, Vision-Set camera, workspace markers and depth camera.

Run this first. It saves the images to the folder check_output/, which you should inspect.

    python check_hardware.py --robot-ip <IP>            # without robot motion
    python check_hardware.py --robot-ip <IP> --move     # moves to the observation pose first
"""

import argparse
import os

import cv2
import numpy as np

from src.depth_camera import OakDDepthCamera
from src.robot_helpers import WORKSPACE_NAME, capture_image, connect_robot, move_to_observation_pose
from src.workspace_markers import extract_workspace, find_workspace_markers


def check_robot(robot_ip: str, move: bool, output_dir: str) -> None:
    """Check the robot connection, the Vision-Set camera and the workspace markers.

    Args:
        robot_ip (str): IP address of the robot.
        move (bool): Move to the observation pose before capturing the image.
        output_dir (str): Folder for the saved images.
    """
    from pyniryo import NiryoRobot

    robot = connect_robot(robot_ip) if move else NiryoRobot(robot_ip)
    try:
        print(f"[Roboter] verbunden, Kalibrierung nötig: {robot.need_calibration()}, Werkzeug: {robot.get_current_tool_id()}")
        print(f"[Roboter] gespeicherte Workspaces: {robot.get_workspace_list()} (benötigt: '{WORKSPACE_NAME}')")
        if move:
            move_to_observation_pose(robot)
        image = capture_image(robot)
        cv2.imwrite(os.path.join(output_dir, "vision_set.png"), cv2.cvtColor(image, cv2.COLOR_RGB2BGR))
        workspace = extract_workspace(image)
        if workspace is None:
            print("[Vision-Set] Marker NICHT gefunden - Beobachtungspose (OBSERVATION_JOINTS) anpassen.")
        else:
            cv2.imwrite(os.path.join(output_dir, "workspace.png"), cv2.cvtColor(workspace, cv2.COLOR_RGB2BGR))
            print("[Vision-Set] alle vier Marker gefunden, Draufsicht gespeichert.")
    finally:
        robot.close_connection()


def check_depth_camera(output_dir: str) -> None:
    """Check the depth camera and whether it sees the workspace markers.

    Args:
        output_dir (str): Folder for the saved images.
    """
    camera = OakDDepthCamera()
    try:
        gray = camera.read_gray()
        depth = camera.read_depth()
    finally:
        camera.close()
    valid = depth[depth > 0]
    print(f"[Tiefenkamera] Bild {depth.shape}, gültige Pixel {100 * valid.size / depth.size:.0f} %, Median {np.median(valid):.0f} mm")
    corners = find_workspace_markers(gray)
    print("[Tiefenkamera] Marker gefunden." if corners is not None else "[Tiefenkamera] Marker NICHT gefunden.")

    low, high = np.percentile(valid, [3, 97])
    normalized = np.clip((depth.astype(np.float32) - low) / max(high - low, 1) * 255, 0, 255).astype(np.uint8)
    colored = cv2.applyColorMap(255 - normalized, cv2.COLORMAP_TURBO)
    colored[depth == 0] = 0
    cv2.imwrite(os.path.join(output_dir, "depth.png"), colored)
    cv2.imwrite(os.path.join(output_dir, "depth_gray.png"), gray)


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Check the hardware of the Niryo object detection task")
    parser.add_argument("--robot-ip", type=str, default=None, help="IP address of the Niryo Ned2. If omitted, only the depth camera is checked.")
    parser.add_argument("--move", action="store_true", help="Calibrate and move to the observation pose first.")
    parser.add_argument("--output-dir", type=str, default="check_output", help="Folder for the saved images.")
    args = parser.parse_args()

    os.makedirs(args.output_dir, exist_ok=True)
    if args.robot_ip:
        check_robot(args.robot_ip, args.move, args.output_dir)
    check_depth_camera(args.output_dir)
    print(f"Bilder gespeichert in: {args.output_dir}/")
