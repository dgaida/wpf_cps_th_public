"""Phase 2: Train and evaluate the object classifier.

    python train_classifier.py --data-dir data --model-type custom --output model.keras

TODO: Implement evaluate(). Training and the command line interface are provided.
"""

import argparse
import os
from typing import Dict

from src.cnn_classifier import ObjectClassifier


def evaluate(classifier: ObjectClassifier, test_dir: str) -> Dict[str, object]:
    """Evaluate the trained model on the test split.

    Args:
        classifier (ObjectClassifier): Classifier with a trained model.
        test_dir (str): Folder of the test split (one subfolder per class).

    Returns:
        Dict[str, object]: Dictionary with the keys "accuracy" (float), "confusion_matrix"
            (np.ndarray, rows = true class) and "inference_ms" (float, time per image).
    """
    # TODO: Compute accuracy, confusion matrix and inference time per image on the test split.
    raise NotImplementedError("TODO: implement evaluate")


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Train the Niryo object classifier")
    parser.add_argument("--data-dir", type=str, default="data", help="Dataset root with train/val/test folders.")
    parser.add_argument("--model-type", choices=["custom", "transfer"], default="custom", help="Model architecture.")
    parser.add_argument("--epochs", type=int, default=30, help="Maximum number of training epochs.")
    parser.add_argument("--batch-size", type=int, default=32, help="Batch size.")
    parser.add_argument("--output", type=str, default="model.keras", help="Path of the trained model file.")
    args = parser.parse_args()

    classifier = ObjectClassifier()
    if args.model_type == "transfer":
        classifier.build_transfer_learning_model()
    else:
        classifier.build_custom_cnn()
    classifier.train(args.data_dir, epochs=args.epochs, batch_size=args.batch_size)
    classifier.save_model(args.output)

    metrics = evaluate(classifier, os.path.join(args.data_dir, "test"))
    print(f"Klassen: {classifier.class_names}")
    print(f"Test-Accuracy: {metrics['accuracy']:.3f}")
    print(f"Confusion Matrix (Zeilen = wahre Klasse):\n{metrics['confusion_matrix']}")
    print(f"Inferenzzeit pro Bild: {metrics['inference_ms']:.1f} ms")
