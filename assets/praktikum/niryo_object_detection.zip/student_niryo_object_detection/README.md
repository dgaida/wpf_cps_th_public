# Praktikum: Objektdetektion & Turmbau mit Niryo Ned2 und Tiefenkamera

> **Fortgeschrittenes Praktikum (CPS)**

In diesem Praktikum kombinieren Sie Bildverarbeitung, ein mit TensorFlow trainiertes Convolutional Neural Network (CNN) und Robotersteuerung zu einer autonomen Sortier- und Stapelaufgabe.

---

## 🎯 Aufgabe

Auf der Arbeitsmatte des **Niryo Ned2** liegen Objekte aus vier Klassen. Der Roboter soll sie selbstständig erkennen und einsortieren:

| Klasse | Beispiele | Ziel |
|---|---|---|
| `wuerfel` | farbige Holzwürfel ($25 \times 25 \times 25\text{ mm}$) | zu einem **Turm** rechts neben dem Arbeitsbereich stapeln |
| `schokoriegel` | verpackte Schokoriegel | **links neben dem Arbeitsbereich** ablegen |
| `usb_stick` | USB-Sticks | links neben dem Arbeitsbereich ablegen |
| `zylinder` | flache Zylinder (Spielsteine) | links neben dem Arbeitsbereich ablegen |

Dafür stehen zwei Kameras zur Verfügung:

- **Niryo Vision-Set Kamera** (am Roboterarm über dem Greifer): liefert das Farbbild, in dem die Objekte über die **vier Vision-Marker** der Arbeitsmatte lokalisiert und anschließend klassifiziert werden.  
- **Tiefenkamera Luxonis OAK-D Pro** (über dem Arbeitsbereich montiert): misst die aktuelle **Höhe des Turms**, damit der nächste Würfel in der richtigen Höhe abgelegt wird.  

```text
   Vision-Set Kamera ──► Marker ──► Draufsicht ──► Objekte finden ──► CNN ──► Klasse
                                                        │
                                                        ▼
   Tiefenkamera ──► Turmhöhe ──► Ablagehöhe ──►  Greifen & Ablegen (pyniryo)
```

---

## 📂 Aufgabenstellung

Die Aufgabe ist in vier Phasen gegliedert. Lesen Sie zuerst die Einrichtung, dann die Phasen in dieser Reihenfolge:

0. [**Einrichtung & Inbetriebnahme**](./docs/00_einrichtung.md) – Installation, Hardware-Check, Sicherheit.  
1. [**Phase 1: Objekte lokalisieren & Datensatz erstellen**](./docs/01_datenerfassung_lokalisierung.md)  
2. [**Phase 2: CNN-Entwicklung & Transfer Learning**](./docs/02_cnn_tensorflow_modellierung.md)  
3. [**Phase 3: Höhenmessung mit der Tiefenkamera**](./docs/03_tiefenbild_tiefenkamera.md)  
4. [**Phase 4: Systemintegration & Turmbau**](./docs/04_systemintegration_turmbau.md)  

---

## 🧱 Bereitgestelltes Gerüst

Sie haben zwei Möglichkeiten, die Aufgabe umzusetzen:

- **Mit dem Gerüst:** Sie verwenden die vorgegebene Struktur. Treiber und Markererkennung sind fertig; Ihre Aufgabe sind die mit `TODO` markierten Stellen.  
- **Von Grund auf:** Sie setzen das Projekt mit einer eigenen Struktur selbst um. Das Gerüst ist ein Angebot, keine Vorgabe. Die bereitgestellten Module dürfen Sie auch dann ganz oder teilweise übernehmen oder als Nachschlagewerk nutzen.  

Die Aufgabenstellung in [`docs/`](./docs/) und die erwarteten Ergebnisse gelten für beide Wege.

| Datei | Inhalt | Status |
|---|---|---|
| [`check_hardware.py`](./check_hardware.py) | prüft Roboter, beide Kameras und die Marker | fertig |
| [`src/robot_helpers.py`](./src/robot_helpers.py) | Verbindung, Beobachtungspose, Kamerabild, Umrechnung relativer Koordinaten in Roboterposen | fertig |
| [`src/workspace_markers.py`](./src/workspace_markers.py) | Marker finden, Arbeitsbereich in Draufsicht entzerren | fertig |
| [`src/depth_camera.py`](./src/depth_camera.py) | Treiber der OAK-D Pro (Tiefenbild und Graustufenbild) | fertig |
| [`src/object_localizer.py`](./src/object_localizer.py) | Objekte in der Draufsicht segmentieren und ausschneiden | **TODO (Phase 1)** |
| [`collect_dataset.py`](./collect_dataset.py) | Trainingsbilder aufnehmen und aufteilen | **TODO (Phase 1)** |
| [`src/cnn_classifier.py`](./src/cnn_classifier.py) | Custom CNN, Transfer Learning, Training, Inferenz | **TODO (Phase 2)** |
| [`train_classifier.py`](./train_classifier.py) | Training starten, Modell auswerten | **TODO (Phase 2)** |
| [`src/height_measurement.py`](./src/height_measurement.py) | ROI, Bodenreferenz, Turmhöhe, Ablagehöhe | **TODO (Phase 3)** |
| [`main_mission.py`](./main_mission.py) | gesamter Missionsablauf | **TODO (Phase 4)** |
| [`tests/`](./tests/) | Selbsttests für Phase 1 bis 3 (ohne Hardware) | fertig |

Die Funktionssignaturen und Docstrings im Gerüst beschreiben, was jede Funktion liefern soll. Sie dürfen weitere Funktionen und Dateien ergänzen.

> **Bei eigener Struktur:** Führen Sie trotzdem zuerst [`check_hardware.py`](./check_hardware.py) aus und lesen Sie die bereitgestellten Module. Sie enthalten Einstellungen, die am Aufbau nötig sind – etwa die Konfiguration der Tiefenkamera und die Umrechnung von Positionen neben der Matte.

---

## 🧪 Selbsttests

Die Tests prüfen Ihre Implementierung mit synthetischen Bildern – ohne Roboter und Kamera. Zu Beginn schlagen alle Tests der TODO-Module fehl; mit jedem gelösten Teil werden mehr grün.

Die Tests sind auf die Funktionen des Gerüsts zugeschnitten. Bei eigener Struktur passen sie nicht direkt; schreiben Sie dann eigene Tests für Ihre Funktionen.

```bash
python -m pytest tests -v
```

Bestandene Tests sind eine notwendige, aber keine hinreichende Bedingung: Ob Ihre Lösung am echten Aufbau funktioniert, zeigt erst der Versuch am Roboter.

---

## ✅ Erwartete Ergebnisse

- Ein selbst aufgenommener Datensatz mit Trainings-, Validierungs- und Testbildern aller vier Klassen.  
- Ein trainiertes Custom CNN und ein Transfer-Learning-Modell mit Auswertung (Accuracy, Confusion Matrix, Inferenzzeit) und einem Vergleich beider Ansätze.  
- Eine Auswertung der Turmhöhenmessung: gemessene gegenüber tatsächlicher Höhe für ein bis vier Würfel.  
- Eine Vorführung der Mission am Roboter: Würfel werden gestapelt, alle anderen Objekte links abgelegt.  
