"""Phase 4: Sorting and tower building mission.

    python main_mission.py --robot-ip <IP> --model-path model.keras

TODO: Implement process_object() and run_mission(). The command line interface is provided.
"""

import argparse
from typing import Any, Dict, Tuple

from src.cnn_classifier import ObjectClassifier
from src.object_localizer import DetectedObject

# Positions relative to the workspace markers, see docs/04_systemintegration_turmbau.md
TOWER_REL_POSITION: Tuple[float, float] = (1.22, 0.15)  # right next to the workspace
DISCARD_REL_POSITION: Tuple[float, float] = (-0.45, 0.5)  # left next to the workspace


def process_object(
    robot: Any,
    obj: DetectedObject,
    classifier: ObjectClassifier,
    tower_height_m: float,
) -> Dict[str, Any]:
    """Classify one object and move it to the tower or to the discard zone.

    Args:
        robot (Any): Connected NiryoRobot instance.
        obj (DetectedObject): Object localised in the workspace.
        classifier (ObjectClassifier): Classifier with a trained model.
        tower_height_m (float): Current tower height in meters.

    Returns:
        Dict[str, Any]: Result with at least the keys "label", "confidence" and "action"
            ("stacked_on_tower", "sorted_to_left_zone" or "skipped_low_confidence").
    """
    # TODO:
    # 1. Classify obj.crop. Skip the object if the confidence is too low.
    # 2. Compute the pick pose with robot_helpers.pose_from_rel (position and yaw of the object).
    # 3. Cube: place pose = tower position at the height from height_measurement.place_height_offset.
    #    Other classes: place pose = discard zone left of the workspace.
    # 4. robot.pick(pick_pose), robot.place(place_pose). Handle exceptions (collision stop).
    raise NotImplementedError("TODO: implement process_object")


def run_mission(robot_ip: str, model_path: str, max_cycles: int = 12) -> int:
    """Execute the whole mission until the workspace is empty.

    Args:
        robot_ip (str): Robot IP address.
        model_path (str): Path of the trained model file.
        max_cycles (int): Maximum number of observation cycles. Defaults to 12.

    Returns:
        int: Number of successfully processed objects.
    """
    # TODO:
    # 1. Load the model, connect to robot and depth camera.
    # 2. Before stacking: place the depth ROI on the tower position and measure Z_Boden.
    # 3. Loop: observation pose -> image -> workspace -> objects -> process one object.
    #    Measure the tower height again before every cube.
    # 4. Stop when no object is left, after max_cycles or after a robot error.
    # 5. Always close robot and camera (try/finally).
    raise NotImplementedError("TODO: implement run_mission")


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Niryo Ned2 sorting and tower building mission")
    parser.add_argument("--robot-ip", type=str, required=True, help="IP address of the Niryo Ned2.")
    parser.add_argument("--model-path", type=str, required=True, help="Path of the trained model file.")
    parser.add_argument("--max-cycles", type=int, default=12, help="Maximum number of observation cycles.")
    args = parser.parse_args()
    run_mission(robot_ip=args.robot_ip, model_path=args.model_path, max_cycles=args.max_cycles)
