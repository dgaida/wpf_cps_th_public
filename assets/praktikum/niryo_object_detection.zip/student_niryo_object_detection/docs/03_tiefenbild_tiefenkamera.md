# Phase 3: Höhenmessung mit der Tiefenkamera

Die Tiefenkamera **OAK-D Pro** hängt über dem Arbeitsbereich und liefert ein Tiefenbild: Jeder Pixel enthält den Abstand $Z$ zwischen Kamera und Oberfläche in Millimetern. Der Wert $0$ bedeutet „keine gültige Messung".

Implementieren Sie die Funktionen in [`src/height_measurement.py`](../src/height_measurement.py).

```python
from src.depth_camera import OakDDepthCamera
from src.workspace_markers import find_workspace_markers

camera = OakDDepthCamera()
gray = camera.read_gray()     # Graustufenbild, deckungsgleich mit dem Tiefenbild
depth = camera.read_depth()   # uint16, Millimeter, 0 = ungültig
corners = find_workspace_markers(gray)
camera.close()
```

---

## 1. Region of Interest (ROI) am Turmplatz

Ausgewertet wird nur ein kleiner Bildausschnitt um den Turmplatz. Der Turmplatz ist in **relativen Workspace-Koordinaten** gegeben (siehe Phase 4). Weil die Tiefenkamera dieselben vier Marker sieht wie die Vision-Set Kamera, lässt sich diese Position mit `relative_to_pixel` in Pixel des Tiefenbilds umrechnen – auch wenn die Kamera verschoben wurde.

- **Größe:** Die ROI muss den Turm sicher enthalten, darf aber keine anderen Objekte erfassen.  
- **Perspektive:** Die Spitze eines hohen Turms erscheint im Bild gegenüber seinem Fuß verschoben. Wählen Sie die ROI entsprechend großzügig.  
- **Rauschfilterung:** Medianfilter ($5 \times 5$) gegen Sensorrauschen; ungültige Pixel ($0\text{ mm}$) werden ignoriert.  

---

## 2. Referenzebene und Turmhöhe

### Referenzwert Tischboden $Z_{\text{Boden}}$

**Einmalig vor dem Stapeln**, bei leerem Turmplatz:

$$
Z_{\text{Boden}} = \text{Median}\left(\{ Z(x,y) \mid (x,y) \in \text{ROI},\ Z(x,y) > 0 \}\right)
$$

### Turmspitze $Z_{\text{Turmspitze}}$

Mit Würfeln auf dem Turmplatz verringert sich der Abstand in der ROI:

$$
Z_{\text{Turmspitze}} = \min_{(x,y) \in \text{ROI}} Z(x,y)
$$

Ein einzelner Ausreißer verfälscht das Minimum. Robuster ist ein kleines Perzentil (z. B. das 2. Perzentil) der gültigen Werte.

### Turmhöhe

$$
\Delta Z_{\text{Turm}} = Z_{\text{Boden}} - Z_{\text{Turmspitze}}
$$

Unplausible Werte ($\Delta Z_{\text{Turm}} > 0{,}40\text{ m}$) führen zu einem Fehler; die Mission wird dann gestoppt.

---

## 3. Messgenauigkeit prüfen und korrigieren

Verlassen Sie sich nicht darauf, dass die Messung stimmt – prüfen Sie es. Die Würfel sind $25\text{ mm}$ hoch:

1. Messen Sie die Höhe für einen, zwei, drei und vier gestapelte Würfel.  
2. Tragen Sie gemessene über tatsächlicher Höhe auf. Liegen die Punkte auf einer Geraden durch den Ursprung? Welche Steigung hat sie?  
3. Liefert die Kamera systematisch zu große oder zu kleine Abstände, korrigieren Sie die Höhe mit einem Faktor (`depth_scale` in `measure_tower_height`).  
4. Wie stark streut die Messung bei wiederholter Aufnahme derselben Szene?  

### Typische Fehlerquellen

- **Mindestabstand:** Stereokameras messen erst ab einem Mindestabstand. Der bereitgestellte Treiber aktiviert dafür *Extended Disparity*.  
- **Einfarbige Flächen:** Auf der weißen Matte fehlt Textur. Der IR-Punktprojektor der OAK-D Pro projiziert deshalb ein Punktmuster.  
- **Überbelichtung:** Helle Oberflächen (z. B. gelbe Würfel) liefern überbelichtet keine Tiefenwerte. Der Treiber belichtet deshalb bewusst dunkler.  
- **Schräge Kamera:** Hängt die Kamera nicht genau senkrecht, ist $Z_{\text{Boden}}$ über die ROI nicht konstant.  

---

## 4. Ablagehöhe

Der nächste Würfel wird knapp über der Turmspitze losgelassen:

$$
h_{\text{Ablage}} = \Delta Z_{\text{Turm}} + \Delta z_{\text{Offset}}, \qquad \Delta z_{\text{Offset}} \approx 0{,}005\text{ m}
$$

$h_{\text{Ablage}}$ ist die Höhe über der Tischfläche und wird als `height_offset_m` an `pose_from_rel` übergeben. Ist der Offset zu klein, drückt der Greifer den Würfel auf den Turm (Kollisionsstopp); ist er zu groß, fällt der Würfel und der Turm wird ungenau.
