# Phase 1: Objekte lokalisieren & Datensatz erstellen

In dieser Phase entsteht der Bilddatensatz für die Klassifikation. Weil die Vision-Set Kamera immer den ganzen Arbeitsbereich mit mehreren Objekten zeigt, müssen die Objekte zuerst einzeln gefunden und ausgeschnitten werden.

---

## 1. Relative Koordinaten über die Vision-Marker

Die vier Marker spannen ein Koordinatensystem auf, das unabhängig von der Kameraposition ist:

- $(0, 0)$ ist der Marker mit dem abweichenden Muster, $x_{\text{rel}}$ läuft in der Draufsicht nach rechts, $y_{\text{rel}}$ nach unten.  
- Jede Position auf der Matte hat Koordinaten $(x_{\text{rel}}, y_{\text{rel}}) \in [0, 1]^2$.  
- Der Roboter rechnet relative Koordinaten in Greifposen um (`pose_from_rel` in [`src/robot_helpers.py`](../src/robot_helpers.py)).  

Die Funktion `extract_workspace` in [`src/workspace_markers.py`](../src/workspace_markers.py) entzerrt das Kamerabild in eine Draufsicht, in der ein Pixel $(u, v)$ direkt der relativen Position entspricht:

$$
x_{\text{rel}} = \frac{u}{B - 1}, \qquad y_{\text{rel}} = \frac{v}{H - 1}
$$

---

## 2. Aufgabe: Objekte segmentieren (`src/object_localizer.py`)

Implementieren Sie `segment_objects` und `detect_objects` – oder eine eigene Lösung mit gleichem Ergebnis, falls Sie nicht mit dem Gerüst arbeiten. Für jedes Objekt werden benötigt:

1. die relative Position $(x_{\text{rel}}, y_{\text{rel}})$ seines Mittelpunkts,  
2. der Greifwinkel (der Greifer soll über die schmale Seite schließen),  
3. ein quadratischer Bildausschnitt als Eingabe für das CNN.  

Beginnen Sie mit `workspace.png` aus dem Hardware-Check und entwickeln Sie die Segmentierung zunächst offline an gespeicherten Bildern.

### Worauf Sie achten müssen

- **Schatten:** Würfel werfen deutliche Schatten. Zählt der Schatten zum Objekt, verschiebt sich der Mittelpunkt, und benachbarte Objekte verschmelzen zu einem.  
- **Unbunte Objekte:** Ein metallischer USB-Stick hat kaum Farbsättigung und ist ähnlich dunkel wie ein Schatten.  
- **Bedruckte Verpackungen:** Ein Schokoriegel ist weder einfarbig noch gleichmäßig dunkel und zerfällt leicht in mehrere Teile.  
- **Sich berührende Objekte:** Liegen zwei Objekte aneinander, bilden sie einen zusammenhängenden Fleck.  
- **Rand und Marker:** Die gestreifte Umrandung und die Marker in den Ecken sind keine Objekte.  

Eine perfekte Segmentierung ist nicht das Ziel. Legen Sie die Objekte für die ersten Versuche mit Abstand zueinander, dokumentieren Sie, welche Fälle Ihre Lösung beherrscht und welche nicht, und verbessern Sie gezielt.

---

## 3. Aufgabe: Datensatz aufnehmen (`collect_dataset.py`)

Implementieren Sie `collect`. Pro Durchlauf liegen nur Objekte **einer** Klasse auf der Matte; alle gefundenen Ausschnitte erhalten dieses Label.

Das Kamerabild kommt von `capture_image`:

```python
from src.robot_helpers import capture_image, connect_robot, move_to_observation_pose
from src.workspace_markers import extract_workspace

robot = connect_robot("<IP>")
move_to_observation_pose(robot)
image = capture_image(robot)          # entzerrtes RGB-Bild
workspace = extract_workspace(image)  # Draufsicht oder None, wenn Marker fehlen
```

### Klassen und Ordnerstruktur

```text
data/
├── train/
│   ├── schokoriegel/
│   ├── usb_stick/
│   ├── wuerfel/
│   └── zylinder/
├── val/
│   └── ...
└── test/
    └── ...
```

### Variation

Ein Modell lernt nur, was es gesehen hat. Verändern Sie zwischen den Aufnahmen:

- **Position und Drehung** der Objekte auf der gesamten Matte,  
- **Nachbarschaft:** ähnliche Objekte nebeneinander (z. B. roter Würfel neben rotem Zylinder),  
- **Beleuchtung:** unterschiedliche Tageszeiten, Schattenwurf.  

Viele Aufnahmen derselben Anordnung bringen wenig: Die Ausschnitte sehen nahezu identisch aus.

### Aufteilung

Teilen Sie den Datensatz in Training ($70\%$), Validierung ($15\%$) und Test ($15\%$) auf.

> **Wichtig:** Landen Bilder derselben Anordnung in Training und Test, misst der Test nur, ob das Modell die Anordnung wiedererkennt. Für eine ehrliche Bewertung muss der Testdatensatz aus **eigenen Anordnungen** stammen. Überlegen Sie, wie Sie das in `collect` umsetzen.

---

## 4. Datenaugmentierung

Ergänzend zur echten Variation wird beim Training eine Online-Augmentierung eingesetzt (z. B. über `tf.keras.layers`):

- **Rotation:** Die Objekte werden von oben gesehen und können in jeder Drehlage liegen.  
- **Spiegeln:** horizontal und vertikal.  
- **Helligkeit:** Faktor $0{,}8$ bis $1{,}2$.  
- **Zoom & Verschiebung:** maximal $10\%$.  
