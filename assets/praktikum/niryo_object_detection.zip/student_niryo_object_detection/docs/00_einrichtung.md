# Einrichtung & Inbetriebnahme

Die Dateinamen in den Aufgabendokumenten beziehen sich auf das bereitgestellte Gerüst. Wenn Sie das Projekt mit eigener Struktur umsetzen, gelten die Aufgaben sinngemäß; die Einrichtung und der Hardware-Check auf dieser Seite sind in beiden Fällen der erste Schritt.

---

## 1. Installation

```bash
conda env create -f environment.yml
conda activate niryo_object_detection
```

Alternativ mit pip in einer bestehenden Python-3.11-Umgebung:

```bash
pip install -r requirements.txt
```

---

## 2. Aufbau

- **Niryo Ned2** mit Greifer und Vision-Set Kamera, per Netzwerk erreichbar (IP-Adresse beim Betreuer erfragen).  
- **Arbeitsmatte** mit vier Vision-Markern vor dem Roboter. Auf dem Roboter muss ein Workspace mit dem Namen `niryo` eingelernt sein, der zu dieser Matte passt (Niryo Studio → Vision → Workspaces). Verschieben Sie die Matte danach nicht mehr.  
- **Tiefenkamera OAK-D Pro** per USB-3-Kabel am Rechner, senkrecht über der Matte. Sie muss alle vier Marker **und** den Turmplatz rechts neben der Matte sehen.  

> **Netzwerk:** Ist der Rechner gleichzeitig per WLAN mit dem Internet und per Kabel mit dem Labornetz verbunden, muss das WLAN in der Reihenfolge der Netzwerkdienste vor dem Kabeladapter stehen. Sonst ist das Internet nicht erreichbar, sobald das Kabel steckt.

---

## 3. Hardware-Check

Führen Sie vor der ersten Programmierung das bereitgestellte Prüfskript aus:

```bash
# Nur lesen, der Roboter bewegt sich nicht
python check_hardware.py --robot-ip <IP>

# Kalibrieren und in die Beobachtungspose fahren
python check_hardware.py --robot-ip <IP> --move
```

Das Skript speichert vier Bilder im Ordner `check_output/`:

| Bild | Was Sie prüfen |
|---|---|
| `vision_set.png` | Sind alle vier Marker vollständig im Bild? |
| `workspace.png` | Entzerrte Draufsicht des Arbeitsbereichs – die Grundlage für Phase 1 |
| `depth.png` | Farbcodiertes Tiefenbild: Ist die Matte flächig gemessen (wenig Schwarz)? |
| `depth_gray.png` | Graustufenbild der Tiefenkamera: Sind alle vier Marker und der Turmplatz sichtbar? |

### Beobachtungspose

Meldet das Skript „Marker NICHT gefunden", sieht die Vision-Set Kamera aus der Beobachtungspose nicht alle vier Marker. Passen Sie dann `OBSERVATION_JOINTS` in [`src/robot_helpers.py`](../src/robot_helpers.py) an:

- Die Kamera blickt nicht genau dorthin, wo der Greifer hinzeigt, sondern ein Stück weiter vom Roboter weg.  
- Ändern Sie die Gelenkwinkel in kleinen Schritten und prüfen Sie nach jedem Schritt `vision_set.png`.  
- Die Standard-Beobachtungspose aus der Niryo-Dokumentation passt nicht zu jedem Aufbau.  

---

## 4. Sicherheit

- Solange ein Programm läuft, bleiben **Hände aus dem Arbeitsbereich**. `connect_robot` kalibriert den Roboter bei Bedarf; dabei bewegt sich der Arm sofort.  
- Eine Person steht am **Not-Aus**, wenn neue Bewegungen zum ersten Mal ausgeführt werden.  
- Arbeiten Sie mit reduzierter Geschwindigkeit (`max_velocity_percent`, Voreinstellung 40 %).  
- Nach einem Kollisionsstopp verweigert der Roboter weitere Bewegungen, bis `recover_from_collision` aufgerufen wurde. Klären Sie zuerst die Ursache.  
- Fahren Sie nach einem Programmabbruch den Arm nicht blind weiter: Prüfen Sie, wo er steht und ob er noch ein Objekt hält.  
