# Phase 2: CNN-Entwicklung & Transfer Learning mit TensorFlow

In dieser Phase entwickeln Sie die Klassifikation in **TensorFlow / Keras** und vergleichen zwei Ansätze: ein eigenes, schlankes CNN und ein vortrainiertes Transfer-Learning-Modell.

Implementieren Sie die mit `TODO` markierten Methoden in [`src/cnn_classifier.py`](../src/cnn_classifier.py) sowie `evaluate` in [`train_classifier.py`](../train_classifier.py).

---

## 1. Custom CNN

- **Eingabe:** $128 \times 128 \times 3$ (RGB, Pixelwerte $0 \dots 255$; die Normierung ist Teil des Modells).  
- **Convolutional Block 1:** $32$ Filter ($3 \times 3$, ReLU), Max-Pooling ($2 \times 2$).  
- **Convolutional Block 2:** $64$ Filter ($3 \times 3$, ReLU), Max-Pooling ($2 \times 2$).  
- **Convolutional Block 3:** $128$ Filter ($3 \times 3$, ReLU), Max-Pooling ($2 \times 2$).  
- **Klassifikationskopf:** Flatten, Dense mit $128$ Neuronen, Dropout $0{,}5$, Softmax-Ausgabe mit $4$ Neuronen.  

Die Reihenfolge der Ausgabeneuronen entspricht der alphabetischen Reihenfolge der Klassenordner: `schokoriegel`, `usb_stick`, `wuerfel`, `zylinder`.

---

## 2. Transfer Learning mit MobileNetV2

1. **Feature Extractor:** `tf.keras.applications.MobileNetV2` ohne Klassifikationsschichten (`include_top=False`), vortrainiert auf ImageNet.  
2. **Vorverarbeitung:** `tf.keras.applications.mobilenet_v2.preprocess_input`.  
3. **Freezing:** Gewichte des Backbones einfrieren (`base_model.trainable = False`).  
4. **Kopf:** Global Average Pooling, Dropout $0{,}3$, Dense-Ausgabe mit Softmax.  
5. **Fine-Tuning (optional):** oberste Schichten auftauen und mit sehr kleiner Lernrate (z. B. $\eta = 10^{-5}$) weitertrainieren.  

> **Farbkanäle:** OpenCV und `pyniryo` arbeiten mit BGR, Keras lädt Bilder als RGB. `capture_image` liefert bereits RGB. Achten Sie darauf, dass Training und Inferenz dieselbe Kanalreihenfolge sehen – besonders beim vortrainierten Modell.

---

## 3. Training

- **Loss:** `sparse_categorical_crossentropy` (ganzzahlige Labels).  
- **Optimizer:** Adam mit Lernrate $\eta = 0{,}001$.  
- **Early Stopping:** Abbruch, wenn sich der Validierungsverlust über $5$ Epochen nicht verbessert; beste Gewichte wiederherstellen.  
- **Augmentierung:** nur auf den Trainingsdaten (siehe Phase 1).  

---

## 4. Auswertung

Werten Sie beide Modelle auf dem Testdatensatz aus:

1. **Accuracy.**  
2. **Confusion Matrix:** Welche Klassen werden verwechselt? Typisch sind Verwechslungen zwischen gleichfarbigen Würfeln und Zylindern.  
3. **Inferenzzeit** pro Einzelbild in Millisekunden.  
4. **Konfidenzschwelle:** Eine Vorhersage wird nur verwendet, wenn $p_{\text{max}} \ge 0{,}8$; sonst gilt das Objekt als `unknown`. Wie viele Testbilder fallen unter die Schwelle?  

### Generalisierung prüfen

Legen Sie die Objekte neu auf die Matte, nehmen Sie eine frische Aufnahme auf und klassifizieren Sie alle Ausschnitte mit dem trainierten Modell – **bevor** diese Bilder in den Datensatz kommen. Das ist der aussagekräftigste Test:

- Wie viele Objekte werden richtig und oberhalb der Schwelle erkannt?  
- Wie verändert sich das Ergebnis, wenn Sie den Datensatz um weitere Anordnungen erweitern?  

Vergleichen Sie Custom CNN und Transfer Learning nach Genauigkeit, Trainingsdauer, Modellgröße und Inferenzzeit.
