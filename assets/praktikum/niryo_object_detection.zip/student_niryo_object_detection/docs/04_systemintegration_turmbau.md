# Phase 4: Systemintegration & Turmbau

In Phase 4 fügen Sie alle Teile in [`main_mission.py`](../main_mission.py) zu einer geschlossenen Prozesskette zusammen.

---

## 1. Ablauf

```text
[ Start ]
   │
   ▼
0. Turmplatz leer: ROI setzen und Z_Boden messen
   │
   ▼
1. Roboter fährt in die Beobachtungspose
   │
   ▼
2. Vision-Set Kamera: Bild aufnehmen, Arbeitsbereich entzerren, Objekte finden
   │
   ├── kein Objekt mehr? ──► [ Ende ]
   ▼
3. Ein Objekt auswählen und seinen Bildausschnitt klassifizieren
   ├── Konfidenz < 0,8 ──► [ Warnung ausgeben, Objekt überspringen ]
   └── Konfidenz >= 0,8
         │
         ├── Klasse != "wuerfel"
         │     ▼
         │   [ Greifen & links neben dem Arbeitsbereich ablegen ]
         │
         └── Klasse == "wuerfel"
               ▼
             [ Tiefenkamera: aktuelle Turmhöhe messen ]
               ▼
             [ Ablagehöhe berechnen ]
               ▼
             [ Greifen & auf dem Turm ablegen ]
   │
   ▼
[ zurück zu 1 ]
```

Nach jedem bewegten Objekt wird der Arbeitsbereich **neu aufgenommen**: Beim Greifen können sich Nachbarobjekte verschieben.

---

## 2. Positionen

Alle Positionen werden relativ zu den Vision-Markern angegeben (siehe Phase 1) und mit `pose_from_rel` in Roboterposen umgerechnet. Positionen neben der Matte haben Koordinaten außerhalb von $[0, 1]$.

| Ort | $x_{\text{rel}}$ | $y_{\text{rel}}$ | Höhe |
|---|---|---|---|
| Objekt greifen | aus der Lokalisierung | aus der Lokalisierung | $0$ (Tischhöhe) |
| Turm (rechts neben der Matte) | $1{,}22$ | $0{,}15$ | $h_{\text{Ablage}}$ aus Phase 3 |
| Ablage (links neben der Matte) | $-0{,}45$ | $0{,}5$ | ca. $0{,}03\text{ m}$ |

```python
from src.robot_helpers import pose_from_rel

pick_pose = pose_from_rel(robot, obj.x_rel, obj.y_rel, 0.0, obj.yaw_rad)
robot.pick(pick_pose)      # anfahren von oben, greifen, anheben
robot.place(place_pose)    # anfahren von oben, loslassen, anheben
```

Prüfen Sie am Aufbau, ob Turmplatz und Ablagefläche frei und erreichbar sind, und passen Sie die Werte bei Bedarf an.

### Hinweise aus der Praxis

- **Nicht mit Objekt in die Beobachtungspose fahren:** Dabei kann das Objekt aus dem Greifer rutschen. Nach `pick` folgt direkt `place`.  
- **Mehrere Ablageplätze:** Werden alle Objekte an derselben Stelle abgelegt, stapeln sie sich. Lassen Sie sie aus wenigen Zentimetern Höhe los oder verwenden Sie mehrere Plätze.  
- **Übersprungene Objekte:** Ein Objekt mit zu geringer Konfidenz bleibt liegen und wird im nächsten Durchlauf wieder gefunden. Merken Sie sich seine Position, sonst endet die Mission nie.  
- **Turm im Kamerabild:** Ein hoher Turm neben der Matte kann in das Bild des Arbeitsbereichs hineinragen und als Objekt erkannt werden.  

---

## 3. Fehlerbehandlung & Sicherheit

1. **Konfidenzprüfung:** Unterhalb von $0{,}8$ wird nicht gegriffen.  
2. **Plausibilität der Turmhöhe:** Bei unrealistischen Werten stoppt die Mission.  
3. **Kollisionsstopp:** Meldet der Roboter eine Kollision oder eine nicht ausführbare Bewegung, wird die Mission beendet (`recover_from_collision`), nicht einfach fortgesetzt.  
4. **Begrenzte Durchläufe:** Die Schleife endet spätestens nach `max_cycles` Durchläufen.  
5. **Aufräumen:** Roboterverbindung und Kamera werden in jedem Fall geschlossen (`try`/`finally`).  

---

## 4. Auswertung

Führen Sie die Mission mehrfach mit unterschiedlichen Anordnungen durch und dokumentieren Sie:

- Wie viele Objekte wurden richtig einsortiert, wie viele übersprungen oder falsch behandelt?  
- Wie hoch wird der Turm, bevor er instabil wird? Woran liegt es: an der Ablagehöhe, an der seitlichen Ablagegenauigkeit oder am Greifen?  
- Welche Anordnungen bereiten Ihrer Lokalisierung Probleme?  

---

## 5. Zusatzaufgaben

### Gestapelte Würfel im Arbeitsbereich

Liegen Würfel bereits gestapelt auf der Matte, muss der oberste zuerst gegriffen werden.

- Die Tiefenkamera liefert die Höhe jedes Objekts; daraus ergibt sich die Greifhöhe.  
- Die Vision-Set Kamera blickt schräg auf die Matte. Die Oberseite eines hohen Stapels erscheint deshalb gegenüber seiner wahren Position verschoben – bei drei Würfeln um mehr als einen Zentimeter. Die Greifposition muss korrigiert werden.  
- Tipp: Aus den vier Markerpixeln und der Kameramatrix lässt sich die Lage einer Kamera zum Arbeitsbereich berechnen (`cv2.solvePnP`). Die Marker bilden ein Quadrat.  

### Geregeltes Stapeln

Der Roboter legt die Würfel nicht exakt übereinander ab; der Versatz wächst mit der Turmhöhe. Messen Sie vor jedem Würfel die tatsächliche Lage der Turmspitze mit der Tiefenkamera und korrigieren Sie die Ablageposition.
