"""Phase 1: Collect training images of single objects with the Niryo Vision-Set camera.

    python collect_dataset.py --robot-ip <IP> --label wuerfel --views 10

TODO: Implement collect(). The command line interface is provided.
"""

import argparse

from src.cnn_classifier import CLASS_NAMES


def collect(robot_ip: str, label: str, views: int = 10, output_dir: str = "data") -> int:
    """Capture object crops of one class and store them in the dataset folders.

    Args:
        robot_ip (str): Robot IP address.
        label (str): Class label of all objects currently lying in the workspace.
        views (int): Number of captures; the objects are rearranged by hand in between. Defaults to 10.
        output_dir (str): Dataset root with the folders train/val/test. Defaults to "data".

    Returns:
        int: Number of stored object crops.
    """
    # TODO:
    # 1. Connect to the robot and move to the observation pose (src.robot_helpers).
    # 2. For every view: wait for the user (input()), capture an image, extract the workspace
    #    (src.workspace_markers) and detect the objects (src.object_localizer).
    # 3. Save the crops as PNG files to <output_dir>/<split>/<label>/ with the splits
    #    train (70 %), val (15 %) and test (15 %).
    #    Think about how to split: crops of the same arrangement look almost identical.
    # 4. Always close the robot connection (try/finally).
    raise NotImplementedError("TODO: implement collect")


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Collect object crops with the Niryo Vision-Set camera")
    parser.add_argument("--robot-ip", type=str, required=True, help="IP address of the Niryo Ned2.")
    parser.add_argument("--label", type=str, required=True, choices=CLASS_NAMES, help="Class of all objects in the workspace.")
    parser.add_argument("--views", type=int, default=10, help="Number of captures.")
    parser.add_argument("--output-dir", type=str, default="data", help="Root folder of the dataset.")
    args = parser.parse_args()
    collect(robot_ip=args.robot_ip, label=args.label, views=args.views, output_dir=args.output_dir)
