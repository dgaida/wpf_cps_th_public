"""Provided driver for the overhead Luxonis OAK-D Pro depth camera (depthai v2 API).

This module is complete. You do not have to change it, but you should read and understand it.
"""

from typing import Any

import numpy as np


class OakDDepthCamera:
    """Depth and grayscale stream of the OAK-D Pro.

    The depth image is aligned to the rectified right mono camera: a depth pixel and the
    grayscale pixel at the same coordinates show the same point of the scene.

    Attributes:
        camera_matrix (np.ndarray): 3x3 intrinsic matrix of the depth/grayscale image.
    """

    def __init__(
        self,
        ir_dot_projector_intensity: float = 0.8,
        warmup_frames: int = 15,
        exposure_compensation: int = -3,
    ) -> None:
        """Open the OAK-D device and start the stereo depth pipeline.

        Args:
            ir_dot_projector_intensity (float): Intensity (0..1) of the IR dot projector, which adds
                texture to uniform surfaces such as the white workspace mat. Defaults to 0.8.
            warmup_frames (int): Frames discarded after start until auto exposure settles. Defaults to 15.
            exposure_compensation (int): Auto exposure compensation of the mono cameras (-9..9).
                Darker images keep the dot pattern visible on bright surfaces. Defaults to -3.

        Raises:
            RuntimeError: If no OAK-D device is connected.
        """
        import depthai as dai

        if not dai.Device.getAllAvailableDevices():
            raise RuntimeError("No OAK-D depth camera found.")

        pipeline = dai.Pipeline()
        left = pipeline.create(dai.node.MonoCamera)
        right = pipeline.create(dai.node.MonoCamera)
        stereo = pipeline.create(dai.node.StereoDepth)
        for cam, socket in ((left, dai.CameraBoardSocket.CAM_B), (right, dai.CameraBoardSocket.CAM_C)):
            cam.setBoardSocket(socket)
            cam.setResolution(dai.MonoCameraProperties.SensorResolution.THE_800_P)
            cam.setFps(10)
            cam.initialControl.setAutoExposureCompensation(exposure_compensation)
        stereo.setDefaultProfilePreset(dai.node.StereoDepth.PresetMode.HIGH_ACCURACY)
        stereo.setLeftRightCheck(True)
        stereo.setSubpixel(True)
        # Without extended disparity, surfaces closer than about 0.62 m are invalid.
        stereo.setExtendedDisparity(True)
        stereo.initialConfig.setMedianFilter(dai.MedianFilter.MEDIAN_OFF)
        left.out.link(stereo.left)
        right.out.link(stereo.right)

        for name, output in (("depth", stereo.depth), ("gray", stereo.rectifiedRight)):
            xout = pipeline.create(dai.node.XLinkOut)
            xout.setStreamName(name)
            output.link(xout.input)

        self._device: Any = dai.Device(pipeline)
        width, height = right.getResolutionSize()
        self.camera_matrix: np.ndarray = np.array(
            self._device.readCalibration().getCameraIntrinsics(dai.CameraBoardSocket.CAM_C, width, height)
        )
        self._ir_intensity: float = ir_dot_projector_intensity
        self._device.setIrLaserDotProjectorIntensity(ir_dot_projector_intensity)
        self._depth_queue: Any = self._device.getOutputQueue("depth", maxSize=2, blocking=False)
        self._gray_queue: Any = self._device.getOutputQueue("gray", maxSize=2, blocking=False)
        for _ in range(warmup_frames):
            self._depth_queue.get()

    def read_depth(self, num_frames: int = 5) -> np.ndarray:
        """Read a depth image, fused from several frames by a per-pixel median.

        Args:
            num_frames (int): Number of fused frames. Defaults to 5.

        Returns:
            np.ndarray: 2D uint16 depth image in millimeters (0 = invalid measurement).
        """
        frames = np.stack([self._depth_queue.get().getFrame() for _ in range(num_frames)])
        return np.median(frames, axis=0).astype(np.uint16)

    def read_gray(self, settle_frames: int = 6) -> np.ndarray:
        """Read a grayscale image aligned with the depth image.

        The IR dot projector is switched off for the capture, because the dot pattern disturbs
        the marker detection.

        Args:
            settle_frames (int): Frames discarded after switching the projector. Defaults to 6.

        Returns:
            np.ndarray: 2D uint8 grayscale image.
        """
        self._device.setIrLaserDotProjectorIntensity(0.0)
        try:
            for _ in range(settle_frames):
                self._gray_queue.get()
            return self._gray_queue.get().getCvFrame()
        finally:
            self._device.setIrLaserDotProjectorIntensity(self._ir_intensity)
            for _ in range(settle_frames):
                self._depth_queue.get()

    def close(self) -> None:
        """Stop the pipeline and release the device."""
        self._device.close()
