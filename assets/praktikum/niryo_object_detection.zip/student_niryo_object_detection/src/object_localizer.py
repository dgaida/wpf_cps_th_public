"""Phase 1: Localisation of the objects in the top-down workspace image.

TODO: Implement the functions marked with TODO. The tests in tests/test_object_localizer.py
check your implementation with synthetic images.
"""

from dataclasses import dataclass
from typing import List

import numpy as np


@dataclass(eq=False)
class DetectedObject:
    """Single object found inside the marker-bounded workspace.

    Attributes:
        x_rel (float): Relative x position in the workspace image (0 = left edge, 1 = right edge).
        y_rel (float): Relative y position in the workspace image (0 = top edge, 1 = bottom edge).
        yaw_rad (float): Gripper yaw for grasping the object across its short side, in radians.
            pyniryo.vision.image_functions.get_contour_angle uses the convention the robot expects.
        crop (np.ndarray): Square RGB crop around the object used as CNN input.
    """

    x_rel: float
    y_rel: float
    yaw_rad: float
    crop: np.ndarray


def segment_objects(ws_image: np.ndarray) -> np.ndarray:
    """Compute a binary mask of all objects lying on the bright workspace mat.

    Args:
        ws_image (np.ndarray): Warped RGB workspace image (see workspace_markers.extract_workspace).

    Returns:
        np.ndarray: Binary uint8 mask of the same height and width (255 = object, 0 = background).
    """
    # TODO: Separate the objects from the mat.
    # Hints:
    # - Colourful objects stand out in the saturation channel of the HSV colour space.
    # - Shadows are grey and darker than the mat, they must not be part of the mask,
    #   otherwise neighbouring objects merge into one blob.
    # - The markers in the four corners and the striped border are not objects.
    # - Morphological opening/closing removes thin structures and fills holes.
    raise NotImplementedError("TODO: implement segment_objects")


def detect_objects(ws_image: np.ndarray, crop_size: int = 128) -> List[DetectedObject]:
    """Find all objects in a warped workspace image.

    Args:
        ws_image (np.ndarray): Warped RGB workspace image.
        crop_size (int): Side length of the square object crops in pixels. Defaults to 128.

    Returns:
        List[DetectedObject]: One entry per object with relative position, gripper yaw and crop.
    """
    # TODO: Find the contours in the mask of segment_objects and create one DetectedObject per
    # contour of plausible size.
    # Hints:
    # - cv2.findContours, cv2.contourArea, cv2.minAreaRect, cv2.boundingRect
    # - x_rel = centre_x / (image_width - 1), y_rel = centre_y / (image_height - 1)
    # - Cut the crop a bit larger than the bounding box and resize it to (crop_size, crop_size).
    raise NotImplementedError("TODO: implement detect_objects")
