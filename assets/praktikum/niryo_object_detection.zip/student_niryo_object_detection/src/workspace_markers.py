"""Provided helpers for the four vision markers of the Niryo workspace.

This module is complete. You do not have to change it, but you should read and understand it.
"""

import itertools
from typing import Any, List, Optional, Tuple

import cv2
import numpy as np


def find_workspace_markers(image: np.ndarray) -> Optional[np.ndarray]:
    """Detect the four Niryo workspace markers in an image.

    Works for the Vision-Set camera as well as for the grayscale image of the depth camera. If
    more markers are visible (e.g. those of the conveyor), the marker square closest to the image
    centre is used.

    Args:
        image (np.ndarray): Grayscale or RGB image showing the workspace.

    Returns:
        Optional[np.ndarray]: Marker centres as float32 array of shape (4, 2) in pixel coordinates.
            The order starts at the unique marker (relative position (0, 0)) and continues with
            (1, 0), (1, 1) and (0, 1) - independent of the viewpoint of the camera. None if the
            markers could not be found.
    """
    from pyniryo.vision import markers_detection as md

    gray = image if image.ndim == 2 else cv2.cvtColor(image, cv2.COLOR_RGB2GRAY)
    img_thresh = cv2.adaptiveThreshold(
        gray,
        maxValue=255,
        adaptiveMethod=cv2.ADAPTIVE_THRESH_MEAN_C,
        thresholdType=cv2.THRESH_BINARY,
        blockSize=15,
        C=25,
    )
    markers = md.find_markers_from_img_thresh(img_thresh)
    if not markers or not 4 <= len(markers) <= 12:
        return None
    if len(markers) > 4:
        markers = _select_workspace_quad(markers, gray.shape)
        if markers is None:
            return None
    markers = md.sort_markers_detection(list(markers))
    return np.array([m.get_center() for m in markers], dtype=np.float32)


def _select_workspace_quad(markers: List[Any], image_shape: Tuple[int, ...]) -> Optional[List[Any]]:
    """Pick the four markers forming a square closest to the image centre.

    Args:
        markers (List[Any]): Marker candidates providing get_center().
        image_shape (Tuple[int, ...]): Shape of the image (height, width, ...).

    Returns:
        Optional[List[Any]]: The four selected markers, or None if no square was found.
    """
    image_center = np.array([image_shape[1] / 2.0, image_shape[0] / 2.0])
    best: Optional[List[Any]] = None
    best_dist = np.inf
    for combo in itertools.combinations(markers, 4):
        pts = np.array([m.get_center() for m in combo], dtype=np.float64)
        centroid = pts.mean(axis=0)
        order = np.argsort(np.arctan2(pts[:, 1] - centroid[1], pts[:, 0] - centroid[0]))
        ring = pts[order]
        sides = np.linalg.norm(ring - np.roll(ring, -1, axis=0), axis=1)
        diagonals = np.array([np.linalg.norm(ring[0] - ring[2]), np.linalg.norm(ring[1] - ring[3])])
        if sides.max() > 1.3 * sides.min() or diagonals.max() > 1.2 * diagonals.min():
            continue
        dist = float(np.linalg.norm(centroid - image_center))
        if dist < best_dist:
            best, best_dist = list(combo), dist
    return best


def extract_workspace(image: np.ndarray, workspace_ratio: float = 1.0, height_px: int = 400) -> Optional[np.ndarray]:
    """Warp the marker-bounded workspace into a top-down image.

    In the result, a pixel (u, v) corresponds to the relative workspace position
    x_rel = u / (width - 1) and y_rel = v / (height - 1).

    Args:
        image (np.ndarray): RGB (or grayscale) camera image showing all four markers.
        workspace_ratio (float): Width over height ratio of the workspace. Defaults to 1.0.
        height_px (int): Height of the warped image in pixels. Defaults to 400.

    Returns:
        Optional[np.ndarray]: Warped workspace image, or None if the markers were not found.
    """
    corners = find_workspace_markers(image)
    if corners is None:
        return None
    w, h = int(round(height_px * workspace_ratio)), height_px
    target = np.array([[0, 0], [w - 1, 0], [w - 1, h - 1], [0, h - 1]], dtype=np.float32)
    return cv2.warpPerspective(image, cv2.getPerspectiveTransform(corners, target), (w, h))


def relative_to_pixel(corners: np.ndarray, x_rel: float, y_rel: float) -> Tuple[float, float]:
    """Convert a relative workspace position into pixel coordinates of the image the markers were found in.

    Useful to locate a workspace position (e.g. the tower) in the image of the depth camera.

    Args:
        corners (np.ndarray): Marker centres as returned by find_workspace_markers.
        x_rel (float): Relative x position (may lie outside 0..1).
        y_rel (float): Relative y position (may lie outside 0..1).

    Returns:
        Tuple[float, float]: Pixel coordinates (x, y).
    """
    unit = np.array([[0, 0], [1, 0], [1, 1], [0, 1]], dtype=np.float32)
    matrix = cv2.getPerspectiveTransform(unit, corners.astype(np.float32))
    px = cv2.perspectiveTransform(np.array([[[x_rel, y_rel]]], dtype=np.float32), matrix)[0, 0]
    return float(px[0]), float(px[1])
