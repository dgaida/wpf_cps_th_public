"""Phase 3: Tower height measurement with the overhead depth camera.

TODO: Implement the functions marked with TODO. The tests in tests/test_height_measurement.py
check your implementation with synthetic depth images.
"""

from typing import Tuple

import numpy as np

# Region of interest in the depth image: (ymin, xmin, ymax, xmax) in pixels
Roi = Tuple[int, int, int, int]


def roi_around_position(
    marker_corners: np.ndarray,
    x_rel: float,
    y_rel: float,
    half_size_rel: float,
    image_shape: Tuple[int, int],
) -> Roi:
    """Place a rectangular ROI around a relative workspace position in the depth image.

    Args:
        marker_corners (np.ndarray): Marker centres in the grayscale image of the depth camera, as
            returned by workspace_markers.find_workspace_markers.
        x_rel (float): Relative x position of the ROI centre (may lie outside 0..1).
        y_rel (float): Relative y position of the ROI centre (may lie outside 0..1).
        half_size_rel (float): Half side length of the ROI relative to the workspace size.
        image_shape (Tuple[int, int]): Shape (height, width) of the depth image.

    Returns:
        Roi: ROI (ymin, xmin, ymax, xmax) in pixels, clipped to the image.
    """
    # TODO: Convert the four corners of the square (x_rel +- half_size_rel, y_rel +- half_size_rel)
    # into pixels with workspace_markers.relative_to_pixel and return their bounding box.
    raise NotImplementedError("TODO: implement roi_around_position")


def measure_ground_distance(depth_image: np.ndarray, roi: Roi) -> float:
    """Measure the reference distance Z_Boden between camera and the empty table inside the ROI.

    Args:
        depth_image (np.ndarray): 2D uint16 depth image in millimeters (0 = invalid measurement).
        roi (Roi): ROI (ymin, xmin, ymax, xmax) in pixels.

    Returns:
        float: Distance Z_Boden in meters.
    """
    # TODO: Median filter (5 x 5), crop the ROI, ignore invalid pixels, take the median.
    raise NotImplementedError("TODO: implement measure_ground_distance")


def measure_tower_height(
    depth_image: np.ndarray,
    roi: Roi,
    z_ground_m: float,
    depth_scale: float = 1.0,
    max_height_m: float = 0.40,
) -> float:
    """Measure the current tower height Delta Z_Turm inside the ROI.

    Args:
        depth_image (np.ndarray): 2D uint16 depth image in millimeters (0 = invalid measurement).
        roi (Roi): ROI (ymin, xmin, ymax, xmax) in pixels.
        z_ground_m (float): Reference distance Z_Boden of the empty table in meters.
        depth_scale (float): Correction factor for the metric scale of the depth camera, see
            docs/03_tiefenbild_tiefenkamera.md. Defaults to 1.0.
        max_height_m (float): Largest plausible tower height in meters. Defaults to 0.40.

    Returns:
        float: Tower height in meters (0.0 if nothing stands in the ROI).

    Raises:
        ValueError: If the measured height is larger than max_height_m.
    """
    # TODO: Median filter, crop the ROI, ignore invalid pixels. The smallest distance belongs to the
    # tower top; a low percentile is more robust against single outliers than the minimum.
    raise NotImplementedError("TODO: implement measure_tower_height")


def place_height_offset(tower_height_m: float, safety_offset_m: float = 0.005) -> float:
    """Compute the height above the table at which the next cube is released.

    Args:
        tower_height_m (float): Current tower height in meters.
        safety_offset_m (float): Clearance above the tower in meters. Defaults to 0.005.

    Returns:
        float: Height offset for robot_helpers.pose_from_rel in meters.
    """
    # TODO
    raise NotImplementedError("TODO: implement place_height_offset")
