"""Phase 2: TensorFlow CNN classifier (custom CNN and MobileNetV2 transfer learning).

TODO: Implement the methods marked with TODO. The tests in tests/test_cnn_classifier.py check the
model structure and the confidence threshold.
"""

from typing import List, Optional, Tuple

import numpy as np
import tensorflow as tf

# Alphabetical order - identical to the order tf.keras.utils.image_dataset_from_directory uses
CLASS_NAMES: List[str] = ["schokoriegel", "usb_stick", "wuerfel", "zylinder"]


class ObjectClassifier:
    """TensorFlow/Keras classifier for the four object classes."""

    def __init__(
        self,
        class_names: Optional[List[str]] = None,
        img_size: Tuple[int, int] = (128, 128),
        confidence_threshold: float = 0.8,
    ) -> None:
        """Initialize the object classifier.

        Args:
            class_names (Optional[List[str]]): Class labels sorted alphabetically. Defaults to CLASS_NAMES.
            img_size (Tuple[int, int]): Input image resolution (height, width). Defaults to (128, 128).
            confidence_threshold (float): Minimum confidence for a valid prediction. Defaults to 0.8.
        """
        self.class_names: List[str] = class_names if class_names is not None else CLASS_NAMES
        self.img_size: Tuple[int, int] = img_size
        self.confidence_threshold: float = confidence_threshold
        self.model: Optional[tf.keras.Model] = None

    def build_custom_cnn(self) -> tf.keras.Model:
        """Construct and compile a custom Convolutional Neural Network from scratch.

        Returns:
            tf.keras.Model: Compiled Keras model with input shape (height, width, 3), pixel values
                0..255, and one softmax output per class.
        """
        # TODO: Build the network described in docs/02_cnn_tensorflow_modellierung.md,
        # compile it, store it in self.model and return it.
        raise NotImplementedError("TODO: implement build_custom_cnn")

    def build_transfer_learning_model(self, trainable_base: bool = False) -> tf.keras.Model:
        """Construct and compile a transfer learning model with a MobileNetV2 backbone.

        Args:
            trainable_base (bool): Whether the MobileNetV2 layers are trained too (fine-tuning).
                Defaults to False.

        Returns:
            tf.keras.Model: Compiled Keras model with the same input and output as the custom CNN.
        """
        # TODO: Use tf.keras.applications.MobileNetV2 (include_top=False, weights="imagenet") and do
        # not forget tf.keras.applications.mobilenet_v2.preprocess_input.
        raise NotImplementedError("TODO: implement build_transfer_learning_model")

    def train(self, data_dir: str, epochs: int = 30, batch_size: int = 32) -> tf.keras.callbacks.History:
        """Train the model on the folders data_dir/train and data_dir/val.

        Args:
            data_dir (str): Dataset root with the subfolders train and val (one folder per class each).
            epochs (int): Maximum number of training epochs. Defaults to 30.
            batch_size (int): Batch size. Defaults to 32.

        Returns:
            tf.keras.callbacks.History: Keras training history.
        """
        # TODO: Load both splits with tf.keras.utils.image_dataset_from_directory
        # (class_names=self.class_names, image_size=self.img_size), add data augmentation for the
        # training split and train with early stopping.
        raise NotImplementedError("TODO: implement train")

    def predict(self, image: np.ndarray) -> Tuple[str, float, np.ndarray]:
        """Classify a single RGB image.

        Args:
            image (np.ndarray): RGB image of shape (H, W, 3) with pixel values 0..255.

        Returns:
            Tuple[str, float, np.ndarray]: Predicted class label, its confidence and the
                probabilities of all classes.
        """
        # TODO: Resize the image to self.img_size, add the batch dimension and evaluate self.model.
        raise NotImplementedError("TODO: implement predict")

    def predict_with_threshold(self, image: np.ndarray) -> Tuple[str, float]:
        """Classify an image and reject uncertain predictions.

        Args:
            image (np.ndarray): RGB image of shape (H, W, 3) with pixel values 0..255.

        Returns:
            Tuple[str, float]: Class label and confidence. The label is "unknown" if the confidence
                is below self.confidence_threshold.
        """
        # TODO: Use self.predict and apply the confidence threshold.
        raise NotImplementedError("TODO: implement predict_with_threshold")

    def save_model(self, filepath: str) -> None:
        """Save the trained model.

        Args:
            filepath (str): Target path, e.g. "model.keras".
        """
        self.model.save(filepath)

    def load_model(self, filepath: str) -> None:
        """Load a trained model.

        Args:
            filepath (str): Path of the model file.
        """
        self.model = tf.keras.models.load_model(filepath)
