"""Source package of the student task: Niryo Ned2 object detection, classification and tower building."""
