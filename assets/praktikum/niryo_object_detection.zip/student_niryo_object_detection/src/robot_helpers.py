"""Provided helpers for the Niryo Ned2: connection, Vision-Set camera and workspace coordinates.

This module is complete. You do not have to change it, but you should read and understand it.
"""

import time
from typing import Any, List, Optional

import cv2
import numpy as np

# Joint configuration [rad] from which the Vision-Set camera should see all four workspace markers.
# Depends on where the workspace mat lies - verify it with check_hardware.py and adapt it if needed.
OBSERVATION_JOINTS: List[float] = [0.0, 0.55, -0.33, 0.0, -1.90, 0.0]
# Name of the workspace stored on the robot (Niryo Studio -> Vision -> Workspaces)
WORKSPACE_NAME: str = "niryo"


def connect_robot(robot_ip: str, max_velocity_percent: int = 40, attempts: int = 5) -> Any:
    """Connect to the Niryo Ned2, calibrate it if necessary and prepare the gripper.

    Args:
        robot_ip (str): IP address of the robot.
        max_velocity_percent (int): Arm velocity limit in percent. Defaults to 40.
        attempts (int): Number of connection attempts. Defaults to 5.

    Returns:
        Any: Connected pyniryo NiryoRobot instance.

    Raises:
        ConnectionError: If the robot cannot be reached.
    """
    from pyniryo import NiryoRobot

    last_error: Optional[Exception] = None
    for _ in range(attempts):
        try:
            robot = NiryoRobot(robot_ip)
            break
        except Exception as e:
            # The robot's TCP server needs a moment after a previous client disconnected.
            last_error = e
            time.sleep(3.0)
    else:
        raise ConnectionError(f"Could not connect to Niryo Ned2 at {robot_ip}: {last_error}")

    robot.calibrate_auto()
    robot.update_tool()
    robot.set_arm_max_velocity(max_velocity_percent)
    return robot


def move_to_observation_pose(robot: Any, joints: Optional[List[float]] = None, settle_time_s: float = 1.0) -> None:
    """Move the arm to the observation pose and wait until the camera image is steady.

    Args:
        robot (Any): Connected NiryoRobot instance.
        joints (Optional[List[float]]): Joint configuration in rad. Defaults to OBSERVATION_JOINTS.
        settle_time_s (float): Waiting time after the motion in seconds. Defaults to 1.0.
    """
    from pyniryo import JointsPosition

    robot.move(JointsPosition(*(joints if joints is not None else OBSERVATION_JOINTS)))
    time.sleep(settle_time_s)


def capture_image(robot: Any) -> np.ndarray:
    """Capture an undistorted RGB image from the Vision-Set camera.

    Args:
        robot (Any): Connected NiryoRobot instance.

    Returns:
        np.ndarray: RGB image of shape (H, W, 3) and dtype uint8.
    """
    from pyniryo import uncompress_image, undistort_image

    mtx, dist = robot.get_camera_intrinsics()
    image_bgr = undistort_image(uncompress_image(robot.get_img_compressed()), mtx, dist)
    # pyniryo delivers OpenCV images in BGR channel order
    return cv2.cvtColor(image_bgr, cv2.COLOR_BGR2RGB)


def pose_from_rel(
    robot: Any,
    x_rel: float,
    y_rel: float,
    height_offset_m: float = 0.0,
    yaw_rel: float = 0.0,
    workspace_name: str = WORKSPACE_NAME,
) -> Any:
    """Convert a position relative to the workspace markers into a robot pose.

    (0, 0) is the unique marker, x_rel runs to the right and y_rel downwards in the workspace image.
    The robot itself only converts positions inside the marker rectangle (0..1). Positions next to
    the workspace (e.g. x_rel = 1.2) are extrapolated linearly from the workspace corners here.

    Args:
        robot (Any): Connected NiryoRobot instance.
        x_rel (float): Relative x position.
        y_rel (float): Relative y position.
        height_offset_m (float): Height above the workspace surface in meters. Defaults to 0.0.
        yaw_rel (float): Rotation of the gripper around the vertical axis in rad. Defaults to 0.0.
        workspace_name (str): Name of the workspace stored on the robot. Defaults to WORKSPACE_NAME.

    Returns:
        Any: pyniryo PoseObject that can be passed to robot.pick(), robot.place() or robot.move().
    """
    x_in, y_in = float(np.clip(x_rel, 0.0, 1.0)), float(np.clip(y_rel, 0.0, 1.0))
    pose = robot.get_target_pose_from_rel(workspace_name, height_offset_m, x_in, y_in, yaw_rel)
    if (x_in, y_in) != (x_rel, y_rel):
        origin, x_corner, y_corner = (
            np.array(robot.get_target_pose_from_rel(workspace_name, 0.0, cx, cy, 0.0).to_list()[:3])
            for cx, cy in [(0.0, 0.0), (1.0, 0.0), (0.0, 1.0)]
        )
        offset = (x_rel - x_in) * (x_corner - origin) + (y_rel - y_in) * (y_corner - origin)
        pose.x, pose.y, pose.z = pose.x + offset[0], pose.y + offset[1], pose.z + offset[2]
    return pose


def workspace_side_length_m(robot: Any, workspace_name: str = WORKSPACE_NAME) -> float:
    """Get the distance between two neighbouring workspace markers in meters.

    Args:
        robot (Any): Connected NiryoRobot instance.
        workspace_name (str): Name of the workspace stored on the robot. Defaults to WORKSPACE_NAME.

    Returns:
        float: Mean side length of the marker square in meters.
    """
    origin, x_corner, y_corner = (
        np.array(robot.get_target_pose_from_rel(workspace_name, 0.0, cx, cy, 0.0).to_list()[:3])
        for cx, cy in [(0.0, 0.0), (1.0, 0.0), (0.0, 1.0)]
    )
    return 0.5 * float(np.linalg.norm(x_corner - origin) + np.linalg.norm(y_corner - origin))


def recover_from_collision(robot: Any) -> None:
    """Reset the collision flag and open the gripper so that the arm can be moved again.

    Args:
        robot (Any): Connected NiryoRobot instance.
    """
    robot.clear_collision_detected()
    robot.release_with_tool()


def workspace_ratio(robot: Any, workspace_name: str = WORKSPACE_NAME) -> float:
    """Get the width over height ratio of the workspace stored on the robot.

    Args:
        robot (Any): Connected NiryoRobot instance.
        workspace_name (str): Name of the workspace stored on the robot. Defaults to WORKSPACE_NAME.

    Returns:
        float: Width over height ratio.
    """
    return float(robot.get_workspace_ratio(workspace_name))
