"""Self-check tests for Phase 2 (src/cnn_classifier.py)."""

import numpy as np

from src.cnn_classifier import CLASS_NAMES, ObjectClassifier


def test_build_custom_cnn() -> None:
    """The custom CNN has the expected input and output shape."""
    classifier = ObjectClassifier()
    model = classifier.build_custom_cnn()
    assert classifier.model is model
    assert model.input_shape == (None, 128, 128, 3)
    assert model.output_shape == (None, len(CLASS_NAMES))


def test_predict_returns_probabilities() -> None:
    """predict returns a label, its confidence and probabilities summing to one."""
    classifier = ObjectClassifier()
    classifier.build_custom_cnn()
    label, confidence, probabilities = classifier.predict(np.zeros((200, 150, 3), dtype=np.uint8))
    assert label in CLASS_NAMES
    assert probabilities.shape == (len(CLASS_NAMES),)
    assert np.isclose(probabilities.sum(), 1.0, atol=1e-4)
    assert np.isclose(confidence, probabilities.max())


def test_predict_with_threshold_rejects_uncertain_predictions() -> None:
    """Predictions below the confidence threshold are reported as unknown."""
    classifier = ObjectClassifier(confidence_threshold=0.8)
    classifier.predict = lambda image: ("wuerfel", 0.6, np.array([0.1, 0.1, 0.6, 0.2]))
    assert classifier.predict_with_threshold(np.zeros((128, 128, 3), dtype=np.uint8)) == ("unknown", 0.6)

    classifier.predict = lambda image: ("wuerfel", 0.9, np.array([0.0, 0.05, 0.9, 0.05]))
    assert classifier.predict_with_threshold(np.zeros((128, 128, 3), dtype=np.uint8)) == ("wuerfel", 0.9)
