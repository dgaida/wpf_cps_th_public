"""Tests of the provided marker helpers - they pass without any changes and show how to use them."""

import numpy as np

from src.workspace_markers import extract_workspace, find_workspace_markers, relative_to_pixel
from tests.conftest import MARKER_CENTERS


def test_find_workspace_markers(camera_scene: np.ndarray) -> None:
    """The markers are returned starting at the unique marker."""
    corners = find_workspace_markers(camera_scene)
    assert corners is not None
    assert np.allclose(corners, np.array(MARKER_CENTERS), atol=2)


def test_extract_workspace(camera_scene: np.ndarray) -> None:
    """The workspace is warped into a square top-down image."""
    workspace = extract_workspace(camera_scene, height_px=400)
    assert workspace is not None
    assert workspace.shape == (400, 400, 3)


def test_relative_to_pixel(camera_scene: np.ndarray) -> None:
    """Relative positions can be converted into pixels, also outside the marker square."""
    corners = find_workspace_markers(camera_scene)
    assert np.allclose(relative_to_pixel(corners, 0.5, 0.5), (270, 250), atol=2)
    assert np.allclose(relative_to_pixel(corners, 1.2, 0.0), (480, 100), atol=2)
