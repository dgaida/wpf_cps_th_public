"""Shared fixtures for the self-check tests. Run them from the task folder: python -m pytest tests -v"""

import os
import sys
from typing import List, Tuple

import cv2
import numpy as np
import pytest

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

MARKER_CENTERS: List[Tuple[int, int]] = [(120, 100), (420, 100), (420, 400), (120, 400)]


def draw_marker(image: np.ndarray, center: Tuple[int, int], unique: bool = False) -> None:
    """Draw a Niryo-style concentric ring marker.

    Args:
        image (np.ndarray): Image to draw on.
        center (Tuple[int, int]): Marker centre (x, y) in pixels.
        unique (bool): Draw the marker with a dark centre, which identifies the workspace origin.
    """
    for radius, color in [(20, 0), (16, 255), (12, 0), (8, 255)]:
        cv2.circle(image, center, radius, (color, color, color), -1)
    if unique:
        cv2.circle(image, center, 4, (0, 0, 0), -1)


@pytest.fixture
def camera_scene() -> np.ndarray:
    """Synthetic RGB camera image with the four markers.

    Returns:
        np.ndarray: RGB image of shape (500, 540, 3).
    """
    image = np.full((500, 540, 3), 235, dtype=np.uint8)
    for i, center in enumerate(MARKER_CENTERS):
        draw_marker(image, center, unique=(i == 0))
    return image


@pytest.fixture
def workspace_image() -> np.ndarray:
    """Synthetic top-down workspace image with a red cube, its grey shadow and a blue bar.

    Returns:
        np.ndarray: RGB image of shape (400, 400, 3).
    """
    image = np.full((400, 400, 3), 225, dtype=np.uint8)
    cv2.rectangle(image, (80, 100), (140, 160), (200, 30, 30), -1)  # red cube, centre (110, 130)
    cv2.rectangle(image, (141, 105), (160, 160), (120, 120, 120), -1)  # its shadow
    cv2.rectangle(image, (220, 260), (320, 300), (30, 30, 200), -1)  # blue bar, centre (270, 280)
    return image
