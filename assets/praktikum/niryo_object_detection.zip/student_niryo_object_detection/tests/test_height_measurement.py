"""Self-check tests for Phase 3 (src/height_measurement.py)."""

import cv2
import numpy as np
import pytest

from src.height_measurement import (
    measure_ground_distance,
    measure_tower_height,
    place_height_offset,
    roi_around_position,
)
from src.workspace_markers import find_workspace_markers


def test_roi_around_position(camera_scene: np.ndarray) -> None:
    """The ROI is centred on the relative position and scales with the workspace size."""
    gray = cv2.cvtColor(camera_scene, cv2.COLOR_RGB2GRAY)
    corners = find_workspace_markers(gray)
    ymin, xmin, ymax, xmax = roi_around_position(corners, 0.5, 0.5, 0.1, gray.shape)
    # Marker square: x 120..420, y 100..400
    assert np.isclose((xmin + xmax) / 2, 270, atol=2)
    assert np.isclose((ymin + ymax) / 2, 250, atol=2)
    assert np.isclose(xmax - xmin, 60, atol=3)


def test_roi_is_clipped_to_image(camera_scene: np.ndarray) -> None:
    """A ROI next to the workspace never leaves the image."""
    gray = cv2.cvtColor(camera_scene, cv2.COLOR_RGB2GRAY)
    corners = find_workspace_markers(gray)
    ymin, xmin, ymax, xmax = roi_around_position(corners, 1.4, 0.5, 0.2, gray.shape)
    assert 0 <= xmin < xmax <= gray.shape[1]
    assert 0 <= ymin < ymax <= gray.shape[0]


def test_measure_ground_distance_ignores_invalid_pixels() -> None:
    """Invalid pixels (0) do not influence Z_Boden."""
    depth = np.full((480, 640), 600, dtype=np.uint16)
    depth[150:170, 150:170] = 0
    assert np.isclose(measure_ground_distance(depth, (100, 100, 200, 200)), 0.600)


def test_measure_tower_height() -> None:
    """A tower of 75 mm is measured, single outliers are ignored."""
    depth = np.full((480, 640), 600, dtype=np.uint16)
    depth[130:160, 130:160] = 525  # tower top
    depth[110, 110] = 300  # outlier
    assert np.isclose(measure_tower_height(depth, (100, 100, 200, 200), z_ground_m=0.600), 0.075, atol=0.002)


def test_measure_tower_height_empty() -> None:
    """Without tower the height is zero."""
    depth = np.full((480, 640), 600, dtype=np.uint16)
    assert np.isclose(measure_tower_height(depth, (100, 100, 200, 200), z_ground_m=0.600), 0.0, atol=0.001)


def test_measure_tower_height_applies_depth_scale() -> None:
    """The depth scale corrects a camera that measures distances too large."""
    depth = np.full((480, 640), 660, dtype=np.uint16)
    depth[130:160, 130:160] = 605  # 55 mm in camera units, 50 mm in reality
    height = measure_tower_height(depth, (100, 100, 200, 200), z_ground_m=0.660, depth_scale=1 / 1.1)
    assert np.isclose(height, 0.050, atol=0.002)


def test_measure_tower_height_plausibility() -> None:
    """Implausible heights raise an error."""
    depth = np.full((480, 640), 900, dtype=np.uint16)
    depth[130:160, 130:160] = 300
    with pytest.raises(ValueError):
        measure_tower_height(depth, (100, 100, 200, 200), z_ground_m=0.900)


def test_place_height_offset() -> None:
    """The next cube is released slightly above the tower."""
    assert np.isclose(place_height_offset(0.050, safety_offset_m=0.005), 0.055)
