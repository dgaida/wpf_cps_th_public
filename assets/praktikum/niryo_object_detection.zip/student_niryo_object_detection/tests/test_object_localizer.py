"""Self-check tests for Phase 1 (src/object_localizer.py)."""

import numpy as np

from src.object_localizer import detect_objects, segment_objects


def test_segment_objects_mask(workspace_image: np.ndarray) -> None:
    """Objects are part of the mask, the mat and the shadow are not."""
    mask = segment_objects(workspace_image)
    assert mask.shape == workspace_image.shape[:2]
    assert mask[130, 110] == 255  # red cube
    assert mask[280, 270] == 255  # blue bar
    assert mask[50, 300] == 0  # empty mat
    assert mask[130, 152] == 0  # shadow of the cube


def test_detect_objects_positions(workspace_image: np.ndarray) -> None:
    """Both objects are found at their relative positions."""
    objects = detect_objects(workspace_image)
    assert len(objects) == 2

    cube = min(objects, key=lambda o: o.x_rel)
    bar = max(objects, key=lambda o: o.x_rel)
    assert np.isclose(cube.x_rel, 110 / 399, atol=0.02)
    assert np.isclose(cube.y_rel, 130 / 399, atol=0.02)
    assert np.isclose(bar.x_rel, 270 / 399, atol=0.02)
    assert np.isclose(bar.y_rel, 280 / 399, atol=0.02)


def test_detect_objects_crops(workspace_image: np.ndarray) -> None:
    """Every object comes with a square crop showing the object in its centre."""
    objects = detect_objects(workspace_image, crop_size=128)
    cube = min(objects, key=lambda o: o.x_rel)
    assert cube.crop.shape == (128, 128, 3)
    assert cube.crop[64, 64, 0] > 150 and cube.crop[64, 64, 2] < 80  # red centre
