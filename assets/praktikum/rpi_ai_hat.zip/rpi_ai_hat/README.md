# Praktikum: Edge-AI Modell-Ausführung mit Raspberry Pi 5 & AI HAT+ 2 (Objektdetektion & LLM)

> **Einführendes Praktikum (CPS)**

Willkommen zur einführenden Praktikumsaufgabe „Edge-AI Modell-Ausführung mit Raspberry Pi 5 und AI HAT+ 2 (26 TOPS Hailo-8 NPU)“. In diesem Praktikum lernen Sie die Grundlagen modernster Edge-AI-Hardwarebeschleunigung kennen. Sie führen zwei grundlegende Klassen von KI-Modellen direkt auf eingebetteter Hardware aus und evaluieren deren Performanz:

1. **Aufgabe 1: Live-Objektdetektion (Computer Vision)** – Latenzarme Objekterkennung im Videostream einer Intel RealSense D415 Kamera mittels Ultralytics YOLO (YOLOv8 / YOLOE / YOLO26).  
2. **Aufgabe 2: Lokale Generative KI & LLMs (Large Language Models)** – Ausführung und Benchmarking kompakter Sprachmodelle (z. B. `Llama-3.2-1B`, `Qwen2.5-1.5B`) auf der NPU/CPU-Architektur via Hailo GenAI.  

---

## 🎯 Überblick & Zielsetzung

In eingebetteten cyber-physischen Systemen (CPS) wie mobilen Robotern, autonomen Drohnen oder Smart-Factory-Zellen gewinnt die lokale Ausführung von KI-Modellen an der Kante (*Edge AI*) stark an Bedeutung. Sowohl die Auswertung von Kamerasignalen (Computer Vision) als auch das Verständnis natürlicher Sprache und Handlungsplanung durch Sprachmodelle (Generative AI / LLMs) müssen direkt auf dem System effizient, latenzarm und ohne ständige Cloud-Verbindung ablaufen.

In diesem Praktikum nutzen Sie ein leistungsfähiges Edge-AI-System bestehend aus:

1. **Raspberry Pi 5 (8 GB RAM):** Als zentraler Host-Computer für Systemsteuerung, Datenakquisition und Ablauflogik.  
2. **Raspberry Pi AI HAT+ 2 (Hailo-10, 40 TOPS, 8GB RAM):** Als PCIe-basierte NPU-Erweiterungskarte zur Hardwarebeschleunigung von Inferenz-Pipelines in HEF-Modellformat.  
3. **Intel RealSense D415:** Als USB 3.0 RGB-D Kamerasystem zur Bereitstellung von Live-Videostreams für Computer-Vision-Aufgaben.  
4. **Ultralytics YOLO & Hailo GenAI:** Als Software-Frameworks für Echtzeit-Objektdetektion und generative Sprachmodellierung auf der NPU.  

---

## 🏗 Systemarchitektur & Inferenz-Pipelines

```text
+-------------------------------------------------------------------+
|                        System-Eingaben                            |
|   - Kamera-Stream: Intel RealSense D415 (RGB Video @ 30 FPS)      |
|   - Text-Prompts: Benutzeranfragen für Sprachmodellierung         |
+---------------------------------+---------------------------------+
                                  |
                                  v
+-------------------------------------------------------------------+
|                        Raspberry Pi 5                             |
|  - Frame-Capture / Text-Preprocessing                             |
|  - Host-Ablaufsteuerung & Ressourcen-Monitoring (CPU/RAM/NPU)     |
+---------------------------------+---------------------------------+
                                  |
                                  | PCIe Gen 3.0 x1 Bus
                                  v
+-------------------------------------------------------------------+
|               Raspberry Pi AI HAT+ 2 (Hailo-8 NPU)                |
|  - 26 TOPS Inferenz-Beschleunigung                                |
|  - Pipeline A (Vision): HEF-Modellausführung (YOLOv8/YOLOE/YOLO26)|
|  - Pipeline B (GenAI): Hailo GenAI LLM Execution                  |
+---------------------------------+---------------------------------+
                                  |
                                  v
+-------------------------------------------------------------------+
|                        System-Ausgaben                            |
|  - Vision Output: Bounding Boxes, Klassen-Labels, Live-FPS        |
|  - LLM Output: Generierter Text, Token-Rate (Tokens/s), TTFT      |
+-------------------------------------------------------------------+
```

---

## 📂 Detaillierte Setup-Anleitungen

#### 1. SSH-Verbindung einrichten

Hängt den Inhalt der [config](./config) an eure SSH-Config (`~/.ssh/config`) an. Verbindet euch dann im Labornetz mit dem Passwort aus dem Sciebo-Ordner per SSH mit dem Raspberry Pi:

```bash
ssh rpi-ai-hat
```

> **Hinweis:** Achtet darauf, dass vor dem neuen Eintrag `Host rpi-ai-hat` eine Leerzeile steht. Falls eure bestehende `~/.ssh/config` nicht mit einer Leerzeile endet, fügt vorher eine ein. Sonst landet `Host rpi-ai-hat` am Ende der letzten Zeile (z. B. `User xyzHost rpi-ai-hat`) und SSH bricht mit `keyword user extra arguments at end of line` ab.

#### 2. Projektdateien prüfen (und nur bei Bedarf kopieren)

Prüft zuerst, ob der Projektordner mit den Dateien aus diesem Repository bereits auf dem Raspberry Pi liegt:

```bash
ssh rpi-ai-hat ls /home/raspberry/[euer projektname]
```

Nur falls der Ordner oder einzelne Dateien fehlen, kopiert ihr sie von eurem Rechner aus diesem Ordner auf den Raspberry Pi:

```bash
scp -r . rpi-ai-hat:/home/raspberry/[euer projektname]
```

#### 3. Entwicklungs-Container starten

Alle Python-Skripte werden **im Docker-Container** ausgeführt, nicht direkt auf dem Raspberry Pi. Nur dort sind OpenCV, Ultralytics, pyrealsense2 und die HailoRT-Bindings installiert. Wechselt dazu auf dem Raspberry Pi in euren Projektordner und startet zuerst den Container:

```bash
cd /home/raspberry/[euer projektname]
docker compose run --rm -it rpi-ai-hat
```

Euer Projektordner ist im Container unter `/workspace` eingebunden. `--rm` sorgt dafür, dass der Container nach `exit` automatisch gelöscht wird. Dateien in `/workspace` bleiben erhalten, alles andere (z. B. per `sudo apt install` nachinstallierte Pakete) geht verloren. Das Passwort des Container-Users `develop` lautet `develop`.

#### 4. Dateien bearbeiten (optional mit VS Code)

Per [VS Code Remote Plugin](https://marketplace.visualstudio.com/items?itemName=ms-vscode-remote.remote-ssh) könnt ihr euch auf den Raspberry Pi verbinden, euren Projektordner öffnen und Dateien editieren. Da das X11 Forwarding mit dem VS Code Remote Plugin nicht zuverlässig funktioniert, startet den Container (Schritt 3) und eure Skripte in einem separaten Terminal mit SSH-Verbindung.

Für das X11 Forwarding (Anzeige der OpenCV-Fenster) muss auf eurem System ein X11-Server laufen. Unter Linux läuft dieser meist standardmäßig, unter macOS (z. B. [XQuartz](https://www.xquartz.org/)) und Windows (z. B. VcXsrv) müsst ihr ein entsprechendes Programm einrichten. Durch das X11 Forwarding kann es zu geringen Latenzen bei GUI-Anwendungen kommen.

## 📋 Praktikumsaufgaben & Ausführung

Das Praktikum gliedert sich in zwei gleichwertige Hauptaufgaben:

### 1️⃣ Aufgabe 1: Live-Objektdetektion im Kamerastream (Computer Vision)

In der ersten Aufgabe führen Sie Echtzeit-Objektdetektion mit Ultralytics YOLO auf der Hailo-10 NPU im Live-Kamerastream durch.

Die Musterlösung dazu ist in [`object_detection_realsense.py`](./object_detection_realsense.py) implementiert.

#### Ausführung im Mock-Modus (Ohne angeschlossene Hardware)

Wenn weder der AI HAT+ 2 noch die RealSense D415 Kamera angeschlossen sind, kann das Skript im Simulationsmodus getestet werden:

```bash
python3 object_detection_realsense.py --mock
```

#### Ausführung an der echten Hardware (Raspberry Pi 5 + AI HAT+ 2 + RealSense D415)

Startet zuerst den Entwicklungs-Container (siehe [Setup, Schritt 3](#3-entwicklungs-container-starten)) und führt das Skript dann darin aus:

```bash
docker compose run --rm -it rpi-ai-hat
python3 object_detection_realsense.py --model yolo-models/yolov8n_hailo_model/yolov8n.hef --conf 0.5
```

Die für den Hailo-10H kompilierten Modelle liegen auf dem Raspberry Pi im Projektordner unter `yolo-models/` (z. B. `yolo11n_hailo_model/yolo11n.hef`, `yolo26n_hailo_model/yolo26n.hef`).

#### Evaluierungsaufgaben (Aufgabe 1)

- Vergleichen Sie die Bildverarbeitungsrate (FPS) und Inferenzlatenz bei der Ausführung auf der Hailo-8 NPU im Vergleich zur Ausführung auf der Raspberry Pi 5 Host-CPU (`--mock` vs. `--model yolov8n.hef`).  
- Testen Sie unterschiedliche YOLO-Modellvarianten (`yolov8n.hef`, `yoloe.hef`, `yolo26.hef`) und bewerten Sie den Trade-off zwischen Erkennungsgenauigkeit (mAP / Konfidenz) und Bildrate (FPS).  

---

### 2️⃣ Aufgabe 2: Generative KI & Lokale LLM-Inferenz (Large Language Models)

In der zweiten Aufgabe führen Sie generative Sprachmodelle (LLMs) lokal auf der Raspberry Pi 5 + AI HAT+ 2 Hardware aus.

#### Einrichtung der LLM-Inferenzumgebung

Allgemeine Infos zum Einsatz von LLMs auf dem Raspberry Pi finden sich in der [offiziellen Raspberry Pi AI-Dokumentation zu LLMs](https://www.raspberrypi.com/documentation/computers/ai.html#LLMs). Unser spiegelt das offizielle Raspberry Pi Setup nur bedingt wieder, deswegen werden nicht alle Befehle wie angegeben funktionieren. Die LLM-Modelle für den Hailo 10H sind bereits heruntergeladen, sind auf dem Pi unter ~/.local/share/hailo-ollama/models/blob/ zu finden und werden im rpi-ai-hat service automatisch unter /workspace/llm-models eingehangen.

Weitere Infos zu unterstützten Modellen finden Sie unter [Hailo Model Zoo GenAI Repository](https://github.com/hailo-ai/hailo_model_zoo_genai) und die darin bereitgestellten [Model Manifests](https://github.com/hailo-ai/hailo_model_zoo_genai/tree/main/models/manifests).

#### Ausführung mit hailo-ollama

Die LLMs werden über `hailo-ollama` ausgeführt, einen lokalen Server mit Ollama-kompatibler API. `hailo-ollama` ist **direkt auf dem Raspberry Pi** installiert, nicht im Docker-Container. Die folgenden Befehle führen Sie daher in SSH-Terminals auf dem Raspberry Pi aus.

> **Hinweis:** Die NPU kann immer nur von einem Prozess gleichzeitig genutzt werden. Beenden Sie vorher die Objektdetektion aus Aufgabe 1 und prüfen Sie, ob nicht bereits jemand anderes `hailo-ollama` gestartet hat. Sonst erhalten Sie den Fehler `HAILO_OUT_OF_PHYSICAL_DEVICES`.

**1. Server starten** (dieses Terminal bleibt geöffnet, hier erscheinen die Server-Logs):

```bash
hailo-ollama
```

Der Server läuft anschließend auf Port `8000`.

**2. Verfügbare Modelle auflisten** (in einem zweiten Terminal):

```bash
curl --silent http://localhost:8000/hailo/v1/list
```

Die Modelle sind bereits heruntergeladen. Der in der Raspberry-Pi-Dokumentation beschriebene Schritt `api/pull` entfällt, da der Raspberry Pi keine Internetverbindung hat.

**3. Prompt senden:**

```bash
curl --silent http://localhost:8000/api/chat \
  -H 'Content-Type: application/json' \
  -d '{"model": "qwen2:1.5b", "stream": false,
       "messages": [{"role": "user", "content": "Erkläre kurz, was ein cyber-physisches System ist."}]}'
```

Die Antwort enthält neben dem Text nur `total_duration` (in Nanosekunden) und `eval_count` (Anzahl generierter Tokens). Die Zeit bis zum ersten Token (TTFT) lässt sich daraus nicht bestimmen.

**4. Benchmark ausführen:**

Für die Messung von TTFT und Tokens/s steht das Skript [`llm_benchmark.py`](./llm_benchmark.py) bereit. Es nutzt Streaming und kommt ohne zusätzliche Pakete aus:

```bash
cd /home/raspberry/[euer projektname]
python3 llm_benchmark.py --model qwen2:1.5b
python3 llm_benchmark.py --model llama3.2:1b --prompt "Schreibe eine Python-Funktion, die eine Liste sortiert."
```

Das Skript führt standardmäßig zwei Durchläufe aus (`--runs`). Der erste Durchlauf enthält die Ladezeit des Modells (ca. 20 s) und verfälscht die TTFT, werten Sie daher den zweiten Durchlauf aus. Mit `--quiet` wird der Antworttext nicht ausgegeben.

Zur Analyse der Systemauslastung lassen Sie parallel in einem dritten Terminal `htop` laufen.

#### Durchführung & Benchmarking (Aufgabe 2)

1. **Modellauswahl & Downloads:** Wählen Sie mindestens zwei unterschiedliche Sprachmodelle aus den unterstützten Manifesten aus (z. B. ein allgemeines Sprachmodell wie `Llama-3.2-1B` und ein spezialisiertes Modell wie `Qwen2.5-Coder-1.5B`).  
2. **Inferenz-Start & Interaktion:** Starten Sie die Modelle interaktiv und testen Sie verschiedene Prompts (z. B. einfache Textgenerierung, logische Aufgabenstellungen oder Code-Erzeugung).  
3. **Performanz-Analyse & Benchmarking:**  
   - Messen Sie die Generierungsgeschwindigkeit in **Tokens pro Sekunde (Tokens/s)**.  
   - Ermitteln Sie die Zeit bis zum ersten generierten Token (**Time To First Token / TTFT**).  
   - Analysieren Sie die Systemauslastung (CPU-Auslastung, RAM-Verbrauch sowie NPU-Auslastung via System-Monitoring).  
4. **Vergleich & Reflexion:** Vergleichen Sie die Performanz kompakter LLMs auf dem AI HAT+ 2 mit reiner CPU-Ausführung (z. B. via Ollama) und diskutieren Sie die Eignung kompakter Sprachmodelle für autonomes Agieren in cyber-physischen Systemen.  
