"""
Detector module for object detection pipelines using Hailo NPU or Ultralytics CPU/GPU.
"""

from typing import List, Tuple, Dict, Any, Optional
import time
import numpy as np

# COCO class names in the order used by the Hailo Model Zoo YOLO models (80 classes)
COCO_CLASSES: List[str] = [
    "person", "bicycle", "car", "motorcycle", "airplane", "bus", "train", "truck",
    "boat", "traffic light", "fire hydrant", "stop sign", "parking meter", "bench",
    "bird", "cat", "dog", "horse", "sheep", "cow", "elephant", "bear", "zebra",
    "giraffe", "backpack", "umbrella", "handbag", "tie", "suitcase", "frisbee",
    "skis", "snowboard", "sports ball", "kite", "baseball bat", "baseball glove",
    "skateboard", "surfboard", "tennis racket", "bottle", "wine glass", "cup",
    "fork", "knife", "spoon", "bowl", "banana", "apple", "sandwich", "orange",
    "broccoli", "carrot", "hot dog", "pizza", "donut", "cake", "chair", "couch",
    "potted plant", "bed", "dining table", "toilet", "tv", "laptop", "mouse",
    "remote", "keyboard", "cell phone", "microwave", "oven", "toaster", "sink",
    "refrigerator", "book", "clock", "vase", "scissors", "teddy bear",
    "hair drier", "toothbrush",
]


class ObjectDetector:
    """Wrapper class for Ultralytics YOLO and Hailo-8 NPU inference.

    Attributes:
        model_path (str): Path to the model file (.pt, .hef, or .onnx).
        conf_threshold (float): Minimum confidence score for detections.
        use_mock (bool): Whether to run in simulated mock mode without hardware.
    """

    def __init__(
        self,
        model_path: str = "yolov8n.hef",
        conf_threshold: float = 0.5,
        use_mock: bool = False,
    ) -> None:
        """Initializes the object detector.

        Args:
            model_path: Path to the model file (.hef for Hailo, .pt for PyTorch).
            conf_threshold: Detection confidence threshold (0.0 to 1.0).
            use_mock: Enable mock inference mode for simulation/testing.
        """
        self.model_path: str = model_path
        self.conf_threshold: float = conf_threshold
        self.use_mock: bool = use_mock
        self.is_hailo: bool = model_path.endswith(".hef")
        self.hailo_infer_pipeline: Optional[Any] = None
        self.yolo_model: Optional[Any] = None

        if not self.use_mock:
            self._initialize_model()

    def _initialize_model(self) -> None:
        """Initializes either the Hailo NPU or standard Ultralytics model."""
        if self.is_hailo:
            try:
                # Import Hailo Platform runtime if available
                from hailo_platform import VDevice, FormatType

                self.vdevice = VDevice()
                self.infer_model = self.vdevice.create_infer_model(self.model_path)
                self.infer_model.set_batch_size(1)
                self.infer_model.input().set_format_type(FormatType.UINT8)
                for output in self.infer_model.outputs:
                    output.set_format_type(FormatType.FLOAT32)

                # Model input shape is NHWC without batch, e.g. (640, 640, 3)
                self.input_height, self.input_width = self.infer_model.input().shape[:2]
                self.output_name: str = self.infer_model.output().name
                self.output_shape = self.infer_model.output().shape
                self.configured_model = self.infer_model.configure()
            except Exception as err:
                print(f"[Warning] Hailo NPU initialization failed: {err}. Falling back to mock mode.")
                self.use_mock = True
        else:
            try:
                from ultralytics import YOLO
                self.yolo_model = YOLO(self.model_path)
            except Exception as err:
                print(f"[Warning] Ultralytics initialization failed: {err}. Falling back to mock mode.")
                self.use_mock = True

    def detect(
        self, frame: np.ndarray
    ) -> List[Tuple[Tuple[int, int, int, int], float, str]]:
        """Runs object detection on a single RGB frame.

        Args:
            frame: Input BGR/RGB image array of shape (H, W, 3).

        Returns:
            List of detected objects, each represented as a tuple:
            ((x1, y1, x2, y2), confidence, class_label).
        """
        if self.use_mock:
            return self._mock_detect(frame)

        if self.is_hailo:
            return self._hailo_detect(frame)
        else:
            return self._yolo_detect(frame)

    def _mock_detect(
        self, frame: np.ndarray
    ) -> List[Tuple[Tuple[int, int, int, int], float, str]]:
        """Simulates detection results for mock/testing mode.

        Args:
            frame: Input image frame.

        Returns:
            Simulated list of detected bounding boxes and classes.
        """
        height, width = frame.shape[:2]
        # Generate dynamic moving bounding boxes for mock visualization
        t_val = time.time()
        cx1 = int((width / 2) + np.sin(t_val) * 100)
        cy1 = int((height / 2) + np.cos(t_val) * 60)

        mock_results = [
            ((cx1 - 60, cy1 - 60, cx1 + 60, cy1 + 60), 0.92, "bottle"),
            ((50, 50, 180, 180), 0.85, "cup"),
            ((width - 200, height - 150, width - 50, height - 30), 0.78, "laptop"),
        ]
        return [res for res in mock_results if res[1] >= self.conf_threshold]

    def _yolo_detect(
        self, frame: np.ndarray
    ) -> List[Tuple[Tuple[int, int, int, int], float, str]]:
        """Runs inference using Ultralytics YOLO.

        Args:
            frame: Input RGB/BGR image frame.

        Returns:
            List of detected objects with bounding boxes, confidence, and class names.
        """
        if self.yolo_model is None:
            return []

        results = self.yolo_model(frame, conf=self.conf_threshold, verbose=False)
        detections = []
        if len(results) > 0:
            boxes = results[0].boxes
            for box in boxes:
                x1, y1, x2, y2 = map(int, box.xyxy[0].tolist())
                conf = float(box.conf[0].item())
                cls_id = int(box.cls[0].item())
                cls_name = self.yolo_model.names.get(cls_id, f"cls_{cls_id}")
                detections.append(((x1, y1, x2, y2), conf, cls_name))
        return detections

    def _letterbox(self, frame: np.ndarray) -> Tuple[np.ndarray, float, int, int]:
        """Resizes a BGR frame to the model input size while keeping the aspect ratio.

        Args:
            frame: Input BGR image of shape (H, W, 3).

        Returns:
            Tuple of (RGB uint8 model input, scale factor, x padding, y padding).
        """
        import cv2

        height, width = frame.shape[:2]
        scale = min(self.input_width / width, self.input_height / height)
        new_w, new_h = int(round(width * scale)), int(round(height * scale))
        pad_x = (self.input_width - new_w) // 2
        pad_y = (self.input_height - new_h) // 2

        resized = cv2.resize(frame, (new_w, new_h), interpolation=cv2.INTER_LINEAR)
        canvas = np.full((self.input_height, self.input_width, 3), 114, dtype=np.uint8)
        canvas[pad_y : pad_y + new_h, pad_x : pad_x + new_w] = resized
        rgb = cv2.cvtColor(canvas, cv2.COLOR_BGR2RGB)
        return np.ascontiguousarray(rgb), scale, pad_x, pad_y

    @staticmethod
    def _parse_nms_by_class(raw: Any) -> List[Tuple[int, np.ndarray]]:
        """Parses HailoRT 'NMS BY CLASS' output into per-class detection arrays.

        HailoRT returns either a list (one entry per class) of arrays with rows
        [y_min, x_min, y_max, x_max, score] in normalized coordinates, or a flat
        float32 buffer where each class block is [count, count * 5 values].

        Args:
            raw: Output buffer as returned by HailoRT.

        Returns:
            List of (class_id, array of shape (N, 5)) for classes with detections.
        """
        parsed: List[Tuple[int, np.ndarray]] = []

        if isinstance(raw, (list, tuple)):
            for class_id, dets in enumerate(raw):
                dets = np.asarray(dets, dtype=np.float32).reshape(-1, 5)
                if len(dets):
                    parsed.append((class_id, dets))
            return parsed

        flat = np.asarray(raw, dtype=np.float32).ravel()
        idx = 0
        class_id = 0
        while idx < flat.size and class_id < len(COCO_CLASSES):
            count = int(flat[idx])
            idx += 1
            if count > 0:
                parsed.append((class_id, flat[idx : idx + count * 5].reshape(count, 5)))
            # Each class block reserves space for its actual count only
            idx += count * 5
            class_id += 1
        return parsed

    def _hailo_detect(
        self, frame: np.ndarray
    ) -> List[Tuple[Tuple[int, int, int, int], float, str]]:
        """Runs YOLO inference on the Hailo NPU (HEF model with on-chip NMS).

        The frame is letterboxed to the model input size, converted to RGB and
        sent to the NPU. The NMS output (normalized boxes per class) is mapped
        back to original frame coordinates.

        Args:
            frame: Input BGR frame from the camera.

        Returns:
            List of detected objects ((x1, y1, x2, y2), confidence, class_label).
        """
        input_data, scale, pad_x, pad_y = self._letterbox(frame)

        output_buffer = np.empty(self.output_shape, dtype=np.float32)
        bindings = self.configured_model.create_bindings(
            output_buffers={self.output_name: output_buffer}
        )
        bindings.input().set_buffer(input_data)
        self.configured_model.run([bindings], 10000)
        raw = bindings.output().get_buffer()

        height, width = frame.shape[:2]
        detections: List[Tuple[Tuple[int, int, int, int], float, str]] = []
        for class_id, dets in self._parse_nms_by_class(raw):
            for y_min, x_min, y_max, x_max, score in dets:
                if score < self.conf_threshold:
                    continue
                # Normalized model coordinates -> pixels in letterboxed image -> original frame
                x1 = (x_min * self.input_width - pad_x) / scale
                y1 = (y_min * self.input_height - pad_y) / scale
                x2 = (x_max * self.input_width - pad_x) / scale
                y2 = (y_max * self.input_height - pad_y) / scale
                box = (
                    int(np.clip(x1, 0, width - 1)),
                    int(np.clip(y1, 0, height - 1)),
                    int(np.clip(x2, 0, width - 1)),
                    int(np.clip(y2, 0, height - 1)),
                )
                label = COCO_CLASSES[class_id] if class_id < len(COCO_CLASSES) else f"cls_{class_id}"
                detections.append((box, float(score), label))
        return detections

    def release(self) -> None:
        """Releases Hailo NPU resources so other processes can use the device."""
        configured = getattr(self, "configured_model", None)
        if configured is not None and hasattr(configured, "__exit__"):
            try:
                configured.__exit__(None, None, None)
            except Exception:
                pass
        self.configured_model = None
        self.infer_model = None

        vdevice = getattr(self, "vdevice", None)
        if vdevice is not None and hasattr(vdevice, "release"):
            try:
                vdevice.release()
            except Exception:
                pass
        self.vdevice = None
