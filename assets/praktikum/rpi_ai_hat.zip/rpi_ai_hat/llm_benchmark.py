"""
Benchmark for local LLM inference on the Raspberry Pi AI HAT+ 2 via hailo-ollama.

Sends a prompt to the hailo-ollama server (Ollama-compatible API) using streaming
and measures Time To First Token (TTFT), token count and generation speed.
Only uses the Python standard library, so it runs directly on the Raspberry Pi.
"""

from typing import Any, Dict, Optional
import argparse
import json
import time
import urllib.request


def run_benchmark(host: str, model: str, prompt: str) -> Dict[str, Any]:
    """Runs one streamed chat request and measures timing metrics.

    Args:
        host: Base URL of the hailo-ollama server, e.g. "http://localhost:8000".
        model: Model name as listed by /hailo/v1/list, e.g. "qwen2:1.5b".
        prompt: User prompt sent to the model.

    Returns:
        Dictionary with ttft_s, tokens, tokens_per_s, total_s and the answer text.
    """
    payload = {
        "model": model,
        "stream": True,
        "messages": [{"role": "user", "content": prompt}],
    }
    request = urllib.request.Request(
        f"{host}/api/chat",
        data=json.dumps(payload).encode("utf-8"),
        headers={"Content-Type": "application/json"},
    )

    t_start = time.time()
    t_first: Optional[float] = None
    chunks = 0
    answer_parts = []
    last: Dict[str, Any] = {}

    with urllib.request.urlopen(request) as response:
        for line in response:
            if not line.strip():
                continue
            last = json.loads(line)
            content = last.get("message", {}).get("content", "")
            if content:
                chunks += 1
                answer_parts.append(content)
                if t_first is None:
                    t_first = time.time()
    t_end = time.time()

    if t_first is None:
        raise RuntimeError("Keine Tokens vom Modell erhalten.")

    # Prefer the server-side token count, fall back to the number of streamed chunks
    tokens = int(last.get("eval_count", chunks))
    generation_s = t_end - t_first
    return {
        "ttft_s": t_first - t_start,
        "tokens": tokens,
        "tokens_per_s": tokens / generation_s if generation_s > 0 else float("nan"),
        "total_s": t_end - t_start,
        "answer": "".join(answer_parts),
    }


def main() -> None:
    """Parses CLI arguments, runs the benchmark and prints the results."""
    parser = argparse.ArgumentParser(
        description="LLM-Benchmark (TTFT, Tokens/s) für hailo-ollama auf dem AI HAT+ 2"
    )
    parser.add_argument("--model", type=str, default="qwen2:1.5b", help="Modellname, z. B. llama3.2:1b")
    parser.add_argument(
        "--prompt",
        type=str,
        default="Erkläre kurz, was ein cyber-physisches System ist.",
        help="Prompt, der an das Modell gesendet wird",
    )
    parser.add_argument("--host", type=str, default="http://localhost:8000", help="URL des hailo-ollama Servers")
    parser.add_argument("--runs", type=int, default=2, help="Anzahl Durchläufe (der erste enthält die Ladezeit)")
    parser.add_argument("--quiet", action="store_true", help="Antworttext nicht ausgeben")
    args = parser.parse_args()

    print("==================================================================")
    print(" LLM-Benchmark auf Raspberry Pi 5 & AI HAT+ 2 (hailo-ollama)")
    print(f" Modell: {args.model} | Durchläufe: {args.runs}")
    print("==================================================================")

    for run in range(1, args.runs + 1):
        result = run_benchmark(args.host, args.model, args.prompt)
        note = " (inkl. Ladezeit des Modells)" if run == 1 else ""
        print(f"\n--- Durchlauf {run}{note} ---")
        if not args.quiet:
            print(result["answer"])
            print()
        print(f"TTFT:        {result['ttft_s']:.2f} s")
        print(f"Tokens:      {result['tokens']}")
        print(f"Tokens/s:    {result['tokens_per_s']:.2f}  (ohne TTFT)")
        print(f"Gesamtzeit:  {result['total_s']:.2f} s")


if __name__ == "__main__":
    main()
