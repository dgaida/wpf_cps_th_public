# 2D Kalman-Filter Lokalisierung im AirSim Simulator

Dieses Praktikum behandelt die Zustandsschätzung und Lokalisierung eines autonom fahrenden Fahrzeugs in einer 2D-Simulationsumgebung (AirSim) unter Nutzung eines Kalman-Filters.

```mermaid
graph LR
    M["Messungen:<br/>a) GPS (Position, Geschwindigkeit)<br/>b) IMU (Beschleunigung)<br/>c) Fusion (GPS + IMU)"] --> KF["Kalman-Filter"]
    KF -- "x̂_k" --> R["Regler"]
    P["Pfad (rote Linie)"] --> R
    R --> C["Lenkwinkel<br/>Beschleunigung"]
```

---

## Dokumentation

Vollständige Anleitungen und Aufgabenbeschreibungen befinden sich im Ordner [`docs/`](./docs/):

- 📖 [**Installation und Einrichtung**](./docs/installation.md): Installation von AirSimNH, Einrichtung der Anaconda-Umgebung und Konfiguration.  
- 🎯 [**Aufgabenstellung**](./docs/aufgabenstellung.md): Detaillierte Aufgabenstellung, Erläuterung der Sensoren, Bewertungs-Kriterien und Abgabeanforderungen.  

---

## Projektstruktur

```
praktikum/kalman_localization_2d/
├── docs/                        # Dokumentation (Installation & Aufgabenstellung)
│   ├── aufgabenstellung.md
│   └── installation.md
├── airsimcar/                   # Schnittstelle zum AirSim Fahrzeug & Sensoren
├── airsimcontroller/            # Pfad- und Zustandsverwaltung sowie Plotter
├── tests/                       # Unit- und Integrationstests
│   ├── unit/
│   └── integration/
├── environment.yml              # Conda-Umgebungskonfiguration
├── kalman_filter_musterloesung.py # Beispiel-/Musterlösung für das Kalman-Filter
├── manager.py                   # Hauptschnittstelle zur Simulation & Steuerung
├── pyproject.toml               # Python Paket- und Tool-Konfiguration
├── requirements.txt             # Python Abhängigkeiten
├── settings.json                # AirSim Konfigurationsdatei
└── student_task.py              # Zu bearbeitende Datei (Implementierung des Kalman-Filters)
```

---

## Schnellstart

1. AirSimNH Simulator starten.  
2. Conda-Umgebung aktivieren:  
   ```bash
   conda activate cpskalmancar
   ```
3. Kalman-Filter in `student_task.py` bearbeiten und ausführen:  
   ```bash
   python student_task.py
   ```

---

## Tests ausführen

Das Projekt enthält Unit- und Integrationstests. Führen Sie die Tests im Projektordner oder aus dem Repository-Root aus:

```bash
pytest praktikum/kalman_localization_2d/tests/
```
