# Aufgabenstellung: 2D Kalman-Filter Lokalisierung

## Einführung

In diesem Praktikum ist es Ihre Aufgabe, die Position eines Fahrzeugs mithilfe eines **Kalman-Filters** zu schätzen und zu bestimmen. Das Fahrzeug nutzt die Zustandsschätzung des Kalman-Filters, um Pfadentscheidungen zu treffen und autonom einer vorgegebenen Strecke zu folgen.

Als Simulationsumgebung nutzen wir **AirSim** (von Microsoft), einen Open-Source-Simulator auf Basis der Unreal Engine zur Entwicklung und Testung autonomer Systeme. In diesem Praktikum fährt das Fahrzeug eine Testrunde um den Häuserblock.

![AirSim Car Simulation](images/airsimcarsim.png)

---

## Sensoren und Koordinatensysteme

Das Fahrzeug ist mit zwei zentralen Sensoren ausgestattet:

1. **GPS-Sensor (Global Positioning System)**:  
   - Misst die geografische Position (Breitengrad, Längengrad, Höhe).  
   - Im Rahmen des Praktikums wird die GPS-Messung direkt in kartesische $X$-, $Y$- und $Z$-Koordinaten der Umgebung umgeformt.  

2. **IMU-Sensor (Inertial Measurement Unit)**:  
   - Misst die Beschleunigung des Fahrzeugs in $X$-, $Y$- und $Z$-Richtung sowie die Rotationsgeschwindigkeiten um die drei Achsen.  
   - Die IMU misst ursprünglich im fahrzeugfesten Koordinatensystem. Die Koordinatentransformation in das globale Umgebungs-Koordinatensystem wird vom Framework bereits automatisch durchgeführt.  

---

## Visualisierung und Leistungsauswertung

1. **Echtzeit-Graph**: Während das Fahrzeug fährt, werden die gefahrene Route und die Geschwindigkeit live dargestellt.  

   ![Live-Plot der gefahrenen Route und der Geschwindigkeit](images/plot_route_speed.png)

2. **Bewertungsscores**: Nach Abschluss der Fahrt werden Performance-Kennzahlen berechnet:
   - **Estimate Score**: Gibt an, wie präzise die Zustandsschätzung im Vergleich zur wahren Position war.  
   - **Drive Score**: Gibt an, wie gut das Fahrzeug der Soll-Route gefolgt ist (Ziel: $\ge 60$).  

   ![Performance-Bewertungsscores](images/protocol_score.png)

3. **Abschluss-Diagramme**:
   - Abweichung der Zustandsschätzung von der echten Position.  
     ![Abweichung der Zustandsschätzung](images/plot_position_estim_error.png)
   - Gegenüberstellung von echter und geschätzter Geschwindigkeit.  
     ![Echte vs. geschätzte Geschwindigkeit](images/plot_car_velocity.png)
   - Übersicht der gefahrenen Route im Vergleich zum Soll-Pfad.  
     ![Übersicht gefahrene Route vs. Soll-Pfad](images/plot_route_block.png)

---

## Übersicht der Projektdateien

### Zu bearbeitende Datei  
- **`student_task.py`**: Enthält die Klasse `KalmanFilter` sowie die Hauptschleife. Hier definieren Sie die Matrizen und die Prädiktions- und Korrekturschritte des Kalman-Filters.  

### Zu analysierende Schnittstellen-Datei  
- **`manager.py`**: Stellt die Klasse `Manager` als Schnittstelle zum Fahrzeug und den Sensoren bereit. Die Methode `update` liefert dem Fahrzeug die geschätzte Position und Geschwindigkeit.  

### Unterstützende Dateien (Framework)  
- `airsimcar/car.py`: Schnittstelle zum AirSim-Fahrzeug.  
- `airsimcar/control.py`: Fahrzeugsteuerung.  
- `airsimcar/gps.py`: Schnittstelle zum GPS-Sensor.  
- `airsimcar/imu.py`: Schnittstelle zum IMU-Sensor.  
- `airsimcar/pid_controller.py`: Implementierung des PID-Reglers.  
- `airsimcar/path.csv`: Wegpunkte der Fahrstrecke.  
- `airsimcontroller/plot_manager.py`: Visualisierung der Messungen und Ergebnisse.  
- `airsimcontroller/state_manager.py`: Zustandsverwaltung des Fahrzeugs.  
- `airsimcontroller/waypoints.py`: Verwaltung der Wegpunkte.  
- `airsimcontroller/utils.py`: Hilfsfunktionen zur Steuerung.  

---

## Praktikumsaufgaben

1. **Zustandsraummodell definieren**:  
   - Definieren Sie den Zustandsvektor $\mathbf{x}$ und die Systemmatrix $\mathbf{A}$ des Fahrzeugs.  
   - Welche Zustände sind für das Projekt notwendig und welche Zustandskomponenten können gemessen werden?  

2. **Kalman-Filter implementieren**:  
   - Vervollständigen Sie die Klasse `KalmanFilter` in `student_task.py` (Initialisierung der Matrizen $\mathbf{A}, \mathbf{C}, \mathbf{R}, \mathbf{Q}, \mathbf{P}$ sowie die `update`-Methode für Prädiktion und Korrektur).  

3. **Filter testen & optimieren**:  
   - Testen Sie Ihre Implementierung in der Simulation und stimmen Sie die Rausch-Kovarianzen ab, um einen **Drive Score von mindestens 60** zu erreichen.  

4. **Sensor-Vergleich durchführen**:  
   Vergleichen Sie das Fahrverhalten und die Schätzgenauigkeit in folgenden Konfigurationen:  
   - **a.** GPS als einziger Sensor  
   - **b.** Beschleunigungssensor (IMU) als einziger Sensor  
   - **c.** Fusion von GPS und Beschleunigungssensor  
   - **d.** Zeichnen Sie die Ergebnisse optional als Video auf (Windows: `Win + G`, Ubuntu: `Ctrl + Shift + Alt + R`).  

5. **Abgabe**:  
   - Erstellen Sie einen kurzen Bericht, der Ihr Kalman-Filter-Design, die Parameterwahl und die Ergebnisse vorstellt.  
   - Laden Sie die finale `student_task.py` bspw. auf github hoch.  

---

## Hinweis zur Simulationsleistung

Die AirSim-Simulation ist rechenintensiv. Bei sehr langsamen Rechnern kann es trotz korrekter Kalman-Filter-Implementierung vorkommen, dass der Drive Score unter 60 liegt. Falls Sie auf Ihrer Hardware trotz korrekter Lösung keinen Score von 60 erreichen, wenden Sie sich bitte an das Betreuungsteam.
