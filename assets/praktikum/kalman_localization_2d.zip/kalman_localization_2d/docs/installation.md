# Installation und Einrichtung

Diese Anleitung beschreibt die Installation und Einrichtung der Simulationsumgebung **AirSim** sowie der benötigten Python-Umgebung für das Praktikum "2D Kalman-Filter Lokalisierung".

---

## 1. AirSim Simulator herunterladen und testen

1. **AirSimNH v1.8.1 herunterladen**:  
   Laden Sie die Umgebung *AirSimNH* Version 1.8.1 (Dateiname `AirSimNH.zip`) für Windows oder Linux von den offiziellen Releases herunter:
   👉 [AirSim Releases auf GitHub](https://github.com/Microsoft/AirSim/releases)

2. **Entpacken**:  
   Verschieben Sie die heruntergeladene Datei in einen beliebigen Ordner und entpacken Sie diese.

3. **Simulator testen**:  
   - Unter **Windows**: Starten Sie die Datei `AirSimNH/WindowsNoEditor/AirSimNH.exe`.  
     *Hinweis:* Unter Windows kann es vorkommen, dass die Anwendung direkt mit dem Hinweis beendet wird, dass DirectX benötigt wird. In diesem Fall muss die [DirectX-Endbenutzer-Runtime](https://www.microsoft.com/de-de/download/details.aspx?id=35) installiert werden.  
     *Hinweis zu Microsoft Defender:* Beim ersten Start unter Windows kann eine Warnmeldung von Microsoft Defender ("Der Computer wurde durch Windows geschützt") erscheinen. Dies ist kein Problem. Klicken Sie in der Meldung auf "Weitere Informationen" und anschließend auf "Trotzdem ausführen".

     <img src="images/AirSimNHWinMicrosoftDefender.png" alt="Microsoft Defender Warnmeldung" width="50%" />  
   - Unter **Linux**: Starten Sie die Datei `AirSimNH/LinuxNoEditor/AirSimNH.sh` (bzw. `./AirSimNH.sh` im entpackten Ordner).  
   - Wählen Sie bei der Startabfrage das **Fahrzeug** (Car) aus.  
   - Sie sollten sich nun mit dem Fahrzeug in der Simulationsumgebung bewegen können.  
   - **Simulation beenden**: Sie können den Simulator jederzeit durch Drücken der Taste `Esc` (Escape) oder durch Schließen des Fensters beenden.  

4. **Tipps bei Performance-Problemen**:  
   Falls der Simulator ruckelt oder hohe Last erzeugt, erstellen Sie eine Verknüpfung zu `AirSimNH.exe` und fügen Sie die Startparameter `-ResX=640 -ResY=480 -windowed` hinzu. Dies reduziert die Auflösung und verbessert die Performance erheblich.

---

## 2. Projektcode und Konfiguration

1. **Projektcode**:  
   Der Quellcode und die benötigten Projektdateien sind bereits im heruntergeladenen Praktikumspaket im Ordner `praktikum/kalman_localization_2d` enthalten.

2. **`settings.json` kopieren**:  
   Kopieren Sie die Datei `settings.json` aus dem Projektordner in das Verzeichnis, in dem sich die ausführbare Datei `AirSimNH.exe` (bzw. `AirSimNH.sh` unter Linux) befindet.
   *Hintergrund zur `settings.json`*: In der `settings.json` ist der Simulationsmodus für das Fahrzeug (`"SimMode": "Car"`) sowie das Fahrzeug `TestCar` und dessen Sensoren definiert. Insbesondere werden dort das GPS und die IMU aktiviert und deren Abtastfrequenzen, Latenzen sowie Rausch- und Driftparameter (z. B. `EphInitial`, `AngularRandomWalk`) festgelegt.

---

## 3. Python-Umgebung einrichten (Conda / Miniconda)

Es wird empfohlen, eine separate virtuelle Umgebung mit **Anaconda** oder **Miniconda** zu verwenden.

1. **Anaconda / Miniconda installieren**:  
   Falls noch nicht vorhanden, installieren Sie [Anaconda oder Miniconda](https://docs.conda.io/projects/conda/en/latest/user-guide/install/download.html#anaconda-or-miniconda).

2. **Anaconda Powershell Prompt öffnen**:  
   Starten Sie die *"Anaconda Powershell Prompt (anaconda3)"* (oder ein Terminal unter Linux/macOS).

3. **In das Projektverzeichnis wechseln**:  
   Navigieren Sie zum Ordner `praktikum/kalman_localization_2d`, in dem sich die Datei `environment.yml` befindet.

4. **Virtuelle Umgebung erstellen**:  
   ```bash
   conda env create -f environment.yml
   ```
   *Hinweis:* Befehl erstellt die Umgebung `cpskalmancar` inklusive Python und aller benötigten Abhängigkeiten.

5. **Umgebung aktivieren**:  
   ```bash
   conda activate cpskalmancar
   ```

---

## 4. Ausführung der Simulation

1. Starten Sie AirSimNH (`AirSimNH.exe` unter Windows bzw. `AirSimNH.sh` unter Linux).  
2. Wechseln Sie in der Anaconda Powershell in das Projektverzeichnis.  
3. Führen Sie die Aufgabenstellung aus:  
   ```bash
   python student_task.py
   ```
4. Das Fahrzeug in der Simulation sollte jetzt automatisch einmal um den Block fahren und es werden Plots verschiedener Größen angezeigt.  

   In dieser initialen Ausführung existiert noch kein Kalman-Filter. Die Regelung des Fahrzeugs nutzt stattdessen direkt die ungefilterten Messwerte der GPS-Position und GPS-Geschwindigkeit als Istwerte, um dem vorgegebenen Soll-Pfad (rote Linie) zu folgen:

   ```mermaid
   graph LR
       M["Messungen:<br/>- GPS-Position<br/>- GPS-Geschwindigkeit"] --> R["Regler"]
       P["Pfad (rote Linie)"] --> R
       R --> C["Lenkwinkel<br/>Beschleunigung"]
   ```

   **Frage / Arbeitsauftrag:**  
   - Beschreiben Sie qualitativ die Fahrweise des Fahrzeugs, wenn es ausschließlich mit den ungefilterten GPS-Messdaten (ohne Kalman-Filter) gesteuert wird.  
   - Welche Metriken (z. B. Drive Score, Estimate Score, Anzahl der Kollisionen, Fahrzeit) werden am Ende der Fahrt in der Konsole ausgegeben?  
