# Installation und Einrichtung

Diese Anleitung beschreibt die Installation und Einrichtung der Simulationsumgebung **AirSim** sowie der benötigten Python-Umgebung für das Praktikum "2D Kalman-Filter Lokalisierung".

---

## 1. AirSim Simulator herunterladen und testen

1. **AirSimNH v1.8.1 herunterladen**:  
   Laden Sie die Umgebung *AirSimNH* Version 1.8.1 von den offiziellen Releases herunter:
   👉 [AirSim Releases auf GitHub](https://github.com/Microsoft/AirSim/releases)

2. **Entpacken**:  
   Verschieben Sie die heruntergeladene Datei in einen beliebigen Ordner und entpacken Sie diese.

3. **Simulator testen**:  
   - Unter **Windows**: Starten Sie die Datei `AirSimNH/WindowsNoEditor/AirSimNH.exe`.  
   - Wählen Sie bei der Startabfrage das **Fahrzeug** (Car) aus.  
   - Sie sollten sich nun mit dem Fahrzeug in der Simulationsumgebung bewegen können.  

4. **Tipps bei Performance-Problemen**:  
   Falls der Simulator ruckelt oder hohe Last erzeugt, erstellen Sie eine Verknüpfung zu `AirSimNH.exe` und fügen Sie die Startparameter `-ResX=640 -ResY=480 -windowed` hinzu. Dies reduziert die Auflösung und verbessert die Performance erheblich.

---

## 2. Projektcode und Konfiguration

1. **Projektcode herunterladen**:  
   Der vollständige Quellcode und die benötigten Projektdateien stehen über die Kursseite bereit:
   👉 [WPF CPS Website](https://dgaida.github.io/wpf_cps_th_public/)

2. **`settings.json` kopieren**:  
   Kopieren Sie die Datei `settings.json` aus dem Projektordner in das Verzeichnis, in dem sich die ausführbare Datei `AirSimNH.exe` befindet.

---

## 3. Python-Umgebung einrichten (Conda / Miniconda)

Es wird empfohlen, eine separate virtuelle Umgebung mit **Anaconda** oder **Miniconda** zu verwenden.

1. **Anaconda / Miniconda installieren**:  
   Falls noch nicht vorhanden, installieren Sie [Anaconda oder Miniconda](https://docs.conda.io/projects/conda/en/latest/user-guide/install/download.html#anaconda-or-miniconda).

2. **Anaconda Powershell Prompt öffnen**:  
   Starten Sie die *"Anaconda Powershell Prompt (anaconda3)"* (oder ein Terminal unter Linux/macOS).

3. **In das Projektverzeichnis wechseln**:  
   Navigieren Sie zum Ordner `praktikum/kalman_localization_2d`, in dem sich die Datei `environment.yml` befindet.

4. **Virtuelle Umgebung erstellen**:  
   ```bash
   conda env create -f environment.yml
   ```
   *Hinweis:* Befehl erstellt die Umgebung `kipraktikum3` inklusive Python und aller benötigten Abhängigkeiten.

5. **Umgebung aktivieren**:  
   ```bash
   conda activate kipraktikum3
   ```

---

## 4. Ausführung der Simulation

1. Starten Sie `AirSimNH.exe`.  
2. Wechseln Sie in der Anaconda Powershell in das Projektverzeichnis.  
3. Führen Sie die Aufgabenstellung aus:  
   ```bash
   python student_task.py
   ```
4. Das Fahrzeug in der Simulation sollte sich nun automatisch bewegen.  
