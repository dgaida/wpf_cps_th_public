import airsim
import numpy as np
import pymap3d as pm
from airsim import Vector3r
from typing import List, Optional

""" An object of the class GPS represents a GPS measuring device installed in a vehicle.
    It measures the position of the vehicle expressed as latitude and longitude.
    The sampling rate of the GPS measuring device is defined in the settings.json file.
    The measured position can also be returned in the NED coordinate system as x and y coordinates.
    The measurement uncertainty is modelled by a mean-free Gaussian normal distribution
    with the standard deviations stddev_long/stddev_lat.
    The speed of the vehicle can also be estimated from the measured positions.
"""


class GPS:
    """Represents a GPS sensor measuring vehicle position in geodetic coordinates.

    Attributes:
        airsim_car_client (airsim.CarClient): AirSim CarClient instance.
        car_name (str): Vehicle name in AirSim environment.
        stddev_long (float): Longitude measurement standard deviation.
        stddev_lat (float): Latitude measurement standard deviation.
        measured_positions (List[List[float]]): History of NED position measurements [[x, y], ...].
        measured_position (Optional[Vector3r]): Latest measured NED position.
    """

    def __init__(
        self,
        airsim_car_client: airsim.CarClient,
        car_name: str = "TestCar",
        stddev_long: float = 0.000005,
        stddev_lat: float = 0.000005,
    ) -> None:
        """Initialize GPS sensor.

        Args:
            airsim_car_client: The AirSim CarClient instance.
            car_name: Name of the car in AirSim.
            stddev_long: Standard deviation of longitude measurements.
            stddev_lat: Standard deviation of latitude measurements.
        """
        self.airsim_car_client: airsim.CarClient = airsim_car_client
        np.random.seed(20)
        self.car_name: str = car_name
        self.stddev_long: float = stddev_long
        self.stddev_lat: float = stddev_lat
        self.measured_positions: List[List[float]] = []
        self.measured_position: Optional[Vector3r] = None
        self.measure_position()

    # *** PUBLIC GET methods ***

    def get_x_stddev(self) -> float:
        """Calculates position standard deviation along x-axis in NED frame.

        Returns:
            The standard deviation in meters along x-axis.
        """
        x_stddev, _, _ = pm.geodetic2ned(self.stddev_lat, 0, 0, 0, 0, 0)
        return float(x_stddev)

    def get_y_stddev(self) -> float:
        """Calculates position standard deviation along y-axis in NED frame.

        Returns:
            The standard deviation in meters along y-axis.
        """
        _, y_stddev, _ = pm.geodetic2ned(0, self.stddev_long, 0, 0, 0, 0)
        return float(y_stddev)

    def get_longitude(self) -> float:
        """Gets noisy longitude measurement.

        Returns:
            Measured longitude in degrees.
        """
        gps_data = self._get_gps_data()
        longitude = gps_data.gnss.geo_point.longitude + np.random.normal(0, self.stddev_long)
        return float(longitude)

    def get_latitude(self) -> float:
        """Gets noisy latitude measurement.

        Returns:
            Measured latitude in degrees.
        """
        gps_data = self._get_gps_data()
        latitude = gps_data.gnss.geo_point.latitude + np.random.normal(0, self.stddev_lat)
        return float(latitude)

    def get_measured_position(self) -> Vector3r:
        """Returns the measured position.

        Returns:
            The measured position as Vector3r in the NED coordinate frame in meters.

        Raises:
            RuntimeError: If position has not been measured yet.
        """
        if self.measured_position is None:
            raise RuntimeError("Position has not been measured yet.")
        return self.measured_position

    def measure_position(self) -> None:
        """Converts measured latitude and longitude to the NED coordinate frame.

            Initial default position of the car (see in https://microsoft.github.io/AirSim/settings/).
                "OriginGeopoint": {
                "Latitude": 47.641468,
                "Longitude": -122.140165,
                "Altitude": 122
                }
        """
        lon = self.get_longitude()
        lat = self.get_latitude()
        x, y, z = pm.geodetic2ned(lat, lon, 0, 47.641468, -122.140165, 122)
        self.measured_positions.append([float(x), float(y)])
        self.measured_position = Vector3r(x_val=float(x), y_val=float(y), z_val=float(z))

    def get_calculated_velocity(self, delta_time: float) -> Vector3r:
        """Calculates the velocity through the last 5 measured positions.

        Args:
            delta_time: The time between every measurement in seconds.

        Returns:
            The calculated velocity in m/s in the x, y and z direction.
        """
        last_positions = self.measured_positions[-5:]
        length = len(last_positions)
        if length > 1:
            v_x = 0.0
            v_y = 0.0
            for i in range(length - 1):
                v_x += last_positions[i + 1][0] - last_positions[i][0]
                v_y += last_positions[i + 1][1] - last_positions[i][1]

            v_x = v_x / ((length - 1) * delta_time)
            v_y = v_y / ((length - 1) * delta_time)

            return airsim.Vector3r(x_val=v_x, y_val=v_y, z_val=0.0)
        return airsim.Vector3r(x_val=0.0, y_val=0.0, z_val=0.0)

    # *** PUBLIC methods ***

    def print_data(self) -> None:
        """Prints raw GPS data from AirSim client."""
        gps_data = self._get_gps_data()
        print("gps_data: %s" % gps_data)

    # *** PRIVATE methods ***

    def _get_gps_data(self) -> airsim.GpsData:
        """Fetches raw GPS data from AirSim client.

        Returns:
            AirSim GpsData object.
        """
        gps_data = self.airsim_car_client.getGpsData("Gps", self.car_name)
        return gps_data
