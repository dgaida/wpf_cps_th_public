import time
import airsim
import numpy as np

import airsimcar.gps as gps
import airsimcar.imu as imu
import airsimcar.control as control
from airsimcontroller.utils import quaternion_to_mat
from airsim import Vector3r

""" An object of the Car class connects to the airsim CarClient and serves as the interface to the car in airsim.
    The attributes of the car are defined in settings.json.
    The car object manages the car's sensors that the car owns and the controls of the car.
    You have access through the car object to the sensor data and the controls of the car.
    You can control the car with the method drive and stop.
"""


class Car:
    """Interface to the AirSim vehicle, handling sensor measurements and driving controls.

    Attributes:
        airsim_car_client (airsim.CarClient): AirSim CarClient instance.
        car_name (str): Vehicle identifier in AirSim environment.
        my_gps (gps.GPS): GPS sensor instance.
        my_imu (imu.IMU): IMU sensor instance.
        car_controls (airsim.CarControls): AirSim CarControls object.
        my_control (control.Control): Controller instance for driving signals.
    """

    def __init__(self, car_name: str = "TestCar") -> None:
        """ Initialize Car.

        Args:
            car_name (str): The name of the car defined in settings.json.
        """
        self.airsim_car_client: airsim.CarClient = self._init_airsim(car_name)
        self.car_name: str = car_name

        self.my_gps: gps.GPS = gps.GPS(self.airsim_car_client, car_name)

        self.my_imu: imu.IMU = imu.IMU(self.airsim_car_client, car_name)

        self.car_controls: airsim.CarControls = airsim.CarControls()

        self.my_control: control.Control = control.Control(self.airsim_car_client, self.car_controls, car_name)

    # *** PUBLIC GET methods ***

    def get_gps_velocity(self, delta_time: float) -> Vector3r:
        """ Get velocity of car as 3d vector estimated from recent GPS position measurements

        Args:
            delta_time (float): The time between every measurement in seconds.

        Returns:
            Vector3r: The estimated velocity in m/s in the x, y and z direction.
        """
        velocity: Vector3r = self.my_gps.get_calculated_velocity(delta_time)

        return velocity

    def get_imu_lin_acc(self) -> Vector3r:
        """ Get linear acceleration from IMU sensor in world frame.

        Returns:
            Vector3r: Linear acceleration vector in m/s^2.
        """
        lin_acc: Vector3r = self.my_imu.get_lin_acc()

        return lin_acc

    def get_imu_ang_velo(self) -> float:
        """ Get angular velocity from IMU sensor around x-axis.

        Returns:
            float: Angular velocity in rad/s.
        """
        ang_vel: float = self.my_imu.get_ang_velo()

        return ang_vel

    def get_gps_position(self) -> Vector3r:
        """ Get latest GPS position measurement in NED frame.

        Returns:
            Vector3r: Measured position vector in meters.
        """
        return self.my_gps.get_measured_position()

    def get_gps_y_stddev(self) -> float:
        """ Get GPS y-axis standard deviation in meters.

        Returns:
            float: y-axis standard deviation in meters.
        """
        return self.my_gps.get_y_stddev()

    def get_gps_x_stddev(self) -> float:
        """ Get GPS x-axis standard deviation in meters.

        Returns:
            float: x-axis standard deviation in meters.
        """
        return self.my_gps.get_x_stddev()

    def get_control_input(self) -> np.ndarray:
        """ Calculates the control input with the throttle and brake.

        Returns:
            np.ndarray: the control input as a 2x1 vector [x, y].T.
        """
        state = self._get_car_state()
        if self.my_control.get_car_controls().brake == 0:
            acceleration = self.my_control.get_car_controls().throttle
        else:
            acceleration = -self.my_control.get_car_controls().brake

        vector = np.array([[acceleration, 0.0, 0.0]]).T
        quaternion = state.kinematics_estimated.orientation
        rotation_mat = quaternion_to_mat(quaternion)
        control_input = rotation_mat @ vector

        return control_input[:2]

    # *** PUBLIC methods ***

    def drive(
        self,
        distance: float,
        distance_direction: float,
        route_direction: float,
        car_direction: float,
        velocity: Vector3r,
        target_speed: float,
        delta_time: float,
    ) -> None:
        """Drives the car along the route.

        Args:
            distance (float): The distance between car and route in meter.
            distance_direction (float): The direction from car to route in rad.
            route_direction (float): The direction of travel of the route in rad.
            car_direction (float): The drive direction of the vehicle in rad.
            velocity (Vector3r): The velocity of the car in the x, y and z direction in m/s.
            target_speed (float): The target speed in m/s.
            delta_time (float): The time to the next update in seconds.
        """
        self.my_control.calc_drive_signal(
            distance,
            distance_direction,
            route_direction,
            car_direction,
            velocity,
            target_speed,
            delta_time,
        )

    def accelerate(
        self,
        route_direction: float,
        car_direction: float,
        velocity: Vector3r,
        target_speed: float,
        delta_time: float,
    ) -> None:
        """ Accelerates the car to target speed.

        Args:
            route_direction (float): The direction of travel of the route in rad.
            car_direction (float): The drive direction of the vehicle in rad.
            velocity (Vector3r): The velocity of the car in the x, y and z direction in m/s.
            target_speed (float): The target speed in m/s.
            delta_time (float): The time to the next update in seconds.
        """
        self.my_control.calc_longitudinal_signal(
            route_direction, car_direction, velocity, target_speed, delta_time
        )

    def has_collided(self) -> bool:
        """ Checks if the vehicle has collided with an obstacle.

        Returns:
            bool: True if vehicle has collided, False otherwise.
        """
        collision = self.airsim_car_client.simGetCollisionInfo(self.car_name)

        return bool(collision.has_collided)

    def measure_position(self) -> None:
        """ The GPS sensor of the car measures the position of the car. """
        self.my_gps.measure_position()

    def reset_airsim(self) -> None:
        """ Resets the simulation and car position. """
        time.sleep(0.1)
        while self.airsim_car_client.simIsPause():
            self.airsim_car_client.simPause(False)
        self.airsim_car_client.reset()
        self.airsim_car_client.enableApiControl(False)

    # *** PROTECTED methods ***

    @staticmethod
    def _init_airsim(car_name: str = "TestCar") -> airsim.CarClient:
        client = airsim.CarClient()
        client.confirmConnection()
        client.enableApiControl(True, car_name)

        return client

    def _get_car_state(self) -> airsim.CarState:
        car_state = self.airsim_car_client.getCarState(self.car_name)

        return car_state

    def get_kinematics(self) -> airsim.KinematicsState:
        car_state = self._get_car_state()

        kinematics: airsim.KinematicsState = car_state.kinematics_estimated

        return kinematics

    def get_speed(self) -> float:
        car_state = self._get_car_state()

        return float(car_state.speed)
