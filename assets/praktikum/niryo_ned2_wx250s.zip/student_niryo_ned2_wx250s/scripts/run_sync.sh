#!/usr/bin/env bash
# Startet die Synchronisation (Argumente siehe: scripts/run_sync.sh --help).
set -e
source "${INTERBOTIX_WS:-$HOME/interbotix_ws}/install/setup.bash"
cd "$(dirname "$0")/.."
exec python3 -m ned2_wx250s_sync.sync "$@"
