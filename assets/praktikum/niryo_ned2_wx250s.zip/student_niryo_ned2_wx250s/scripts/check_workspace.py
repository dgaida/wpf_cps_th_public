#!/usr/bin/env python3
"""Prüft den konfigurierten Arbeitsraum offline (ohne Roboter).

Für Punkte im Arbeitsraum wird mit der IK getestet, ob der Ned2 sie unter
Einhaltung von Gelenkgrenzen (inkl. Sicherheitsabstand) und Mindesthöhe der
Gelenke erreicht – einmal nur die Position, einmal mit senkrecht nach unten
zeigendem Greifer. Außerdem: welcher Anteil der Bewegungen des wx250s ohne
Begrenzung abgebildet wird.

    python3 scripts/check_workspace.py [--config config/sync.yaml]
"""

import argparse
import sys
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
from ned2_wx250s_sync import kinematics as K  # noqa: E402
from ned2_wx250s_sync.config import load_config  # noqa: E402

SEEDS = ([0.0, 0.0, 0.0, 0.0, 0.0], [-0.8, 0.5, 0.0, 1.0, 0.0], [0.3, -1.0, 0.0, 1.2, 0.0],
         [-1.2, 0.8, 0.0, 0.5, 0.0], [0.4, 0.9, 0.0, -1.0, 0.0])


def reachable(arm, ws, margin, p, down: bool) -> bool:
    yaw = np.arctan2(p[1], p[0])
    T = np.eye(4)
    T[:3, 3] = p
    T[:3, :3] = K.rpy_to_matrix(0.0, np.pi / 2, yaw)
    for s in SEEDS:
        seed = np.array([yaw, *s])
        if down:
            seed[4] = 1.2
        ik = K.solve_ik(arm, T, seed, follow_orientation=down, reference_gain=0.0, max_iterations=80,
                        limit_margin=margin, min_joint_height=ws.min_joint_height)
        if ik.pos_error < 2e-3 and (not down or ik.ori_error < 0.05) \
                and not ws.check_arm_points(arm.fk_points(ik.q)):
            return True
    return False


def main():
    parser = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument('--config', default=None)
    args = parser.parse_args()
    cfg = load_config(args.config)
    ws, margin = cfg.workspace, cfg.ned2.joint_limit_margin
    tcp = cfg.ned2.tcp if isinstance(cfg.ned2.tcp, list) else [0.085, 0, 0, 0, 0, 0]
    arm = K.ned2(tcp[:3], tcp[3:])

    # 1. Querschnitt bei Gierwinkel 0 (bzw. Mitte des Sektors)
    yaw = np.radians(np.mean(ws.yaw_deg))
    rs = np.linspace(ws.radius[0], ws.radius[1], 13)
    zs = np.linspace(ws.z[0], ws.z[1], 13)
    for down in (False, True):
        title = 'Greifer senkrecht nach unten' if down else 'nur Position'
        print('\nQuerschnitt (%s), # = erreichbar, . = nicht erreichbar, Leer = außerhalb' % title)
        print('       r = %.2f ... %.2f m' % (rs[0], rs[-1]))
        hits = total = 0
        for z in zs[::-1]:
            row = ''
            for r in rs:
                p = np.array([r * np.cos(yaw), r * np.sin(yaw), z])
                if not ws.contains(p):
                    row += ' '
                    continue
                ok = reachable(arm, ws, margin, p, down)
                hits += ok
                total += 1
                row += '#' if ok else '.'
            print('z=%.2f  %s' % (z, row))
        print('-> %d %% der Punkte erreichbar' % (100 * hits / max(total, 1)))

    # 2. Zufallspunkte im ganzen Arbeitsraum (nur Position)
    rng = np.random.default_rng(0)
    pts = []
    while len(pts) < 150:
        r = rng.uniform(*ws.radius)
        a = np.radians(rng.uniform(*ws.yaw_deg))
        p = np.array([r * np.cos(a), r * np.sin(a), rng.uniform(*ws.z)])
        if ws.contains(p):
            pts.append(p)
    bad = [p for p in pts if not reachable(arm, ws, margin, p, False)]
    print('\nGesamter Arbeitsraum: %d von %d Zufallspunkten erreichbar' % (len(pts) - len(bad), len(pts)))
    for p in bad[:10]:
        print('  nicht erreichbar: (%.3f, %.3f, %.3f)' % tuple(p))

    # 3. Abdeckung: Anteil der wx250s-Positionen, die ohne Begrenzung abgebildet werden
    wx = K.wx250s()
    inside = 0
    n = 2000
    for _ in range(n):
        q = rng.uniform(wx.lower * 0.8, wx.upper * 0.8)
        p_wx = wx.fk(q)[:3, 3]
        if p_wx[2] < 0.0:
            continue
        inside += ws.contains(cfg.mapping.position(p_wx))
    print('\nAbbildung (scale %.2f): %d %% zufälliger wx250s-Haltungen landen im Arbeitsraum'
          % (cfg.mapping.scale, 100 * inside / n))


if __name__ == '__main__':
    main()
