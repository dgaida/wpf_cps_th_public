#!/usr/bin/env bash
# Startet den Interbotix-ROS2-Treiber für den wx250s (mit RViz).
#   scripts/start_wx250s.sh                 echte Hardware an /dev/ttyDXL
#   scripts/start_wx250s.sh use_sim:=true   simulierter Arm (ohne Hardware)
#   scripts/start_wx250s.sh use_rviz:=false
set -e
source "${INTERBOTIX_WS:-$HOME/interbotix_ws}/install/setup.bash"
exec ros2 launch interbotix_xsarm_control xsarm_control.launch.py robot_model:=wx250s "$@"
