#!/usr/bin/env python3
"""Zeigt den Zustand des Ned2 und prüft das lokale Kinematikmodell gegen den Roboter.

    python3 scripts/ned2_status.py               nur lesen
    python3 scripts/ned2_status.py --calibrate   zusätzlich (neu) kalibrieren, auch wenn der Ned2
                                                 schon kalibriert ist (Arm bewegt sich!)
"""

import argparse
import sys
from pathlib import Path

import numpy as np
import roslibpy

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
from ned2_wx250s_sync import kinematics as K  # noqa: E402
from ned2_wx250s_sync.config import load_config  # noqa: E402
from ned2_wx250s_sync.follower_ned2 import Ned2Follower  # noqa: E402


def check_fk(ned: Ned2Follower, arm: K.SerialArm, samples: int = 8) -> float:
    """Vergleicht die lokale FK mit dem FK-Service des Ned2 (rechnet nur, bewegt nichts)."""
    srv = roslibpy.Service(ned.ros, '/niryo_robot/kinematics/forward', 'niryo_robot_arm_commander/GetFK')
    rng = np.random.default_rng(0)
    worst = 0.0
    for _ in range(samples):
        q = rng.uniform(arm.lower, arm.upper)
        pose = srv.call(roslibpy.ServiceRequest({'joints': q.tolist()}), timeout=5)['pose']
        p = pose['position']
        worst = max(worst, float(np.linalg.norm(arm.fk(q)[:3, 3] - [p['x'], p['y'], p['z']])))
    return worst


def main():
    parser = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument('--config', default=None)
    parser.add_argument('--calibrate', action='store_true')
    args = parser.parse_args()
    cfg = load_config(args.config)

    ned = Ned2Follower(cfg.ned2.host, cfg.ned2.port)
    ned.connect()
    try:
        hs = ned.hardware_status or {}
        print('Verbindung      : %s:%d' % (cfg.ned2.host, cfg.ned2.port))
        print('Kalibriert      : %s' % ('nein' if ned.calibration_needed else 'ja'))
        print('Learning-Mode   : %s' % ('an (Arm frei)' if ned.learning_mode else 'aus (Drehmoment an)'))
        print('Not-Halt        : %s' % ('GEDRÜCKT' if ned.estop else 'nein'))
        print('Werkzeug-ID     : %s' % ned.tool_id)
        tcp = ned.tcp_offset()
        print('TCP             : %s' % (('xyz %s rpy %s' % tcp) if tcp else 'deaktiviert'))
        print('Gelenke [rad]   : %s' % np.round(ned.joints(), 3))
        print('Temperaturen    : %s' % dict(zip(hs.get('motor_names', []), hs.get('temperatures', []))))
        errors = ned.hardware_errors()
        print('Hardwarefehler  : %s' % ('; '.join(errors) if errors else 'keine'))

        arm = K.ned2(*(tcp or ((0, 0, 0), (0, 0, 0))))
        worst = check_fk(ned, arm)
        print('Kinematik-Check : max. Abweichung %.2f mm zur FK des Roboters %s'
              % (worst * 1000, '(OK)' if worst < 1e-3 else '(PRÜFEN!)'))

        if args.calibrate:
            already = not ned.calibration_needed
            question = ('Ned2 ist bereits kalibriert. Trotzdem neu kalibrieren?' if already
                        else 'Ned2 jetzt kalibrieren?')
            if input(question + ' Der Arm bewegt sich! [j/N] ').strip().lower() in ('j', 'ja'):
                if already:
                    ned.request_new_calibration()
                print('Kalibriere ...')
                ned.calibrate()
                print('Fertig.')
            else:
                print('Abgebrochen.')
    finally:
        ned.close()


if __name__ == '__main__':
    main()
