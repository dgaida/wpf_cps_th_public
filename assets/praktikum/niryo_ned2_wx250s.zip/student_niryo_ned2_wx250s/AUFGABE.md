# Praktikum: Ein Roboter führt den anderen

Leader-Follower-Synchronisation: **WidowX 250s → Niryo Ned2**

## 1. Worum geht es?

Ihr führt einen **WidowX 250s** (kurz wx250s, Trossen/Interbotix) von Hand. Ein
**Niryo Ned2** soll diese Bewegung in Echtzeit nachmachen: die Position des
Greifers, seine Orientierung und das Öffnen und Schließen.

Das klingt einfach, ist es aber nicht:

* Die Roboter sind **unterschiedlich groß** und haben **verschiedene Gelenkgrenzen**.  
  Der Ned2 kann nicht jede Pose einnehmen, die der wx250s vormacht.  
* Ihr müsst deshalb einen **Arbeitsraum** festlegen, in dem sich der Ned2 bewegen  
  darf. Führt jemand den wx250s darüber hinaus, soll der Ned2 an der Grenze
  entlanggleiten – nicht stehen bleiben, nicht ruckeln und vor allem nie
  hinausfahren.  
* Beide Roboter hängen an **verschiedenen Systemen**: der wx250s an ROS2 auf dem  
  Jetson, der Ned2 an ROS1 auf seinem eigenen Rechner, erreichbar über das Netz.
  Den Ned2 steuert ihr wahlweise über **ROS (rosbridge)** oder über Niryos
  Python-Bibliothek **pyniryo** (Abschnitt 4).  
* Am Ende bewegt sich ein **echter Roboter** auf Befehle eures Programms hin.  
  Fehler kosten hier nicht nur Zeit.

### Lernziele

Nach dem Praktikum könnt ihr …

* die Vorwärtskinematik eines seriellen Roboters mit dem *Product of Exponentials*  
  aufstellen und gegen den echten Roboter prüfen,  
* eine numerische inverse Kinematik mit Gelenkgrenzen, Singularitäten und  
  Prioritäten zwischen Teilaufgaben implementieren,  
* einen Arbeitsraum definieren, Punkte darauf projizieren und seine  
  Erreichbarkeit nachweisen,  
* eine Echtzeit-Regelschleife mit Geschwindigkeits- und Sicherheitsgrenzen bauen,  
* zwei Roboter anbinden – den wx250s über ROS2, den Ned2 über rosbridge oder pyniryo,  
* Software für reale Roboter schrittweise und sicher in Betrieb nehmen.  

## 2. Aufbau im Labor

**Arbeitsplatz ist der Rechner „Jetson CPS 1242“.** Für
das Praktikum müsst ihr diesen Rechner nutzen: Nur an ihm ist der wx250s per USB
angeschlossen, und von ihm aus ist der Ned2 über das Labornetz erreichbar. Alle
benötigten Programme und Bibliotheken sind dort installiert.

| Komponente | Details |
|---|---|
| Jetson CPS 1242 (Pflicht) | Jetson Orin, Ubuntu 20.04, ROS2 Galactic, Interbotix-Workspace in `~/interbotix_ws`, `roslibpy` und `pyniryo` installiert |
| WidowX 250s (Leader) | USB am Jetson CPS 1242 (`/dev/ttyDXL`), Treiber `interbotix_xs_sdk` (ROS2), Namespace `/wx250s`, 6 Gelenke + Greifer |
| Niryo Ned2 (Follower) | `192.168.0.141`, Niryo-Software 5.0 (ROS Noetic auf dem Roboter), rosbridge auf Port 9090, pyniryo-Server auf Port 40001, Greifer „Standard Gripper“ (Werkzeug-ID 11) |

```
wx250s ──USB──> Interbotix xs_sdk (ROS2) ──/wx250s/joint_states──┐
               (alles auf dem Jetson CPS 1242)                    v
              euer Programm (ca. 30 Hz, Python)
              FK wx250s -> Abbildung -> Arbeitsraum -> IK Ned2 -> Prüfung -> Begrenzung
                                                                  │
Ned2 <── rosbridge (Port 9090) oder pyniryo (Port 40001) ─────────┘
```

Die Bedienung (Treiber starten, Statusskript usw.) steht in der `README.md`.

## 3. Sicherheitsregeln (verbindlich)

1. **Jede neue Programmversion durchläuft drei Stufen:** zuerst offline (Tests,  
   simulierter Leader), dann ein Probelauf mit `--dry-run` am echten wx250s,
   bei dem der Ned2 sich nicht bewegt, und erst danach live.  
2. **Live-Tests nur, wenn eine zweite Person den Not-Halt des Ned2 in der Hand  
   hat** und niemand im Bewegungsbereich steht.  
3. Arbeitsraum und Geschwindigkeitsgrenzen (`config/sync.yaml`) **nicht ohne  
   Rücksprache vergrößern**.  
4. Schaltet ihr das Drehmoment des wx250s ab, **haltet den Arm fest**, sonst fällt er.  
5. Beim **ROS-Weg** gehen eure Befehle direkt an den Trajektorien-Controller des  
   Ned2; die Sicherheitsprüfungen der Niryo-Software greifen dabei **nicht**. Beim
   **pyniryo-Weg** prüft Niryo zusätzlich. In beiden Fällen ist euer Code für
   Gelenkgrenzen, Arbeitsraum und Geschwindigkeit verantwortlich.  
6. Die Kalibrierung des Ned2 bewegt den Arm. Vorher den Bereich freimachen.  

## 4. Zwei Wege zum Ned2

|  | ROS (rosbridge) | pyniryo |
|---|---|---|
| Bibliothek | `roslibpy`, WebSocket an Port 9090 | `pyniryo`, TCP an Port 40001 |
| Gelenkziele | absolut, 30-mal pro Sekunde an den Trajektorien-Controller | relative Jog-Befehle, Niryo übernimmt höchstens etwa 6 pro Sekunde |
| Nachführen | flüssig | stufiger, deutlich verzögert |
| Prüfungen der Niryo-Software | umgangen | aktiv |
| Einstieg | etwas mehr ROS-Wissen (Topics, Services, Nachrichtentypen) | einfache Funktionsaufrufe |

Für jeden Weg gibt es ein Tutorial und ein lauffähiges Beispielskript, das sich
verbindet, den Status liest, kalibriert, den Arm bewegt und den Greifer schaltet:

* [Tutorial ROS (rosbridge)](aufgabe/tutorial_ned2_rosbridge.md) – [`beispiele/ned2_rosbridge.py`](beispiele/ned2_rosbridge.py)  
* [Tutorial pyniryo](aufgabe/tutorial_ned2_pyniryo.md) – [`beispiele/ned2_pyniryo.py`](beispiele/ned2_pyniryo.py)  

Ohne Option lesen die Skripte nur; mit `--bewegen` bewegen sie den Ned2 (nach
Rückfrage, zweite Person am Not-Halt). Probiert beide in Teil 1 aus und
entscheidet euch spätestens in Teil 4 für einen Weg. Wer beide umsetzt, kann sie
im Zusatzteil vergleichen.

## 5. Mit oder ohne Gerüst

Ihr könnt auf zwei Wegen arbeiten.

**Mit Gerüst.** Ihr bekommt die Projektstruktur. Vollständig enthalten sind:
Konfiguration (`config/`, `config.py`), simulierter Leader (`sim_leader.py`),
RViz-Visualisierung (`visualization.py`), Tastaturabfrage (`keyboard.py`), die
Beispielskripte in `beispiele/`, die Hilfsskripte in `scripts/` und die Tests in
`tests/`. In den Kernmodulen sind die Funktionskörper leer (`TODO`); Signaturen
und Docstrings beschreiben, was jede Funktion leisten soll. Welche Funktionen zu
einem Teil gehören, steht dort unter **Gerüst**. Die Tests prüfen genau diese
Schnittstellen, ihr seht also jederzeit, wie weit ihr seid. Für den Ned2 gibt es
zwei Module: `follower_ned2.py` (ROS) und `follower_ned2_pyniryo.py` (pyniryo);
ihr braucht nur das zu eurem Weg.

**Ohne Gerüst.** Ihr wählt Architektur und Bibliotheken selbst (z. B. die
installierte Bibliothek `modern_robotics`). Die mitgelieferten Tests passen dann
nicht direkt. Ihr müsst aber dieselben **Abnahmekriterien** nachweisen, etwa
mit eigenen Tests oder angepassten Kopien.

Ihr könnt auch mischen: z. B. das Gerüst für die Roboteranbindung nutzen und
Kinematik sowie Regler frei bauen.

## 6. Aufgabenteile

| Teil | Inhalt | Gerüst-Dateien | Hardware |
|---|---|---|---|
| 1 | [Roboter kennenlernen und Vorwärtskinematik](aufgabe/teil1_kinematik.md) | `kinematics.py` | nur lesend |
| 2 | [Abbildung und Arbeitsraum](aufgabe/teil2_abbildung_arbeitsraum.md) | `mapping.py`, `workspace.py` | nein |
| 3 | [Inverse Kinematik und Regelzyklus](aufgabe/teil3_ik_regelzyklus.md) | `kinematics.py`, `controller.py` | nein |
| 4 | [Roboteranbindung und Live-Betrieb](aufgabe/teil4_roboter_live.md) | `leader_wx250s.py`, `follower_ned2.py` oder `follower_ned2_pyniryo.py`, `sync.py` | ja |
| Zusatz | [Erweiterungen (optional)](aufgabe/zusatz_erweiterungen.md) | – | je nach Thema |

Teil 2 und 3 laufen vollständig ohne Roboter. Wenn ihr zu zweit arbeitet, kann
eine Person die Roboteranbindung aus Teil 4 parallel dazu angehen.

Jeder Teil hat eine eigene Seite im Ordner [`aufgabe/`](aufgabe/) mit Ziel,
Aufgaben, Hinweisen, den Gerüst-Funktionen und den Abnahmekriterien.

## 7. Abgabe

* Lauffähiger Code; alle Abnahmetests grün (bzw. eigene, gleichwertige Tests ohne Gerüst).  
* Kurzer Bericht:  
  * Skizzen aus Teil 1,  
  * Arbeitsraum mit Begründung und Ausgabe von `check_workspace.py`,  
  * welchen Weg zum Ned2 ihr gewählt habt und warum,  
  * Antworten auf die Fragen,  
  * Messergebnisse aus Teil 4,  
  * was nicht funktioniert hat und warum.  
* Video der Live-Demo.  

## 8. Literatur und Dokumentation

* K. M. Lynch, F. C. Park: *Modern Robotics – Mechanics, Planning, and Control*,  
  Cambridge University Press 2017, Kap. 4–6 (Vorwärtskinematik, Jacobi-Matrix,
  inverse Kinematik). Frei verfügbar unter
  <http://hades.mech.northwestern.edu/index.php/Modern_Robotics>.  
* S. R. Buss: *Introduction to Inverse Kinematics with Jacobian Transpose,  
  Pseudoinverse and Damped Least Squares Methods*, 2004.  
* B. Siciliano, J.-J. Slotine: *A General Framework for Managing Multiple Tasks  
  in Highly Redundant Robotic Systems*, ICAR 1991 (Aufgaben mit Prioritäten).  
* Interbotix X-Series Arms: <https://docs.trossenrobotics.com/interbotix_xsarms_docs/>  
* Niryo Ned2 (ROS-Schnittstellen): <https://docs.niryo.com/>  
* roslibpy: <https://roslibpy.readthedocs.io/>  
* pyniryo: <https://pypi.org/project/pyniryo/>  
