"""Berechnet aus der Haltung des wx250s das nächste Gelenkziel für den Ned2.

Ablauf je Zyklus:
  1. Leader-Gelenke filtern, TCP-Pose des wx250s berechnen (FK)
  2. Pose auf den Ned2 abbilden (Skalierung, Drehung, Spiegelung)
  3. Position in den Arbeitsraum projizieren
  4. Kartesische Geschwindigkeit begrenzen
  5. IK für den Ned2 (Position vor Orientierung), zuerst lokal um die aktuelle Stellung
  6. Sicherheitsprüfung (Gelenkgrenzen, Arbeitsraum, Gelenkhöhen)
  7. Gelenkgeschwindigkeit begrenzen; große Sprünge -> langsame Annäherung
  8. Prüfung der tatsächlich gesendeten Stellung – sie liegt immer im Arbeitsraum
Ohne Hardware nutzbar und daher direkt testbar.
"""

import time
from dataclasses import dataclass, field
from typing import List, Optional, Tuple

import numpy as np

from . import kinematics as K
from .config import SyncConfig


@dataclass
class StepResult:
    q_command: np.ndarray
    leader_tcp: np.ndarray
    mapped_tcp: np.ndarray
    goal_tcp: np.ndarray
    commanded_tcp: np.ndarray
    clamped: bool
    holding: bool
    approaching: bool
    ik_pos_error: float
    ik_ori_error: float
    problems: List[str] = field(default_factory=list)
    orientation_active: bool = True


class SyncController:
    # Kartesische Grenzgeschwindigkeiten im Folgebetrieb
    MAX_LINEAR_SPEED = 0.35   # m/s
    MAX_ANGULAR_SPEED = 2.0   # rad/s
    # Ab diesem Sprung der IK-Lösung zwischen zwei Zyklen (rad) langsam überblenden
    JUMP_THRESHOLD = 0.35
    # Annäherung beendet, wenn das kartesische Ziel so weit eingeholt ist
    # (der Rest wird mit voller Geschwindigkeit in ~0.15 s aufgeholt)
    APPROACH_DONE_DISTANCE = 0.05   # m
    APPROACH_DONE_ANGLE = 0.3       # rad
    # Braucht der Gelenkbegrenzer mehr Zyklen als das, wird gelenkweise interpoliert
    INTERPOLATION_RATIO = 3.0
    # Zusätzliche Startwerte (Gelenke 2..6) für die reine Positions-IK
    POSITION_SEEDS = ([-0.8, 0.5, 0.0, 1.0, 0.0],
                      [0.3, -1.0, 0.0, 1.2, 0.0],
                      [-1.2, 0.8, 0.0, 0.5, 0.0],
                      [0.0, 0.0, 0.0, 0.0, 0.0])

    def __init__(self, cfg: SyncConfig, follower: K.SerialArm, leader: Optional[K.SerialArm] = None):
        self.cfg = cfg
        self.follower = follower
        self.leader = leader or K.wx250s()
        self.mapping = cfg.mapping
        self.workspace = cfg.workspace
        self.vmax = np.asarray(cfg.ned2.max_joint_velocity, dtype=float)
        if self.vmax.shape != (6,) or np.any(self.vmax <= 0):
            raise ValueError('ned2.max_joint_velocity braucht 6 positive Werte')
        self._q_leader: Optional[np.ndarray] = None
        self._q_cmd: Optional[np.ndarray] = None
        self._q_valid: Optional[np.ndarray] = None
        self._T_cart: Optional[np.ndarray] = None
        self._next_attempt = 0
        self._switching = False
        self.orientation_active = cfg.ik.follow_orientation
        self.approaching = True

    # ------------------------------------------------------------------
    def reset(self, q_follower: np.ndarray):
        """Neustart (Programmstart, nach einer Pause) ab der gemessenen Stellung des Ned2.

        Args:
            q_follower: Gemessene Gelenkwinkel (6,) des Ned2.
        """
        # TODO (Teil 3): Zustand des Regelzyklus zurücksetzen; die kommandierte Stellung beginnt bei
        # q_follower, danach langsame Anfahrt (R4).
        raise NotImplementedError("TODO: implement reset")

    def goal_pose(self, q_leader: np.ndarray):
        """Zielpose des Ned2 zu einer Haltung des wx250s.

        Args:
            q_leader: Gelenkwinkel (6,) des wx250s.

        Returns:
            Tuple: (TCP-Pose des wx250s, abgebildete Pose, Zielpose im Arbeitsraum, begrenzt?) mit Posen (4, 4).
        """
        # TODO (Teil 3): FK des wx250s, Abbildung (Teil 2), Position in den Arbeitsraum projizieren.
        raise NotImplementedError("TODO: implement goal_pose")

    def step(self, q_leader_raw: np.ndarray, dt: float) -> StepResult:
        """Ein Regelzyklus: nächstes Gelenkziel des Ned2 aus der Haltung des wx250s.

        reset() muss vorher aufgerufen worden sein.

        Args:
            q_leader_raw: Gemessene Gelenkwinkel des wx250s (mindestens 6 Werte).
            dt: Zeit seit dem letzten Zyklus in s.

        Returns:
            StepResult: zu sendende Stellung q_command und Diagnosewerte (holding = Ned2 hält an,
            approaching = langsame Anfahrt, clamped = Ziel wurde auf den Arbeitsraum begrenzt).
        """
        # TODO (Teil 3): Regelzyklus nach aufgabe/teil3_ik_regelzyklus.md (Filter, Abbildung, Arbeitsraum,
        # kartesische Begrenzung, IK, Prüfung, Gelenkbegrenzung, Prüfung der gesendeten Stellung),
        # so dass R1 bis R6 erfüllt sind.
        raise NotImplementedError("TODO: implement step")

    def _solve_ik(self, T: np.ndarray, q_ref: np.ndarray, local_bounds) -> Tuple[K.IKResult, bool]:
        """IK in der Nähe der aktuellen Stellung, sonst mit weiteren Startwerten.

        Args:
            T: Zielpose (4, 4) des Ned2.
            q_ref: Referenzhaltung (6,) (gelenkweise Entsprechung des wx250s).
            local_bounds: (untere, obere) Gelenkgrenzen für die lokale Suche oder None.

        Returns:
            Tuple[K.IKResult, bool]: (Ergebnis, Teilschritt). Teilschritt = lokale Lösung, die das Ziel noch
            nicht erreicht, ihm aber näher kommt.
        """
        # TODO (Teil 3): zuerst IK um die aktuelle Stellung (in local_bounds), sonst weitere Startwerte
        # (Referenzhaltung, POSITION_SEEDS) im Zeitbudget probieren.
        raise NotImplementedError("TODO: implement _solve_ik")

    def _ik(self, T: np.ndarray, seed: np.ndarray, q_ref: np.ndarray, follow_orientation: bool,
            bounds=None) -> K.IKResult:
        ik_cfg = self.cfg.ik
        return K.solve_ik(self.follower, T, seed, q_ref, follow_orientation=follow_orientation,
                          reference_gain=ik_cfg.reference_gain, damping=ik_cfg.damping,
                          limit_margin=self.cfg.ned2.joint_limit_margin,
                          max_iterations=ik_cfg.max_iterations,
                          min_joint_height=self.workspace.min_joint_height, bounds=bounds)

    def check(self, q: np.ndarray, floor_only: bool = False) -> List[str]:
        """Sicherheitsprüfung einer Gelenkstellung des Ned2.

        Args:
            q: Gelenkwinkel (6,).
            floor_only: Nur z_min statt des ganzen Arbeitsraums prüfen (Zusatz: Start außerhalb).

        Returns:
            List[str]: Gefundene Probleme; leer = die Stellung darf an den Ned2 gesendet werden.
        """
        # TODO (Teil 3): Gelenkgrenzen, TCP im Arbeitsraum (Toleranz ik.workspace_tolerance) und Gelenkhöhen
        # prüfen (Anforderung R1).
        raise NotImplementedError("TODO: implement check")


def _limit_pose_step(T_from: np.ndarray, T_to: np.ndarray, max_lin: float, max_ang: float) -> np.ndarray:
    """Begrenzt den Schritt von einer Pose zur nächsten.

    Args:
        T_from: Ausgangspose (4, 4).
        T_to: Zielpose (4, 4).
        max_lin: Größte Verschiebung in m.
        max_ang: Größte Drehung in rad.

    Returns:
        np.ndarray: Pose (4, 4) auf dem Weg von T_from nach T_to.
    """
    # TODO (Teil 3): Translation auf max_lin und Drehung (Rotationsvektor) auf max_ang begrenzen.
    raise NotImplementedError("TODO: implement _limit_pose_step")
