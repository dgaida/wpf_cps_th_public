"""Niryo Ned2 über pyniryo (TCP-Port 40001) ansteuern – Alternative zu rosbridge.

Gelenkziele gehen als Jog-Befehle (relative Verschiebungen, ``jog_joints``) an
den Jog-Regler des Ned2. Dessen Verhalten in der Niryo-Software 5.0
(niryo_robot_arm_commander/scripts/jog_controller.py):

* Ziel = Bezugspunkt + Verschiebung (je Gelenk max. 0,2 rad); Bezugspunkt ist
  das zuletzt veröffentlichte Ziel
* veröffentlicht wird alle 0,15 s; kommen in einem Takt mehrere Befehle an,
  gilt der letzte (sie werden nicht aufsummiert)
* mehr als 0,5 s ohne Befehl -> Jog aus (geprüft einmal pro Sekunde)
* Jog einschalten – auch ein schon eingeschaltetes – setzt den Bezugspunkt auf
  die gemessene Lage; ein Befehl bei ausgeschaltetem Jog schaltet ihn ein
* Nachführfehler > 0,2 rad -> Niryo wertet das als Kollision und schaltet den
  Learning-Mode ein
* ein Jog-Befehl schaltet einen aktiven Learning-Mode aus und wird auch ohne
  Kalibrierung ausgeführt

Der echte Arm hinkt seiner Vorgabe merklich hinterher. Verschiebungen gegen die
*gemessene* Lage zu rechnen, schaukelt sich deshalb auf (Hin- und Herfahren).
Stattdessen sorgt JogPlanner dafür, dass Niryo jeden Befehl genau einmal
übernimmt, und rechnet Niryos Bezugspunkt exakt mit.
"""

import logging
import queue
import threading
import time
import warnings
from typing import Optional

import numpy as np

from .follower_ned2 import GRIPPER_TOOL_IDS, Ned2Error

log = logging.getLogger(__name__)

JOG_PERIOD = 0.15        # s, Takt des Niryo-Jog-Reglers (jog_timer_rate_sec)
JOG_MAX_SHIFT = 0.2      # rad, Begrenzung je Befehl im Niryo-Jog-Regler (jog_limits/joints)
JOG_IDLE_DISABLE = 0.5   # s ohne Befehl, nach denen Niryo Jog abschaltet
# Über pyniryo (Software 5.0) nicht lesbar; Wert per rosbridge vom Roboter gelesen
KNOWN_TCP = {11: ((0.085, 0.0, 0.0), (0.0, 0.0, 0.0))}


class JogPlanner:
    """Plant Jog-Befehle so, dass Niryos Bezugspunkt jederzeit bekannt ist.

    * Zwischen zwei Befehlen liegt mehr als ein Niryo-Takt. Niryo übernimmt so
      jeden Befehl genau einmal, und sein Bezugspunkt ist danach
      ``Bezugspunkt + Verschiebung`` – ohne Rückkopplung auf die nachhinkende Messung.
    * Nach einer Pause hat Niryo Jog womöglich abgeschaltet. Dann wird Jog gezielt
      ausgeschaltet (``resync``); der nächste Befehl schaltet ihn wieder ein, und
      Niryo setzt den Bezugspunkt auf die gemessene Lage – dieselbe, die hier als
      Basis dient. (Einschalten bei laufendem Jog würde den Bezugspunkt mitten in
      der Bewegung auf die nachhinkende Lage zurücksetzen.)
    """

    SPACING = JOG_PERIOD + 0.01            # s vom Ende eines Befehls bis zum nächsten
    RESYNC_IDLE = JOG_IDLE_DISABLE - 0.1   # s Pause, ab der neu synchronisiert wird
    MIN_SHIFT = 1e-4                       # rad, kleinere Verschiebungen werden nicht gesendet

    def __init__(self, max_shift: float = 0.15):
        self.max_shift = min(max_shift, JOG_MAX_SHIFT)
        self.reference: Optional[np.ndarray] = None
        self.last_sent = -1e9

    def plan(self, now: float, target, measured):
        """Plant den nächsten Jog-Befehl.

        Args:
            now: Aktuelle Zeit in s (time.monotonic()).
            target: Gewünschte Gelenkwinkel (6,).
            measured: Gemessene Gelenkwinkel (6,).

        Returns:
            None, wenn jetzt nichts gesendet wird, sonst (resync, Basis, Verschiebung): resync = vorher Jog
            ausschalten, Basis = Niryos Bezugspunkt, Verschiebung = Argument für jog_joints.
        """
        # TODO (Teil 4, Weg b): frühestens SPACING s nach dem letzten Befehl; nach einer Pause (RESYNC_IDLE)
        # von der gemessenen Lage aus neu synchronisieren, sonst vom mitgerechneten Bezugspunkt; alle
        # Gelenke im selben Verhältnis auf max_shift begrenzen, Verschiebungen unter MIN_SHIFT nicht senden.
        raise NotImplementedError("TODO: implement plan")

    def sent(self, now: float, base, shift, ok: bool):
        """Meldet einen gesendeten Befehl (Zeitpunkt der Antwort).

        Args:
            now: Zeitpunkt der Antwort in s.
            base: Basis aus plan().
            shift: Gesendete Verschiebung.
            ok: False, wenn Niryo den Befehl abgelehnt hat; dann wird neu synchronisiert.
        """
        # TODO (Teil 4, Weg b): Zeitpunkt merken und den Bezugspunkt mitrechnen (bei Fehler verwerfen).
        raise NotImplementedError("TODO: implement sent")


def _connect_pyniryo(host: str):
    try:
        from pyniryo import NiryoRobot
    except ImportError as exc:
        raise Ned2Error('pyniryo fehlt: pip3 install --user --no-deps pyniryo==1.2.5 (%s)' % exc)
    robot = NiryoRobot(verbose=False)
    robot.connect(host)        # Port 40001 ist in pyniryo fest eingestellt
    return robot


class Ned2PyNiryoFollower:
    STATUS_PERIOD = 0.5      # s zwischen Abfragen des Hardwarestatus
    TARGET_TIMEOUT = 0.3     # s, ältere Ziele werden nicht mehr gesendet

    def __init__(self, host: str, max_shift: float = 0.15, robot_factory=_connect_pyniryo):
        self.host = host
        self._planner = JogPlanner(max_shift)
        self._factory = robot_factory
        self._robot = None
        self._lock = threading.Lock()
        self._jobs: 'queue.Queue' = queue.Queue()
        self._stop = threading.Event()
        self._thread: Optional[threading.Thread] = None
        self._joints: Optional[np.ndarray] = None
        self._joints_stamp = 0.0
        self._target: Optional[np.ndarray] = None
        self._target_stamp = 0.0
        self._last_status = 0.0
        self._failed: Optional[Exception] = None
        self.learning_mode: Optional[bool] = None
        self.hardware_status = None
        self.tool_id: Optional[int] = None
        self.busy: Optional[str] = None     # z. B. 'Greifer schaltet' – Arm wird so lange nicht bewegt
        self.jog_commands = 0
        self.jog_rejected = 0
        # über pyniryo mit Software 5.0 nicht abfragbar
        self.estop = False
        self.collision = False
        self.arm_commander_active = False

    # ------------------------------------------------------------------
    # Verbindung / Status
    # ------------------------------------------------------------------
    def connect(self, timeout: float = 10.0):
        """Verbindet sich über pyniryo mit dem Ned2 und startet den Roboter-Thread.

        Args:
            timeout: Wartezeit in s.

        Raises:
            Ned2Error: Keine Verbindung.
        """
        # TODO (Teil 4, Weg b): Verbindung über self._factory aufbauen, Gelenkwinkel, Status und Werkzeug lesen,
        # dann den Roboter-Thread (_worker) starten.
        raise NotImplementedError("TODO: implement connect")

    def close(self):
        self._stop.set()
        if self._thread is not None:
            self._thread.join(timeout=2.0)
        if self._robot is not None:
            try:
                self._robot.set_jog_control(False)
                self._robot.close_connection()
            except Exception:
                pass

    @property
    def connected(self) -> bool:
        return self._robot is not None and self._failed is None and (
            self._thread is None or self._thread.is_alive())

    def joints(self) -> Optional[np.ndarray]:
        with self._lock:
            return None if self._joints is None else self._joints.copy()

    def joints_age(self) -> float:
        with self._lock:
            return time.monotonic() - self._joints_stamp

    @property
    def calibration_needed(self) -> bool:
        return bool(self.hardware_status and self.hardware_status.calibration_needed)

    @property
    def calibration_in_progress(self) -> bool:
        return bool(self.hardware_status and self.hardware_status.calibration_in_progress)

    def hardware_errors(self) -> list:
        out = []
        hs = self.hardware_status
        if hs is not None:
            out = ['%s: %s' % (n, e) for n, e in zip(hs.motor_names, hs.hardware_errors) if e]
            message = str(hs.error_message).strip('\'" ')   # der Server setzt die Meldung in Hochkommas
            if message:
                out.append(message)
        if self._failed is not None:
            out.append('pyniryo: %s' % self._failed)
        return out

    def tcp_offset(self):
        """TCP relativ zu tool_link – pyniryo kann ihn bei Software 5.0 nicht lesen."""
        return KNOWN_TCP.get(self.tool_id)

    @property
    def has_gripper(self) -> bool:
        return self.tool_id in GRIPPER_TOOL_IDS

    def reset_collision(self):
        self.collision = False

    # ------------------------------------------------------------------
    # Befehle
    # ------------------------------------------------------------------
    def send_joints(self, q, duration: float = JOG_PERIOD):
        """Übergibt ein neues Gelenkziel; die Dauer legt der Niryo-Jog-Regler fest (0,15 s je Takt).

        Args:
            q: Gelenkziel (6,) in rad (vorher geprüft!).
            duration: Wird ignoriert (gleiche Schnittstelle wie Ned2Follower).
        """
        # TODO (Teil 4, Weg b): neuestes Ziel mit Zeitstempel thread-sicher ablegen; gesendet wird im Roboter-Thread.
        raise NotImplementedError("TODO: implement send_joints")

    def gripper(self, close: bool, tool_id: int, speed: int, max_torque: int, hold_torque: int):
        """Öffnet oder schließt den Greifer (blockiert den Roboter-Thread, der Arm steht so lange).

        Args:
            close: True = schließen, False = öffnen.
            tool_id: Werkzeug-ID des Greifers.
            speed: Geschwindigkeit des Greifers.
            max_torque: Maximales Drehmoment in Prozent.
            hold_torque: Haltemoment in Prozent.
        """
        # TODO (Teil 4, Weg b): open_gripper/close_gripper als Job im Roboter-Thread ausführen (_submit);
        # self.busy setzen, solange der Greifer schaltet.
        raise NotImplementedError("TODO: implement gripper")

    def calibrate(self, timeout: float = 120.0):
        """Automatische Kalibrierung. ACHTUNG: der Roboter bewegt sich dabei!"""
        # TODO (Teil 4, Weg b): calibrate_auto() im Roboter-Thread ausführen (_run), danach Status prüfen.
        raise NotImplementedError("TODO: implement calibrate")

    def set_learning_mode(self, enabled: bool, timeout: float = 5.0):
        """Schaltet den Learning-Mode (Arm frei beweglich) ein oder aus.

        Args:
            enabled: True = Arm frei, False = Drehmoment an.
            timeout: Wartezeit in s.

        Raises:
            Ned2Error: Der Zustand hat sich nicht geändert.
        """
        # TODO (Teil 4, Weg b): set_learning_mode im Roboter-Thread ausführen und den neuen Zustand prüfen.
        raise NotImplementedError("TODO: implement set_learning_mode")

    def stop_arm_commander(self):
        pass   # über pyniryo nicht nötig: Bewegungen des Commanders sind blockierend

    # ------------------------------------------------------------------
    # Roboter-Thread
    # ------------------------------------------------------------------
    def _submit(self, fn) -> dict:
        job = {'fn': fn, 'done': threading.Event(), 'result': None, 'error': None}
        if self._thread is None or not self._thread.is_alive():
            self._execute(job)
        else:
            self._jobs.put(job)
        return job

    def _run(self, fn, timeout: float):
        job = self._submit(fn)
        if not job['done'].wait(timeout):
            raise Ned2Error('Ned2 antwortet nicht innerhalb von %.0f s' % timeout)
        if job['error'] is not None:
            raise Ned2Error(str(job['error']))
        return job['result']

    def _execute(self, job):
        try:
            job['result'] = job['fn'](self._robot)
        except Exception as exc:
            job['error'] = exc
        finally:
            job['done'].set()

    def _poll_now(self):
        self._run(lambda r: self._poll_status(force=True), 5.0)

    def _worker(self):
        while not self._stop.is_set():
            try:
                while not self._jobs.empty():
                    self._execute(self._jobs.get_nowait())
                self._read_joints()
                self._poll_status()
                self._send_jog()
            except Exception as exc:   # Verbindung verloren o. ä.
                log.error('pyniryo: %s', exc)
                self._failed = exc
                return
            time.sleep(0.002)

    def _read_joints(self):
        q = np.array(list(self._robot.get_joints()), dtype=float)
        with self._lock:
            self._joints, self._joints_stamp = q, time.monotonic()

    def _poll_status(self, force: bool = False):
        self.learning_mode = bool(self._robot.get_learning_mode())
        now = time.monotonic()
        if force or now - self._last_status > self.STATUS_PERIOD:
            self.hardware_status = self._robot.get_hardware_status()
            self._last_status = now

    def _send_jog(self):
        """Schickt im Roboter-Thread das neueste Ziel als Jog-Befehl, wenn der JogPlanner es erlaubt."""
        # TODO (Teil 4, Weg b): nur mit aktuellem Ziel, ohne Learning-Mode und mit Kalibrierung senden;
        # JogPlanner.plan befragen, bei resync vorher set_jog_control(False), dann jog_joints(Verschiebung)
        # und JogPlanner.sent melden.
        raise NotImplementedError("TODO: implement _send_jog")
