"""RViz-Marker: Ned2-Arbeitsraum und Ziel, zurückgerechnet in den wx250s-Frame.

So sieht man beim Führen des wx250s direkt, in welchem Bereich der Ned2 exakt
folgt. Topic: /ned2_sync/markers (visualization_msgs/MarkerArray).
"""

from typing import Optional

import numpy as np
from geometry_msgs.msg import Point
from visualization_msgs.msg import Marker, MarkerArray

from .controller import StepResult
from .mapping import Mapping
from .workspace import Workspace


class SyncVisualizer:
    def __init__(self, node, frame_id: str, workspace: Workspace, mapping: Mapping):
        self.node = node
        self.frame_id = frame_id
        self.mapping = mapping
        self.pub = node.create_publisher(MarkerArray, '/ned2_sync/markers', 1)
        self._outline = self._make_outline(workspace)

    def _make_outline(self, ws: Workspace) -> Marker:
        m = self._marker(0, Marker.LINE_LIST, (0.2, 0.6, 1.0, 0.8))
        m.scale.x = 0.003
        segments = ws.boundary_lines()
        if ws.box_x is not None or ws.box_y is not None:
            bx = ws.box_x or (-ws.radius[1], ws.radius[1])
            by = ws.box_y or (-ws.radius[1], ws.radius[1])
            corners = [np.array([x, y, z]) for x in bx for y in by for z in ws.z]
            for i in range(8):
                for j in range(i + 1, 8):
                    if np.count_nonzero(corners[i] != corners[j]) == 1:
                        segments.append((corners[i], corners[j]))
        for a, b in segments:
            m.points.append(self._point(self.mapping.position_inverse(a)))
            m.points.append(self._point(self.mapping.position_inverse(b)))
        return m

    def publish(self, res: Optional[StepResult]):
        arr = MarkerArray()
        self._outline.header.stamp = self.node.get_clock().now().to_msg()
        arr.markers.append(self._outline)
        if res is not None:
            color = (1.0, 0.6, 0.0, 0.9) if res.clamped else (0.1, 0.9, 0.2, 0.9)
            arr.markers.append(self._sphere(1, self.mapping.position_inverse(res.goal_tcp), color, 0.025))
            arr.markers.append(self._sphere(2, self.mapping.position_inverse(res.commanded_tcp),
                                            (0.2, 0.4, 1.0, 0.9), 0.02))
        self.pub.publish(arr)

    def _marker(self, mid: int, mtype: int, rgba) -> Marker:
        m = Marker()
        m.header.frame_id = self.frame_id
        m.ns = 'ned2_sync'
        m.id = mid
        m.type = mtype
        m.action = Marker.ADD
        m.pose.orientation.w = 1.0
        m.color.r, m.color.g, m.color.b, m.color.a = rgba
        return m

    def _sphere(self, mid: int, p, rgba, size: float) -> Marker:
        m = self._marker(mid, Marker.SPHERE, rgba)
        m.header.stamp = self.node.get_clock().now().to_msg()
        m.pose.position = self._point(p)
        m.scale.x = m.scale.y = m.scale.z = size
        return m

    @staticmethod
    def _point(p) -> Point:
        return Point(x=float(p[0]), y=float(p[1]), z=float(p[2]))
