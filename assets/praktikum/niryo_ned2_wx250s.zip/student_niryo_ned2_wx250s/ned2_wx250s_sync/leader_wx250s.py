"""WidowX 250s als Leader über den Interbotix-ROS2-Treiber (xs_sdk).

Der Treiber muss laufen (scripts/start_wx250s.sh). Das Drehmoment wird
abgeschaltet, damit der Arm von Hand geführt werden kann; die Gelenkwinkel
kommen über /<robot_name>/joint_states.
"""

import threading
import time
from typing import Optional, Tuple

import numpy as np
import rclpy
from interbotix_xs_msgs.msg import JointGroupCommand, JointSingleCommand
from interbotix_xs_msgs.srv import TorqueEnable
from rclpy.executors import SingleThreadedExecutor
from rclpy.node import Node
from sensor_msgs.msg import JointState

from .kinematics import WX250S_JOINTS


class LeaderError(RuntimeError):
    pass


class Wx250sLeader:
    def __init__(self, node: Node, robot_name: str = 'wx250s'):
        """Verbindet sich mit dem Interbotix-Treiber des wx250s.

        Args:
            node: rclpy-Node, der in einem eigenen Thread läuft (RosSpinner).
            robot_name: Namespace des Treibers.
        """
        self.node = node
        self.ns = '/' + robot_name.strip('/')
        self._lock = threading.Lock()
        self._q: Optional[np.ndarray] = None
        self._finger: Optional[float] = None
        self._stamp = 0.0
        # TODO (Teil 4): /<ns>/joint_states abonnieren (-> _on_joint_states), Client für /<ns>/torque_enable
        # sowie Publisher für /<ns>/commands/joint_group und /<ns>/commands/joint_single anlegen.
        raise NotImplementedError("TODO: implement Wx250sLeader.__init__")

    def _on_joint_states(self, msg: JointState):
        """Speichert die Gelenkwinkel aus /<ns>/joint_states (thread-sicher).

        Args:
            msg: sensor_msgs/JointState des Treibers.
        """
        # TODO (Teil 4): Winkel in der Reihenfolge WX250S_JOINTS und left_finger (m) mit Zeitstempel speichern.
        raise NotImplementedError("TODO: implement _on_joint_states")

    def wait_for_driver(self, timeout: float = 10.0):
        """Wartet, bis der Treiber läuft und Gelenkwinkel liefert.

        Args:
            timeout: Wartezeit in s.

        Raises:
            LeaderError: Treiber oder Gelenkwinkel nicht innerhalb von timeout verfügbar.
        """
        # TODO (Teil 4): auf den Torque-Service und die ersten Gelenkwinkel warten.
        raise NotImplementedError("TODO: implement wait_for_driver")

    def latest(self) -> Tuple[Optional[np.ndarray], Optional[float], float]:
        """Letzter empfangener Zustand des wx250s.

        Returns:
            Tuple: (Gelenkwinkel (6,) oder None, Fingerposition in m oder None, Alter in s; inf ohne Daten).
        """
        # TODO (Teil 4): letzten Zustand thread-sicher zurückgeben.
        raise NotImplementedError("TODO: implement latest")

    def set_torque(self, enable: bool, timeout: float = 5.0):
        """Schaltet das Drehmoment aller Motoren ein oder aus.

        Args:
            enable: True = Drehmoment an (Arm hält), False = aus (Arm frei, vorher festhalten!).
            timeout: Wartezeit auf den Service in s.

        Raises:
            LeaderError: Service antwortet nicht.
        """
        # TODO (Teil 4): vor dem Einschalten die aktuellen Winkel als Ziel senden (sonst springt der Arm),
        # dann /<ns>/torque_enable (cmd_type="group", name="all") aufrufen und auf die Antwort warten.
        raise NotImplementedError("TODO: implement set_torque")


class RosSpinner:
    """Führt rclpy in einem Hintergrund-Thread aus."""

    def __init__(self, node_name: str = 'ned2_wx250s_sync'):
        # TODO (Teil 4): rclpy initialisieren, Node anlegen und mit einem Executor in einem
        # Hintergrund-Thread (_spin) ausführen.
        raise NotImplementedError("TODO: implement RosSpinner.__init__")

    def _spin(self):
        try:
            self._executor.spin()
        except Exception:
            pass

    def shutdown(self):
        """Beendet den Spin-Thread und rclpy in der richtigen Reihenfolge."""
        # TODO (Teil 4): erst Executor und Thread beenden, dann den Node zerstören und rclpy herunterfahren.
        raise NotImplementedError("TODO: implement shutdown")
