"""Niryo Ned2 über rosbridge (Port 9090) ansteuern.

Gelenkziele werden als einpunktige JointTrajectory direkt an den
ros_control-Controller des Ned2 gestreamt. Dabei werden die Prüfungen des
Niryo-Arm-Commanders umgangen – Gelenkgrenzen, Arbeitsraum und
Geschwindigkeiten müssen deshalb hier im Programm eingehalten werden.
"""

import logging
import threading
import time
import uuid
from typing import Optional, Sequence

import numpy as np
import roslibpy

from .kinematics import NED2_JOINTS

# Twisted 18.9 (Ubuntu 20.04) ist mit dem Logging von Python 3.8 inkompatibel
# (findCaller-Signatur); INFO-Meldungen von Twisted daher gar nicht erst weiterleiten
logging.getLogger('twisted').setLevel(logging.WARNING)
log = logging.getLogger(__name__)

TRAJECTORY_TOPIC = '/niryo_robot_follow_joint_trajectory_controller/command'
GRIPPER_TOOL_IDS = (11, 12, 13)
OPEN_GRIPPER, CLOSE_GRIPPER = 1, 2
GOAL_PREFIX = 'ned2_wx250s_sync_'


class Ned2Error(RuntimeError):
    pass


class Ned2Follower:
    def __init__(self, host: str, port: int = 9090):
        self.host, self.port = host, port
        self.ros = roslibpy.Ros(host=host, port=port)
        self._lock = threading.Lock()
        self._joints: Optional[np.ndarray] = None
        self._joints_stamp = 0.0
        self.learning_mode: Optional[bool] = None
        self.hardware_status: Optional[dict] = None
        self.estop = False
        self.collision = False
        self.arm_commander_active = False
        self.tool_id: Optional[int] = None
        self.tcp: Optional[dict] = None
        self._subs = []
        self._traj_pub = None
        self._tool_pub = None

    # ------------------------------------------------------------------
    # Verbindung / Status
    # ------------------------------------------------------------------
    def connect(self, timeout: float = 10.0):
        """Verbindet sich mit der rosbridge des Ned2 und abonniert alle Status-Topics.

        Args:
            timeout: Wartezeit für den Verbindungsaufbau in s.

        Raises:
            Ned2Error: Keine Verbindung oder keine Statusdaten.
        """
        # TODO (Teil 4, Weg a): rosbridge verbinden und die Status-Topics aus aufgabe/teil4_roboter_live.md
        # abonnieren; auf Gelenkwinkel, Hardwarestatus und Learning-Mode warten.
        raise NotImplementedError("TODO: implement connect")

    def close(self):
        for sub in self._subs:
            try:
                sub.unsubscribe()
            except Exception:
                pass
        for pub in (self._traj_pub, self._tool_pub):
            if pub is not None:
                try:
                    pub.unadvertise()
                except Exception:
                    pass
        if self.ros.is_connected:
            self.ros.close()

    def _subscribe(self, name, msg_type, cb):
        topic = roslibpy.Topic(self.ros, name, msg_type, queue_length=1)
        topic.subscribe(cb)
        self._subs.append(topic)

    def _on_joint_states(self, msg):
        names = msg['name']
        try:
            q = np.array([msg['position'][names.index(j)] for j in NED2_JOINTS])
        except ValueError:
            return
        with self._lock:
            self._joints = q
            self._joints_stamp = time.monotonic()

    def _on_collision(self, msg):
        if msg['data']:
            self.collision = True

    def _on_tool_result(self, msg):
        status = msg.get('status', {})
        if not status.get('goal_id', {}).get('id', '').startswith(GOAL_PREFIX):
            return
        if status.get('status') != 3:     # 3 = SUCCEEDED
            log.warning('Greifer: Niryo meldet Fehler – %s',
                        msg.get('result', {}).get('message') or status.get('text') or status.get('status'))

    def reset_collision(self):
        """Alte (gelatchte) Kollisionsmeldungen verwerfen, z. B. beim Start."""
        self.collision = False

    @staticmethod
    def _wait_for(pred, timeout, error):
        end = time.monotonic() + timeout
        while time.monotonic() < end:
            if pred():
                return True
            time.sleep(0.05)
        if error:
            raise Ned2Error(error)
        return False

    @property
    def connected(self) -> bool:
        return self.ros.is_connected

    def joints(self) -> Optional[np.ndarray]:
        with self._lock:
            return None if self._joints is None else self._joints.copy()

    def joints_age(self) -> float:
        with self._lock:
            return time.monotonic() - self._joints_stamp

    @property
    def calibration_needed(self) -> bool:
        return bool(self.hardware_status and self.hardware_status.get('calibration_needed'))

    @property
    def calibration_in_progress(self) -> bool:
        return bool(self.hardware_status and self.hardware_status.get('calibration_in_progress'))

    def hardware_errors(self) -> list:
        hs = self.hardware_status or {}
        out = []
        for name, err, msg in zip(hs.get('motor_names', []), hs.get('hardware_errors', []),
                                  hs.get('hardware_errors_message', [])):
            if err:
                out.append('%s: %s (%s)' % (name, err, msg))
        if hs.get('error_message'):
            out.append(hs['error_message'])
        return out

    def tcp_offset(self):
        """TCP relativ zu tool_link als (xyz, rpy) oder None, wenn deaktiviert/unbekannt."""
        if not self.tcp or not self.tcp.get('enabled'):
            return None
        p, r = self.tcp['position'], self.tcp['rpy']
        return (p['x'], p['y'], p['z']), (r['roll'], r['pitch'], r['yaw'])

    @property
    def has_gripper(self) -> bool:
        return self.tool_id in GRIPPER_TOOL_IDS

    # ------------------------------------------------------------------
    # Services
    # ------------------------------------------------------------------
    def _call(self, name, srv_type, request=None, timeout=10.0):
        srv = roslibpy.Service(self.ros, name, srv_type)
        return srv.call(roslibpy.ServiceRequest(request or {}), timeout=timeout)

    def calibrate(self, timeout: float = 120.0):
        """Automatische Kalibrierung. ACHTUNG: der Roboter bewegt sich dabei!"""
        # TODO (Teil 4, Weg a): Kalibrier-Service nicht blockierend aufrufen und auf Antwort und Hardwarestatus warten.
        raise NotImplementedError("TODO: implement calibrate")

    def request_new_calibration(self, timeout: float = 5.0):
        """Kalibrierung als nötig markieren (bewegt nichts); danach calibrate() aufrufen."""
        resp = self._call('/niryo_robot/joints_interface/request_new_calibration', 'niryo_robot_msgs/Trigger')
        if resp.get('status', 0) < 0:
            raise Ned2Error('Neue Kalibrierung abgelehnt: %s' % resp.get('message'))
        self._wait_for(lambda: self.calibration_needed, timeout,
                       'Ned2 meldet nach der Anforderung keine nötige Kalibrierung')

    def set_learning_mode(self, enabled: bool, timeout: float = 5.0):
        """Schaltet den Learning-Mode (Arm frei beweglich) ein oder aus.

        Args:
            enabled: True = Arm frei, False = Drehmoment an.
            timeout: Wartezeit auf die Bestätigung in s.

        Raises:
            Ned2Error: Service meldet einen Fehler oder der Zustand ändert sich nicht.
        """
        # TODO (Teil 4, Weg a): Service aufrufen und warten, bis das Topic den neuen Zustand meldet.
        raise NotImplementedError("TODO: implement set_learning_mode")

    def stop_arm_commander(self):
        self._call('/niryo_robot_arm_commander/stop_command', 'niryo_robot_msgs/Trigger', timeout=5.0)

    # ------------------------------------------------------------------
    # Befehle
    # ------------------------------------------------------------------
    def send_joints(self, q: Sequence[float], duration: float):
        """Fährt in `duration` Sekunden zu q; jeder neue Befehl ersetzt den vorigen.

        Args:
            q: Gelenkziel (6,) in rad (vorher geprüft!).
            duration: time_from_start des Trajektorienpunkts in s.
        """
        # TODO (Teil 4, Weg a): einpunktige JointTrajectory auf TRAJECTORY_TOPIC senden (header.stamp = 0,
        # time_from_start = duration, joint_names = NED2_JOINTS).
        raise NotImplementedError("TODO: implement send_joints")

    def gripper(self, close: bool, tool_id: int, speed: int, max_torque: int, hold_torque: int):
        """Öffnet oder schließt den Greifer.

        Args:
            close: True = schließen, False = öffnen.
            tool_id: Werkzeug-ID des Greifers.
            speed: Geschwindigkeit des Greifers.
            max_torque: Maximales Drehmoment in Prozent.
            hold_torque: Haltemoment in Prozent.
        """
        # TODO (Teil 4, Weg a): ToolActionGoal mit eigener goal_id (Präfix GOAL_PREFIX) direkt auf das
        # Goal-Topic veröffentlichen.
        raise NotImplementedError("TODO: implement gripper")
