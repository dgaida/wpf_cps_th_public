"""Hauptprogramm: Niryo Ned2 folgt dem von Hand geführten WidowX 250s.

    python3 -m ned2_wx250s_sync.sync [--config CONFIG] [--dry-run] [--sim-leader] [--calibrate]
"""

import argparse
import logging
import signal
import sys
import time
from typing import Optional

import numpy as np

from . import kinematics as K
from .config import DEFAULT_CONFIG, SyncConfig, load_config
from .controller import StepResult, SyncController
from .follower_ned2 import Ned2Error, Ned2Follower
from .sim_leader import SimLeader

log = logging.getLogger('ned2_wx250s_sync')

# Ruhepose des Ned2 (für --offline)
NED2_HOME = np.array([0.0, 0.5, -1.25, 0.0, 0.0, 0.0])


def confirm(question: str, assume_yes: bool) -> bool:
    if assume_yes:
        log.info('%s -> ja (--yes)', question)
        return True
    try:
        return input('%s [j/N] ' % question).strip().lower() in ('j', 'ja', 'y', 'yes')
    except EOFError:
        return False


def fmt(p) -> str:
    return '(%+.3f %+.3f %+.3f)' % tuple(p)


class SyncApp:
    def __init__(self, cfg: SyncConfig, args):
        self.cfg = cfg
        self.args = args
        self.ned2: Optional[Ned2Follower] = None
        self.spinner = None
        self.leader = None
        self.visualizer = None
        self.leader_torque_off = False
        self.gripper_closed: Optional[bool] = None
        self.last_gripper_cmd = 0.0
        self.keys = None

    # ------------------------------------------------------------------
    def setup_ned2(self) -> K.SerialArm:
        cfg, args = self.cfg.ned2, self.args
        if args.offline:
            log.info('Offline: keine Verbindung zum Ned2, Start in der Ruhepose')
            return K.ned2(*self._tcp_from_config(None))

        if cfg.backend == 'pyniryo':
            from .follower_ned2_pyniryo import Ned2PyNiryoFollower
            log.info('Verbinde mit Ned2 %s:40001 (pyniryo, Jog) ...', cfg.host)
            self.ned2 = Ned2PyNiryoFollower(cfg.host, cfg.pyniryo.max_shift)
            # Jog: Gelenkgeschwindigkeit zusätzlich begrenzen (Niryo-Nachführfehler > 0,2 rad
            # gilt als Kollision und schaltet den Learning-Mode ein)
            cfg.max_joint_velocity = [min(v, cfg.pyniryo.max_joint_velocity) for v in cfg.max_joint_velocity]
        elif cfg.backend == 'rosbridge':
            log.info('Verbinde mit Ned2 %s:%d (rosbridge) ...', cfg.host, cfg.port)
            self.ned2 = Ned2Follower(cfg.host, cfg.port)
        else:
            raise ValueError("ned2.backend muss 'rosbridge' oder 'pyniryo' sein")
        self.ned2.connect()
        errors = self.ned2.hardware_errors()
        if errors:
            raise Ned2Error('Hardwarefehler am Ned2: ' + '; '.join(errors))
        if self.ned2.estop:
            raise Ned2Error('Not-Halt des Ned2 ist gedrückt')

        if not args.dry_run:
            if self.ned2.calibration_needed:
                if not args.calibrate:
                    raise Ned2Error('Der Ned2 muss kalibriert werden. Mit --calibrate starten '
                                    '(der Arm bewegt sich dabei – Arbeitsbereich freihalten!)')
                if not confirm('Ned2 jetzt kalibrieren? Der Arm bewegt sich!', args.yes):
                    raise Ned2Error('Kalibrierung abgebrochen')
                log.info('Kalibriere Ned2 ...')
                self.ned2.calibrate()
                log.info('Kalibrierung abgeschlossen')
            if self.ned2.learning_mode:
                log.info('Learning-Mode aus (Drehmoment an) ...')
                self.ned2.set_learning_mode(False)
            if self.ned2.arm_commander_active:
                log.info('Laufende Bewegung des Ned2 wird gestoppt')
                self.ned2.stop_arm_commander()
                time.sleep(0.5)
        elif self.ned2.calibration_needed:
            log.warning('Ned2 ist nicht kalibriert – die Gelenkwinkel sind unzuverlässig (nur Testlauf)')

        tcp = self._tcp_from_config(self.ned2)
        log.info('Ned2: Werkzeug-ID %s, TCP %s m / rpy %s rad', self.ned2.tool_id,
                 fmt(tcp[0]), fmt(tcp[1]))
        return K.ned2(*tcp)

    def _tcp_from_config(self, ned2):
        tcp = self.cfg.ned2.tcp
        if isinstance(tcp, (list, tuple)):
            if len(tcp) != 6:
                raise ValueError('ned2.tcp braucht 6 Werte [x, y, z, roll, pitch, yaw]')
            return tuple(tcp[:3]), tuple(tcp[3:])
        if tcp != 'auto':
            raise ValueError("ned2.tcp muss 'auto' oder eine Liste mit 6 Werten sein")
        offset = ned2.tcp_offset() if ned2 is not None else None
        if offset is None:
            if ned2 is not None and self.cfg.ned2.backend == 'pyniryo':
                raise Ned2Error('pyniryo kann den TCP für Werkzeug %s nicht lesen – bitte ned2.tcp '
                                'in config/sync.yaml angeben' % ned2.tool_id)
            if ned2 is not None:
                log.warning('TCP des Ned2 unbekannt/deaktiviert – nutze tool_link')
                return (0.0, 0.0, 0.0), (0.0, 0.0, 0.0)
            return (0.085, 0.0, 0.0), (0.0, 0.0, 0.0)
        return offset

    def setup_ros(self):
        need_ros = not self.args.sim_leader or self.cfg.visualization.enabled
        if not need_ros:
            return
        try:
            from .leader_wx250s import RosSpinner
        except ImportError as exc:
            if not self.args.sim_leader:
                raise RuntimeError('ROS2/Interbotix nicht gefunden (%s). Vorher ausführen: '
                                   'source ~/interbotix_ws/install/setup.bash' % exc)
            log.warning('ROS2 nicht verfügbar – keine RViz-Marker')
            return
        self.spinner = RosSpinner()

    def setup_leader(self):
        if self.args.sim_leader:
            log.info('Simulierter wx250s (--sim-leader)')
            self.leader = SimLeader()
            return
        from .leader_wx250s import Wx250sLeader
        self.leader = Wx250sLeader(self.spinner.node, self.cfg.wx250s.robot_name)
        log.info('Warte auf Interbotix-Treiber /%s ...', self.cfg.wx250s.robot_name)
        self.leader.wait_for_driver()
        print('\nDas Drehmoment des wx250s wird abgeschaltet, damit er von Hand geführt werden kann.\n'
              'Den Arm vorher festhalten oder in der Ruhepose ablegen – sonst fällt er herunter!')
        if not confirm('Drehmoment des wx250s abschalten?', self.args.yes):
            raise RuntimeError('Abgebrochen')
        self.leader.set_torque(False)
        self.leader_torque_off = True
        log.info('wx250s ist frei beweglich')

    def setup_visualization(self):
        if self.spinner is None or not self.cfg.visualization.enabled:
            return
        from .visualization import SyncVisualizer
        frame = '%s/base_link' % self.cfg.wx250s.robot_name
        self.visualizer = SyncVisualizer(self.spinner.node, frame, self.cfg.workspace, self.cfg.mapping)
        log.info('RViz-Marker auf /ned2_sync/markers (Frame %s)', frame)

    # ------------------------------------------------------------------
    def run(self):
        """Hauptschleife der Synchronisation (läuft bis Strg+C oder Kollision)."""
        # TODO (Teil 4): Roboter einrichten (setup_*), Greifertasten starten, SyncController anlegen und mit
        # fester Rate laufen lassen; pausieren (_pause_reason), nach Pausen reset() aufrufen, Befehle
        # senden, Greifer nachführen, Status ausgeben (_print_status). Bei Kollision beenden.
        raise NotImplementedError("TODO: implement run")

    def _pause_reason(self, q_leader, age) -> Optional[str]:
        """Grund für eine Pause in diesem Zyklus.

        Args:
            q_leader: Letzte Gelenkwinkel des wx250s oder None.
            age: Alter dieser Gelenkwinkel in s.

        Returns:
            Optional[str]: None = weiterfahren; 'Kollision' = Programm beenden; sonst der Pausegrund.
        """
        # TODO (Teil 4): Pausegründe aus aufgabe/teil4_roboter_live.md prüfen (veraltete Leader-Daten,
        # Verbindung, Kollision, Not-Halt, Hardwarefehler, Learning-Mode, Greifer schaltet, veraltete
        # Ned2-Daten).
        raise NotImplementedError("TODO: implement _pause_reason")

    def _start_gripper_keys(self):
        """Startet die Tastatursteuerung des Greifers, wenn gripper.source = 'keyboard'.

        Raises:
            ValueError: Unbekannter Wert für gripper.source.
        """
        # TODO (Teil 4): gripper.source prüfen ('keyboard' oder 'wx250s'); bei 'keyboard' einen KeyReader
        # (keyboard.py) anlegen und die Tastenbelegung ausgeben.
        raise NotImplementedError("TODO: implement _start_gripper_keys")

    def _update_gripper(self, finger: Optional[float], sending: bool, paused: bool):
        """Schaltet den Greifer des Ned2 nach Tastatur oder Fingerposition des wx250s.

        Args:
            finger: Position von left_finger des wx250s in m oder None.
            sending: True = Befehle gehen an den Ned2 (kein Testlauf).
            paused: True = Synchronisation pausiert gerade.
        """
        # TODO (Teil 4): Tasten auswerten (Leertaste umschalten, o öffnen, s schließen) bzw. bei
        # source 'wx250s' die Fingerposition mit Hysterese; nur bei Änderung, nicht in der Pause und nur
        # mit montiertem Greifer schalten (im Testlauf nur melden).
        raise NotImplementedError("TODO: implement _update_gripper")

    def _print_status(self, res: Optional[StepResult], paused: Optional[str]):
        if paused:
            log.info('PAUSE (%s)', paused)
            return
        if res is None:
            return
        mode = 'HALT' if res.holding else ('Anfahrt' if res.approaching else 'Folgen')
        extra = ' [begrenzt %s->%s]' % (fmt(res.mapped_tcp), fmt(res.goal_tcp)) if res.clamped else ''
        problems = (' – ' + '; '.join(res.problems)) if res.problems else ''
        orient = ('Orient.-Abw. %4.1f°' if res.orientation_active
                  else 'Orient. ausgesetzt (%.0f°, hier nicht erreichbar)') % np.degrees(res.ik_ori_error)
        gripper = {None: '', True: '  Greifer zu', False: '  Greifer offen'}[self.gripper_closed]
        log.info('%-7s wx250s %s  Ned2-Ziel %s  Ned2 %s  %s%s%s%s',
                 mode, fmt(res.leader_tcp), fmt(res.goal_tcp), fmt(res.commanded_tcp), orient, gripper, extra,
                 problems)

    def shutdown(self):
        """Räumt beim Beenden auf: wx250s hält seine Pose, der Ned2 bleibt stehen."""
        # TODO (Teil 4): Terminal wiederherstellen, Drehmoment des wx250s wieder einschalten, Verbindung zum
        # Ned2 schließen, ROS beenden.
        raise NotImplementedError("TODO: implement shutdown")


def _raise_keyboard_interrupt(signum, frame):
    """SIGTERM (kill, systemd) wie Strg+C behandeln, damit aufgeräumt wird."""
    raise KeyboardInterrupt


def main(argv=None):
    parser = argparse.ArgumentParser(description='Niryo Ned2 folgt dem WidowX 250s')
    parser.add_argument('--config', default=str(DEFAULT_CONFIG), help='YAML-Konfiguration')
    parser.add_argument('--dry-run', action='store_true',
                        help='nur rechnen und anzeigen, nichts an den Ned2 senden')
    parser.add_argument('--offline', action='store_true',
                        help='ohne Ned2-Verbindung (impliziert --dry-run)')
    parser.add_argument('--sim-leader', action='store_true',
                        help='simulierte wx250s-Bewegung statt des echten Arms')
    parser.add_argument('--backend', choices=('rosbridge', 'pyniryo'),
                        help='Ansteuerung des Ned2 (überschreibt ned2.backend aus der Konfiguration)')
    parser.add_argument('--calibrate', action='store_true',
                        help='Ned2 bei Bedarf automatisch kalibrieren (Arm bewegt sich!)')
    parser.add_argument('--yes', action='store_true', help='Sicherheitsabfragen automatisch bestätigen')
    parser.add_argument('-v', '--verbose', action='store_true')
    args = parser.parse_args(argv)
    if args.offline:
        args.dry_run = True

    logging.basicConfig(level=logging.DEBUG if args.verbose else logging.INFO,
                        format='%(asctime)s %(levelname)-7s %(message)s', datefmt='%H:%M:%S')
    signal.signal(signal.SIGTERM, _raise_keyboard_interrupt)
    cfg = load_config(args.config)
    if args.backend:
        cfg.ned2.backend = args.backend
    app = SyncApp(cfg, args)
    try:
        app.run()
    except KeyboardInterrupt:
        print()
        log.info('Beendet durch Benutzer')
    except (Ned2Error, RuntimeError, ValueError) as exc:
        log.error('%s', exc)
        return 1
    finally:
        app.shutdown()
    return 0


if __name__ == '__main__':
    sys.exit(main())
