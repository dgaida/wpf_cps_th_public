"""Laden der YAML-Konfiguration (config/sync.yaml)."""

from dataclasses import dataclass, field, fields, is_dataclass
from pathlib import Path
from typing import List, Optional, Union

import yaml

from .mapping import Mapping
from .workspace import Workspace

DEFAULT_CONFIG = Path(__file__).resolve().parent.parent / 'config' / 'sync.yaml'


@dataclass
class PyNiryoConfig:
    max_joint_velocity: float = 0.6   # rad/s, Obergrenze für alle Gelenke im pyniryo-Betrieb
    max_shift: float = 0.15           # rad je Jog-Befehl (Niryo begrenzt auf 0,2)


@dataclass
class Ned2Config:
    host: str = '192.168.0.141'
    # 'rosbridge' = Gelenkziele mit 30 Hz an den Trajektorien-Controller (Port 9090)
    # 'pyniryo'   = Jog-Befehle über den Niryo-TCP-Server (Port 40001), ca. 6 Ziele/s
    backend: str = 'rosbridge'
    port: int = 9090
    pyniryo: PyNiryoConfig = field(default_factory=PyNiryoConfig)
    # 'auto' = TCP vom Roboter lesen, sonst [x, y, z, roll, pitch, yaw] in m / rad
    tcp: Union[str, List[float]] = 'auto'
    joint_limit_margin: float = 0.05
    max_joint_velocity: List[float] = field(default_factory=lambda: [1.0, 1.0, 1.0, 1.5, 1.5, 1.5])
    approach_velocity_scale: float = 0.3
    approach_tolerance: float = 0.1
    command_lookahead: float = 0.15


@dataclass
class Wx250sConfig:
    robot_name: str = 'wx250s'
    stale_timeout: float = 0.3


@dataclass
class LoopConfig:
    rate_hz: float = 30.0
    leader_filter: float = 0.5
    status_interval: float = 1.0


@dataclass
class IKConfig:
    follow_orientation: bool = True
    reference_gain: float = 0.1
    damping: float = 0.02
    max_iterations: int = 30
    max_position_error: float = 0.01
    workspace_tolerance: float = 0.01


@dataclass
class GripperConfig:
    enabled: bool = True
    # 'keyboard' = Tasten im Terminal (Leertaste/o/s); 'wx250s' = Fingerstellung des wx250s
    # (nur sinnvoll, wenn sich dessen Greifer von Hand bewegen lässt)
    source: str = 'keyboard'
    close_below: float = 0.022
    open_above: float = 0.030
    speed: int = 500
    max_torque_percentage: int = 100
    hold_torque_percentage: int = 30


@dataclass
class VisualizationConfig:
    enabled: bool = True


@dataclass
class SyncConfig:
    ned2: Ned2Config = field(default_factory=Ned2Config)
    wx250s: Wx250sConfig = field(default_factory=Wx250sConfig)
    loop: LoopConfig = field(default_factory=LoopConfig)
    mapping: Mapping = field(default_factory=Mapping)
    workspace: Workspace = field(default_factory=Workspace)
    ik: IKConfig = field(default_factory=IKConfig)
    gripper: GripperConfig = field(default_factory=GripperConfig)
    visualization: VisualizationConfig = field(default_factory=VisualizationConfig)


def _build(cls, data: Optional[dict], path: str):
    data = data or {}
    known = {f.name: f for f in fields(cls)}
    unknown = set(data) - set(known)
    if unknown:
        raise ValueError('Unbekannte Einträge in %s: %s' % (path or 'Konfiguration', ', '.join(sorted(unknown))))
    kwargs = {}
    for name, value in data.items():
        f = known[name]
        sub = f.default_factory() if callable(f.default_factory) else None
        if is_dataclass(sub) and isinstance(value, dict):
            value = _build(type(sub), value, '%s.%s' % (path, name) if path else name)
        elif isinstance(value, list) and _is_tuple_field(f):
            value = tuple(value)
        kwargs[name] = value
    return cls(**kwargs)


def _is_tuple_field(f) -> bool:
    return 'Tuple' in str(f.type)


def load_config(path: Optional[Union[str, Path]] = None) -> SyncConfig:
    path = Path(path) if path else DEFAULT_CONFIG
    with open(path) as fh:
        data = yaml.safe_load(fh) or {}
    return _build(SyncConfig, data, '')
