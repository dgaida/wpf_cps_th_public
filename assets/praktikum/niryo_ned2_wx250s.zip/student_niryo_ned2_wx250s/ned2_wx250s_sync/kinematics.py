"""Kinematik (Product of Exponentials) für WidowX 250s und Niryo Ned2.

Beide Arme haben dieselbe Topologie (Gier, Nick, Nick, Roll, Nick, Roll) und
in Nullstellung dieselbe Grundhaltung: Oberarm senkrecht, Unterarm waagerecht
nach vorn, Werkzeug-Frame = Einheitsmatrix (x nach vorn, z nach oben).
"""

from dataclasses import dataclass, field
from typing import List, Optional, Sequence, Tuple

import numpy as np


# --------------------------------------------------------------------------
# Rotations-Hilfsfunktionen
# --------------------------------------------------------------------------

def skew(w: np.ndarray) -> np.ndarray:
    """Schiefsymmetrische Matrix [w] mit [w] @ v = w x v.

    Args:
        w: Vektor (3,).

    Returns:
        np.ndarray: Matrix (3, 3).
    """
    # TODO (Teil 1): schiefsymmetrische Matrix aufstellen.
    raise NotImplementedError("TODO: implement skew")


def rpy_to_matrix(roll: float, pitch: float, yaw: float) -> np.ndarray:
    """Rotationsmatrix aus Roll-, Nick- und Gierwinkel.

    URDF-/Niryo-Konvention: R = Rz(yaw) @ Ry(pitch) @ Rx(roll).

    Args:
        roll: Drehung um x in rad.
        pitch: Drehung um y in rad.
        yaw: Drehung um z in rad.

    Returns:
        np.ndarray: Rotationsmatrix (3, 3).
    """
    # TODO (Teil 1): R = Rz(yaw) @ Ry(pitch) @ Rx(roll) berechnen.
    raise NotImplementedError("TODO: implement rpy_to_matrix")


def matrix_to_rpy(R: np.ndarray) -> Tuple[float, float, float]:
    """Umkehrung von rpy_to_matrix.

    Args:
        R: Rotationsmatrix (3, 3).

    Returns:
        Tuple[float, float, float]: (roll, pitch, yaw) in rad mit pitch in [-pi/2, pi/2]. Im Gimbal Lock
        (cos(pitch) = 0) wird roll = 0 gesetzt.
    """
    # TODO (Teil 1): Winkel aus den Einträgen von R bestimmen (arctan2), Gimbal Lock behandeln.
    raise NotImplementedError("TODO: implement matrix_to_rpy")


def rotation_log(R: np.ndarray) -> np.ndarray:
    """Rotationsvektor (so3-Logarithmus) einer Rotationsmatrix.

    Args:
        R: Rotationsmatrix (3, 3).

    Returns:
        np.ndarray: Achse * Winkel (3,) mit Winkel in [0, pi]. Auch für Winkel nahe 0 und nahe pi stabil.
    """
    # TODO (Teil 1): Winkel aus der Spur, Achse aus dem schiefsymmetrischen Anteil;
    # Winkel nahe 0 und nahe pi gesondert behandeln.
    raise NotImplementedError("TODO: implement rotation_log")


def transform(xyz: Sequence[float], rpy: Sequence[float] = (0.0, 0.0, 0.0)) -> np.ndarray:
    T = np.eye(4)
    T[:3, :3] = rpy_to_matrix(*rpy)
    T[:3, 3] = xyz
    return T


def exp_twist(S: np.ndarray, theta: float) -> np.ndarray:
    """Matrixexponential exp([S] theta) einer Dreh-Schraubenachse.

    Args:
        S: Schraubenachse (6,) = (w, v) mit |w| = 1 und v = -w x p (p: Punkt auf der Achse).
        theta: Drehwinkel in rad.

    Returns:
        np.ndarray: Homogene Transformation (4, 4).
    """
    # TODO (Teil 1): Rotation mit der Rodrigues-Formel, Translation nach Lynch & Park (Gl. 3.88).
    raise NotImplementedError("TODO: implement exp_twist")


# --------------------------------------------------------------------------
# Serieller Arm
# --------------------------------------------------------------------------

@dataclass
class SerialArm:
    name: str
    joint_names: List[str]
    Slist: np.ndarray            # 6 x n, Schraubenachsen im Basis-Frame (Nullstellung)
    M: np.ndarray                # TCP-Pose in Nullstellung
    lower: np.ndarray
    upper: np.ndarray
    # Punkte auf den Gelenkachsen in Nullstellung (für Höhen-/Kollisionsprüfung)
    joint_points: np.ndarray = field(default_factory=lambda: np.zeros((0, 3)))

    def __post_init__(self):
        # Konstante Anteile von exp([S] theta) für alle Gelenke vorberechnen;
        # bei 3x3-Matrizen kostet jeder numpy-Aufruf mehr als die Rechnung selbst
        self._W = np.array([skew(w) for w in self.Slist[:3].T])
        self._WW = self._W @ self._W
        self._v = self.Slist[3:].T.copy()
        self._Wv = np.einsum('nij,nj->ni', self._W, self._v)
        self._WWv = np.einsum('nij,nj->ni', self._WW, self._v)
        self._axes0 = self.Slist[:3].T.copy()

    @property
    def dof(self) -> int:
        return self.Slist.shape[1]

    def _chain(self, q: Sequence[float]) -> Tuple[np.ndarray, np.ndarray]:
        """Produkte der Exponentiale vor jedem Gelenk und nach dem letzten.

        (Rs[i], ps[i]) ist Rotation und Translation von exp([S1] q1) ... exp([Si] qi): Rs[0] = I, ps[0] = 0,
        (Rs[n], ps[n]) ist das Produkt über alle Gelenke (ohne M). Die in __post_init__ vorberechneten
        Größen (self._W, self._WW, self._v, self._Wv, self._WWv) sparen Rechenzeit.

        Args:
            q: Gelenkwinkel (n,) in rad.

        Returns:
            Tuple[np.ndarray, np.ndarray]: Rs (n+1, 3, 3) und ps (n+1, 3).
        """
        # TODO (Teil 1): exp([Si] qi) für alle Gelenke auf einmal berechnen (vorberechnete Größen
        # aus __post_init__ nutzen) und der Reihe nach multiplizieren.
        raise NotImplementedError("TODO: implement _chain")

    def _tcp(self, R: np.ndarray, p: np.ndarray) -> np.ndarray:
        T = np.eye(4)
        T[:3, :3] = R @ self.M[:3, :3]
        T[:3, 3] = R @ self.M[:3, 3] + p
        return T

    def fk(self, q: Sequence[float]) -> np.ndarray:
        """Vorwärtskinematik: TCP-Pose T(q) = exp([S1] q1) ... exp([Sn] qn) M.

        Args:
            q: Gelenkwinkel (n,) in rad.

        Returns:
            np.ndarray: TCP-Pose (4, 4) im Basis-Koordinatensystem.
        """
        # TODO (Teil 1): Vorwärtskinematik mit _chain und M.
        raise NotImplementedError("TODO: implement fk")

    def fk_points(self, q: Sequence[float]) -> np.ndarray:
        """Weltpositionen aller Gelenkpunkte (joint_points) und des TCP.

        Args:
            q: Gelenkwinkel (n,) in rad.

        Returns:
            np.ndarray: (n+1, 3); Zeile i < n ist der Punkt auf der Achse von Gelenk i+1, die letzte Zeile der TCP.
        """
        # TODO (Teil 1): Gelenkpunkt i mit dem Produkt der Exponentiale vor Gelenk i abbilden.
        raise NotImplementedError("TODO: implement fk_points")

    def jacobian(self, q: Sequence[float]) -> Tuple[np.ndarray, np.ndarray]:
        """Geometrische Jacobi-Matrix (6 x n, oben linear, unten Winkel) am TCP."""
        J, T_tcp, _, _ = self.jacobian_full(q)
        return J, T_tcp

    def jacobian_full(self, q: Sequence[float]):
        """Geometrische Jacobi-Matrix am TCP, dazu Gelenkachsen und Gelenkpunkte.

        Spalte i: oben die lineare Geschwindigkeit des TCP a_i x (p_tcp - p_i), unten die
        Winkelgeschwindigkeit a_i, mit Achse a_i und Gelenkpunkt p_i von Gelenk i in Weltkoordinaten.

        Args:
            q: Gelenkwinkel (n,) in rad.

        Returns:
            Tuple: J (6, n), TCP-Pose (4, 4), Gelenkachsen (n, 3), Gelenkpunkte (n, 3).
        """
        # TODO (Teil 1): Achsen und Gelenkpunkte mit _chain abbilden, Spalten a_i x (p_tcp - p_i) und a_i.
        raise NotImplementedError("TODO: implement jacobian_full")

    def clip(self, q: Sequence[float], margin: float = 0.0) -> np.ndarray:
        return np.clip(np.asarray(q, dtype=float), self.lower + margin, self.upper - margin)

    def within_limits(self, q: Sequence[float], tol: float = 1e-6) -> bool:
        q = np.asarray(q)
        return bool(np.all(q >= self.lower - tol) and np.all(q <= self.upper + tol))


def arm_from_urdf_chain(name: str,
                        joint_names: List[str],
                        chain: List[Tuple[Sequence[float], Sequence[float]]],
                        tool: np.ndarray,
                        lower: Sequence[float],
                        upper: Sequence[float]) -> SerialArm:
    """Baut ein PoE-Modell aus den Gelenk-Origins einer URDF.

    Jedes Gelenk dreht um die lokale z-Achse seines Frames. Der Frame von Gelenk i ist das Produkt der
    Origins 1..i (transform(xyz, rpy)); daraus folgen Achse w, Gelenkpunkt p und S = (w, -w x p). Die
    TCP-Pose in Nullstellung ist der Frame des letzten Gelenks mal `tool`.

    Args:
        name: Name des Arms.
        joint_names: Gelenknamen.
        chain: (xyz, rpy) der Gelenk-Origins in der Reihenfolge der URDF.
        tool: Transformation (4, 4) vom Frame des letzten Gelenks zum TCP.
        lower: Untere Gelenkgrenzen in rad.
        upper: Obere Gelenkgrenzen in rad.

    Returns:
        SerialArm: Modell mit Slist, M, Grenzen und joint_points.
    """
    # TODO (Teil 1): Gelenk-Frames aufmultiplizieren, je Gelenk w, p und S = (w, -w x p) bestimmen.
    raise NotImplementedError("TODO: implement arm_from_urdf_chain")


# --------------------------------------------------------------------------
# Robotermodelle
# --------------------------------------------------------------------------

WX250S_JOINTS = ['waist', 'shoulder', 'elbow', 'forearm_roll', 'wrist_angle', 'wrist_rotate']
NED2_JOINTS = ['joint_1', 'joint_2', 'joint_3', 'joint_4', 'joint_5', 'joint_6']


def wx250s() -> SerialArm:
    """Modell des WidowX 250s bis 'ee_gripper_link'.

    Slist und M stehen in interbotix_xs_modules/xs_robot/mr_descriptions.py (Klasse wx250s), die
    Gelenkgrenzen in der Motorkonfiguration wx250s.yaml (Min/Max_Position_Limit, 4096 Ticks pro
    Umdrehung, Mitte 2048). Die Gelenkpunkte liegen auf den Gelenkachsen (für die Höhenprüfung).

    Returns:
        SerialArm: Modell des wx250s mit den Gelenknamen WX250S_JOINTS.
    """
    # TODO (Teil 1): Slist, M, Gelenkpunkte und Gelenkgrenzen eintragen.
    raise NotImplementedError("TODO: implement wx250s")


# TODO (Teil 1): Werte aus der robot_description des Ned2 (Parameter /robot_description) eintragen:
# Gelenk-Origins (xyz, rpy) von joint_1 bis joint_6, die Transformation vom Frame von joint_6
# zu 'tool_link' sowie die Gelenkgrenzen (lower, upper) in rad.
NED2_CHAIN: List[Tuple[Tuple[float, float, float], Tuple[float, float, float]]] = []
NED2_HAND_TO_TOOL = np.eye(4)
NED2_LOWER: List[float] = []
NED2_UPPER: List[float] = []


def ned2(tcp_xyz: Sequence[float] = (0.085, 0.0, 0.0),
         tcp_rpy: Sequence[float] = (0.0, 0.0, 0.0),
         lower: Optional[Sequence[float]] = None,
         upper: Optional[Sequence[float]] = None) -> SerialArm:
    """Modell des Niryo Ned2 bis zum TCP, aus der robot_description des Roboters.

    Args:
        tcp_xyz: TCP relativ zu 'tool_link' in m (Standard: Greifer 1, 85 mm in x).
        tcp_rpy: Verdrehung des TCP relativ zu 'tool_link' in rad.
        lower: Untere Gelenkgrenzen in rad (None: NED2_LOWER).
        upper: Obere Gelenkgrenzen in rad (None: NED2_UPPER).

    Returns:
        SerialArm: Modell des Ned2 mit den Gelenknamen NED2_JOINTS.
    """
    # TODO (Teil 1): Modell mit arm_from_urdf_chain aus NED2_CHAIN, NED2_HAND_TO_TOOL und dem TCP bauen.
    raise NotImplementedError("TODO: implement ned2")


# --------------------------------------------------------------------------
# Inverse Kinematik
# --------------------------------------------------------------------------

@dataclass
class IKResult:
    q: np.ndarray
    pos_error: float      # m
    ori_error: float      # rad
    iterations: int


def _dls(J: np.ndarray, e: np.ndarray, lam2: float, sigma_null: float):
    """Gedämpfte Lösung von J dq = e und Basis des Nullraums von J (über die SVD).

    Args:
        J: Matrix (m, n).
        e: Fehlervektor (m,).
        lam2: Quadrat des Dämpfungsfaktors.
        sigma_null: Singulärwerte darunter zählen zum Nullraum.

    Returns:
        Tuple[np.ndarray, np.ndarray]: dq (n,) = J^T (J J^T + lam2 I)^-1 e und die Nullraumbasis (k, n)
        als orthonormale Zeilen.
    """
    # TODO (Teil 3): SVD von J, gedämpfte Pseudoinverse, Nullraum aus kleinen Singulärwerten und
    # den Zeilen von Vt ohne Singulärwert.
    raise NotImplementedError("TODO: implement _dls")


def solve_ik(arm: SerialArm,
             T_target: np.ndarray,
             q_seed: Sequence[float],
             q_ref: Optional[Sequence[float]] = None,
             follow_orientation: bool = True,
             reference_gain: float = 0.1,
             damping: float = 0.02,
             limit_margin: float = 0.02,
             max_iterations: int = 30,
             pos_tolerance: float = 5e-4,
             ori_tolerance: float = 5e-3,
             max_step: float = 0.2,
             min_step: float = 2e-4,
             min_joint_height: Optional[float] = None,
             bounds: Optional[Tuple[np.ndarray, np.ndarray]] = None) -> IKResult:
    """Priorisierte IK (gedämpfte kleinste Quadrate über SVD) mit Gelenkgrenzen.

    Prioritäten:
      1. TCP-Position und – mit `min_joint_height` – Gelenkpunkte 2..n über dieser Höhe
      2. Orientierung, nur im Nullraum von 1 (verschlechtert die Position nie)
      3. Referenzhaltung `q_ref` im verbleibenden Nullraum (Anteil `reference_gain`
         je Iteration) – so folgt z. B. ein gestrecktes Handgelenk dem Leader-Arm.
    `bounds` schränkt die Gelenke zusätzlich ein (z. B. auf die in einem
    Regelzyklus erreichbaren Winkel), damit die Lösung nicht wegspringt.
    """
    # TODO (Teil 3): priorisierte IK, siehe aufgabe/teil3_ik_regelzyklus.md.
    raise NotImplementedError("TODO: implement solve_ik")
