"""Einzelne Tastendrücke im Terminal lesen, ohne Enter (für die Greifersteuerung).

Das Terminal wird in den cbreak-Modus geschaltet: Tasten kommen sofort an und
werden nicht angezeigt, Strg+C beendet das Programm weiterhin.
"""

import os
import select
import sys
import termios
import tty
from typing import List


class KeyReader:
    def __init__(self):
        self._fd = None
        self._old = None
        if sys.stdin.isatty():
            self._fd = sys.stdin.fileno()
            self._old = termios.tcgetattr(self._fd)
            tty.setcbreak(self._fd)

    @property
    def active(self) -> bool:
        return self._fd is not None

    def keys(self) -> List[str]:
        """Alle seit dem letzten Aufruf gedrückten Tasten (blockiert nicht)."""
        out = []
        while self._fd is not None and select.select([self._fd], [], [], 0)[0]:
            ch = os.read(self._fd, 1)
            if not ch:
                break
            out.append(ch.decode(errors='ignore').lower())
        return out

    def close(self):
        """Terminal wiederherstellen."""
        if self._fd is not None:
            termios.tcsetattr(self._fd, termios.TCSADRAIN, self._old)
            self._fd = None
