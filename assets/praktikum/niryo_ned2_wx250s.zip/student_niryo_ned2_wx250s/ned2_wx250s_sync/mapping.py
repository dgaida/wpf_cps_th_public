"""Abbildung Leader (wx250s) -> Follower (Ned2).

Position:    p_f = offset + scale * Rz(yaw) * S * p_l
Orientierung: R_f = Rz(yaw) * S * R_l * S * R_tool
S ist die Spiegelung an der x-z-Ebene (nur bei mirror=True, sonst Einheitsmatrix).
"""

from dataclasses import dataclass
from typing import Sequence, Tuple

import numpy as np

from .kinematics import rpy_to_matrix

# Vorzeichen der gelenkweisen Entsprechung: q_ned2[i] = JOINT_SIGNS[i] * q_wx250s[i]
# TODO (Teil 2): Vorzeichen aus den Gelenkachsen beider Roboter in Nullstellung bestimmen.
JOINT_SIGNS = np.ones(6)
# Gelenke, die beim Spiegeln das Vorzeichen wechseln (Gier und Roll)
MIRROR_SIGNS = np.array([-1.0, 1.0, 1.0, -1.0, 1.0, -1.0])


@dataclass
class Mapping:
    scale: float = 0.9
    yaw_deg: float = 0.0
    offset: Tuple[float, float, float] = (0.0, 0.0, 0.0)
    mirror: bool = False
    tool_rpy_deg: Tuple[float, float, float] = (0.0, 0.0, 0.0)

    def __post_init__(self):
        if self.scale <= 0.0:
            raise ValueError('mapping.scale muss > 0 sein')
        a = np.radians(self.yaw_deg)
        self._Rz = np.array([[np.cos(a), -np.sin(a), 0.0],
                             [np.sin(a), np.cos(a), 0.0],
                             [0.0, 0.0, 1.0]])
        self._S = np.diag([1.0, -1.0, 1.0]) if self.mirror else np.eye(3)
        self._R_tool = rpy_to_matrix(*np.radians(self.tool_rpy_deg))
        self._offset = np.asarray(self.offset, dtype=float)

    def pose(self, T_leader: np.ndarray) -> np.ndarray:
        """Bildet eine TCP-Pose des wx250s auf eine Zielpose des Ned2 ab.

        Args:
            T_leader: TCP-Pose (4, 4) des wx250s.

        Returns:
            np.ndarray: Zielpose (4, 4) des Ned2 (noch nicht auf den Arbeitsraum begrenzt).
        """
        # TODO (Teil 2): Position mit position(), Orientierung R_f = Rz(yaw) S R_l S R_tool.
        raise NotImplementedError("TODO: implement pose")

    def position(self, p_leader: Sequence[float]) -> np.ndarray:
        """Bildet einen Punkt des wx250s auf einen Punkt des Ned2 ab.

        Args:
            p_leader: Punkt (3,) im Basis-Koordinatensystem des wx250s.

        Returns:
            np.ndarray: Punkt (3,) im Basis-Koordinatensystem des Ned2.
        """
        # TODO (Teil 2): p_f = offset + scale * Rz(yaw) * S * p_l.
        raise NotImplementedError("TODO: implement position")

    def position_inverse(self, p_follower: Sequence[float]) -> np.ndarray:
        """Umkehrung von position(): Follower-Punkt -> Leader-Punkt (z. B. um den Arbeitsraum beim wx250s anzuzeigen).

        Args:
            p_follower: Punkt (3,) im Basis-Koordinatensystem des Ned2.

        Returns:
            np.ndarray: Punkt (3,) im Basis-Koordinatensystem des wx250s.
        """
        # TODO (Teil 2): position() nach p_l auflösen.
        raise NotImplementedError("TODO: implement position_inverse")

    def joints(self, q_leader: Sequence[float]) -> np.ndarray:
        """Gelenkweise Entsprechung wx250s -> Ned2 (Referenzhaltung für die IK).

        Mit diesen Gelenkwinkeln hat der Ned2 dieselbe Greiferorientierung wie pose() sie vorgibt.

        Args:
            q_leader: Gelenkwinkel des wx250s (mindestens 6 Werte, weitere werden ignoriert).

        Returns:
            np.ndarray: Gelenkwinkel (6,) des Ned2, Gelenk 1 in [-pi, pi).
        """
        # TODO (Teil 2): Vorzeichen anwenden (bei mirror zusätzlich MIRROR_SIGNS), yaw_deg zu Gelenk 1
        # addieren und auf [-pi, pi) normieren.
        raise NotImplementedError("TODO: implement joints")
