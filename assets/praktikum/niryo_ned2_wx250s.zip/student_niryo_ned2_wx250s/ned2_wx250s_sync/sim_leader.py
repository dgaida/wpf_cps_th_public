"""Simulierter wx250s: fährt eine feste Bahn ab (Tests ohne Leader-Hardware)."""

import time
from typing import Optional, Tuple

import numpy as np

from . import kinematics as K


class SimLeader:
    """Kreisbogen vor dem Roboter mit Auf-/Abbewegung, Greifer schräg nach unten.

    Die Bahn liegt teilweise außerhalb des Ned2-Arbeitsraums, damit das
    Begrenzen sichtbar wird. Der Greifer öffnet/schließt alle 6 s.
    """

    def __init__(self):
        self.arm = K.wx250s()
        self._t0 = time.monotonic()
        self._q: Optional[np.ndarray] = None

    def pose_at(self, t: float) -> np.ndarray:
        yaw = 1.2 * np.sin(2 * np.pi * t / 16.0)
        r = 0.40 + 0.12 * np.sin(2 * np.pi * t / 9.0)
        z = 0.15 + 0.13 * np.sin(2 * np.pi * t / 6.0)
        T = np.eye(4)
        T[:3, :3] = K.rpy_to_matrix(0.3 * np.sin(2 * np.pi * t / 5.0), 1.1, yaw)
        T[:3, 3] = [r * np.cos(yaw), r * np.sin(yaw), z]
        return T

    def latest(self) -> Tuple[np.ndarray, float, float]:
        t = time.monotonic() - self._t0
        seed = self._q if self._q is not None else np.array([0.0, 0.0, 0.0, 0.0, 1.1, 0.0])
        self._q = K.solve_ik(self.arm, self.pose_at(t), seed, reference_gain=0.0, limit_margin=0.0).q
        finger = 0.016 if int(t / 6.0) % 2 else 0.035
        return self._q.copy(), finger, 0.0

    def wait_for_driver(self, timeout: float = 0.0):
        pass

    def set_torque(self, enable: bool, timeout: float = 0.0):
        pass
