"""Arbeitsraum des Ned2 (im Basis-Koordinatensystem des Ned2, Meter).

Der erlaubte Raum ist die Schnittmenge aus
  * Zylindersektor um die Basis: Radius [r_min, r_max], Winkel [yaw_min, yaw_max], Höhe [z_min, z_max]
  * optionalem Quader (z. B. Tischgrenzen, Wände, Nachbarroboter)
  * Kugel um die Schulter mit Radius max_reach (Reichweite)
Zusätzlich müssen alle Gelenkpunkte über `min_joint_height` liegen.
"""

from dataclasses import dataclass
from typing import List, Optional, Sequence, Tuple

import numpy as np


@dataclass
class Workspace:
    radius: Tuple[float, float] = (0.15, 0.45)
    yaw_deg: Tuple[float, float] = (-120.0, 120.0)
    z: Tuple[float, float] = (0.03, 0.50)
    box_x: Optional[Tuple[float, float]] = None
    box_y: Optional[Tuple[float, float]] = None
    max_reach: float = 0.50
    shoulder: Tuple[float, float, float] = (0.0, 0.0, 0.1663)
    min_joint_height: float = 0.05

    def __post_init__(self):
        if self.radius[0] >= self.radius[1] or self.z[0] >= self.z[1] or self.yaw_deg[0] >= self.yaw_deg[1]:
            raise ValueError('Arbeitsraum: Untergrenzen müssen kleiner als Obergrenzen sein')
        if not -180.0 <= self.yaw_deg[0] < self.yaw_deg[1] <= 180.0:
            raise ValueError('Arbeitsraum: yaw_deg muss in [-180, 180] liegen')
        self._yaw = np.radians(self.yaw_deg)
        self._shoulder = np.asarray(self.shoulder, dtype=float)

    # ------------------------------------------------------------------
    def violations(self, p: Sequence[float], tol: float = 0.0) -> List[str]:
        """Liste der verletzten Grenzen eines Punktes.

        Args:
            p: Punkt (3,) im Basis-Koordinatensystem des Ned2.
            tol: Toleranz in m, um die jede Grenze erweitert wird.

        Returns:
            List[str]: Namen der verletzten Grenzen aus 'r_min', 'r_max', 'yaw', 'z_min', 'z_max', 'box_x',
            'box_y', 'reach' (leer = Punkt liegt im Arbeitsraum).
        """
        # TODO (Teil 2): Radius, Sektorwinkel (Toleranz in Winkel umrechnen), Höhe, Quader und Reichweite
        # prüfen; Namen der verletzten Grenzen sammeln.
        raise NotImplementedError("TODO: implement violations")

    def contains(self, p: Sequence[float], tol: float = 0.0) -> bool:
        """Prüft, ob ein Punkt im Arbeitsraum liegt.

        Args:
            p: Punkt (3,).
            tol: Toleranz in m.

        Returns:
            bool: True, wenn keine Grenze verletzt ist.
        """
        # TODO (Teil 2): mit violations() prüfen.
        raise NotImplementedError("TODO: implement contains")

    def clamp(self, p: Sequence[float], iterations: int = 8) -> Tuple[np.ndarray, bool]:
        """Projiziert einen Punkt auf einen möglichst nahen Punkt im Arbeitsraum.

        Args:
            p: Punkt (3,).
            iterations: Höchstzahl der Projektionsrunden.

        Returns:
            Tuple[np.ndarray, bool]: (Punkt im Arbeitsraum, wurde_begrenzt). Ein Punkt im Arbeitsraum wird
            unverändert zurückgegeben.
        """
        # TODO (Teil 2): abwechselnd auf Zylindersektor, Quader und Reichweitenkugel projizieren,
        # bis der Punkt drin liegt.
        raise NotImplementedError("TODO: implement clamp")

    def check_arm_points(self, points: np.ndarray) -> List[str]:
        """Prüft die Gelenkpunkte 2..n gegen die Mindesthöhe.

        Args:
            points: Zeilen von SerialArm.fk_points (Gelenkpunkte 1..n, als letzte Zeile der TCP).

        Returns:
            List[str]: Meldungen der Form 'Gelenk 5 zu tief' (leer = alle hoch genug). Gelenk 1 und der TCP
            werden nicht geprüft.
        """
        # TODO (Teil 2): Gelenkpunkte 2..n (ohne TCP) gegen min_joint_height prüfen.
        raise NotImplementedError("TODO: implement check_arm_points")

    # ------------------------------------------------------------------
    def _clamp_cylinder(self, p: np.ndarray) -> np.ndarray:
        """Projiziert einen Punkt auf den Zylindersektor.

        Liegt der Punkt außerhalb des Sektorwinkels (z. B. hinter dem Roboter), wird die nähere
        Sektorgrenze gewählt; der Sektor ist wegen r_min nicht konvex.

        Args:
            p: Punkt (3,).

        Returns:
            np.ndarray: Punkt (3,) im Zylindersektor.
        """
        # TODO (Teil 2): Winkel auf die nähere Sektorgrenze, Radius und Höhe begrenzen.
        raise NotImplementedError("TODO: implement _clamp_cylinder")

    def _clamp_reach(self, p: np.ndarray) -> np.ndarray:
        """Projiziert einen Punkt in die Kugel um die Schulter mit Radius max_reach.

        Args:
            p: Punkt (3,).

        Returns:
            np.ndarray: Punkt (3,) mit Abstand zur Schulter höchstens max_reach.
        """
        # TODO (Teil 2): Punkt außerhalb der Kugel um die Schulter auf die Kugel ziehen.
        raise NotImplementedError("TODO: implement _clamp_reach")

    # ------------------------------------------------------------------
    def boundary_lines(self, n: int = 48) -> List[Tuple[np.ndarray, np.ndarray]]:
        """Linienstücke der Arbeitsraum-Kontur (Zylindersektor, für RViz)."""
        lines = []
        yaws = np.linspace(self._yaw[0], self._yaw[1], n)
        for r in self.radius:
            for z in self.z:
                pts = [np.array([r * np.cos(a), r * np.sin(a), z]) for a in yaws]
                lines += list(zip(pts[:-1], pts[1:]))
        for a in (self._yaw[0], self._yaw[1]):
            c = np.array([np.cos(a), np.sin(a), 0.0])
            corners = [c * r + np.array([0, 0, z]) for r in self.radius for z in self.z]
            lines += [(corners[0], corners[1]), (corners[2], corners[3]),
                      (corners[0], corners[2]), (corners[1], corners[3])]
        return lines


def _wrap(a: float) -> float:
    return (a + np.pi) % (2.0 * np.pi) - np.pi


def _angle_outside(a: float, limits: np.ndarray, tol: float = 0.0) -> bool:
    return a < limits[0] - tol or a > limits[1] + tol
