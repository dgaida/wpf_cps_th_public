import dataclasses

import numpy as np
import pytest

from ned2_wx250s_sync import kinematics as K
from ned2_wx250s_sync.config import load_config
from ned2_wx250s_sync.controller import SyncController
from ned2_wx250s_sync.sim_leader import SimLeader

DT = 1.0 / 30.0
NED2_REST = np.array([0.0, 0.5, -1.25, 0.0, 0.0, 0.0])


@pytest.fixture
def ctl():
    c = SyncController(load_config(), K.ned2())
    c.reset(NED2_REST)
    return c


def leader_ik(T, seed):
    return K.solve_ik(K.wx250s(), T, seed, reference_gain=0.0, limit_margin=0.0, max_iterations=100).q


def run(ctl, q_leader, steps):
    return [ctl.step(q_leader, DT) for _ in range(steps)]


def test_reaches_static_target(ctl):
    T = np.eye(4)
    T[:3, :3] = K.rpy_to_matrix(0, 1.2, 0.3)
    T[:3, 3] = [0.35, 0.1, 0.12]
    q_l = leader_ik(T, [0.3, 0, 0, 0, 1.2, 0])
    res = run(ctl, q_l, 300)[-1]
    assert not res.holding and not res.approaching
    assert np.linalg.norm(res.commanded_tcp - res.goal_tcp) < 1e-3
    assert np.allclose(res.goal_tcp, 0.9 * T[:3, 3], atol=1e-3)   # Leader-IK ist auf 0.5 mm genau


def test_joint_velocity_limited(ctl):
    vmax = np.asarray(ctl.cfg.ned2.max_joint_velocity)
    prev = NED2_REST
    leader = SimLeader()
    for i in range(600):
        T = leader.pose_at(i * DT)
        res = ctl.step(leader_ik(T, [0, 0, 0, 0, 1.1, 0]), DT)
        assert np.all(np.abs(res.q_command - prev) <= vmax * DT + 1e-9)
        prev = res.q_command


def test_tracks_trajectory_inside_workspace(ctl):
    leader = SimLeader()
    q_l = np.array([0, 0, 0, 0, 1.1, 0])
    results = []
    for i in range(900):
        q_l = leader_ik(leader.pose_at(i * DT), q_l)
        results.append(ctl.step(q_l, DT))
    tail = results[200:]
    assert not any(r.holding for r in tail)
    assert sum(r.clamped for r in tail) > 0, 'die Testbahn soll den Arbeitsraum verlassen'
    tol = ctl.cfg.ik.workspace_tolerance
    for r in tail:
        assert ctl.workspace.contains(r.commanded_tcp, tol=tol)


def test_leader_below_table_keeps_ned2_above_z_min(ctl):
    T = np.eye(4)
    T[:3, :3] = K.rpy_to_matrix(0, np.pi / 2, 0)
    T[:3, 3] = [0.35, 0.0, -0.05]          # TCP des wx250s unter der Tischebene
    q_l = leader_ik(T, [0, 0.5, 0.5, 0, 1.2, 0])
    res = run(ctl, q_l, 300)[-1]
    assert res.clamped
    assert res.commanded_tcp[2] >= ctl.workspace.z[0] - 1e-3


def test_leader_behind_is_clamped_to_sector(ctl):
    T = np.eye(4)
    T[:3, :3] = K.rpy_to_matrix(0, 1.0, np.pi)
    T[:3, 3] = [-0.3, 0.05, 0.15]           # hinter dem Roboter
    q_l = leader_ik(T, [3.0, 0, 0, 0, 1.0, 0])
    res = run(ctl, q_l, 600)[-1]
    yaw = np.degrees(np.arctan2(res.commanded_tcp[1], res.commanded_tcp[0]))
    assert res.clamped
    assert abs(yaw) <= ctl.workspace.yaw_deg[1] + 1.0


def test_commanded_pose_never_leaves_workspace(ctl):
    """Auch bei sprunghaften Zielen und Konfigurationswechseln: jede gesendete
    Stellung liegt im Arbeitsraum (Start in der Ruhepose, die selbst drin liegt)."""
    rng = np.random.default_rng(3)
    for _ in range(12):
        r = rng.uniform(0.15, 0.55)
        a = rng.uniform(-np.pi / 2, np.pi / 2)
        T = np.eye(4)
        T[:3, :3] = K.rpy_to_matrix(rng.uniform(-0.3, 0.3), rng.uniform(0, np.pi / 2), a)
        T[:3, 3] = [r * np.cos(a), r * np.sin(a), rng.uniform(0.0, 0.4)]
        q_l = leader_ik(T, [a, 0, 0, 0, 1.0, 0])
        for res in run(ctl, q_l, 150):
            assert ctl.check(res.q_command) == [], res.problems


def test_enters_workspace_when_starting_outside():
    """Liegt die Startpose außerhalb (hier: Ruhepose bei r = 0.20 < r_min), fährt der
    Ned2 hinein und verlässt den Arbeitsraum danach nicht mehr."""
    cfg = load_config()
    cfg.workspace = dataclasses.replace(cfg.workspace, radius=(0.25, 0.45))
    c = SyncController(cfg, K.ned2())
    c.reset(NED2_REST)
    assert c.check(NED2_REST)
    inside_since = None
    for i, res in enumerate(run(c, np.array([0, 0.0, 0.3, 0, 1.0, 0]), 240)):
        inside = not c.check(res.q_command)
        if inside and inside_since is None:
            inside_since = i
        assert inside or inside_since is None
    assert inside_since is not None and not res.holding
    assert np.linalg.norm(res.commanded_tcp - res.goal_tcp) < 1e-3


def test_orientation_suspended_near_column(ctl):
    """Ruhepose des wx250s -> Ziel dicht an der Säule, Orientierung nicht erreichbar:
    der Ned2 folgt nur der Position und bleibt ruhig; in der Arbeitspose wieder mit Orientierung."""
    sleep = np.array([0, -1.80, 1.55, 0, 0.8, 0])
    res = run(ctl, sleep, 300)
    assert not res[-1].orientation_active
    assert np.linalg.norm(res[-1].commanded_tcp - res[-1].goal_tcp) < 1e-3
    assert np.max(np.abs(res[-1].q_command - res[-30].q_command)) < 1e-3   # steht still
    res = run(ctl, np.array([0, 0.0, 0.3, 0, 1.0, 0]), 300)
    assert res[-1].orientation_active and res[-1].ik_ori_error < 0.02


def test_check_configurations(ctl):
    assert ctl.check(NED2_REST) == []
    assert ctl.check(np.array([0.0, 0.7, 0.0, 0.0, 0.0, 0.0]))       # Gelenk 2 über der Grenze
    assert ctl.check(np.array([0.0, -1.7, 1.4, 0.0, 0.0, 0.0]))      # TCP unter dem Tisch
    assert ctl.check(np.array([2.5, 0.0, 0.0, 0.0, 0.0, 0.0]))       # außerhalb des Sektors
