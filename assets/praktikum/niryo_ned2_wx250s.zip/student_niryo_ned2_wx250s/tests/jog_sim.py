"""Nachbildung des Niryo-Jog-Reglers (Software 5.0) für Offline-Tests des pyniryo-Backends.

Abgebildet (niryo_robot_arm_commander/scripts/jog_controller.py, v5.0.0):
* Jog-Befehl bei ausgeschaltetem Jog -> einschalten, Bezugspunkt = gemessene Lage
* Ziel = Bezugspunkt + Verschiebung (je Gelenk ±0,2 rad); der letzte Befehl gewinnt
* alle 0,15 s: anstehendes Ziel veröffentlichen (Gelenkregler fährt es in 0,15 s an),
  Bezugspunkt = dieses Ziel
* jede Sekunde: mehr als 0,5 s ohne Befehl -> Jog aus
Zusätzlich hinkt der echte Arm seiner Vorgabe nach (Verzögerung 1. Ordnung), und
gemessene Gelenkwinkel kommen verzögert an.
"""

import numpy as np

from ned2_wx250s_sync.follower_ned2_pyniryo import JOG_IDLE_DISABLE, JOG_MAX_SHIFT, JOG_PERIOD, JogPlanner


class NiryoJogSim:
    def __init__(self, q0, tick_phase=0.0, check_phase=0.3, robot_lag=0.0, latency=0.01, dt=0.001):
        self.dt, self.lag, self.latency = dt, robot_lag, latency
        self.t = 0.0
        self.enabled = False
        self.reference = np.array(q0, dtype=float)
        self.pending = None
        self.last_command = -1e9
        self.next_tick, self.next_check = tick_phase, check_phase
        self.seg = (self.reference.copy(), self.reference.copy(), -1.0)
        self.actual = self.reference.copy()
        self.history = [self.actual.copy()]
        self.published = []

    # --- Niryo-Schnittstelle -------------------------------------------
    def set_jog_control(self, enabled):
        if not enabled:
            self.enabled, self.pending = False, None
        else:          # enable() setzt den Bezugspunkt neu (auch wenn Jog schon an ist)
            self.enabled, self.reference = True, self.actual.copy()

    def jog_joints(self, shift):
        if not self.enabled:
            self.set_jog_control(True)
        self.last_command = self.t
        self.pending = self.reference + np.clip(shift, -JOG_MAX_SHIFT, JOG_MAX_SHIFT)

    # --- Zeit ------------------------------------------------------------
    def desired(self, t):
        start, end, t0 = self.seg
        return start + (end - start) * float(np.clip((t - t0) / JOG_PERIOD, 0.0, 1.0))

    def advance_to(self, t_end):
        while self.t + self.dt <= t_end + 1e-12:
            self.t += self.dt
            t = self.t
            if t >= self.next_tick:
                if self.enabled and self.pending is not None:
                    self.seg = (self.desired(t), self.pending, t)
                    self.reference, self.pending = self.pending, None
                    self.published.append((t, self.reference.copy()))
                self.next_tick += JOG_PERIOD
            if t >= self.next_check:
                if self.enabled and t - self.last_command > JOG_IDLE_DISABLE:
                    self.enabled, self.pending = False, None
                self.next_check += 1.0
            d = self.desired(t)
            self.actual = self.actual + (d - self.actual) * (min(1.0, self.dt / self.lag) if self.lag > 0 else 1.0)
            self.history.append(self.actual.copy())

    def measured(self):
        return self.history[max(0, len(self.history) - 1 - int(round(self.latency / self.dt)))]


def simulate(target_fn, duration, robot_lag=0.0, latency=0.01, tick_phase=0.0, check_phase=0.3,
             loop_period=0.008, call_time=0.005, max_shift=0.15):
    """Backend-Planung (JogPlanner) gegen die Nachbildung. Rückgabe: Zeiten, Ziele, Ist-Lagen, Sim."""
    q0 = np.zeros_like(np.asarray(target_fn(0.0), dtype=float))
    sim = NiryoJogSim(q0, tick_phase, check_phase, robot_lag, latency)
    planner = JogPlanner(max_shift)
    ts, targets, actual = [], [], []
    t = 0.0
    while t < duration:
        target = np.asarray(target_fn(t), dtype=float)
        plan = planner.plan(t, target, sim.measured())
        if plan is not None:
            resync, base, shift = plan
            if resync:
                sim.set_jog_control(False)
            sim.jog_joints(shift)
            sim.advance_to(t + call_time)
            t += call_time
            planner.sent(t, base, shift, True)
        sim.advance_to(t + loop_period)
        t += loop_period
        ts.append(t)
        targets.append(target)
        actual.append(sim.actual.copy())
    return np.array(ts), np.array(targets), np.array(actual), sim
