import numpy as np
import pytest

from ned2_wx250s_sync import kinematics as K
from ned2_wx250s_sync.mapping import JOINT_SIGNS

RNG = np.random.default_rng(42)


@pytest.fixture(scope='module')
def ned():
    return K.ned2()


@pytest.fixture(scope='module')
def wx():
    return K.wx250s()


def naive_fk(arm, q):
    T = np.eye(4)
    for i in range(arm.dof):
        T = T @ K.exp_twist(arm.Slist[:, i], q[i])
    return T @ arm.M


def test_ned2_zero_pose_matches_robot(ned):
    # Werte vom FK-Service des Ned2 (Software 5.0, Greifer 1, TCP 85 mm)
    assert np.allclose(ned.fk(np.zeros(6))[:3, 3], [0.380, 0.0, 0.429], atol=1e-3)
    assert np.allclose(ned.fk([0, 0.5, -1.25, 0, 0, 0])[:3, 3], [0.202, 0.0, 0.146], atol=1e-3)
    assert np.allclose(ned.fk(np.zeros(6))[:3, :3], np.eye(3), atol=1e-9)


def test_fk_matches_naive_product(ned, wx):
    for arm in (ned, wx):
        for _ in range(20):
            q = RNG.uniform(arm.lower, arm.upper)
            assert np.allclose(arm.fk(q), naive_fk(arm, q), atol=1e-12)


def test_jacobian_matches_finite_differences(ned):
    for _ in range(10):
        q = RNG.uniform(ned.lower, ned.upper)
        J, T = ned.jacobian(q)
        eps = 1e-6
        for i in range(6):
            d = np.zeros(6)
            d[i] = eps
            T2 = ned.fk(q + d)
            assert np.allclose(J[:3, i], (T2[:3, 3] - T[:3, 3]) / eps, atol=1e-5)
            assert np.allclose(J[3:, i], K.rotation_log(T2[:3, :3] @ T[:3, :3].T) / eps, atol=1e-5)


def test_same_topology_gives_same_orientation(ned, wx):
    """Gleiche Achsen bis aufs Vorzeichen: gespiegelte Gelenkwinkel -> identische Orientierung."""
    for _ in range(20):
        q = RNG.uniform(-1.5, 1.5, 6)
        assert np.allclose(ned.fk(JOINT_SIGNS * q)[:3, :3], wx.fk(q)[:3, :3], atol=1e-12)


def test_rpy_roundtrip():
    for _ in range(20):
        rpy = RNG.uniform([-3, -1.5, -3], [3, 1.5, 3])
        assert np.allclose(K.matrix_to_rpy(K.rpy_to_matrix(*rpy)), rpy, atol=1e-9)


def test_rotation_log_near_pi():
    R = K.rpy_to_matrix(np.pi - 1e-8, 0, 0)
    assert np.isclose(np.linalg.norm(K.rotation_log(R)), np.pi, atol=1e-6)


def test_ik_roundtrip(ned):
    ori_ok = 0
    for _ in range(30):
        q = RNG.uniform(ned.lower + 0.1, ned.upper - 0.1)
        T = ned.fk(q)
        seed = np.clip(q + RNG.normal(0, 0.2, 6), ned.lower, ned.upper)
        res = K.solve_ik(ned, T, seed, limit_margin=0.0, max_iterations=100)
        assert res.pos_error < 1e-3
        assert ned.within_limits(res.q)
        ori_ok += res.ori_error < 1e-2
    # an Gelenkanschlägen kann die Orientierung in einem lokalen Minimum enden
    assert ori_ok >= 27


def test_ik_position_priority(ned):
    """Unerreichbare Orientierung darf die Position nicht verschlechtern."""
    T = np.eye(4)
    T[:3, 3] = [0.20, 0.0, 0.05]       # tief und nah an der Basis ...
    T[:3, :3] = K.rpy_to_matrix(0, -1.2, np.pi)   # ... Greifer nach hinten oben: nicht erreichbar
    res = K.solve_ik(ned, T, [0, -0.5, -0.5, 0, 1.0, 0], limit_margin=0.05, max_iterations=100)
    assert res.pos_error < 1e-3
    assert res.ori_error > 0.5


def test_ik_min_joint_height(ned):
    T = np.eye(4)
    T[:3, 3] = [0.40, 0.0, 0.04]       # weit vorn, tief, Greifer waagerecht -> Handgelenk zu tief
    res = K.solve_ik(ned, T, [0, -1.0, 0.3, 0, 0.5, 0], limit_margin=0.05, max_iterations=100,
                     min_joint_height=0.05)
    assert res.pos_error < 1e-3
    assert np.all(ned.fk_points(res.q)[1:-1, 2] > 0.05 - 1e-3)
