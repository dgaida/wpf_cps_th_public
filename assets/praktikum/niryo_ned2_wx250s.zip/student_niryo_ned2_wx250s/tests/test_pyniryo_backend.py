"""pyniryo-Backend gegen eine Nachbildung des Niryo-Jog-Reglers (Software 5.0)."""

import time
from types import SimpleNamespace

import numpy as np
import pytest

from jog_sim import NiryoJogSim, simulate
from ned2_wx250s_sync.follower_ned2_pyniryo import JogPlanner, Ned2PyNiryoFollower

PHASES = [(tick, check) for tick in (0.0, 0.05, 0.1) for check in (0.1, 0.6)]
LAGS = [0.0, 0.1, 0.3]       # s, Nachlauf des echten Arms hinter seiner Vorgabe


def test_planner_keeps_direction_and_spacing():
    p = JogPlanner(max_shift=0.15)
    resync, base, shift = p.plan(0.0, np.array([0.5, -0.25, 0, 0, 0, 0]), np.zeros(6))
    assert resync and np.isclose(np.max(np.abs(shift)), 0.15) and np.isclose(shift[0] / shift[1], -2.0)
    p.sent(0.01, base, shift, True)
    assert p.plan(0.1, np.ones(6), np.zeros(6)) is None                  # zu früh: Niryo-Takt abwarten
    resync, base, _ = p.plan(0.2, np.ones(6), np.zeros(6))
    assert not resync and np.allclose(base, shift)                        # Bezugspunkt mitgerechnet


@pytest.mark.parametrize('lag', LAGS)
def test_step_and_ramp_without_overshoot_or_oscillation(lag):
    step = lambda t: np.array([0.4 if t > 0.2 else 0.0])
    ramp = lambda t: np.array([0.5 * min(max(t - 0.2, 0.0), 1.0)])    # 0,5 rad/s, dann Stopp
    for fn, final in ((step, 0.4), (ramp, 0.5)):
        for tick, check in PHASES:
            t, _, q, _ = simulate(fn, 4.0, robot_lag=lag, tick_phase=tick, check_phase=check)
            assert q[:, 0].max() - final < 0.005                  # kein Überschießen
            late = q[t > 3.0, 0]
            assert late.max() - late.min() < 1e-3                  # kein Hin und Her
            assert abs(q[-1, 0] - final) < 1e-3                    # kein Driften


@pytest.mark.parametrize('lag', LAGS)
def test_pause_and_resume_without_jump_back(lag):
    """Ziel steht 1 s still (Niryo schaltet Jog ab), dann geht es weiter."""
    fn = lambda t: np.array([0.0 if t < 0.2 else 0.3 + 0.3 * min(max(t - 3.0, 0.0), 1.0)])
    for tick, check in PHASES:
        t, _, q, sim = simulate(fn, 6.5, robot_lag=lag, tick_phase=tick, check_phase=check)
        assert q[t > 2.5, 0].min() > 0.3 - 0.01
        assert abs(q[-1, 0] - 0.6) < 1e-3


def test_tracks_moving_target_within_niryo_limits():
    sine = lambda t: np.array([0.3 * np.sin(0.6 * np.pi * t)])   # Spitze 0,57 rad/s
    for tick, check in PHASES:
        t, target, q, sim = simulate(sine, 6.0, robot_lag=0.1, tick_phase=tick, check_phase=check)
        err = target[t > 1.0, 0] - q[t > 1.0, 0]
        assert np.sqrt(np.mean(err ** 2)) < 0.15
        steps = np.diff([p[1][0] for p in sim.published])
        assert np.max(np.abs(steps)) <= 0.2                      # Niryos Grenze je Befehl


class FakeNiryo:
    """pyniryo-Client gegen den nachgebildeten Jog-Regler, in Echtzeit."""

    def __init__(self):
        self.t0 = time.monotonic()
        self.sim = NiryoJogSim(np.zeros(6), robot_lag=0.1, latency=0.005)
        self.learning = False
        self.calibration_needed = False
        self.jogs = 0
        self.enable_calls = 0

    def _sync(self):
        self.sim.advance_to(time.monotonic() - self.t0)

    def get_joints(self):
        time.sleep(0.002)
        self._sync()
        return list(self.sim.measured())

    def get_learning_mode(self):
        return self.learning

    def get_hardware_status(self):
        return SimpleNamespace(calibration_needed=self.calibration_needed, calibration_in_progress=False,
                               motor_names=['joint_%d' % i for i in range(1, 7)],
                               hardware_errors=[0] * 6, error_message="''")

    def get_current_tool_id(self):
        return SimpleNamespace(value=11)

    def set_jog_control(self, enabled):
        self._sync()
        self.enable_calls += bool(enabled)
        self.sim.set_jog_control(enabled)

    def jog_joints(self, *shift):
        assert not self.learning and not self.calibration_needed
        self._sync()
        self.sim.jog_joints(np.array(shift))
        self.jogs += 1

    def close_connection(self):
        pass


def drive(follower, target, seconds):
    end = time.monotonic() + seconds
    while time.monotonic() < end:
        follower.send_joints(target)
        time.sleep(1 / 30)


def test_follower_thread_reaches_target_and_respects_learning_mode():
    fake = FakeNiryo()
    f = Ned2PyNiryoFollower('sim', robot_factory=lambda host: fake)
    f.connect()
    try:
        assert f.has_gripper and f.tcp_offset() is not None and f.hardware_errors() == []
        target = np.array([0.3, -0.2, 0.1, 0.0, 0.2, -0.1])
        drive(f, target, 2.0)
        assert np.max(np.abs(f.joints() - target)) < 0.01
        assert f.jog_commands >= 2
        assert fake.enable_calls == 0     # Einschalten bei laufendem Jog würde zurückspringen lassen

        # Learning-Mode (Freedrive) oder fehlende Kalibrierung: keine Jog-Befehle
        for attr in ('learning', 'calibration_needed'):
            setattr(fake, attr, True)
            time.sleep(0.6)                        # Statusabfrage abwarten
            before = fake.jogs
            drive(f, target + 0.2, 0.5)
            assert fake.jogs == before
            setattr(fake, attr, False)
    finally:
        f.close()
