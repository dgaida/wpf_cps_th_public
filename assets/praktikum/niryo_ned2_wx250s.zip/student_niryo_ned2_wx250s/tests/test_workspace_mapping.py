import numpy as np
import pytest

from ned2_wx250s_sync import kinematics as K
from ned2_wx250s_sync.config import DEFAULT_CONFIG, load_config
from ned2_wx250s_sync.mapping import Mapping
from ned2_wx250s_sync.workspace import Workspace

RNG = np.random.default_rng(7)


def test_default_config_loads():
    cfg = load_config(DEFAULT_CONFIG)
    assert cfg.ned2.host == '192.168.0.141'
    assert isinstance(cfg.workspace, Workspace)
    assert isinstance(cfg.workspace.radius, tuple)


def test_unknown_config_key_rejected(tmp_path):
    p = tmp_path / 'bad.yaml'
    p.write_text('workspace:\n  radus: [0.1, 0.4]\n')
    with pytest.raises(ValueError, match='radus'):
        load_config(p)


def test_invalid_workspace_rejected():
    with pytest.raises(ValueError):
        Workspace(z=(0.5, 0.1))


def test_clamp_puts_points_inside():
    ws = Workspace(box_x=(0.0, 0.35), box_y=(-0.25, 0.3))
    for _ in range(500):
        p = RNG.uniform([-0.8, -0.8, -0.3], [0.8, 0.8, 0.9])
        q, clamped = ws.clamp(p)
        assert ws.contains(q, tol=1e-6), (p, q, ws.violations(q))
        assert clamped == (not ws.contains(p))


def test_clamp_keeps_inside_points():
    ws = Workspace()
    p = np.array([0.3, 0.05, 0.2])
    q, clamped = ws.clamp(p)
    assert not clamped and np.array_equal(p, q)


def test_clamp_examples():
    ws = Workspace(radius=(0.15, 0.45), yaw_deg=(-90, 90), z=(0.03, 0.5), max_reach=1.0)
    q, _ = ws.clamp([0.3, 0.0, -0.1])            # unter dem Tisch -> auf z_min
    assert np.allclose(q, [0.3, 0.0, 0.03])
    q, _ = ws.clamp([0.05, 0.0, 0.2])            # zu nah an der Säule -> r_min
    assert np.allclose(q, [0.15, 0.0, 0.2])
    q, _ = ws.clamp([-0.1, 0.3, 0.2])            # hinter dem Roboter -> nächste Sektorgrenze
    assert np.allclose(q[:2], [0.0, np.hypot(0.1, 0.3)], atol=1e-9)


def check_mapping(m: Mapping):
    wx, ned = K.wx250s(), K.ned2()
    for _ in range(20):
        p = RNG.uniform(-0.5, 0.5, 3)
        assert np.allclose(m.position_inverse(m.position(p)), p)
        # Gelenkweise Entsprechung und kartesische Abbildung passen zusammen
        q = RNG.uniform(-1.4, 1.4, 6)
        assert np.allclose(m.pose(wx.fk(q))[:3, :3], ned.fk(m.joints(q))[:3, :3], atol=1e-9)


def test_mapping_inverse():
    check_mapping(Mapping(scale=0.8, yaw_deg=30, offset=(0.05, -0.02, 0.01)))


def test_mapped_joints_reproduce_mapped_orientation():
    check_mapping(Mapping(yaw_deg=25))


def test_mirror_mode():
    """Spiegelmodus für gegenüberstehende Roboter (nicht Teil der Praktikumsaufgabe)."""
    check_mapping(Mapping(scale=0.8, yaw_deg=30, offset=(0.05, -0.02, 0.01), mirror=True))


def test_check_arm_points_ignores_tcp():
    ws = Workspace(min_joint_height=0.05)
    pts = np.array([[0, 0, 0.1], [0, 0, 0.16], [0, 0, 0.3], [0.1, 0, 0.3], [0.2, 0, 0.04],
                    [0.2, 0, 0.06], [0.3, 0, 0.01]])
    assert ws.check_arm_points(pts) == ['Gelenk 5 zu tief']
