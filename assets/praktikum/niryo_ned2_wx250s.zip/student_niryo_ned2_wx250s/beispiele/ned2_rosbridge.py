#!/usr/bin/env python3
"""Beispiel: Niryo Ned2 über rosbridge (roslibpy) verbinden und steuern.

    python3 beispiele/ned2_rosbridge.py              nur lesen (Status, Gelenkwinkel)
    python3 beispiele/ned2_rosbridge.py --bewegen    zusätzlich bewegen – Not-Halt bereithalten!

Schritte (Erklärung in aufgabe/tutorial_ned2_rosbridge.md):
  1. Verbinden
  2. Status lesen
  3. Kalibrierung prüfen
  4. Learning-Mode ausschalten
  5. Einzelne Bewegung: Gelenk 1 um 0,2 rad hin und zurück
  6. Gelenkziele laufend senden (30 Hz) – so wie beim Nachführen
  7. Greifer öffnen und schließen
"""

import argparse
import logging
import math
import time
import uuid

import roslibpy

# Twisted 18.9 (Ubuntu 20.04) und das Logging von Python 3.8 vertragen sich nicht
logging.getLogger('twisted').setLevel(logging.WARNING)

HOST = '192.168.0.141'
JOINTS = ['joint_1', 'joint_2', 'joint_3', 'joint_4', 'joint_5', 'joint_6']
JOINT_1_LIMIT = 3.0          # rad, Gelenkgrenze von Gelenk 1 (±)
TRAJECTORY_TOPIC = '/niryo_robot_follow_joint_trajectory_controller/command'
TOOL_GOAL_TOPIC = '/niryo_robot_tools_commander/action_server/goal'
GRIPPER_TOOL_IDS = (11, 12, 13)


def read_once(ros, name, msg_type, timeout=5.0):
    """Eine Nachricht von einem Topic lesen."""
    received = []
    topic = roslibpy.Topic(ros, name, msg_type, queue_length=1)
    topic.subscribe(received.append)
    end = time.time() + timeout
    while not received and time.time() < end:
        time.sleep(0.02)
    topic.unsubscribe()
    if not received:
        raise RuntimeError('Keine Nachricht auf %s' % name)
    return received[0]


def get_joints(ros):
    msg = read_once(ros, '/joint_states', 'sensor_msgs/JointState')
    return [msg['position'][msg['name'].index(j)] for j in JOINTS]


def send_joints(publisher, q, duration):
    """Gelenkziel an den Trajektorien-Controller: in `duration` Sekunden nach q fahren.

    Ein neues Ziel ersetzt das vorige sofort. Die Prüfungen der Niryo-Software
    (Gelenkgrenzen, Kollisionen) greifen hier NICHT – Grenzen selbst einhalten!
    """
    secs = int(duration)
    publisher.publish(roslibpy.Message({
        # Stempel 0 = "sofort starten"; die Uhr des Ned2 geht falsch
        'header': {'stamp': {'secs': 0, 'nsecs': 0}, 'frame_id': ''},
        'joint_names': JOINTS,
        'points': [{'positions': [float(v) for v in q], 'velocities': [], 'accelerations': [],
                    'effort': [], 'time_from_start': {'secs': secs, 'nsecs': int((duration - secs) * 1e9)}}],
    }))


def gripper(publisher, tool_id, close):
    """Greiferbefehl als Goal an den Action-Server der Niryo-Werkzeuge (roslibpy 2.x hat kein actionlib)."""
    stamp = {'secs': 0, 'nsecs': 0}
    publisher.publish(roslibpy.Message({
        'header': {'stamp': stamp, 'frame_id': ''},
        'goal_id': {'stamp': stamp, 'id': 'beispiel_' + uuid.uuid4().hex[:8]},
        'goal': {'cmd': {'cmd_type': 2 if close else 1,          # 1 = öffnen, 2 = schließen
                         'tool_id': tool_id, 'speed': 500, 'max_torque_percentage': 100,
                         'hold_torque_percentage': 30, 'activate': False, 'gpio': ''}},
    }))


def confirm(question):
    return input('%s [j/N] ' % question).strip().lower() in ('j', 'ja')


def main():
    parser = argparse.ArgumentParser(description='Ned2 über rosbridge – Beispiel')
    parser.add_argument('--bewegen', action='store_true', help='auch bewegen (sonst nur lesen)')
    args = parser.parse_args()

    # 1. Verbinden: rosbridge läuft auf dem Ned2 (WebSocket, Port 9090)
    ros = roslibpy.Ros(host=HOST, port=9090)
    ros.run(timeout=10)
    print('Verbunden mit %s:9090' % HOST)
    try:
        # 2. Status lesen
        hw = read_once(ros, '/niryo_robot_hardware_interface/hardware_status', 'niryo_robot_msgs/HardwareStatus')
        learning = read_once(ros, '/niryo_robot/learning_mode/state', 'std_msgs/Bool')['data']
        tool_id = read_once(ros, '/niryo_robot_tools_commander/current_id', 'std_msgs/Int32')['data']
        q0 = get_joints(ros)
        print('Kalibrierung nötig :', hw['calibration_needed'])
        print('Learning-Mode      :', learning)
        print('Werkzeug-ID        :', tool_id)
        print('Gelenke [rad]      :', [round(v, 3) for v in q0])
        if not args.bewegen:
            print('Nur gelesen. Mit --bewegen fährt der Ned2 (Not-Halt bereithalten!).')
            return

        # 3. Kalibrierung: der Service antwortet erst, wenn sie fertig ist -> nicht blockierend aufrufen
        if hw['calibration_needed']:
            if not confirm('Ned2 kalibrieren? Der Arm bewegt sich!'):
                return
            roslibpy.Service(ros, '/niryo_robot/joints_interface/calibrate_motors', 'niryo_robot_msgs/SetInt') \
                .call(roslibpy.ServiceRequest({'value': 1}), callback=lambda r: None, errback=print)
            end = time.time() + 120
            while time.time() < end:
                time.sleep(1.0)
                hw = read_once(ros, '/niryo_robot_hardware_interface/hardware_status',
                               'niryo_robot_msgs/HardwareStatus')
                if not hw['calibration_needed'] and not hw['calibration_in_progress']:
                    break
            print('Kalibriert.')
            q0 = get_joints(ros)

        # 4. Learning-Mode aus = Motoren an (sonst ist der Arm frei beweglich)
        if learning:
            roslibpy.Service(ros, '/niryo_robot/learning_mode/activate', 'niryo_robot_msgs/SetBool') \
                .call(roslibpy.ServiceRequest({'value': False}), timeout=10)
            time.sleep(1.0)

        direction = -1.0 if q0[0] > JOINT_1_LIMIT - 0.3 else 1.0     # an der Grenze in die andere Richtung
        if not confirm('Gelenk 1 (Basis) um %+.1f rad hin und zurück drehen?' % (0.2 * direction)):
            return
        trajectory = roslibpy.Topic(ros, TRAJECTORY_TOPIC, 'trajectory_msgs/JointTrajectory', queue_size=1)
        trajectory.advertise()
        time.sleep(0.5)                  # Verbindung zum Controller aufbauen lassen

        # 5. Einzelne Bewegung: Ziel senden, der Controller fährt es in 3 s an
        target = list(q0)
        target[0] += 0.2 * direction
        send_joints(trajectory, target, 3.0)
        time.sleep(3.5)
        send_joints(trajectory, q0, 3.0)
        time.sleep(3.5)

        # 6. Laufend senden (30 Hz): jedes Ziel 0,15 s voraus – so arbeitet die Synchronisation
        print('Laufend senden: Gelenk 1 pendelt 6 s lang um ±0,15 rad')
        t0 = time.time()
        while time.time() - t0 < 6.0:
            q = list(q0)
            q[0] += 0.15 * direction * math.sin(2 * math.pi * (time.time() - t0) / 3.0)
            send_joints(trajectory, q, 0.15)
            time.sleep(1 / 30)
        send_joints(trajectory, q0, 1.0)
        time.sleep(1.5)
        print('Gelenke [rad]      :', [round(v, 3) for v in get_joints(ros)])

        # 7. Greifer öffnen und schließen; die Antwort von Niryo kommt auf .../result
        if tool_id in GRIPPER_TOOL_IDS and confirm('Greifer öffnen und schließen?'):
            results = roslibpy.Topic(ros, '/niryo_robot_tools_commander/action_server/result',
                                     'niryo_robot_tools_commander/ToolActionResult')
            results.subscribe(lambda m: print('  Niryo:', m['result']['message']))
            goals = roslibpy.Topic(ros, TOOL_GOAL_TOPIC, 'niryo_robot_tools_commander/ToolActionGoal', queue_size=1)
            goals.advertise()
            time.sleep(0.5)
            for close in (False, True):
                print('Greifer %s' % ('schließen' if close else 'öffnen'))
                gripper(goals, tool_id, close)
                time.sleep(2.0)
    finally:
        ros.terminate()


if __name__ == '__main__':
    main()
