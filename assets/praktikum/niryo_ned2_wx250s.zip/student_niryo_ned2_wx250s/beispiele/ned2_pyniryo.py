#!/usr/bin/env python3
"""Beispiel: Niryo Ned2 über pyniryo (TCP-Port 40001) verbinden und steuern.

    python3 beispiele/ned2_pyniryo.py              nur lesen (Status, Gelenkwinkel, Pose)
    python3 beispiele/ned2_pyniryo.py --bewegen    zusätzlich bewegen – Not-Halt bereithalten!

Installation (auf dem Jetson CPS 1242 schon erledigt), OHNE Abhängigkeiten –
pyniryo zieht sonst enum34, das unter Python 3.8 das eingebaute enum überschreibt:
    pip3 install --user --no-deps pyniryo==1.2.5

Schritte (Erklärung in aufgabe/tutorial_ned2_pyniryo.md):
  1. Verbinden
  2. Status lesen
  3. Kalibrierung prüfen
  4. Learning-Mode ausschalten
  5. Geplante Bewegung (move_joints): Gelenk 1 um 0,2 rad hin und zurück
  6. Jog: relative Verschiebungen ohne Planung – so lässt sich laufend nachführen
  7. Greifer öffnen und schließen
"""

import argparse
import math
import time
import warnings

from pyniryo import NiryoRobot

# move_joints/jog_joints gelten in pyniryo 1.2 als veraltet. Die neuen Namen
# (move/jog) kennt die Niryo-Software 5.0 auf dem Ned2 aber noch nicht.
warnings.simplefilter('ignore', DeprecationWarning)

HOST = '192.168.0.141'
JOINT_1_LIMIT = 3.0          # rad, Gelenkgrenze von Gelenk 1 (±)
JOG_SPACING = 0.16           # s zwischen Jog-Befehlen (Niryo übernimmt nur alle 0,15 s einen)
GRIPPER_TOOL_IDS = (11, 12, 13)


def confirm(question):
    return input('%s [j/N] ' % question).strip().lower() in ('j', 'ja')


def main():
    parser = argparse.ArgumentParser(description='Ned2 über pyniryo – Beispiel')
    parser.add_argument('--bewegen', action='store_true', help='auch bewegen (sonst nur lesen)')
    args = parser.parse_args()

    # 1. Verbinden (Port 40001 ist in pyniryo fest eingestellt)
    robot = NiryoRobot(HOST)
    try:
        # 2. Status lesen
        need_calibration = robot.need_calibration()
        learning = robot.get_learning_mode()
        tool_id = robot.get_current_tool_id().value
        q0 = list(robot.get_joints())
        print('Kalibrierung nötig :', need_calibration)
        print('Learning-Mode      :', learning)
        print('Werkzeug-ID        :', tool_id)
        print('Gelenke [rad]      :', [round(v, 3) for v in q0])
        print('Pose (TCP)         :', robot.get_pose())
        if not args.bewegen:
            print('Nur gelesen. Mit --bewegen fährt der Ned2 (Not-Halt bereithalten!).')
            return

        # 3. Kalibrierung – blockiert, bis sie fertig ist
        if need_calibration:
            if not confirm('Ned2 kalibrieren? Der Arm bewegt sich!'):
                return
            robot.calibrate_auto()
            q0 = list(robot.get_joints())

        # 4. Learning-Mode aus = Motoren an
        if learning:
            robot.set_learning_mode(False)

        direction = -1.0 if q0[0] > JOINT_1_LIMIT - 0.3 else 1.0     # an der Grenze in die andere Richtung
        if not confirm('Gelenk 1 (Basis) um %+.1f rad hin und zurück drehen?' % (0.2 * direction)):
            return

        # 5. Geplante Bewegung: Niryo plant die Bahn, prüft Grenzen und Kollisionen
        #    und kehrt erst zurück, wenn das Ziel erreicht ist
        robot.set_arm_max_velocity(30)          # 30 % der Höchstgeschwindigkeit
        target = list(q0)
        target[0] += 0.2 * direction
        robot.move_joints(target)
        robot.move_joints(q0)

        # 6. Jog: relative Verschiebung ohne Planung. Niryos Jog-Regler rechnet
        #    neues Ziel = zuletzt übernommenes Ziel + Verschiebung und übernimmt nur
        #    alle 0,15 s einen Befehl. Deshalb: höchstens alle 0,16 s senden und den
        #    Bezugspunkt selbst mitrechnen – nicht gegen die gemessene Lage rechnen,
        #    der Arm hinkt hinterher und würde sonst hin und her pendeln.
        print('Jog: Gelenk 1 pendelt 6 s lang um ±0,15 rad')
        robot.set_jog_control(False)            # sauberer Start: der erste Befehl übernimmt die gemessene Lage
        reference = list(robot.get_joints())    # Niryos Bezugspunkt
        start = list(reference)
        t0 = time.time()
        while True:
            t = time.time() - t0
            goal = list(start)
            goal[0] += 0.15 * direction * math.sin(2 * math.pi * min(t, 6.0) / 3.0)
            shift = [g - r for g, r in zip(goal, reference)]
            if max(abs(s) for s in shift) > 1e-4:
                robot.jog_joints(shift)
                reference = goal
            if t >= 6.0:
                break
            time.sleep(JOG_SPACING)
        time.sleep(0.5)
        robot.set_jog_control(False)
        print('Gelenke [rad]      :', [round(v, 3) for v in robot.get_joints()])

        # 7. Greifer – die Aufrufe blockieren, bis der Greifer fertig ist
        if tool_id in GRIPPER_TOOL_IDS and confirm('Greifer öffnen und schließen?'):
            print('Greifer öffnen')
            robot.open_gripper(speed=500, max_torque_percentage=100, hold_torque_percentage=30)
            print('Greifer schließen')
            robot.close_gripper(speed=500, max_torque_percentage=100, hold_torque_percentage=30)
    finally:
        robot.close_connection()


if __name__ == '__main__':
    main()
