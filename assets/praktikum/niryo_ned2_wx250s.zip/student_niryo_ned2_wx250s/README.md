# Ned2 folgt wx250s – Leader-Follower-Synchronisation

Der **WidowX 250s** (Trossen/Interbotix, an diesem Rechner) wird von Hand geführt,
der **Niryo Ned2** (192.168.0.141) folgt seinen Bewegungen: Greiferposition,
Greiferorientierung und Öffnen/Schließen des Greifers.

Weil der Ned2 kleiner ist und engere Gelenkgrenzen hat, kann er nicht jede Pose
des wx250s einnehmen. Deshalb gibt es einen **Arbeitsraum**: einen fest
definierten Raum, den der TCP des Ned2 nie verlässt. Führt man den wx250s
darüber hinaus, gleitet der Ned2 an der Grenze entlang, statt anzuhalten
oder irgendwo anzustoßen.

```
wx250s ──USB──> Interbotix xs_sdk (ROS2) ──/wx250s/joint_states──┐
                                                                  v
            ned2_wx250s_sync  (30 Hz)
            FK wx250s -> Abbildung (Skalierung) -> Arbeitsraum -> IK Ned2
            -> Sicherheitsprüfung -> Geschwindigkeitsbegrenzung
                                                                  │
Ned2 <──rosbridge (WebSocket 9090)── JointTrajectory ─────────────┘
```

## Installation

Vorhanden sein müssen ROS2 Galactic und der Interbotix-Workspace (`~/interbotix_ws`).
Dazu kommt:

```bash
pip3 install --user -r requirements.txt     # roslibpy für die Verbindung zum Ned2
pip3 install --user --no-deps pyniryo==1.2.5 # nur für ned2.backend: pyniryo (siehe unten)
```

pyniryo **ohne Abhängigkeiten** installieren: Es verlangt `enum34`, das unter
Python 3.8 das eingebaute `enum` überschreibt und andere Pakete beschädigt. Die
übrigen Abhängigkeiten (OpenCV, typing_extensions) sind schon vorhanden.

Auf dem Ned2 ist nichts zu installieren: rosbridge (Port 9090) und der
pyniryo-Server (Port 40001) sind Teil der Niryo-Software.

### Zwei Wege zum Ned2

| | `rosbridge` (Standard) | `pyniryo` |
|---|---|---|
| Befehle | absolute Gelenkziele, 30 Hz, an den Trajektorien-Controller | relative Jog-Befehle an Niryos Jog-Regler |
| Aktualisierung am Ned2 | 30-mal pro Sekunde | höchstens alle 0,16 s (Niryo-Takt 0,15 s) |
| Geschwindigkeit | bis 1,0–1,5 rad/s | höchstens 0,6 rad/s (`ned2.pyniryo.max_joint_velocity`) |
| Niryos Gelenk-/Kollisionsprüfungen | umgangen (eigene Prüfungen) | aktiv, zusätzlich zu den eigenen |
| Greifer | blockiert nichts | der Arm steht, solange der Greifer schaltet |

Umschalten mit `ned2.backend` in `config/sync.yaml` oder `--backend pyniryo`.

Hinweise zum pyniryo-Weg:

* Niryos Jog-Regler rechnet jede Verschiebung relativ zu seinem *letzten  
  veröffentlichten* Ziel und übernimmt nur alle 0,15 s den zuletzt
  eingegangenen Befehl. Der echte Arm hinkt seiner Vorgabe zudem merklich
  hinterher. Verschiebungen gegen die gemessene Lage zu rechnen, lässt den Arm
  deshalb hin- und herpendeln. Das Programm sendet stattdessen höchstens alle
  0,16 s, sodass Niryo jeden Befehl genau einmal übernimmt, und rechnet Niryos
  Bezugspunkt selbst mit. Nach einer Pause wird Jog gezielt aus- und mit dem
  nächsten Befehl wieder eingeschaltet, damit Niryo neu auf die gemessene Lage
  aufsetzt. In der Nachbildung des Reglers (`tests/jog_sim.py`) mit bis zu
  0,4 s Nachlauf gibt es so kein Überschießen und kein Pendeln. Bei schnellen
  Bewegungen hinkt der Ned2 dafür deutlich hinterher.  
* Weicht ein Gelenk mehr als 0,2 rad von Niryos Vorgabe ab, wertet Niryo das als  
  Kollision und schaltet den **Learning-Mode** ein (Arm kraftlos). Das Programm
  pausiert dann.  
* Den TCP kann pyniryo mit der Niryo-Software 5.0 nicht lesen. Für den Greifer 1  
  ist er hinterlegt, für andere Werkzeuge muss `ned2.tcp` gesetzt werden.

## Bedienung

**1. Treiber für den wx250s starten** (eigenes Terminal, öffnet RViz):

```bash
scripts/start_wx250s.sh
```

**2. Ned2 prüfen** – Verbindung, Kalibrierung, Werkzeug, Hardwarefehler und ein
Abgleich des Kinematikmodells mit dem Roboter. Der Abgleich rechnet nur, der Arm
bewegt sich nicht.

```bash
python3 scripts/ned2_status.py
python3 scripts/ned2_status.py --calibrate   # (neu) kalibrieren, auch wenn schon kalibriert (Arm bewegt sich!)
```

**3. Probelauf ohne Bewegung des Ned2** – der wx250s wird freigeschaltet, das
Programm zeigt an, wohin der Ned2 fahren würde:

```bash
scripts/run_sync.sh --dry-run
```

**4. Synchronisation** – der Ned2 folgt dem wx250s:

```bash
scripts/run_sync.sh              # fragt vor dem Freischalten des wx250s und vor dem Start nach
scripts/run_sync.sh --calibrate  # Ned2 bei Bedarf vorher kalibrieren
```

Ablauf: Das Programm schaltet das Drehmoment des wx250s ab (**Arm vorher festhalten
oder in der Ruhepose ablegen**). Der Ned2 fährt anschließend langsam in die passende
Startpose und folgt dann. **Strg+C** beendet. Der wx250s hält danach seine Pose
(Drehmoment wieder an), der Ned2 bleibt stehen.

Die Statuszeile zeigt einmal pro Sekunde den Modus (`Anfahrt`, `Folgen`, `HALT`),
die TCP-Position beider Arme und ob das Ziel begrenzt wurde:

```
Folgen  wx250s (+0.382 -0.005 +0.013)  Ned2-Ziel (+0.344 -0.005 +0.030)  Ned2 (+0.344 -0.005 +0.030)  Orient.-Abw.  0.0° [begrenzt ...]
```

| Option | Wirkung |
|---|---|
| `--dry-run` | rechnen und anzeigen, nichts an den Ned2 senden |
| `--backend pyniryo` | Ned2 über pyniryo (Jog) statt rosbridge ansteuern |
| `--offline` | ganz ohne Ned2-Verbindung (impliziert `--dry-run`) |
| `--sim-leader` | simulierte wx250s-Bewegung statt des echten Arms |
| `--calibrate` | Ned2 bei Bedarf kalibrieren |
| `--yes` | Sicherheitsabfragen automatisch bestätigen |
| `--config DATEI` | andere Konfiguration (Standard: `config/sync.yaml`) |

## Der Arbeitsraum

Definiert in `config/sync.yaml` unter `workspace`, im Basis-Koordinatensystem
des Ned2 (x nach vorn, z nach oben, Ursprung am Fuß). Erlaubt ist die
**Schnittmenge** aus:

| Teil | Standard | Zweck |
|---|---|---|
| Zylindersektor: `radius`, `yaw_deg`, `z` | r 0,15–0,45 m, ±120°, z 0,03–0,50 m | Abstand zur Säule, Reichweite, Tisch |
| Quader: `box_x`, `box_y` | aus (`null`) | Wände, Tischkanten, Nachbarroboter aussparen |
| Kugel um die Schulter: `max_reach` | 0,50 m | nicht in die volle Streckung |
| `min_joint_height` | 0,05 m | Gelenke 2–6 bleiben über dem Tisch |

Verhalten:

* Ziele außerhalb werden auf den nächsten Punkt am Rand projiziert.  
* Jede Stellung, die an den Ned2 geht, wird vorher mit der Vorwärtskinematik  
  geprüft. Liegt der TCP außerhalb (Toleranz `ik.workspace_tolerance` = 1 cm) oder
  ein Gelenk zu tief, hält der Ned2 an.  
* Die Orientierung des Greifers wird übernommen, wo es geht. Die Position hat  
  immer Vorrang: Ist eine Orientierung an einem Ort nicht erreichbar, dreht der
  Ned2 den Greifer so weit wie möglich mit und bleibt trotzdem exakt auf
  Position. Beispiel: senkrecht nach unten geht nur bis ca. 30 cm Höhe.  
* Bleibt die Orientierung länger als 0,5 s mehr als 35° daneben, z. B. dicht an  
  der Säule, wird sie ausgesetzt (Status `Orient. ausgesetzt`). Der Ned2 folgt dann
  nur der Position, seine Handgelenke folgen der Haltung des wx250s. Sonst würde
  das Handgelenk dort unruhig nach Kompromissen suchen. Zweimal pro Sekunde prüft
  das Programm, ob die Orientierung wieder erreichbar ist (unter 20°).  
* Die **Ruhepose des wx250s** liegt nach der Abbildung direkt an der Säule des  
  Ned2 (Begrenzung auf `r_min`). Zum Starten den wx250s daher besser in eine
  normale Arbeitshaltung bringen, z. B. Greifer etwa 20–30 cm vor der Basis und
  10–15 cm über dem Tisch.

Nach jeder Änderung prüfen, ob der Ned2 den Raum auch erreicht (offline, ca. 15 s):

```bash
python3 scripts/check_workspace.py
```

Die Ausgabe zeigt einen Querschnitt (`#` = erreichbar) für „nur Position“ und
„Greifer nach unten“. Bei den Standardwerten ist der gesamte Raum positionsmäßig
erreichbar.

**In RViz ansehen:** Das Programm veröffentlicht den Arbeitsraum,
zurückgerechnet in den Frame des wx250s, als `MarkerArray` auf
`/ned2_sync/markers`. In RViz über *Add → By topic* einblenden. Dazu kommen zwei
Kugeln: grün das Ziel (orange, wenn begrenzt) und blau die kommandierte
Ned2-Pose. So sieht man beim Führen des wx250s direkt, wo der Ned2 noch exakt
folgt.

## Abbildung wx250s → Ned2

`mapping` in `config/sync.yaml`:

* `scale` (0,9): Die Positionen werden skaliert. Reichweite Schulter→TCP:  
  wx250s ca. 0,66 m, Ned2 mit Greifer ca. 0,59 m.  
* `yaw_deg`, `offset`: wie die Roboter zueinander stehen. Bei  
  `offset: [0, 0, 0]` entspricht die Tischebene des wx250s der des Ned2.  
* `mirror: true`: links/rechts spiegeln, z. B. wenn sich die Roboter gegenüberstehen.  
* `tool_rpy_deg`: falls der Greifer des Ned2 verdreht montiert ist.  

Beide Arme haben dieselbe Gelenkfolge (Drehen, Heben, Ellbogen, Unterarm-Rollen,
Handgelenk-Nicken, Handgelenk-Rollen). Die Haltung des wx250s wird deshalb
zusätzlich als Vorbild genutzt, wo die Pose allein die Gelenke nicht eindeutig
festlegt, z. B. bei gestrecktem Handgelenk.

**Greifer:** Den Greifer des wx250s kann man von Hand nicht schließen, sein
Getriebe (353:1) lässt sich praktisch nicht zurückdrehen. Den Greifer des Ned2
steuert man deshalb im Terminal der Synchronisation:

| Taste | Wirkung |
|---|---|
| Leertaste | umschalten |
| `o` | öffnen |
| `s` | schließen |

Die Statuszeile zeigt `Greifer zu` / `Greifer offen`. Lehnt Niryo einen
Greiferbefehl ab, steht der Grund im Log. Mit `gripper.source: wx250s` folgt der
Ned2-Greifer stattdessen der Fingerstellung des wx250s (`left_finger` unter 22 mm
→ schließen, über 30 mm → öffnen). `gripper.enabled: false` schaltet den Greifer
ganz ab.

## Sicherheit

* Beim rosbridge-Weg gehen Befehle direkt an den Trajektorien-Controller des  
  Ned2. Die Prüfungen des Niryo-Arm-Commanders greifen dabei **nicht**, deshalb
  übernimmt das Programm sie: Gelenkgrenzen mit 0,05 rad Abstand, Arbeitsraum,
  Gelenkhöhen und Geschwindigkeiten. Beim pyniryo-Weg prüft Niryo zusätzlich.  
* Geschwindigkeit: max. 0,35 m/s am TCP, Gelenke max. 1,0–1,5 rad/s  
  (`ned2.max_joint_velocity`). Alle Gelenke werden im selben Verhältnis
  gebremst, damit der TCP auf seiner Bahn bleibt.  
* Langsame Anfahrt (30 %) beim Start, nach jeder Pause und bei einem Wechsel der  
  Armkonfiguration.  
* Pausen, nach denen langsam weitergemacht wird: Gelenkwinkel des wx250s  
  älter als 0,3 s, Verbindungsabbruch, Not-Halt, Learning-Mode (Freedrive-Taste
  am Ned2), Hardwarefehler.  
* Meldet der Ned2 eine Kollision, beendet sich das Programm.  
* Bricht das Programm ab, fährt der Ned2 höchstens noch 0,15 s zu Ende und steht dann.  
* **Nicht abgedeckt** sind Kollisionen mit Gegenständen, mit dem wx250s oder mit  
  dem eigenen Greifer außerhalb der genannten Prüfungen. Den Arbeitsraum deshalb
  passend zum Aufbau einstellen und den Not-Halt des Ned2 in Reichweite halten.

## Tests ohne Hardware

```bash
python3 -m pytest                              # 37 Tests: Kinematik, Arbeitsraum, Regler, pyniryo-Backend
scripts/run_sync.sh --offline --sim-leader     # komplette Schleife, simulierter Leader
scripts/start_wx250s.sh use_sim:=true          # simulierter wx250s im Interbotix-Treiber,
scripts/run_sync.sh --offline                  #   dann mit dem echten ROS2-Pfad
```

Das Kinematikmodell des Ned2 stammt aus der `robot_description` des Roboters
(Software 5.0). `scripts/ned2_status.py` vergleicht es mit dessen
Vorwärtskinematik; die Abweichung liegt unter 1 mm, das ist die Rundung des Roboters.

## Projektstruktur

```
config/sync.yaml                 Konfiguration (Verbindung, Abbildung, Arbeitsraum, Grenzen)
ned2_wx250s_sync/
  kinematics.py                  FK/Jacobi (Product of Exponentials), priorisierte IK
  workspace.py                   Arbeitsraum: Prüfen und Projizieren
  mapping.py                     Abbildung wx250s -> Ned2
  controller.py                  Regelzyklus (ohne Hardware testbar)
  leader_wx250s.py               wx250s über ROS2 (Joint States, Torque)
  follower_ned2.py               Ned2 über rosbridge (Status, Trajektorien, Greifer)
  follower_ned2_pyniryo.py       Ned2 über pyniryo (Jog-Befehle, gleiche Schnittstelle)
  sim_leader.py, visualization.py, keyboard.py, config.py
  sync.py                        Hauptprogramm
scripts/                         Start-, Status- und Prüfskripte
beispiele/                       Ned2 verbinden und steuern: ned2_rosbridge.py, ned2_pyniryo.py
tests/                           pytest
```

## Fehlersuche

| Meldung | Abhilfe |
|---|---|
| `Interbotix-Treiber nicht gefunden` | `scripts/start_wx250s.sh` läuft nicht oder anderer `robot_name` |
| `Der Ned2 muss kalibriert werden` | mit `--calibrate` starten oder `scripts/ned2_status.py --calibrate` |
| `Keine rosbridge-Verbindung` | Netz/IP prüfen (`ping 192.168.0.141`), Port 9090 |
| Status `HALT … TCP außerhalb` | wx250s zurück in den Arbeitsraum führen (RViz-Marker) |
| Status `Zwischenpose: …` | ein Konfigurationswechsel würde durch verbotenes Gebiet führen – wx250s etwas anders halten |
| große `Orient.-Abw.` oder `Orient. ausgesetzt` | Orientierung an diesem Ort für den Ned2 nicht erreichbar (siehe `check_workspace.py`) – wx250s weiter von der Basis weg führen |
