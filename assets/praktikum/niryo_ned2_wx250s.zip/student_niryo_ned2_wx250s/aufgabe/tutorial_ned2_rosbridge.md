# Tutorial: Ned2 über ROS (rosbridge) steuern

*Praktikum „Ein Roboter führt den anderen“ – [Übersicht](../AUFGABE.md) ·
Beispielskript: [`beispiele/ned2_rosbridge.py`](../beispiele/ned2_rosbridge.py)*

Auf dem Ned2 läuft ROS 1 (Noetic). Ihr müsst auf dem Jetson aber kein ROS 1
installieren: Der Ned2 bietet **rosbridge** an, einen WebSocket-Server auf Port  
9090. Mit der Python-Bibliothek `roslibpy` lest ihr darüber Topics, ruft  
Services auf und veröffentlicht Nachrichten, als wärt ihr ein ROS-Knoten.

**Vorteil:** Ihr könnt Gelenkziele mit 30 Hz direkt an den Trajektorien-Controller
schicken; der Ned2 folgt flüssig. **Nachteil:** Dabei greifen die Prüfungen der
Niryo-Software nicht – Gelenkgrenzen, Arbeitsraum und Geschwindigkeit muss euer
Programm selbst einhalten.

## Ausprobieren

Auf dem Jetson CPS 1242 (`roslibpy` ist dort installiert):

```bash
python3 beispiele/ned2_rosbridge.py              # nur lesen
python3 beispiele/ned2_rosbridge.py --bewegen    # bewegt den Ned2 – zweite Person am Not-Halt!
```

Mit `--bewegen` fragt das Skript vor jedem Schritt nach. Es dreht nur Gelenk 1
um 0,2 rad und lässt es danach 6 s lang um ±0,15 rad pendeln.

## Schritt für Schritt

**1. Verbinden.** `run()` startet die Verbindung in einem Hintergrund-Thread.

```python
import roslibpy
ros = roslibpy.Ros(host='192.168.0.141', port=9090)
ros.run(timeout=10)
```

**2. Status lesen.** Topics abonniert man mit einem Callback; im Beispiel
liest `read_once()` genau eine Nachricht. Nachrichten sind Python-Dicts.

| Was | Topic | Typ |
|---|---|---|
| Gelenkwinkel | `/joint_states` | `sensor_msgs/JointState` |
| Kalibrierung, Fehler | `/niryo_robot_hardware_interface/hardware_status` | `niryo_robot_msgs/HardwareStatus` |
| Learning-Mode | `/niryo_robot/learning_mode/state` | `std_msgs/Bool` |
| Werkzeug | `/niryo_robot_tools_commander/current_id` | `std_msgs/Int32` |

Welche Topics und Services es gibt, verrät `ros.get_topics()` bzw. `ros.get_services()`.

**3. Kalibrieren.** Nach dem Einschalten muss der Ned2 kalibriert werden
(Service `/niryo_robot/joints_interface/calibrate_motors`, `value: 1`). Der
Service antwortet erst, wenn die Kalibrierung fertig ist – deutlich nach den
üblichen 10 s Timeout. Ruft ihn deshalb mit `callback=` auf (nicht blockierend)
und wartet, bis `hardware_status` nicht mehr `calibration_needed` meldet.

**4. Learning-Mode aus.** Im Learning-Mode sind die Motoren aus und der Arm ist
frei beweglich. Ausschalten mit Service `/niryo_robot/learning_mode/activate`
(`niryo_robot_msgs/SetBool`, `value: False`).

**5. Eine Bewegung.** Gelenkziele gehen als `trajectory_msgs/JointTrajectory`
mit **einem** Punkt an `/niryo_robot_follow_joint_trajectory_controller/command`.
`time_from_start` legt fest, in welcher Zeit der Controller das Ziel anfährt.

```python
topic = roslibpy.Topic(ros, '/niryo_robot_follow_joint_trajectory_controller/command',
                       'trajectory_msgs/JointTrajectory')
topic.advertise()
topic.publish(roslibpy.Message({
    'header': {'stamp': {'secs': 0, 'nsecs': 0}, 'frame_id': ''},   # 0 = sofort
    'joint_names': ['joint_1', 'joint_2', 'joint_3', 'joint_4', 'joint_5', 'joint_6'],
    'points': [{'positions': ziel, 'velocities': [], 'accelerations': [], 'effort': [],
                'time_from_start': {'secs': 3, 'nsecs': 0}}],
}))
```

**6. Laufend senden.** Für das Nachführen schickt ihr 30-mal pro Sekunde ein
neues Ziel mit `time_from_start` ≈ 0,15 s. Jedes neue Ziel ersetzt das vorige.
Bricht euer Programm ab, steht der Ned2 nach spätestens 0,15 s.

**7. Greifer.** Greiferbefehle sind Goals für den Action-Server
`/niryo_robot_tools_commander/action_server`. roslibpy 2.x hat kein
`actionlib`, deshalb veröffentlicht ihr das Goal direkt auf `…/goal`
(`niryo_robot_tools_commander/ToolActionGoal`, mit eigener `goal_id`).
`cmd_type` 1 = öffnen, 2 = schließen; `tool_id` muss zum montierten Werkzeug
passen. Ob Niryo den Befehl ausgeführt hat, steht auf `…/result`.

## Stolpersteine

* **Uhr:** Die Uhr des Ned2 geht falsch. Mit `header.stamp = 0` startet die  
  Trajektorie sofort; ein Stempel vom Jetson läge Jahre in der Zukunft.  
* **Keine Prüfungen:** Der Trajektorien-Controller fährt jedes Ziel an, auch  
  in den Tisch. Haltet die Gelenkgrenzen (Teil 1) mit Abstand ein und prüft jede
  Stellung gegen euren Arbeitsraum (Teil 3), bevor ihr sie sendet.  
* **Logging-Fehler** `_findCaller() takes from 1 to 2 positional arguments`:  
  Twisted 18.9 passt nicht zu Python 3.8. Abhilfe:
  `logging.getLogger('twisted').setLevel(logging.WARNING)`.  
* **Erste Nachricht weg:** Nach `advertise()` kurz warten (0,5 s), sonst geht  
  die erste Nachricht verloren.

## Vom Beispiel zur Synchronisation

In Teil 4 baut ihr daraus eine Klasse, die dauerhaft verbunden bleibt, den
Status laufend abonniert (statt `read_once()`), jeden Regelzyklus `send_joints()`
aufruft und bei Not-Halt, Learning-Mode oder Kollision eine Pause meldet. Im
Gerüst ist das `follower_ned2.py`.

---

[Übersicht](../AUFGABE.md) · [Tutorial pyniryo →](tutorial_ned2_pyniryo.md)
