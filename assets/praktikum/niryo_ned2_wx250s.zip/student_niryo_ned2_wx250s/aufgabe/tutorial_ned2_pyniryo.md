# Tutorial: Ned2 über pyniryo steuern

*Praktikum „Ein Roboter führt den anderen“ – [Übersicht](../AUFGABE.md) ·
Beispielskript: [`beispiele/ned2_pyniryo.py`](../beispiele/ned2_pyniryo.py)*

**pyniryo** ist die Python-Bibliothek von Niryo. Sie spricht über TCP (Port
40001) mit einem Server auf dem Ned2; jeder Befehl ist ein Funktionsaufruf, der
die Antwort des Roboters abwartet.

**Vorteil:** einfach, und die Prüfungen der Niryo-Software (Gelenkgrenzen,
Kollisionen) bleiben aktiv. **Nachteil:** Zum laufenden Nachführen gibt es nur
Jog-Befehle; der Ned2 übernimmt davon höchstens etwa 6 pro Sekunde und folgt
deshalb stufiger und verzögert.

## Ausprobieren

Auf dem Jetson CPS 1242 ist pyniryo installiert. Auf einem anderen Rechner
**ohne Abhängigkeiten** installieren – pyniryo zieht sonst `enum34`, das unter
Python 3.8 das eingebaute `enum` überschreibt und andere Pakete beschädigt:

```bash
pip3 install --user --no-deps pyniryo==1.2.5      # nur nötig, wenn nicht vorhanden
python3 beispiele/ned2_pyniryo.py                 # nur lesen
python3 beispiele/ned2_pyniryo.py --bewegen       # bewegt den Ned2 – zweite Person am Not-Halt!
```

## Schritt für Schritt

**1. Verbinden.**

```python
from pyniryo import NiryoRobot
robot = NiryoRobot('192.168.0.141')
...
robot.close_connection()
```

**2. Status lesen.** `need_calibration()`, `get_learning_mode()`,
`get_joints()` (Gelenkwinkel in rad), `get_pose()` (TCP-Pose),
`get_current_tool_id()`, `get_hardware_status()`.

**3. Kalibrieren.** `calibrate_auto()` – blockiert, bis die Kalibrierung fertig
ist. Der Arm bewegt sich dabei.

**4. Learning-Mode aus.** `set_learning_mode(False)` schaltet die Motoren ein.

**5. Geplante Bewegung.** `move_joints(ziel)` bzw. `move_pose(...)`: Niryo plant
die Bahn, prüft sie und kehrt erst zurück, wenn der Arm am Ziel ist.
`set_arm_max_velocity(30)` begrenzt auf 30 % der Höchstgeschwindigkeit. Für
einzelne Posen ideal, zum Nachführen ungeeignet: Nach jedem Ziel bleibt der Arm
stehen.

**6. Jog: laufend nachführen.** `jog_joints(verschiebung)` verschiebt die
Gelenke relativ und ohne Bahnplanung. Niryos Jog-Regler arbeitet so:

* neues Ziel = **zuletzt übernommenes Ziel** + Verschiebung (je Gelenk max. 0,2 rad),  
* er übernimmt nur **alle 0,15 s** einen Befehl; kommen mehrere dazwischen an, gilt der letzte,  
* nach 0,5 s ohne Befehl schaltet er sich ab; der nächste Befehl schaltet ihn  
  wieder ein und setzt das Ziel auf die gemessene Lage.

Daraus folgt das Vorgehen im Beispiel:

```python
robot.set_jog_control(False)          # sauberer Start
bezug = robot.get_joints()            # Niryos Bezugspunkt
while ...:
    ziel = ...                        # gewünschte Gelenkwinkel
    robot.jog_joints([z - b for z, b in zip(ziel, bezug)])
    bezug = ziel                      # Bezugspunkt selbst mitrechnen
    time.sleep(0.16)                  # mehr als ein Niryo-Takt
```

Rechnet die Verschiebung **nicht** gegen `get_joints()`: Der echte Arm hinkt
seinem Ziel hinterher, die Verschiebung wird dadurch zu groß, und der Arm
pendelt hin und her.

**7. Greifer.** `open_gripper(speed=500, max_torque_percentage=100,
hold_torque_percentage=30)` bzw. `close_gripper(...)`. Die Aufrufe blockieren,
bis der Greifer fertig ist – so lange bekommt der Arm keine Befehle.

## Stolpersteine

* **Alte Funktionsnamen nutzen:** pyniryo 1.2 empfiehlt `move()` und `jog()`, die  
  Niryo-Software 5.0 auf dem Ned2 kennt aber nur `move_joints()`, `move_pose()`
  und `jog_joints()`. Die Warnung `DeprecationWarning` könnt ihr ignorieren.  
* **Ein Jog-Befehl schaltet den Learning-Mode aus** – auch wenn jemand gerade  
  die Freedrive-Taste hält. Prüft vorher `get_learning_mode()`.  
* **Kalibrierung:** Jog-Befehle werden auch an einem unkalibrierten Ned2  
  ausgeführt. Prüft vorher `need_calibration()`.  
* **Nicht `set_jog_control(True)` während des Joggens:** Niryo setzt dabei das  
  Ziel auf die gerade gemessene, nachhinkende Lage zurück – der Arm springt.  
* **Kollisionserkennung:** Weicht ein Gelenk mehr als 0,2 rad von Niryos Vorgabe  
  ab, schaltet Niryo den Learning-Mode ein; der Arm wird kraftlos.  
* **Ein Client:** pyniryo-Aufrufe nur aus einem Thread; der Client ist nicht threadsicher.  
* **TCP:** `get_tcp()` kennt die Software 5.0 nicht. Für den Greifer 1 liegt der  
  TCP 85 mm vor `tool_link` (siehe Teil 1).

## Vom Beispiel zur Synchronisation

In Teil 4 baut ihr daraus eine Klasse, die in einem eigenen Thread Gelenkwinkel
und Status liest und das jeweils neueste Gelenkziel als Jog-Befehl schickt –
höchstens alle 0,16 s, mit mitgerechnetem Bezugspunkt. Im Gerüst ist das
`follower_ned2_pyniryo.py` (Klassen `JogPlanner` und `Ned2PyNiryoFollower`);
`tests/jog_sim.py` bildet Niryos Jog-Regler nach, sodass ihr ohne Roboter testen könnt.

---

[← Tutorial ROS (rosbridge)](tutorial_ned2_rosbridge.md) · [Übersicht](../AUFGABE.md)
