# Teil 3 – Inverse Kinematik und Regelzyklus

*Praktikum „Ein Roboter führt den anderen“ – [Übersicht](../AUFGABE.md)*

**Ziel:** Ihr findet Gelenkwinkel, mit denen der Ned2 eine Zielpose erreicht,
und erzeugt daraus in jedem Zyklus (ca. 30 Hz) sichere Gelenkziele. Alles ist
ohne Hardware testbar.

**Hintergrund:** Iterativ mit gedämpften kleinsten Quadraten
(*Damped Least Squares*): `Δq = Jᵀ (J Jᵀ + λ² I)⁻¹ e`. Bei mehreren
Teilaufgaben mit **Prioritäten** wird die nachrangige Aufgabe im Nullraum der
vorrangigen gelöst.

## Aufgaben

1. **Inverse Kinematik** mit drei Prioritäten:  
   1. TCP-Position, dazu die Mindesthöhe der Gelenke als weiche Bedingung,  
   2. Orientierung, aber **nur im Nullraum** von 1. Unerreichbare  
      Orientierungen dürfen die Position nicht verschlechtern.  
   3. eine Referenzhaltung (die gelenkweise Entsprechung des wx250s aus Teil 2)  
      im verbleibenden Nullraum. Sie entscheidet, wo die Pose die Gelenke nicht
      eindeutig festlegt, z. B. bei gestrecktem Handgelenk.

   Haltet die Gelenkgrenzen mit Sicherheitsabstand ein. Optional gibt es
   zusätzliche Grenzen (`bounds`), z. B. „nur so weit, wie die Gelenke in einem
   Zyklus kommen“. Ergebnis: Gelenkwinkel, Positions- und
   Orientierungsfehler, Iterationen.  
2. **Regelzyklus**, z. B. mit folgendem Ablauf:  
   1. Gelenkwinkel des wx250s filtern, Vorwärtskinematik  
   2. Abbildung und Projektion in den Arbeitsraum (Teil 2)  
   3. Kartesische Geschwindigkeit begrenzen  
   4. Inverse Kinematik, zuerst lokal um die aktuelle Stellung  
   5. Sicherheitsprüfung des Ergebnisses  
   6. Gelenkgeschwindigkeit begrenzen  
   7. Prüfung der Stellung, die tatsächlich gesendet wird  
3. **Erreichbarkeit** eures Arbeitsraums aus Teil 2 mit  
   `python3 scripts/check_workspace.py` nachweisen.

## Anforderungen an den Regelzyklus

| Nr. | Anforderung |
|---|---|
| R1 | Jede gesendete Stellung liegt im Arbeitsraum (Toleranz 1 cm), hält 0,05 rad Abstand zu den Gelenkanschlägen, und alle Gelenkpunkte liegen über `min_joint_height`. |
| R2 | Gelenkgeschwindigkeit ≤ `max_joint_velocity`, TCP höchstens 0,35 m/s. |
| R3 | Ziele außerhalb werden projiziert: Der Ned2 gleitet an der Grenze entlang. |
| R4 | Nach dem Start und nach jeder Pause fährt der Ned2 langsam an (30 % Geschwindigkeit). |
| R5 | Springt die IK-Lösung (Wechsel der Armkonfiguration), wird langsam übergeblendet, und auch die Zwischenstellungen erfüllen R1. |
| R6 | Rechenzeit typisch unter 5 ms; ein gelegentlicher Ausreißer darf die Zykluszeit nicht dauerhaft überschreiten. |

## Hinweise

* Orientierungsfehler als Rotationsvektor: `log(R_ziel · R_istᵀ)`.  
* Ausprobieren lohnt sich: Gewichtet ihr Position und Orientierung nur  
  unterschiedlich stark, statt sie zu priorisieren, tauscht die IK an
  Gelenkanschlägen Zentimeter an Position gegen ein paar Grad Orientierung.  
* Ein Gelenk am Anschlag, das weiter hinaus will, nimmt man für diesen  
  Iterationsschritt aus der Rechnung. Nur abschneiden führt zu lokalen Minima.  
* Werden die Gelenkschritte einzeln begrenzt, verlässt der TCP seine Bahn.  
  Skaliert alle Gelenke im selben Verhältnis.  
* Richtwert auf dem Orin: höchstens 0,3 ms pro IK-Iteration.  
* Einen simulierten Leader gibt es in `sim_leader.py`. Gute Testfälle: wx250s  
  unter der Tischebene, hinter dem Roboter, dicht an der Säule.

**Gerüst:** `kinematics.py` – `solve_ik`, `_dls`; `controller.py` –
`SyncController.reset`, `goal_pose`, `step`, `check`, `_solve_ik`, `_limit_pose_step`

## Abnahme

```bash
python3 -m pytest tests/test_kinematics.py -k "ik_"
python3 -m pytest tests/test_controller.py -k "not starting_outside and not near_column"
python3 scripts/check_workspace.py              # euer Arbeitsraum: positionsmäßig vollständig erreichbar?
scripts/run_sync.sh --offline --sim-leader      # Statuszeilen: "Anfahrt" -> "Folgen", "[begrenzt ...]"
```

## Fragen

* Was passiert an einer Singularität (z. B. gestrecktes Handgelenk) ohne Dämpfung?  
* Wie viele Freiheitsgrade hat der Nullraum, wenn der Ned2 nur der Position folgt?  

---

[← Teil 2](teil2_abbildung_arbeitsraum.md) · [Übersicht](../AUFGABE.md) · [Teil 4 →](teil4_roboter_live.md)
