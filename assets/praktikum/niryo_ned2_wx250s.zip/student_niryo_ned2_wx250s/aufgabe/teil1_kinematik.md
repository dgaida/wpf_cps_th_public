# Teil 1 – Roboter kennenlernen und Vorwärtskinematik

*Praktikum „Ein Roboter führt den anderen“ – [Übersicht](../AUFGABE.md)*

**Ziel:** Ihr kennt beide Roboter und ihre Schnittstellen. Ihr berechnet aus
Gelenkwinkeln die Pose des Greifers, für beide Roboter, auf unter 1 mm genau.

**Hintergrund:** Product of Exponentials (Lynch & Park, Kap. 4):
`T(q) = exp([S1] q1) · … · exp([Sn] qn) · M`. Dabei ist `M` die TCP-Pose in
Nullstellung und `Si = (ωi, −ωi × pi)` die Schraubenachse von Gelenk i im
Basis-Koordinatensystem.

## Aufgaben

1. **Roboter erkunden.** Startet den Treiber des wx250s  
   (`scripts/start_wx250s.sh`, ohne Hardware mit `use_sim:=true`) und lest
   `/wx250s/joint_states`: Namen, Reihenfolge, Einheiten. Lest den Zustand des
   Ned2 mit `python3 scripts/ned2_status.py`. Probiert dann beide Wege zum Ned2
   aus – die [Tutorials](../AUFGABE.md#4-zwei-wege-zum-ned2) mit den
   Beispielskripten `beispiele/ned2_rosbridge.py` und `beispiele/ned2_pyniryo.py`
   (zunächst ohne `--bewegen`). Lest über rosbridge den Parameter
   `/robot_description` (URDF); den braucht ihr für das Modell des Ned2.  
2. **Skizze.** Zeichnet beide Roboter in **Nullstellung** (alle Gelenkwinkel 0):  
   Gelenkachsen, Drehsinn, Werkzeug-Koordinatensystem.  
3. **Kinematik.** Implementiert die Hilfsfunktionen: schiefsymmetrische Matrix,  
   Roll/Pitch/Yaw ↔ Rotationsmatrix, Rotationsvektor einer Rotationsmatrix
   (Logarithmus) und `exp` einer Schraubenachse. Dazu kommt ein Robotermodell
   mit Vorwärtskinematik, Positionen aller Gelenkpunkte und geometrischer
   Jacobi-Matrix am TCP (oben lineare, unten Winkelgeschwindigkeit, im
   Basis-Koordinatensystem).  
4. **Modelle.**  
   * **wx250s:** `Slist` und `M` stehen in  
     `interbotix_xs_modules/xs_robot/mr_descriptions.py` (Klasse `wx250s`).  
   * **Ned2:** Baut `Slist` und `M` automatisch aus den Gelenk-Origins der URDF  
     (`xyz`, `rpy`, Achse jeweils lokales z). Hängt hinter `tool_link` den TCP an
     (Topic `/niryo_robot_tools_commander/tcp`: 85 mm in x-Richtung).

## Hinweise

* URDF-Konvention: `R = Rz(yaw) · Ry(pitch) · Rx(roll)`.  
* Zur Kontrolle: Der TCP des Ned2 liegt in Nullstellung bei etwa (0,380 / 0 / 0,429) m.  
* Der Service `/niryo_robot/kinematics/forward` (bzw. `forward_kinematics()` in  
  pyniryo) rechnet die Vorwärtskinematik auf dem Roboter, ohne ihn zu bewegen.
  Er rundet auf Millimeter.  
* Auf dem Orin kostet jeder kleine numpy-Aufruf 1–2 µs. Später läuft die FK  
  hunderte Male pro Regelzyklus: Fasst die Rechnungen für alle Gelenke
  zusammen. Richtwert: FK unter 0,2 ms.

**Gerüst:** `kinematics.py` – `skew`, `rpy_to_matrix`, `matrix_to_rpy`,
`rotation_log`, `exp_twist`, `SerialArm` (`_chain`, `fk`, `fk_points`,
`jacobian_full`), `arm_from_urdf_chain`, `wx250s`, `ned2`

## Abnahme

* Skizze beider Roboter in Nullstellung mit allen Achsen.  
* Tests und Abgleich mit dem Roboter:  

```bash
python3 -m pytest tests/test_kinematics.py -k "zero_pose or naive or jacobian or rpy or rotation_log"
python3 scripts/ned2_status.py      # Zeile "Kinematik-Check" < 1 mm
```

## Fragen

* Welche Gelenke der beiden Roboter entsprechen sich?  
* Wo liegt der TCP („Tool Center Point“) des Ned2, und woher kennt der Roboter ihn?  

---

[Übersicht](../AUFGABE.md) · [Teil 2 →](teil2_abbildung_arbeitsraum.md)
