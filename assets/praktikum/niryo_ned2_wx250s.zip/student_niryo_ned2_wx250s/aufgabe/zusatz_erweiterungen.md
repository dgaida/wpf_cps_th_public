# Zusatz – Erweiterungen (optional)

*Praktikum „Ein Roboter führt den anderen“ – [Übersicht](../AUFGABE.md)*

* **Unerreichbare Orientierung:** Dicht an der Säule kann der Ned2 die  
  Orientierung des wx250s nicht einnehmen, und das Handgelenk wird unruhig.
  Setzt das Verfolgen der Orientierung dort mit Hysterese aus und nehmt es
  wieder auf, sobald es geht. Test: `-k near_column`.  
* **Start außerhalb des Arbeitsraums:** Der Ned2 fährt hinein und verlässt ihn  
  danach nie mehr. Test: `-k starting_outside`.  
* **Visualisierung:** den Arbeitsraum in RViz im Koordinatensystem des wx250s  
  anzeigen, damit man beim Führen sieht, wo der Ned2 exakt folgt.  
* **Beide Wege vergleichen:** den Ned2 einmal über ROS (rosbridge) und einmal über  
  pyniryo anbinden und Verzögerung, Genauigkeit und Ruckeln messen.  
* **Kollisionsmodell:** Kapseln um Unterarm und Greifer statt einzelner Gelenkpunkte.  
* **Aufzeichnen und Abspielen** einer geführten Bewegung.  

---

[← Teil 4](teil4_roboter_live.md) · [Übersicht](../AUFGABE.md)
