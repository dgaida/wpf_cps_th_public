# Teil 2 – Abbildung und Arbeitsraum

*Praktikum „Ein Roboter führt den anderen“ – [Übersicht](../AUFGABE.md)*

**Ziel:** Aus einer Pose des wx250s wird eine Zielpose für den Ned2, die
garantiert im erlaubten Arbeitsraum liegt.

## Hintergrund

**Abbildung.** Position und Orientierung werden getrennt abgebildet:

* `p_ned2 = offset + s · Rz(ψ) · p_wx250s`  
* `R_ned2 = Rz(ψ) · R_wx250s · R_tool`  

Dabei ist `s` die Skalierung, `ψ` die Verdrehung der Roboter zueinander (sie
ergibt sich aus dem festen Aufbau im Labor) und `R_tool` eine optionale
Zusatzdrehung am Werkzeug.

**Arbeitsraum.** Der TCP des Ned2 darf sich nur in der **Schnittmenge** bewegen aus

* einem Zylindersektor um die Basis: Radius `[r_min, r_max]`, Drehwinkel  
  `[yaw_min, yaw_max]`, Höhe `[z_min, z_max]`,  
* einem optionalen Quader (`box_x`, `box_y`), z. B. für Wände oder den Nachbarroboter,  
* einer Kugel um die Schulter des Ned2 bei (0 / 0 / 0,1663) m mit Radius `max_reach`.  

Zusätzlich müssen die Gelenkpunkte 2–6 höher als `min_joint_height` liegen.

## Aufgaben

1. **Abbildung:** Implementiert die Abbildung von Pose und Position sowie deren  
   Umkehrung (Follower → Leader). Wählt die Skalierung `s` und begründet sie;
   vergleicht dazu die Reichweite von der Schulter bis zum TCP.  
2. **Gelenkweise Entsprechung:** Welcher Gelenkwinkel des wx250s gehört zu  
   welchem des Ned2, mit welchem Vorzeichen?  
3. **Arbeitsraum prüfen:** Welche Grenzen verletzt ein Punkt (mit Toleranz)?  
   Liegen alle Gelenkpunkte hoch genug?  
4. **Projizieren:** Ein Punkt außerhalb wird auf einen möglichst nahen Punkt im  
   Arbeitsraum abgebildet. Achtung: Der Zylindersektor ist wegen `r_min` nicht
   konvex. Für einen Punkt hinter dem Roboter muss die nächstgelegene
   Sektorgrenze gewählt werden.  
5. **Für euren Aufbau:** Messt Tisch, Hindernisse und den wx250s aus und legt  
   den Arbeitsraum in `config/sync.yaml` fest. Ob der Ned2 ihn überall
   erreicht, prüft ihr in Teil 3.

**Gerüst:** `mapping.py` – `JOINT_SIGNS`, `Mapping.pose`,
`position`, `position_inverse`, `joints`; `workspace.py` –
`Workspace.violations`, `contains`, `clamp`, `check_arm_points`,
`_clamp_cylinder`, `_clamp_reach`

## Abnahme

* Skizze eures Arbeitsraums mit Begründung der Werte.  
* Tests:  

```bash
python3 -m pytest tests/test_kinematics.py tests/test_workspace_mapping.py \
    -k "topology or mapping_inverse or mapped_joints or config or invalid_workspace or clamp or arm_points"
```

## Fragen

* Warum hat der Ned2 bei passend umgerechneten Gelenkwinkeln exakt dieselbe  
  Greiferorientierung wie der wx250s, obwohl die Arme verschieden lang sind?

---

[← Teil 1](teil1_kinematik.md) · [Übersicht](../AUFGABE.md) · [Teil 3 →](teil3_ik_regelzyklus.md)
