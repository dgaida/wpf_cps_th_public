# Teil 4 – Roboteranbindung und Live-Betrieb

*Praktikum „Ein Roboter führt den anderen“ – [Übersicht](../AUFGABE.md)*

**Ziel:** Ihr bindet beide Roboter an und betreibt das Gesamtsystem sicher am
echten Aufbau – auf dem Jetson CPS 1242, an dem der wx250s hängt. Die Anbindung
(Aufgaben 1–2) könnt ihr parallel zu Teil 2 und 3 entwickeln.

Für den Ned2 wählt ihr **einen** der beiden Wege aus Abschnitt 4 der
[Übersicht](../AUFGABE.md): Aufgabe 2a (ROS/rosbridge) oder 2b (pyniryo).
Ausgangspunkt ist jeweils das Tutorial mit Beispielskript.

## Aufgaben

### 1. wx250s anbinden (ROS2, `rclpy`)

* Gelenkwinkel: `/wx250s/joint_states` (`sensor_msgs/JointState`).  
* Den Greifer des wx250s kann man von Hand nicht schließen, sein Getriebe lässt  
  sich praktisch nicht zurückdrehen. Der Greifer des Ned2 wird deshalb per Tastatur gesteuert (Aufgabe 4).  
* Drehmoment: Service `/wx250s/torque_enable`  
  (`interbotix_xs_msgs/srv/TorqueEnable`, `cmd_type='group'`, `name='all'`).  
* **Stolperstein:** Beim Wieder-Einschalten setzt der Treiber die Zielposition  
  nicht neu – der Arm springt zur letzten kommandierten Pose. Vorher die
  aktuellen Winkel auf `/wx250s/commands/joint_group` (Gruppe `arm`) schreiben.  
* rclpy in einem eigenen Thread laufen lassen und beim Beenden erst den Thread  
  stoppen, dann den Node zerstören, sonst stürzt rclpy ab.  
* Testet zuerst mit dem simulierten Treiber (`scripts/start_wx250s.sh use_sim:=true`).  

### 2a. Ned2 anbinden über ROS (rosbridge, `roslibpy`)

Ausgangspunkt: [Tutorial ROS (rosbridge)](tutorial_ned2_rosbridge.md) und
`beispiele/ned2_rosbridge.py`.

| Zweck | Name | Typ |
|---|---|---|
| Gelenkwinkel | `/joint_states` | `sensor_msgs/JointState` |
| Gelenkziele senden | `/niryo_robot_follow_joint_trajectory_controller/command` | `trajectory_msgs/JointTrajectory` |
| Learning-Mode (Arm frei) | Topic `/niryo_robot/learning_mode/state`, Service `/niryo_robot/learning_mode/activate` | `std_msgs/Bool`, `niryo_robot_msgs/SetBool` |
| Kalibrierung | `/niryo_robot/joints_interface/calibrate_motors` (`value: 1`) | `niryo_robot_msgs/SetInt` |
| Status, Fehler | `/niryo_robot_hardware_interface/hardware_status` | `niryo_robot_msgs/HardwareStatus` |
| Not-Halt | `/niryo_robot_rpi/estop_status` | `std_msgs/Bool` |
| Kollision | `/niryo_robot/collision_detected` (und `…/hardware_interface/…`, `…/end_effector_interface/…`) | `std_msgs/Bool` |
| Werkzeug, TCP | `/niryo_robot_tools_commander/current_id`, `/niryo_robot_tools_commander/tcp` | `std_msgs/Int32`, `niryo_robot_tools_commander/TCP` |
| Greifer | `/niryo_robot_tools_commander/action_server/goal` | `niryo_robot_tools_commander/ToolActionGoal` (`cmd_type` 1 = öffnen, 2 = schließen) |
| FK zur Kontrolle | `/niryo_robot/kinematics/forward` | `niryo_robot_arm_commander/GetFK` |

#### Stolpersteine

* Die Uhr des Ned2 geht falsch. Sendet Trajektorien mit `header.stamp = 0`; das bedeutet „sofort starten“.  
* Sendet einen einzelnen Trajektorienpunkt mit `time_from_start` ≈ 0,15 s. Jeder  
  neue Punkt ersetzt den vorigen. Bricht euer Programm ab, steht der Ned2 nach
  spätestens 0,15 s.  
* Der Kalibrier-Service antwortet erst, wenn die Kalibrierung fertig ist –  
  deutlich später als nach den üblichen 10 s Timeout. Ruft ihn deshalb nicht
  blockierend auf und wartet auf den Hardwarestatus.  
* roslibpy 2.x hat kein `actionlib`. Veröffentlicht das Greifer-Goal direkt, mit eigener `goal_id`.  
* Ubuntu 20.04 hat Twisted 18.9, dessen Logging nicht zu Python 3.8 passt.  
  Setzt den Logger `twisted` auf `WARNING`.

### 2b. Ned2 anbinden über pyniryo

Ausgangspunkt: [Tutorial pyniryo](tutorial_ned2_pyniryo.md) und
`beispiele/ned2_pyniryo.py`.

| Zweck | Funktion |
|---|---|
| Gelenkwinkel, Pose | `get_joints()`, `get_pose()` |
| Status, Fehler | `get_hardware_status()`, `need_calibration()` |
| Learning-Mode | `get_learning_mode()`, `set_learning_mode(...)` |
| Kalibrierung | `calibrate_auto()` (blockiert, bis sie fertig ist) |
| Werkzeug | `get_current_tool_id()` |
| Gelenkziele nachführen | `jog_joints(verschiebung)`, `set_jog_control(False)` |
| Greifer | `open_gripper(...)`, `close_gripper(...)` (blockieren) |
| FK zur Kontrolle | `forward_kinematics(gelenke)` |

#### Stolpersteine

* Niryos Jog-Regler rechnet *neues Ziel = zuletzt übernommenes Ziel +  
  Verschiebung* und übernimmt nur alle 0,15 s einen Befehl. Sendet höchstens
  alle 0,16 s und rechnet den Bezugspunkt selbst mit. Gegen die gemessene Lage zu
  rechnen, lässt den Arm pendeln, weil er seinem Ziel hinterherhinkt.  
* Nach 0,5 s ohne Befehl schaltet Niryo Jog ab. Danach erst `set_jog_control(False)`,  
  dann der nächste Befehl: Niryo setzt den Bezugspunkt dabei auf die gemessene
  Lage. `set_jog_control(True)` bei laufendem Jog lässt den Arm zurückspringen.  
* Ein Jog-Befehl schaltet den Learning-Mode aus und läuft auch an einem  
  unkalibrierten Ned2 – vorher prüfen.  
* Weicht ein Gelenk mehr als 0,2 rad ab, schaltet Niryo den Learning-Mode ein.  
  Begrenzt die Gelenkgeschwindigkeit (z. B. 0,6 rad/s).  
* Der Client ist nicht threadsicher: alle Aufrufe in einem eigenen Thread, das  
  Hauptprogramm übergibt nur das jeweils neueste Ziel. Greiferbefehle blockieren
  diesen Thread; der Arm steht so lange.  
* `get_tcp()`, `move()` und `jog()` kennt die Niryo-Software 5.0 nicht.  
* Ohne Roboter testen: `tests/jog_sim.py` bildet Niryos Jog-Regler nach.  

### 3. Erster Bewegungstest

Mit einer Person am Not-Halt das Beispielskript eures Wegs mit `--bewegen`
ausführen: Gelenk 1 des Ned2 fährt um 0,2 rad hin und zurück und pendelt dann
6 s lang um ±0,15 rad. Danach dasselbe mit eurer eigenen Anbindung.

### 4. Hauptprogramm

* **Start:** Hardwarefehler, Not-Halt, Kalibrierung und Learning-Mode prüfen;  
  Werkzeug-TCP übernehmen; vor dem Abschalten des Drehmoments nachfragen.  
* **Schleife mit fester Rate** (Regelzyklus aus Teil 3).  
* **Pause:** bei veralteten Daten des wx250s (älter als 0,3 s), Not-Halt,  
  Learning-Mode, Verbindungsabbruch. Danach langsam wieder anlaufen (R4).  
* **Kollision:** Programm beenden.  
* **Greifer per Tastatur:** Tasten im Terminal ohne Enter lesen (Python: `termios`/`tty`,  
  cbreak-Modus), z. B. Leertaste = umschalten, `o` = öffnen, `s` = schließen. Das
  Terminal beim Beenden wiederherstellen (im Gerüst fertig: `keyboard.py`).  
* **Statusausgabe** etwa einmal pro Sekunde.  
* **Sauberes Ende mit Strg+C:** wx250s mit Drehmoment, Ned2 bleibt stehen.  

### 5. Live-Betrieb

Nehmt das System in drei Stufen in Betrieb: offline → `--dry-run` → live.
Messt und dokumentiert:

* die Abweichung zwischen Ziel und Ned2 im Arbeitsraum,  
* die Verzögerung zwischen Leader und Follower (z. B. per Video oder über Zeitstempel),  
* das Verhalten an den Grenzen des Arbeitsraums.  

**Gerüst:** `leader_wx250s.py` – `Wx250sLeader`, `RosSpinner`;
je nach Weg `follower_ned2.py` – `Ned2Follower.connect`, `send_joints`,
`calibrate`, `set_learning_mode`, `gripper` **oder** `follower_ned2_pyniryo.py` –
`JogPlanner.plan`, `sent`, `Ned2PyNiryoFollower.connect`, `send_joints`,
`calibrate`, `set_learning_mode`, `gripper`, `_send_jog`; `sync.py` – `SyncApp`
(`run`, `_pause_reason`, `_start_gripper_keys`, `_update_gripper`, `shutdown`).
Den Weg wählt `ned2.backend` in `config/sync.yaml` bzw. `--backend`.

## Abnahme

* `scripts/ned2_status.py` zeigt alle Zustände korrekt an.  
* Mit dem simulierten wx250s: Gelenkwinkel kommen an, Drehmoment lässt sich aus- und einschalten.  
* pyniryo-Weg: `python3 -m pytest tests/test_pyniryo_backend.py` (Jog gegen die Nachbildung).  
* Erster Bewegungstest (Aufgabe 3).  
* **Live-Demo:**  
  * Der Ned2 folgt im Arbeitsraum, mit Position und Orientierung.  
  * Unterhalb `z_min` gleitet er über den Tisch, ohne ihn zu berühren.  
  * An Säule und Sektorgrenze wird er sichtbar begrenzt, ohne Ruckeln.  
  * Der Greifer öffnet und schließt per Tastatur.  
  * Bei Not-Halt oder Freedrive-Taste pausiert er und läuft langsam wieder an.  
  * Strg+C beendet sauber.  

---

[← Teil 3](teil3_ik_regelzyklus.md) · [Übersicht](../AUFGABE.md) · [Zusatz →](zusatz_erweiterungen.md)
