# Dev Container & Docker Architektur (TurtleBot 4)

Dieses Dokument beschreibt die Struktur, den Inhalt und die Funktionsweise der Docker- und Dev-Container-Konfiguration im Ordner `praktikum/turtlebot/`.

---

## 1. Übersicht & Zielsetzung

Für die Arbeit mit dem **TurtleBot 4** und **ROS 2 Humble** wird eine vorkonfigurierte Container-Umgebung bereitgestellt. Diese Umgebung bietet:

- **Einsatzfertige ROS 2 Humble Desktop-Umgebung** inklusive `ros-humble-turtlebot4-desktop`.  
- **Grafik-Weiterleitung (X11 Forwarding)** zur Ausführung von GUI-Anwendungen wie `turtlesim`, RViz oder Gazebo.  
- **Netzwerk-Integration (Host Network Mode)** für die direkte Kommunikation mit den echten TurtleBot 4 Robotern im Labor.  
- **Discovery Server Konfiguration (FastDDS)** zur automatischen Erkennung der Roboter über dedizierte Discovery Server (`192.168.0.221:11811` und `192.168.0.222:11811`).  
- **VS Code Dev Containers Integration** für eine direkte Entwicklungsumgebung im Editor.  

---

## 2. Dateien & Komponenten im Detail

### 2.1 Root-Verzeichnis (`praktikum/turtlebot/`)

#### `docker-compose.yml`
Die zentrale Compose-Konfiguration für das TurtleBot-Modul:

```yaml
services:
  turtlebot:
    build: .devcontainer
    environment:
      - DISPLAY=${DISPLAY}
    volumes:
      - /tmp/.X11-unix:/tmp/.X11-unix:z
      - .:/workspace:cached
    network_mode: host
```

- **`build: .devcontainer`**: Verweist auf das Dockerfile im Unterordner `.devcontainer`.  
- **`environment: - DISPLAY=${DISPLAY}`**: Reicht die `DISPLAY`-Variable des Host-Systems an den Container weiter.  
- **`volumes`**:  
  - `/tmp/.X11-unix:/tmp/.X11-unix:z`: Ermöglicht den Zugriff auf den X11-Socket für GUI-Fenster.  
  - `.:/workspace:cached`: Mountet das aktuelle Modulverzeichnis in den Container nach `/workspace`.  
- **`network_mode: host`**: Bindet den Container direkt an das Host-Netzwerk, was für ROS 2 Multicast- und FastDDS-Discovery zwingend erforderlich ist.  

#### `dev_terminal.sh`
Ein Helper-Skript zum schnellen Starten einer interaktiven Terminal-Sitzung:

```bash
xhost +local:docker
docker compose run turtlebot
```

- Schaltet die X11-Berechtigungen für lokale Docker-Container frei (`xhost +local:docker`).  
- Startet den Container interaktiv über Docker Compose.  

---

### 2.2 Dev Container Verzeichnis (`.devcontainer/`)

#### `.devcontainer/devcontainer.json`
Die Konfigurationsdatei für die Visual Studio Code **Dev Containers** Erweiterung:

```json
{
    "dockerComposeFile": ["../docker-compose.yml", "docker-compose.yml"],
    "service": "turtlebot",
    "workspaceFolder": "/workspace",

    "initializeCommand": "xhost +local:docker",

    "customizations": {
        "vscode": {
            "extensions": ["ms-python.python"]
        }
    }
}
```

- **`dockerComposeFile`**: Kombiniert die Haupt-Compose-Datei mit dem DevContainer-Override.  
- **`service`**: Wählt den Service `turtlebot` aus der Compose-Datei aus.  
- **`initializeCommand`**: Führt automatisch `xhost +local:docker` auf dem Host aus, bevor der Container gestartet wird.  
- **`customizations.vscode.extensions`**: Installiert automatisch die VS Code Python-Erweiterung im Container.  

#### `.devcontainer/Dockerfile`
Das Dockerfile baut das Container-Image auf Basis von ROS 2 Humble auf:

```dockerfile
FROM osrf/ros:humble-desktop

ARG USERNAME=turtlebot
ARG USER_UID=1000
ARG USER_GID=$USER_UID

# Non-root Benutzer erstellen
RUN groupadd --gid $USER_GID $USERNAME \
    && useradd --uid $USER_UID --gid $USER_GID -m $USERNAME \
    && apt-get update \
    && apt-get install -y sudo \
    && echo $USERNAME ALL=\(root\) NOPASSWD:ALL > /etc/sudoers.d/$USERNAME \
    && chmod 0440 /etc/sudoers.d/$USERNAME

ENV SHELL=/bin/bash

# TurtleBot 4 Desktop Pakete installieren
RUN sudo apt update -y && sudo apt install -y ros-humble-turtlebot4-desktop

# Discovery Server Konfiguration einbinden
COPY turtlebot4_discovery /etc/turtlebot4_discovery
RUN echo "source /etc/turtlebot4_discovery/setup.bash" >> /etc/bash.bashrc

# Entrypoint Skript kopieren und Rechte setzen
COPY entrypoint.sh /EntryPoint.sh
RUN chmod +x /EntryPoint.sh

USER $USERNAME

ENTRYPOINT ["/EntryPoint.sh"]
CMD [ "bash" ]
```

- **Basis-Image**: `osrf/ros:humble-desktop` (Ubuntu 22.04 LTS mit ROS 2 Humble).  
- **Benutzerverwaltung**: Erstellt den Nicht-Root-Benutzer `turtlebot` mit `sudo`-Rechten.  
- **ROS 2 Pakete**: Installiert `ros-humble-turtlebot4-desktop` für TurtleBot 4 Visualisierungen und Tools.  
- **Discovery Setup**: Kopiert die Labor-Netzwerkkonfiguration nach `/etc/turtlebot4_discovery` und sourcet sie automatisch in der Bash-Shell.  

#### `.devcontainer/docker-compose.yml`
Override-Datei für den DevContainer-Betrieb in VS Code:

```yaml
services:
  turtlebot:
   command: ["/bin/sh", "-c", "while sleep 1000; do :; done"]
```

- Hält den Container im Hintergrund aufrecht, damit VS Code dauerhaft eine Verbindung halten kann.  

#### `.devcontainer/entrypoint.sh`
Der Container-Entrypoint führt notwendige Initialisierungen beim Start durch:

```bash
#!/bin/bash
set -e

# ROS und TurtleBot 4 Umgebungs-Setup sourcen
source /etc/turtlebot4_discovery/setup.bash

# Falls als root gestartet, zum turtlebot Benutzer wechseln
if [ "$(id -u)" = "0" ]; then
    exec su-exec turtlebot "$@"
else
    exec "$@"
fi
```

#### `.devcontainer/turtlebot4_discovery/setup.bash`
Dieses Skript steuert die ROS 2 und FastDDS Netzwerkeinstellungen für das Roboterlabor:

```bash
source /opt/ros/humble/setup.bash
export RMW_IMPLEMENTATION=rmw_fastrtps_cpp
[ -t 0 ] && export ROS_SUPER_CLIENT=True || export ROS_SUPER_CLIENT=False
export ROS_DOMAIN_ID=0
export ROS_DISCOVERY_SERVER="192.168.0.221:11811;192.168.0.222:11811;"
```

- **`RMW_IMPLEMENTATION`**: Legt FastDDS (`rmw_fastrtps_cpp`) als ROS 2 Middleware fest.  
- **`ROS_SUPER_CLIENT`**: Erlaubt der lokalen ROS 2 Node im interaktiven Terminal, alle Topics im Netzwerk trotz Discovery Server einzusehen.  
- **`ROS_DOMAIN_ID=0`**: Setzt die standardmäßige ROS Domain ID.  
- **`ROS_DISCOVERY_SERVER`**: Verbindet die Nodes mit den beiden FastDDS Discovery Servern der Labor-TurtleBots.  

---

## 3. Nutzung der Entwicklungsumgebung

### Option A: VS Code Dev Containers (Empfohlen)

1. Öffnen Sie den Ordner `praktikum/turtlebot` in VS Code.  
2. Drücken Sie `F1` und wählen Sie **Dev Containers: Reopen in Container** (oder klicken Sie auf die Pop-up-Meldung unten rechts).  
3. VS Code baut das Docker-Image auf und öffnet ein eingebettetes Terminal direkt im Container.  

### Option B: Terminal über `dev_terminal.sh` (Linux / macOS / WSL)

1. Stellen Sie sicher, dass das Skript ausführbar ist:  
   ```bash
   chmod +x dev_terminal.sh
   ```
2. Starten Sie das Dev Terminal:  
   ```bash
   ./dev_terminal.sh
   ```
3. Sie befinden sich nun im Container als Benutzer `turtlebot` in `/workspace`.  
