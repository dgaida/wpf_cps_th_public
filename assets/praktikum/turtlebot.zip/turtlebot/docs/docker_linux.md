# Docker Setup & Erste Schritte unter Linux (Ubuntu)

Diese Anleitung beschreibt die Installation von Docker unter Linux (Ubuntu) sowie das Ausführen von ROS 2 Docker-Containern mit GUI-Unterstützung (z. B. für `turtlesim` oder RViz).

---

## 1. Installation von Docker

1. Laden Sie Docker herunter und installieren Sie es gemäß der offiziellen Dokumentation:  
   [Docker Engine Installation Guide](https://docs.docker.com/engine/install/ubuntu/)  
2. (Optional) Fügen Sie Ihren Benutzer der `docker`-Gruppe hinzu, um Docker ohne `sudo` ausführen zu können:  
   ```bash
   sudo usermod -aG docker $USER
   ```
   *(Erfordert anschließendes Neuanmelden)*

---

## 2. Docker-Image herunterladen

Laden Sie das offizielle ROS 2 Humble Docker-Image herunter:

```bash
docker pull osrf/ros:humble-desktop
```

*(Alternativ steht auch `osrf/ros:humble-desktop-full` zur Verfügung).*

---

## 3. Container mit GUI-Unterstützung starten

1. **Zugriff auf den lokalen X-Server freigeben:**  
   Damit GUI-Anwendungen aus dem Docker-Container im lokalen X11-Fenstersystem angezeigt werden können:
   ```bash
   xhost +local:docker
   ```

2. **Container starten:**  
   ```bash
   docker run -it --net=host -e DISPLAY=$DISPLAY -v /tmp/.X11-unix:/tmp/.X11-unix osrf/ros:humble-desktop
   ```

---

## 4. Erste Schritte im Docker Terminal

Nach dem Start des Containers müssen Sie im Docker Terminal das ROS 2 Setup-Skript sourcen, damit ROS-Befehle verfügbar sind:

```bash
source /opt/ros/humble/setup.bash
```

Testen Sie die GUI-Funktionalität durch Starten von Turtlesim:

```bash
ros2 run turtlesim turtlesim_node
```

---

## 5. Weiters Terminal für laufenden Container öffnen

Wenn Sie ein weiteres Terminal für einen bereits gestarteten Docker-Container nutzen möchten, ermitteln Sie den Namen oder die ID des Containers (z. B. via `docker ps`) und führen Sie aus:

```bash
docker exec -it <container_name> bash
```

Führen Sie im neuen Terminal erneut den ROS 2 Setup-Befehl aus:

```bash
source /opt/ros/humble/setup.bash
```
