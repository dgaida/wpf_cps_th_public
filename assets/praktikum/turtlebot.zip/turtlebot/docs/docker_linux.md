# Docker Setup & Erste Schritte unter Linux (Ubuntu)

Diese Anleitung beschreibt die Installation von Docker und Docker Compose unter Linux (Ubuntu) sowie das Ausführen des vorkonfigurierten ROS 2 TurtleBot 4 Containers mit GUI-Unterstützung (z. B. für `turtlesim`, RViz oder Gazebo).

---

## 1. Installation von Docker & Docker Compose

1. Installieren Sie Docker Engine und das Docker Compose Plugin gemäß der offiziellen Dokumentation:  
   [Docker Engine Installation Guide für Ubuntu](https://docs.docker.com/engine/install/ubuntu/)  
2. Fügen Sie Ihren Benutzer der `docker`-Gruppe hinzu, um Docker ohne `sudo` ausführen zu können:  
   ```bash
   sudo usermod -aG docker $USER
   ```
   *(Erfordert ein anschließendes Ab- und Neuanmelden)*

---

## 2. Container ausführen

Es stehen zwei Wege zur Verfügung, um den Container unter Linux zu starten.

### Methode A: VS Code Dev Containers (Empfohlen)

1. Installieren Sie **Visual Studio Code** und die Extension **Dev Containers** (`ms-vscode-remote.remote-containers`).  
2. Öffnen Sie den Ordner `praktikum/turtlebot` in VS Code.  
3. Bestätigen Sie das Pop-up *"Reopen in Container"* (oder drücken Sie `F1` und wählen Sie `Dev Containers: Reopen in Container`).  
4. VS Code baut das Docker-Image automatisch auf, konfiguriert den X-Server-Zugriff und öffnet das Terminal direkt im Container.  

### Methode B: Dev Terminal Skript (`dev_terminal.sh`)

1. Machen Sie das Helper-Skript im Ordner `praktikum/turtlebot` ausführbar:  
   ```bash
   chmod +x dev_terminal.sh
   ```
2. Starten Sie das Dev Terminal:  
   ```bash
   ./dev_terminal.sh
   ```
   *(Das Skript schaltet automatisch den lokalen X11-Zugriff via `xhost +local:docker` frei und führt `docker compose run turtlebot` aus).*

---

## 3. Erste Schritte im Container

Im Container sind ROS 2 Humble sowie die TurtleBot 4 Desktop-Pakete und die Labor-Netzwerkkonfiguration (`ROS_DISCOVERY_SERVER`) bereits fertig eingerichtet und gesourced.

Testen Sie die GUI-Funktionalität durch Starten von Turtlesim:

```bash
ros2 run turtlesim turtlesim_node
```

---

## 4. Weiters Terminal für laufenden Container öffnen

Wenn Sie ein weiteres Terminal für einen bereits laufenden Container öffnen möchten:

1. Ermitteln Sie die Container-ID oder den Namen (z. B. via `docker ps`).  
2. Öffnen Sie eine neue Shell im Container:  
   ```bash
   docker exec -it <container_name> bash
   ```

*(In VS Code Dev Containers können Sie einfach über das `+`-Symbol im Terminal-Fenster weitere Tabs öffnen).*

---

## 5. Weitere Informationen

Eine detaillierte Beschreibung der Ordnerstruktur, des Dockerfiles und der FastDDS Discovery Server Einstellungen finden Sie in der Dokumentation:  
- 📖 [Dev Container & Docker Architektur](docker_devcontainer.md)  
