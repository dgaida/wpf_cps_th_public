# Docker Setup & Erste Schritte unter Windows

Diese Anleitung beschreibt die Installation und Konfiguration von Docker Desktop unter Windows sowie das Ausführen des vorkonfigurierten ROS 2 TurtleBot 4 Containers mit GUI-Unterstützung (z. B. für `turtlesim`, RViz oder Gazebo).

---

## 1. Installation von Docker Desktop

1. Laden Sie **Docker Desktop für Windows** von der offiziellen Website herunter und installieren Sie es:  
   [Docker Desktop Download](https://docs.docker.com/desktop/setup/install/windows-install/)  
2. Vergewissern Sie sich, dass **WSL 2 (Windows Subsystem for Linux 2)** als Backend in Docker Desktop aktiviert ist.  

---

## 2. Windows X-Server Konfiguration für GUI-Anwendungen

Um Grafikanwendungen aus dem Linux-Docker-Container unter Windows anzuzeigen, wird WSLg (standardmäßig in Windows 11 integriert) oder ein Windows X-Server wie **VcXsrv** (unter Windows 10) benötigt.

### Verwendung von VcXsrv (Windows 10 / Manuelles X11 Setup)

1. Download VcXsrv: [VcXsrv bei SourceForge](https://sourceforge.net/projects/vcxsrv/)  
2. Starten Sie **XLaunch**.  
3. Wählen Sie **Multiple windows** -> *Weiter*.  
4. Wählen Sie **Start no client** -> *Weiter*.  
5. **Wichtig:** Setzen Sie ein Häkchen bei **Disable access control** (damit der Docker-Container Verbindungen herstellen darf).  
6. Klicken Sie auf *Finish*.  

---

## 3. Container ausführen

Es stehen zwei Wege zur Verfügung, um den Container unter Windows auszuführen.

### Methode A: VS Code Dev Containers (Empfohlen)

1. Installieren Sie **Visual Studio Code**, die **WSL** Erweiterung und die Erweiterung **Dev Containers** (`ms-vscode-remote.remote-containers`).  
2. Öffnen Sie den Ordner `praktikum/turtlebot` in VS Code.  
3. Klicken Sie auf das Pop-up *"Reopen in Container"* (oder drücken Sie `F1` und wählen Sie `Dev Containers: Reopen in Container`).  
4. VS Code baut das Docker-Image auf und öffnet ein eingebettetes Terminal direkt im Container.  

### Methode B: Docker Compose via PowerShell oder WSL 2

1. Öffnen Sie die **PowerShell** im Ordner `praktikum/turtlebot`.  
2. Ermitteln Sie Ihre lokalen IP-Adresse für die `DISPLAY`-Variable (bei VcXsrv) oder nutzen Sie WSL 2:  
   ```powershell
   $env:DISPLAY="localhost:0.0"
   docker compose run turtlebot
   ```
   *(Unter WSL 2 Linux Terminal kann stattdessen auch das Skript `./dev_terminal.sh` ausgeführt werden).*

---

## 4. Erste Schritte im Container

Im Container sind ROS 2 Humble sowie die TurtleBot 4 Desktop-Pakete und die Labor-Netzwerkkonfiguration (`ROS_DISCOVERY_SERVER`) bereits vollständig vorbereitet und automatisch gesourced.

Testen Sie die GUI-Funktionalität durch Starten von Turtlesim:

```bash
ros2 run turtlesim turtlesim_node
```

---

## 5. Weiters Terminal für laufenden Container öffnen

Wenn Sie ein weiteres Terminal für einen bereits gestarteten Docker-Container nutzen möchten:

```bash
docker exec -it <container_name> bash
```

Wobei `<container_name>` der Name Ihres gestarteten Docker-Containers ist (den Namen finden Sie in Docker Desktop oder über `docker ps`).

*(In VS Code Dev Containers öffnen Sie neue Terminal-Tabs bequem über das `+`-Symbol).*

---

## 6. Weitere Informationen

Eine detaillierte Beschreibung der Ordnerstruktur, des Dockerfiles und der FastDDS Discovery Server Einstellungen finden Sie in der Dokumentation:  
- 📖 [Dev Container & Docker Architektur](docker_devcontainer.md)  
