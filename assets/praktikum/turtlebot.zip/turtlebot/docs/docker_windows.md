# Docker Setup & Erste Schritte unter Windows

Diese Anleitung beschreibt die Installation und Konfiguration von Docker Desktop unter Windows sowie das Ausführen von ROS 2 Docker-Containern mit GUI-Unterstützung (z. B. für `turtlesim` oder RViz).

---

## 1. Installation von Docker Desktop

1. Laden Sie **Docker Desktop für Windows** von der offiziellen Website herunter und installieren Sie es:  
   [Docker Desktop Download](https://docs.docker.com/desktop/setup/install/windows-install/)  
2. Vergewissern Sie sich, dass WSL 2 (Windows Subsystem for Linux 2) als Backend in Docker Desktop aktiviert ist.  

---

## 2. Installation & Konfiguration des Windows X Servers (VcXsrv)

Um Grafikanwendungen (GUI) aus dem Linux-Docker-Container unter Windows anzuzeigen, wird ein Windows X Server benötigt.

- **Ausführliches Tutorial:**  
  [Run GUI app in Linux Docker container on Windows host](https://dev.to/darksmile92/run-gui-app-in-linux-docker-container-on-windows-host-4kde)  
- **Download VcXsrv Windows X Server:**  
  [VcXsrv bei SourceForge](https://sourceforge.net/projects/vcxsrv/)

### Konfiguration von XLaunch

1. Starten Sie **XLaunch** nach der Installation.  
2. Wählen Sie **Multiple windows** und klicken Sie auf *Weiter*.  
3. Wählen Sie **Start no client** und klicken Sie auf *Weiter*.  
4. **Wichtig:** Setzen Sie ein Häkchen bei **Disable access control** (damit der Docker-Container Verbindungen zum X-Server herstellen darf).  
5. Klicken Sie auf *Weiter* und abschließend auf *Finish* (Optional: Speichern Sie die Konfiguration ab, damit XLaunch künftig mit einem Klick gestartet werden kann).  

---

## 3. Container starten (Windows PowerShell)

1. Starten Sie die **Windows PowerShell**.  
2. Ermitteln Sie Ihre IP-Adresse mit:  
   ```powershell
   ipconfig
   ```
   Suchen Sie nach der IPv4-Adresse Ihres aktiven Netzwerkadapters (z. B. `192.168.0.214`).  
3. Setzen Sie die Umgebungsvariable `$DISPLAY` in PowerShell und starten Sie den Docker-Container (ersetzen Sie `192.168.0.214` durch Ihre IP-Adresse):  
   ```powershell
   set-variable -name DISPLAY -value 192.168.0.214:0.0
   docker run -it -e DISPLAY=$DISPLAY osrf/ros:humble-desktop-full
   ```
   *(Alternativ können Sie auch `osrf/ros:humble-desktop` verwenden: `docker run -it -e DISPLAY=$DISPLAY osrf/ros:humble-desktop`)*

---

## 4. Erste Schritte im Docker Terminal

Nach dem Start des Containers müssen Sie im Docker Terminal ROS 2 Umgebungsvariablen laden, damit ROS Befehle gefunden werden:

```bash
source /opt/ros/humble/setup.bash
```

Testen Sie die GUI-Funktionalität durch Starten von Turtlesim:

```bash
ros2 run turtlesim turtlesim_node
```

---

## 5. Weiters Terminal für laufenden Container öffnen

Wenn Sie ein weiteres Terminal für einen bereits gestarteten Docker Container nutzen möchten:

```bash
docker exec -it bold_tesla bash
```

Wobei `bold_tesla` der Name Ihres gestarteten Docker Containers ist (den Namen finden Sie in Docker Desktop oder über `docker ps`).

Vergessen Sie nicht, auch im neuen Terminal den ROS 2 Setup-Befehl auszuführen:

```bash
source /opt/ros/humble/setup.bash
```
