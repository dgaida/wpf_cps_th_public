#!/bin/bash
set -e

# ROS and turtlebot 4 Environment sourcen
source /etc/turtlebot4_discovery/setup.bash


# Falls der Benutzer root ist, zum turtlebot User wechseln
if [ "$(id -u)" = "0" ]; then
    exec su-exec turtlebot "$@"
else
    exec "$@"
fi
