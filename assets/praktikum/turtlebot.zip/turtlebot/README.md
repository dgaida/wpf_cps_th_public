# Praktikum: TurtleBot 4 & ROS 2

Dieses Verzeichnis enthält alle Materialien und Aufgaben für das Praktikum **TurtleBot 4 & ROS 2** im Rahmen des Wahlpflichtfachs *Cyber-physische Systeme (CPS)*.

---

## 📁 Ordnerstruktur

```
turtlebot/
├── .devcontainer/                         # Dev Container Konfiguration für VS Code
│   ├── Dockerfile                         # Image-Definition (ROS 2 Humble, TB4-Desktop, User)
│   ├── devcontainer.json                  # VS Code Container Einstellungen (X11 Forwarding)
│   ├── docker-compose.yml                 # Service-Override für VS Code Lifecycle
│   ├── entrypoint.sh                      # Entrypoint mit User-Switch & Discovery Sourcing
│   └── turtlebot4_discovery/              # Discovery Server & ROS 2 Setup
│       └── setup.bash                     # ROS 2 & FastDDS Discovery Server Variablen
├── docs/                                  # Dokumentation & Anleitungen
│   ├── docker_devcontainer.md             # Erklärungen zu Dev Container & Docker-Inhalten
│   ├── docker_linux.md                    # Docker Setup & Nutzung unter Linux
│   └── docker_windows.md                  # Docker Setup & Nutzung unter Windows
├── 1-ros2_turtlebot_erste_schritte.ipynb  # Jupyter Notebook mit Praktikumsaufgaben
├── src/                                   # Python-Musterlösung für den ROS 2 Node
│   └── first_node.py                      # Referenz-Implementierung eines ROS 2 Nodes
├── dev_terminal.sh                        # Helper-Skript zum Starten des Dev Terminals
├── docker-compose.yml                     # Docker Compose Definition (Volume, Display, Network)
├── res/                                   # Grafiken und Diagramme für das Notebook
└── README.md                              # Diese Übersicht
```

---

## 🎯 Praktikumsziele & Inhalte

Im Praktikum erlernen die Studierenden die Grundlagen des Verteilungssystems **ROS 2 (Robot Operating System)** und die Ansteuerung des mobilen Roboters **TurtleBot 4**.

### Key Topics in `1-ros2_turtlebot_erste_schritte.ipynb`

1. **Docker-Umgebung einrichten:** Installation von Docker, Nutzung des vorgefertigten Docker Compose / Dev Container Setups.  
2. **ROS 2 Grundlagen:** Einarbeitung über die Aufgaben 1.0 bis 1.2 des ROS 2 Industrial Workshop Tutorials (Nodes, Topics, CLI-Tools).  
3. **Simulation mit Turtlesim:** Steuerung eines virtuellen Roboters mit der Tastatur (`turtle_teleop_key`) und Inspektion via CLI.  
4. **Hardware-Inbetriebnahme & Manuelle Steuerung:** Einschalten des TurtleBot 4, Boot-Vorgang (LED-Status), Undocken aus der Ladestation und Fahrerprobung mit dem mitgelieferten Bluetooth-Controller.  
5. **Entwicklung eigener ROS 2 Nodes in Python (`rclpy`):** Programmierung und Test eines Publisher-Knotens zur automatischen Bewegungssteuerung (`geometry_msgs/msg/Twist`) gemäß dem TurtleBot 4 Tutorial.  

---

## ⚙️ Software & Ausführung

Für die praktische Durchführung wird ein vorgefertigtes Docker-Setup mit **ROS 2 Humble Desktop** und **TurtleBot 4 Desktop-Paketen** bereitgestellt.

### Empfohlener Workflow: VS Code Dev Containers
Öffnen Sie diesen Ordner in VS Code mit installierter Extension *Dev Containers* und wählen Sie **Reopen in Container**.

### Alternativer Workflow: Dev Terminal Skript
Starten Sie das vorbereitete Helper-Skript in Ihrer Shell (unter Linux / WSL):
```bash
./dev_terminal.sh
```

Detaillierte Anleitungen sowie Informationen zur internen Funktionsweise des Containers finden Sie hier:

- 📖 **Architektur & Funktionsweise:** [Dev Container & Docker Architektur](docs/docker_devcontainer.md)  
- 📖 **Windows:** [Docker Setup & Erste Schritte unter Windows](docs/docker_windows.md)  
- 📖 **Linux (Ubuntu):** [Docker Setup & Erste Schritte unter Linux (Ubuntu)](docs/docker_linux.md)  

---

## 📚 Links & Dokumentation

- [ROS 2 Industrial Workshop Tutorial](https://ros2-industrial-workshop.readthedocs.io/en/latest/index.html)  
- [ROS 2 Cheat Sheet Concise](https://github.com/ros-industrial/ros2_i_training/blob/main/slides/Basics/source/Cheat_sheet_concise.md)  
- [TurtleBot 4 Docker Simulation (ROS 2 Jazzy)](https://github.com/kscottz/turtlebot4_docker?tab=readme-ov-file) – Docker Container zur Simulation des TurtleBot 4. Verwendet ROS 2 Jazzy Jalisco (statt Humble), ist jedoch extrem performant und läuft auch ohne dezidierte GPU flüssig unter Linux sowie unter Windows (über Docker Desktop / WSL 2).  
- [TurtleBot 4 First Node Python Tutorial](https://turtlebot.github.io/turtlebot4-user-manual/tutorials/first_node_python.html)  
- [Offizielle TurtleBot 4 Dokumentation](https://turtlebot.github.io/turtlebot4-user-manual/)  
- [ROS 2 Humble Dokumentation](https://docs.ros.org/en/humble/)  
- [Docker Download & Installation](https://docs.docker.com/get-docker/)  
- [TurtleBot Webpräsenz](https://www.turtlebot.com/)  
