# Einrichten der Entwicklungsumgebung mit Anaconda / Miniconda

In der Datei `environment.yml` finden Sie alle benötigten Bibliotheken und Abhängigkeiten für das Praktikum mit dem **Niryo NED2**.

Wir empfehlen die Einrichtung der Entwicklungsumgebung mithilfe von **Anaconda** oder **Miniconda**. Anaconda bzw. Miniconda installiert Python sowie alle erforderlichen Pakete isoliert in einer separaten virtuellen Umgebung. Dadurch werden Konflikte mit anderen Python-Installationen oder Projekten auf Ihrem System vermieden.

---

## 📥 Schritt-für-Schritt-Anleitung

### 1. Anaconda oder Miniconda herunterladen und installieren
Laden Sie Anaconda oder Miniconda von der offiziellen Website herunter und führen Sie die Installation durch:  
- 🔗 [Download Anaconda / Miniconda](https://docs.conda.io/projects/conda/en/latest/user-guide/install/download.html#anaconda-or-miniconda)  

---

### 2. Anaconda Konsole öffnen
Öffnen Sie auf Ihrem System die **Anaconda Powershell Prompt (anaconda3)** (unter Windows im Startmenü suchen) bzw. ein Terminal mit aktiviertem Conda unter macOS/Linux.

---

### 3. In das Praktikumsverzeichnis wechseln
Navigieren Sie in der Konsole zu dem Ordner, in dem sich die Datei `environment.yml` befindet (z. B. `praktikum/niryo_ned2/`):

```powershell
cd /pfad/zu/praktikum/niryo_ned2
```

---

### 4. Virtuelle Conda-Umgebung erstellen
Erstellen Sie die virtuelle Umgebung für das Praktikum mit folgendem Befehl:

```powershell
conda env create -f environment.yml
```

> **Hinweis:** Dieser Befehl liest die `environment.yml` ein, erstellt eine neue Conda-Umgebung namens `niryo` und installiert Python sowie alle benötigten Pakete (`pyniryo`, `opencv-python`, `jupyter` etc.).

---

### 5. Virtuelle Umgebung aktivieren
Aktivieren Sie die erstellte Umgebung vor der Arbeit am Praktikum:

```powershell
conda activate niryo
```

---

### 6. Jupyter Notebook starten
Nachdem die Umgebung aktiviert ist, können Sie Jupyter Notebook im Praktikumsordner starten:

```powershell
jupyter notebook
```

Anschließend öffnet sich das Jupyter-Dashboard im Browser, und Sie können das Notebook `1-ned2_fertigungsprozess.ipynb` öffnen.
