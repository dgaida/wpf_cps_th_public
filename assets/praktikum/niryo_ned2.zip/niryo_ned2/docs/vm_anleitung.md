# Durchführung des Niryo Praktikums in einer virtuellen Maschine (VM)

Diese Anleitung beschreibt Schritt für Schritt, wie Sie das Praktikum mit dem **Niryo NED2** in einer virtuellen Maschine (VMware) unter Verwendung einer ROS-Simulationsumgebung durchführen.

---

## 📋 Schritt-für-Schritt-Anleitung

### 1. VMware Workstation / Player installieren
Laden Sie **VMware Workstation Pro** bzw. den VMware Player herunter und installieren Sie die Software auf Ihrem Host-Betriebssystem:  
- 🔗 [VMware Desktop Hypervisor Herunterladen](https://www.vmware.com/products/desktop-hypervisor/workstation-and-fusion)  
*(Hinweis: Für den Download ist die Erstellung eines kostenlosen Benutzeraccounts erforderlich).*

---

### 2. Virtuelle Maschine laden und starten
Kopieren Sie die vorbereitete Virtual Machine aus Sciebo (Ordner: `NED2/Installation/VMware Workstation`) lokal auf Ihren Rechner und starten Sie diese mit dem VMware Player.  
- **Standard-Passwort:** `cps`  

---

### 3. ROS Launch-Datei in die VM kopieren
Kopieren Sie die ROS-Launch-Datei `desktop_gazebo_rviz_simulation.launch` aus Sciebo (`NED2/Installation`) in den Pfad der virtuellen Maschine:
```
catkin_ws_niryo_ned/src/niryo_robot_bringup/launch/
```

![Abbildung 1: Virtual Machine mit Ubuntu nach deren Start](images/00_VMStart_launchfile.png)
*Abbildung 1: Virtual Machine mit Ubuntu nach dem Start. Gezeigt wird der Zielordner für die ROS-Launch-Dateien.*

---

### 4. ROS Simulation starten
Öffnen Sie ein Terminal in der virtuellen Maschine und führen Sie folgenden Befehl aus:

```bash
roslaunch niryo_robot_bringup desktop_gazebo_rviz_simulation.launch
```

![Abbildung 2: Aufruf von roslaunch in der virtuellen Maschine](images/01_VMStart_launchfile_roscommand.png)
*Abbildung 2: Aufruf von `roslaunch` in der Konsole der VM zum Starten der Roboterarm-Simulation.*

> **Performance-Hinweise:**
> - Wenn Ihr Rechner sehr performant ist, können Sie alternativ `roslaunch niryo_robot_bringup desktop_gazebo_simulation.launch` aufrufen, um zusätzlich die 3D-Simulation des Roboterarms in Gazebo zu sehen.
> - Falls es zu Performanceproblemen kommt, können Sie `roslaunch niryo_robot_bringup desktop_gazebo_simulation.launch gui:=false` nutzen. Dieser Aufruf startet die Simulation ohne grafische Oberfläche von RViz.

---

### 5. RViz & Kamerabild überprüfen
Nach Ausführen des Befehls öffnet sich RViz. Sie sehen dort den Roboterarm sowie den Live-Feed der Kamera, die am Greifer angebracht ist.

Mit RViz können Sie den Greifarm interaktiv mit der Maus an eine neue Position bewegen und über die Schaltfläche **"Plan & Execute"** anfahren lassen. *(Abgesehen von diesem Test wird RViz im weiteren Praktikum nicht direkt benötigt).*

![Abbildung 3: Ansicht in der virtuellen Maschine nach dem Start von Gazebo und RViz](images/02_VM_Rviz_start.png)
*Abbildung 3: Ansicht in der virtuellen Maschine nach dem Start. In RViz wurde der Roboterarm an eine neue Position bewegt.*

---

### 6. IP-Adresse der VM ermitteln
Prüfen Sie die IP-Adresse Ihrer virtuellen Maschine:  
1. Klicken Sie in der VM oben rechts auf das Netzwerksymbol (drei verbundene Rechner).  
2. Öffnen Sie die **Settings** (Zahnrad-Symbol).  
3. Lesen Sie die zugewiesene IPv4-Adresse ab.  

![Abbildung 4: Bestimmung der IP-Adresse in der virtuellen Maschine](images/03_VM_Ipaddress.png)
*Abbildung 4: Bestimmung der IP-Adresse in den Netzwerkeinstellungen der virtuellen Maschine.*

---

### 7. Niryo Studio im Host-Betriebssystem verbinden  
1. Starten Sie **Niryo Studio** auf Ihrem Host-Betriebssystem.  
2. Klicken Sie oben rechts neben **"Not Connected"**, um die Verbindung aufzubauen.  
3. Geben Sie die IP-Adresse Ihrer VM ein und klicken Sie auf **"Connect"**.  

![Abbildung 5: Verbindung mit Niryo Studio](images/04_NiryoStudio_connect.png)
*Abbildung 5: Start von Niryo Studio auf dem Host-Betriebssystem und Verbindungsaufbau mit der VM-IP-Adresse.*

---

### 8. Arbeitsfläche in Niryo Studio ausrichten
Damit die Arbeitsfläche des Roboterarms mit der Kamera sichtbar ist:  
1. Bewegen Sie **Gelenk 5 (Joint 5)** nach unten (Wert ca. `-0.6`).  
2. Klicken Sie auf **"Move Joints"**.  

Nun sollten Sie die Arbeitsfläche mit den drei farbigen Würfeln sehen. Die Bewegung wird sowohl in Niryo Studio als auch in der virtuellen Maschine synchron angezeigt.

![Abbildung 6: Ausrichten von Joint 5](images/05_Niryo_workspace.png)
*Abbildung 6: Bewegen von Gelenk 5 (Joint 5) in Niryo Studio zur Sichtbarmachung des Arbeitsbereichs.*

---

### 9. Jupyter Notebook auf dem Host-Betriebssystem starten
Starten Sie Jupyter Notebook auf Ihrem Host-Betriebssystem. Falls Sie eine Conda-Umgebung eingerichtet haben (siehe [Anaconda Setup Guide](anaconda_setup.md)), aktivieren Sie diese zuerst:

```powershell
conda activate niryo
cd /pfad/zu/praktikum/niryo_ned2
jupyter notebook
```

![Abbildung 7: Start von Jupyter Notebook](images/06_Niryo_command_jupyter.png)
*Abbildung 7: Start von Jupyter Notebook in der Konsole des Host-Betriebssystems.*

---

### 10. IP-Adresse im Jupyter Notebook eintragen
Öffnen Sie das Notebook `1-ned2_fertigungsprozess.ipynb`. Tragen Sie in der Variable `robot_ip_address` die IP-Adresse Ihrer virtuellen Maschine ein:

```python
robot_ip_address = "192.168.x.x"  # IP-Adresse Ihrer VM
```

![Abbildung 8: Setzen der IP-Adresse im Notebook](images/07_Niryo_jupyter_ip_addres.png)
*Abbildung 8: Ersetzen der Standard-IP durch die IP-Adresse der virtuellen Maschine im Jupyter Notebook.*

---

### 11. Praktikumsaufgabe ausführen
Führen Sie den Code im Jupyter Notebook aus. Bei korrekter Konfiguration greift der Roboterarm einen der farbigen Steine. Die Animation ist synchron in Niryo Studio und in der VM zu beobachten.

![Abbildung 9: Greifen des grünen Steins](images/08_Niryo_jupyter_grasp_green.png)
*Abbildung 9: Greifen des grünen Steines bei Ausführung des Python-Codes im Notebook.*

![Abbildung 10: Greifen des roten Steins](images/09_Niryo_jupyter_grasp_red.png)
*Abbildung 10: Greifen des roten Steines bei weiterer Prozesstaktung.*

---

### 12. Zurücksetzen der Simulation
Wenn Sie ein gegriffenes Objekt erneut greifen oder den Zustand zurücksetzen möchten:  
- Beenden Sie den laufenden `roslaunch`-Prozess in der Konsole der virtuellen Maschine (`Ctrl + C`).  
- Rufen Sie den `roslaunch`-Befehl erneut auf, um die Simulation im Startzustand neu zu starten.  

---

## 📚 Referenzen

- 🔗 [Niryo ROS Simulation Documentation](https://docs.niryo.com/dev/ros/v4.1.0/en/source/simulation.html)  
