#!/usr/bin/env python3
"""Workspace für die Vision-Funktion des Niryo NED2 per Python anlegen (ohne NiryoStudio).

Ablauf:
  1. NED2 ausschalten, Greifer abnehmen, Kalibrierspitze montieren, NED2 einschalten.
  2. Skript starten. Der Roboter geht in den Lernmodus und lässt sich von Hand führen.
  3. Die Kalibrierspitze nacheinander auf die Mitte der vier Markierungen setzen, beginnend mit
     der Markierung mit dem Punkt, dann im Uhrzeigersinn, jeweils mit Enter bestätigen.
  4. Der Workspace wird unter dem angegebenen Namen auf dem Roboter gespeichert.

Aufruf:
  python3 create_workspace.py                                   # Workspace "cps_praktikum"
  python3 create_workspace.py --name cps_praktikum --ip 192.168.0.226
"""

import argparse
import json
import sys
import time
from typing import Any, List, Optional

from pyniryo import NiryoRobot, NiryoRobotException

DEFAULT_ROBOT_IP = "192.168.0.226"
DEFAULT_WORKSPACE_NAME = "cps_praktikum"
# Werkzeug-IDs von Greifern, Vakuumpumpe und Elektromagnet: dann ist keine Kalibrierspitze montiert
GRIPPER_TOOL_IDS = (11, 12, 13, 30, 31)

# Die Reihenfolge ist wichtig: Der Roboter leitet die Lage der Markierungen aus diesen vier Posen ab.
CORNERS = [
    ("1 (Ursprung)", "die Markierung mit dem PUNKT (im Kamerabild oben links)"),
    ("2", "die nächste Markierung im UHRZEIGERSINN (oben rechts)"),
    ("3", "die nächste Markierung im UHRZEIGERSINN (unten rechts)"),
    ("4", "die letzte Markierung (unten links)"),
]


def ask_yes_no(question: str, default: bool = False) -> bool:
    """Stellt eine Ja/Nein-Frage im Terminal.

    Args:
        question: Fragetext.
        default: Antwort, wenn nur Enter gedrückt wird.

    Returns:
        True für Ja, False für Nein.
    """
    answer = input(question + (" [J/n] " if default else " [j/N] ")).strip().lower()
    if answer == "":
        return default
    return answer in ("j", "ja", "y", "yes")


def record_corner_poses(robot: Any) -> List[Any]:
    """Schaltet den Lernmodus ein und nimmt je Markierung eine Pose der Kalibrierspitze auf.

    Args:
        robot: Verbundene NiryoRobot-Instanz.

    Returns:
        Die vier Posen in der Reihenfolge von CORNERS.
    """
    poses = []
    robot.set_learning_mode(True)
    print("\nLernmodus EIN: Der Roboter lässt sich jetzt von Hand führen.")
    print("Setzen Sie die Kalibrierspitze genau auf die Mitte jeder Markierung.\n")

    for label, description in CORNERS:
        while True:
            input(f"Markierung {label}: Spitze auf {description} setzen und Enter drücken ... ")
            pose = robot.get_pose()
            x, y, z, roll, pitch, yaw = pose.to_list()
            print(f"    Pose: x={x:.4f} y={y:.4f} z={z:.4f} roll={roll:.3f} pitch={pitch:.3f} yaw={yaw:.3f}")
            if ask_yes_no("    Pose übernehmen?", default=True):
                poses.append(pose)
                break
            print("    Roboter neu positionieren.")
    return poses


def create_workspace(
    robot: Any,
    name: str,
    calibrate: bool = True,
    save_json: Optional[str] = None,
) -> bool:
    """Legt einen Workspace aus vier von Hand angefahrenen Posen an.

    Args:
        robot: Verbundene NiryoRobot-Instanz.
        name: Name des Workspace (höchstens 30 Zeichen).
        calibrate: Motoren bei Bedarf kalibrieren.
        save_json: Optionale Datei, in die die vier Posen zusätzlich geschrieben werden.

    Returns:
        True, wenn der Workspace gespeichert wurde, False bei Abbruch.
    """
    if calibrate and robot.need_calibration():
        print("Kalibriere die Motoren ...")
        robot.calibrate_auto()

    robot.update_tool()
    tool_id = robot.get_current_tool_id()
    if tool_id in GRIPPER_TOOL_IDS:
        print(f"Warnung: Greifer/Vakuumpumpe/Elektromagnet erkannt (Werkzeug-ID {tool_id}).")
        if not ask_yes_no("Ist wirklich die Kalibrierspitze montiert?"):
            print("Abbruch: Bitte zuerst die Kalibrierspitze montieren (NED2 dazu ausschalten).")
            return False

    existing = robot.get_workspace_list()
    print(f"Vorhandene Workspaces auf dem Roboter: {existing}")
    if name in existing:
        if not ask_yes_no(f"Workspace '{name}' existiert bereits. Überschreiben?"):
            print("Abbruch, nichts geändert.")
            return False
        robot.delete_workspace(name)
        print(f"Alter Workspace '{name}' gelöscht.")

    poses = record_corner_poses(robot)

    print(f"\nSpeichere Workspace '{name}' ...")
    robot.save_workspace_from_robot_poses(name, *poses)
    time.sleep(0.5)

    if name not in robot.get_workspace_list():
        print(f"Warnung: Workspace '{name}' fehlt nach dem Speichern in der Liste.")
        return False
    print(f"Workspace '{name}' gespeichert. Seitenverhältnis Breite/Höhe: {robot.get_workspace_ratio(name):.3f}")

    if save_json:
        with open(save_json, "w") as f:
            json.dump({"workspace": name, "poses": [p.to_list() for p in poses]}, f, indent=2)
        print(f"Posen gespeichert in {save_json}")
    return True


def main() -> None:
    """Kommandozeile: Verbindung aufbauen, Workspace anlegen, Lernmodus aktiv lassen."""
    parser = argparse.ArgumentParser(description="Workspace des NED2 aus vier von Hand angefahrenen Posen anlegen.")
    parser.add_argument("--ip", default=DEFAULT_ROBOT_IP, help="IP-Adresse des Roboters (Standard: %(default)s)")
    parser.add_argument("--name", default=DEFAULT_WORKSPACE_NAME, help="Name des Workspace (Standard: %(default)s)")
    parser.add_argument("--no-calibration", action="store_true", help="Automatische Motorkalibrierung überspringen")
    parser.add_argument("--save-json", metavar="DATEI", help="Die vier Posen zusätzlich in diese JSON-Datei schreiben")
    args = parser.parse_args()

    if len(args.name) > 30:
        sys.exit("Der Name des Workspace darf höchstens 30 Zeichen lang sein.")

    robot = NiryoRobot(args.ip)
    try:
        if create_workspace(robot, args.name, calibrate=not args.no_calibration, save_json=args.save_json):
            print("\nFertig. Der Lernmodus bleibt aktiv, damit Sie die Kalibrierspitze abnehmen können.")
            print(f"Im Notebook: workspace_name = \"{args.name}\"")
    except NiryoRobotException as e:
        print(f"Roboterfehler: {e}")
        sys.exit(1)
    except (KeyboardInterrupt, EOFError):
        print("\nAbgebrochen, nichts gespeichert.")
    finally:
        try:
            robot.set_learning_mode(True)
        except Exception:
            pass
        robot.close_connection()


if __name__ == "__main__":
    main()
