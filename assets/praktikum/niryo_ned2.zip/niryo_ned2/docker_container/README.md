# Docker Simulation Umfeld für Niryo NED2

Dieses Verzeichnis enthält die Docker-Konfiguration zum Ausführen einer Simulationsumgebung (Gazebo & ROS Noetic) für den **Niryo NED2** Roboterarm. Mit dieser Umgebung kann der Roboterarm virtuell gesteuert und mit Python (`pyniryo`) programmiert werden, ohne dass eine physikalische Hardware vorhanden sein muss.

---

## Was ist Docker Compose

**Docker Compose** ist ein Werkzeug zum Definieren und Ausführen von Multi-Container-Docker-Anwendungen. Über eine zentrale Konfigurationsdatei (`docker-compose.yml`) lässt sich der gesamte Simulations-Container samt seinen Netzwerkkonfigurationen, Portweiterleitungen und Umgebungsvariablen mit einem einzigen Befehl (`docker compose up`) erstellen, starten und verwalten.

---

## 📁 Dateiträgerschaft & Ordnerübersicht

In diesem Ordner befinden sich folgende Dateien:

- **`Dockerfile`**: Das Baurezept für das Docker-Image. Es basiert auf ROS Noetic Desktop Full, installiert notwendige System- und GUI-Abhängigkeiten (z. B. OpenCV, xvfb, x11vnc, noVNC), klont das `ned_ros` Repository von Niryo und kompiliert den ROS-Catkin-Workspace.  
- **`docker-compose.yml`**: Die Orchestrierungsdatei für Docker Compose. Sie definiert den Container-Dienst `ned2_simulation`, verknüpft die benötigten Portweiterleitungen nach außen (noVNC, Video-Server, Rosbridge, Robot-API) und steuert den automatischen Neustart.  
- **`supervisord.conf`**: Konfigurationsdatei für den Prozess-Manager *Supervisor*. Innerhalb des Docker-Containers startet und überwacht Supervisor alle benötigten Hintergrundprozesse parallel (virtueller Framebuffer `Xvfb`, Window Manager `fluxbox`, VNC-Server `x11vnc`, Web-VNC `novnc`, ROS Noetic Launchfile und den Web-Video-Server).  
- **`README.md`**: Diese Dokumentationsdatei mit Anleitungen zur Einrichtung, Nutzung und Fehlerbehebung.  

*(Hinweis zu `supervisord.conf`: Die Datei `supervisord.conf` wird zwingend im Container benötigt, da Docker standardmäßig nur einen Hauptprozess ausführt. Supervisor erlaubt es, die verschiedenen GUI-, VNC- und ROS-Dienste zeitgleich im Container zu betreiben).*

---

## 🚀 Übersicht & Ports

Der Docker-Container stellt folgende Dienste über Ihre lokalen Ports bereit:

| Port | Dienst | Beschreibung |
|------|--------|--------------|
| **8080** | **noVNC (Browser UI)** | Bietet Zugriff auf die virtuelle Benutzeroberfläche (Gazebo Desktop / Fluxbox) im Webbrowser (`http://localhost:8080`). |
| **8081** | **Web Video Server** | Stellt ROS Video-Streams als HTTP MJPEG-Stream bereit. |
| **9090** | **Rosbridge Server** | WebSocket-Schnittstelle zur Interaktion mit ROS-Topics und -Services. |
| **40001** | **Niryo Robot API** | TCP-Schnittstelle für die Kommunikation via `pyniryo` (IP: `127.0.0.1` / `localhost`). |

---

## 🛠️ Voraussetzungen

### Unterstützte Betriebssysteme  
- **Linux** (z. B. Ubuntu, Debian, Arch Linux) – Nativ unterstützt.  
- **macOS** (Intel & Apple Silicon / M-Serie) – Über Docker Desktop.  
- **Windows 10 / 11** – Über Docker Desktop (mit WSL 2 Backend empfohlen).  
  *(Warum WSL 2? Das WSL 2 Backend stellt einen echten Linux-Kernel unter Windows bereit, wodurch Linux-basierte Container wie ROS Noetic & Gazebo nativ, mit vollständiger Systemkompatibilität und deutlich höherer Dateisystem- und I/O-Performance ausgeführt werden können als im alten Hyper-V-Modus).*

### Software & Installation  
- **Docker Engine** (v20.10 oder neuer)  
- **Docker Compose** (v2.0 oder neuer, in modernen Docker Desktop Installationen direkt enthalten)  

#### Bezugsquellen & Installation
Docker und Docker Compose können kostenlos über die offizielle Docker-Dokumentation bezogen und installiert werden:  
- **Docker Desktop (Windows & macOS):** [https://docs.docker.com/desktop/](https://docs.docker.com/desktop/)  
- **Docker Engine & Docker Compose Plugin (Linux):** [https://docs.docker.com/get-docker/](https://docs.docker.com/get-docker/)  

---

## 📋 Verwendung & Befehle

### 1. Container bauen und starten

Wechseln Sie in das Verzeichnis `docker_container` und führen Sie folgenden Befehl aus:

```bash
docker compose up --build -d
```

Der Parameter `-d` startet den Container im Hintergrund (Detached Mode). Beim ersten Start kann der Build-Prozess einige Minuten dauern, da ROS Noetic sowie `ned_ros` heruntergeladen und kompiliert werden.

### 2. Benutzeroberfläche öffnen (noVNC)

Öffnen Sie einen Browser und rufen Sie folgende URL auf:

```
http://localhost:8080
```

Hier sehen Sie den virtuellen Desktop mit der laufenden **Gazebo-Simulation** des Niryo NED2.

### 3. Anbindung an Python Notebooks (`pyniryo`)

Setzen Sie in Ihren Python-Skripten bzw. Jupyter Notebooks die IP-Adresse und den Simulation-Modus wie folgt:

```python
from pyniryo import NiryoRobot

# Verbindung zur Docker-Simulation herstellen
robot = NiryoRobot("127.0.0.1")

# Roboter automatisch kalibrieren
robot.calibrate_auto()

# Tool aktualisieren (z.B. Greifer)
robot.update_tool()

# Testweise Sprach- oder Bewegungskommando senden
robot.say("Simulation bereit", 0)

# Verbindung ordnungsgemäß schließen
robot.close_connection()
```

In `1-ned2_fertigungsprozess.ipynb` stellen Sie `simulation_mode = True` ein.

---

## 🔍 Log-Dateien & Troubleshooting

- **Container-Logs anzeigen:**  
  ```bash
  docker compose logs -f
  ```

- **Container stoppen und entfernen:**  
  ```bash
  docker compose down
  ```

- **Neustarten der Dienste im Container:**  
  Supervisord verwaltet intern `Xvfb`, `x11vnc`, `novnc`, `ros` und `web_video_server`.
