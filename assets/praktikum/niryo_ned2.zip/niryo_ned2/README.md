# Praktikum: Niryo NED2 Fertigungsprozess

Dieses Verzeichnis enthält alle Materialien und Aufgaben für das Praktikum **Niryo NED2** im Rahmen des Wahlpflichtfachs *Cyber-physische Systeme (CPS)*.

---

## 📁 Ordnerstruktur

```
niryo_ned2/
├── 1-ned2_fertigungsprozess.ipynb  # Haupt-Jupyter-Notebook mit Praktikumsaufgaben & Musterlösungen
├── environment.yml                # Conda-Umgebungsdatei für die benötigten Abhängigkeiten
├── requirements.txt               # Python Package-Abhängigkeiten
├── src/                           # Modul-Quellcode für ausgelagerte Funktionen
│   ├── __init__.py
│   └── fertigungsprozess.py
├── tests/                         # Unit- und Integrationstests
│   ├── integration/
│   │   └── test_pipeline_integration.py
│   └── unit/
│       └── test_fertigungsprozess.py
├── docs/                          # Dokumentation & Anleitungen
│   ├── anaconda_setup.md          # Anleitung zur Einrichtung mit Anaconda / Miniconda
│   ├── vm_anleitung.md            # Anleitung zur Durchführung in der VMware-VM
│   └── images/                    # Screenshots für die Dokumentation
├── docker_container/              # Docker-Simulationsumgebung (Gazebo, ROS Noetic, noVNC)
│   ├── Dockerfile
│   ├── docker-compose.yml
│   ├── supervisord.conf
│   └── README.md
├── res/                           # Grafiken und Bilder für Notebook und Dokumentation
└── README.md                      # Diese Übersichtsdatei
```

---

## 🎯 Praktikumsziele & Inhalte

Im Praktikum wird ein industrieller Fertigungsprozess mit dem kollaborativen 6-Achs-Roboterarm **Niryo NED2** simuliert und programmiert.

### Key Topics in `1-ned2_fertigungsprozess.ipynb`

1. **Einrichten von Workspaces & Vision-Set**: Kalibrierung des Arbeitsbereichs vor dem Roboter.  
2. **Kamera-basierte Objekterkennung (Pick & Place)**: Erkennen von Objekten anhand visueller Merkmale (Farbe, Form via `pyniryo`) und Ablegen in ein Rasterschema.  
3. **Qualitätskontrolle & Förderband-Sortierung**: Automatisches Aussortieren fehlerhafter Bauteile (z. B. rote und blaue runde Objekte) direkt aus dem Lager oder auf dem laufenden Förderband.  
4. **Prozessprotokollierung (Logging)**: Erfassung verarbeiteter Gutteile sowie aussortierten Ausschusses in einer Logdatei (`prozess_protokoll.txt`).  
5. **Human-Robot-Interaction (HRI)**: Visuelle Rückmeldungen über den RGB-LED-Ring und akustische Sprachausgabe (`say()`, `led_ring_solid()`).  

---

## ⚙️ Software & Anbindung

Für die Programmierung wird ausschließlich das offizielle Python-Package **`pyniryo`** (Version 1.2.x / v1.2.5+) genutzt (`pyniryo2` wird nicht mehr unterstützt).

### Einrichtung der Entwicklungsumgebung

Wir empfehlen die Installation über Anaconda oder Miniconda anhand der `environment.yml`:

- 📖 **Anleitung:** [Einrichtung der Anaconda-Umgebung](docs/anaconda_setup.md)  

Alternativ können die Python-Abhängigkeiten direkt via `pip` installiert werden:

```bash
pip install -r requirements.txt
```

### Verbindung zum Roboter

Die Verbindung kann wahlweise zu einem realen Roboter oder zu einer Simulationsumgebung hergestellt werden:

- **Realer Roboter:**  
  - Hotspot-IP: `10.10.10.10`  
  - WLAN-IP: z. B. `192.168.0.226`  
- **Docker Simulation:**  
  - IP: `127.0.0.1` (Port `40001`)  
- **VMware Virtual Machine:**  
  - IP der VM (siehe [VM-Anleitung](docs/vm_anleitung.md))  

---

## 🖥️ Simulation (VMware & Docker)

Für die Durchführung des Praktikums ohne reale Hardware stehen zwei Simulationsmöglichkeiten bereit:

1. **Virtuelle Maschine (VMware Workstation / Player):**  
   Empfohlene Variante zur vollständigen Simulation inkl. Gazebo, RViz und Kamerabild.  
   - 📖 **Anleitung:** [Durchführung des Niryo Praktikums in einer virtuellen Maschine](docs/vm_anleitung.md)  

2. **Docker-Simulationsumgebung:**  
   Leichtgewichtige Alternative via Docker Compose. Weitere Details in [docker_container/README.md](docker_container/README.md).

   ```bash
   cd docker_container
   docker compose up --build -d
   ```

   Grafische Gazebo-Oberfläche im Webbrowser unter `http://localhost:8080`.

---

## 🚀 Optionale Weiterführende Aufgaben

Nach der Bearbeitung des Haupt-Notebooks `1-ned2_fertigungsprozess.ipynb` steht eine optionale Vertiefungsaufgabe zur visuellen Kommissionierung mit Künstlicher Intelligenz (TensorFlow & Vision Set) zur Verfügung. In diesem offiziellen Niryo Academy Tutorial lernen Sie, Objekte mittels TensorFlow, Bildverarbeitung und PyNiryo autonom zu erkennen, zu klassifizieren und aufzunehmen: 🎓 [Niryo Academy Tutorial: Pick & Place mit Vision Set & PyNiryo](https://academy.niryo.com/mod/page/view.php?id=410).

---

## 📚 Links & Dokumentation

- [PyNiryo v1.2.5 Dokumentation](https://niryorobotics.github.io/pyniryo/v1.2.5/index.html)  
- [Niryo NED2 Offizielle Dokumentation](https://docs.niryo.com/robots/ned2/)  
- [Niryo Academy Tutorial: Pick & Place mit Vision Set & PyNiryo](https://academy.niryo.com/mod/page/view.php?id=410)  
