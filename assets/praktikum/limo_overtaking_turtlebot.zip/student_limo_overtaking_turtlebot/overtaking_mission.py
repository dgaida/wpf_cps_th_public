#!/usr/bin/env python3
"""Steps 3 to 5: Overtaking mission of the LIMO Cobot.

    python3 overtaking_mission.py --sim                 # simulation, as fast as possible
    python3 overtaking_mission.py --sim --realtime      # simulation in real time
    python3 overtaking_mission.py                       # real robot (ROS 2 must be running)

TODO: Implement run_mission. Robot object, command line interface and shutdown are provided.
"""

import argparse
import enum
from dataclasses import dataclass
from typing import Any


class MissionState(enum.Enum):
    """States of the overtaking state machine."""

    FOLLOW = "follow"                    # approach the TurtleBot, estimate v_tb
    LANE_CHANGE_OUT = "lane_change_out"  # change to the left lane
    PASSING = "passing"                  # drive past the TurtleBot
    LANE_CHANGE_IN = "lane_change_in"    # return to the main lane
    MAIN_LANE = "main_lane"              # continue in front of the TurtleBot
    DONE = "done"


@dataclass
class MissionConfig:
    """Parameters of the manoeuvre. Adapt them if necessary.

    Attributes:
        v_follow (float): Speed while approaching the TurtleBot in m/s.
        v_overtake (float): Overtaking speed in m/s.
        d_start (float): Distance at which the manoeuvre starts in meters.
        d_target (float): Distance in front of the TurtleBot after merging in meters.
        y_lane (float): Lateral offset of the overtaking lane in meters (positive = left).
        x_lane (float): Longitudinal length of one lane change in meters.
        l_limo (float): Length of the LIMO in meters.
        l_tb (float): Length (diameter) of the TurtleBot in meters.
        control_period (float): Period of the control loop in seconds.
    """

    v_follow: float = 0.30
    v_overtake: float = 0.35
    d_start: float = 0.3
    d_target: float = 0.3
    y_lane: float = 0.4
    x_lane: float = 1.0
    l_limo: float = 0.32
    l_tb: float = 0.34
    control_period: float = 0.05


def run_mission(robot: Any, config: MissionConfig) -> bool:
    """Execute the overtaking manoeuvre.

    Args:
        robot (Any): ``LimoRobot`` or ``SimulatedLimo``. Both offer now(), sleep(), get_scan(),
            get_speed(), get_travel(), send_velocity() and stop().
        config (MissionConfig): Parameters of the manoeuvre.

    Returns:
        bool: True if the manoeuvre was completed.
    """
    # TODO: Implement the state machine.
    #   FOLLOW:           drive with v_follow, measure d (speed_estimator.front_distance) and estimate
    #                     v_tb (SpeedEstimator). At d <= d_start: freeze v_tb, compute the prediction
    #                     (prediction.predict_overtake) and print it.
    #   LANE_CHANGE_OUT:  follow the cubic polynomial to +y_lane (lane_change.lane_change_command).
    #   PASSING:          drive straight with v_overtake until the LIMO is far enough ahead.
    #   LANE_CHANGE_IN:   follow the cubic polynomial back to the main lane.
    #   MAIN_LANE:        continue with the TurtleBot speed, then stop.
    # Use robot.sleep(config.control_period) in every loop - never time.sleep - so that the same
    # code works in the simulation. Record the data you need for step 5.
    raise NotImplementedError("TODO: implement run_mission")


def main() -> None:
    """Create the robot (real or simulated), run the mission and shut down safely."""
    parser = argparse.ArgumentParser(description="LIMO Cobot overtakes TurtleBot 4")
    parser.add_argument("--sim", action="store_true", help="Use the simulation instead of the real robot.")
    parser.add_argument("--realtime", action="store_true", help="Run the simulation in real time.")
    parser.add_argument("--tb-speed", type=float, default=0.15, help="True TurtleBot speed in the simulation in m/s.")
    args = parser.parse_args()

    if args.sim:
        from src.simulation import SimulatedLimo, SimulationConfig

        robot: Any = SimulatedLimo(SimulationConfig(v_tb=args.tb_speed), realtime=args.realtime)
    else:
        from src.limo_interface import LimoRobot

        robot = LimoRobot()

    try:
        success = run_mission(robot, MissionConfig())
        print("Überholmanöver abgeschlossen." if success else "Überholmanöver abgebrochen.")
        if args.sim:
            print(robot.summary())
    except KeyboardInterrupt:
        print("Manuell abgebrochen.")
    finally:
        robot.close()


if __name__ == "__main__":
    main()
