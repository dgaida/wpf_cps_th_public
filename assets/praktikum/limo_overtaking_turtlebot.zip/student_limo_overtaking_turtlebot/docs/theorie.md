# Mathematische Grundlagen & Theorie: Trajektorienprognose und Überholdynamik

> **Theoretische Fundierung des Praktikums LIMO Cobot überholt TurtleBot 4**

---

## 1. Relativkinematik in der Ebene

Betrachtet werden zwei Fahrzeuge auf einer zwei-dimensionalen Ebene:  
- **TurtleBot 4 (Fahrzeug TB):** Bewegt sich entlang der $x$-Achse mit der konstanten Geschwindigkeit $v_{\text{tb}}$.  
- **LIMO Cobot (Fahrzeug LIMO):** Bewegt sich mit der variablen Geschwindigkeit $v_{\text{limo}}(t)$ und der lateralen Position $y(t)$.  

Die Kinematik beider Fahrzeuge in kartesischen Koordinaten $(x, y, \theta)$ lautet:

$$\dot{x}_{\text{tb}}(t) = v_{\text{tb}}, \quad \dot{y}_{\text{tb}}(t) = 0$$

$$\dot{x}_{\text{limo}}(t) = v_{\text{limo}}(t) \cdot \cos(\theta_{\text{limo}}(t)), \quad \dot{y}_{\text{limo}}(t) = v_{\text{limo}}(t) \cdot \sin(\theta_{\text{limo}}(t))$$

Der Relativabstand in $x$-Richtung zwischen den beiden Fahrzeugen ist definiert als:

$$\Delta x(t) = x_{\text{tb}}(t) - x_{\text{limo}}(t)$$

---

## 2. Sensorgestützte Geschwindigkeitsmessung & Filterung

Der LIMO Cobot erfasst den Abstand zum vorausfahrenden TurtleBot über seinen LiDAR-Sensor oder das Tiefenbild der Kamera. Die Abtastzeit beträgt $\Delta t$. Die diskrete Abstandsmessung $d_k$ zum Zeitpunkt $t_k = k \cdot \Delta t$ enthält Messrauschen $w_k \sim \mathcal{N}(0, \sigma_r^2)$:

$$d_k = \Delta x(t_k) + w_k = x_{\text{tb}}(t_k) - x_{\text{limo}}(t_k) + w_k$$

### Rohwert-Schätzung der Geschwindigkeit

Aus der Differenz zweier aufeinanderfolgender Abstandsmessungen und der eigenen Radodometrie $v_{\text{limo}, k}$ ergibt sich eine Schätzung $\hat{v}_{\text{tb}, k}$ der TurtleBot-Geschwindigkeit:

$$\hat{v}_{\text{tb}, k} = v_{\text{limo}, k} + \frac{d_k - d_{k-1}}{\Delta t}$$

### Tiefpass- / Exponentielles Filterung

Zur Glättung des Differenzenquotienten wird ein gewichtetes exponentielles Tiefpassfilter eingesetzt:

$$\bar{v}_{\text{tb}, k} = (1 - \alpha) \cdot \bar{v}_{\text{tb}, k-1} + \alpha \cdot \hat{v}_{\text{tb}, k} \quad \text{mit } \alpha \in (0, 1]$$

Ein typischer Parameterwahl im Praktikum ist $\alpha = 0{,}2$.

### Zustandsraum-Modell & Kalman-Filter (Optional)

Alternativ kann die Schätzung als 2D-Kalman-Filter zur Zustandsschätzung der Relativbewegung formuliert werden mit dem Zustand $z_k = [\Delta x_k, v_{\text{tb}, k}]^T$:

$$z_k = A \cdot z_{k-1} + B \cdot u_{k-1} + \omega_k$$

$$y_k = C \cdot z_k + \nu_k$$

Wobei gemäss Vorgabe die Messmatrix $C$ als $C = \begin{bmatrix} 1 & 0 \end{bmatrix}$ gewählt wird.

---

## 3. Prognosemodell des Überholvorgangs

Ein Überholvorgang gliedert sich in drei Phasen:

1. **Ausscheren ($\Delta t_{\text{out}}$):** Wechsel von der Hauptspur ($y = 0\text{ m}$) auf die Überholspur ($y = y_{\text{lane}}$).  
2. **Vorbeifahren ($\Delta t_{\text{pass}}$):** Reine Längsbewegung mit erhöhter Überholgeschwindigkeit $v_{\text{overtake}}$.  
3. **Einscheren ($\Delta t_{\text{in}}$):** Rückkehr auf die Hauptspur ($y = 0\text{ m}$).  

### Kinematische Bilanz ohne Synchronisation (Standardaufgabe)

Der Überholvorgang startet, wenn der Relativabstand $d_0 = d_{\text{start}} = 0{,}3\text{ m}$ erreicht ist.
Das Manöver endet, wenn der LIMO Cobot den Sicherheitsabstand $d_{\text{target}} = 0{,}3\text{ m}$ *vor* dem TurtleBot erreicht hat.

Die zu überwindende Relativdistanz $\Delta s_{\text{rel}}$ beträgt:

$$\Delta s_{\text{rel}} = d_{\text{start}} + L_{\text{limo}} + L_{\text{tb}} + d_{\text{target}}$$

Bei konstanter Überholgeschwindigkeit $v_{\text{overtake}}$ und konstanter TurtleBot-Geschwindigkeit $v_{\text{tb}}$ beträgt die Relativgeschwindigkeit:

$$\Delta v = v_{\text{overtake}} - v_{\text{tb}}$$

Die vorhergesagte Gesamtdauer $T_{\text{overtake}}$ berechnet sich zu:

$$T_{\text{overtake}} = \frac{\Delta s_{\text{rel}}}{\Delta v}$$

Daraus ergeben sich die prognostizierten absoluten Fahrtstrecken im Weltkoordinatensystem:

$$s_{\text{tb, prog}} = v_{\text{tb}} \cdot T_{\text{overtake}}$$

$$s_{\text{limo, prog}} = v_{\text{overtake}} \cdot T_{\text{overtake}} = s_{\text{tb, prog}} + \Delta s_{\text{rel}}$$

---

## 4. Prognosemodell mit synchrone Objektübertragung (Zusatzaufgabe)

In der Zusatzaufgabe bremst der LIMO Cobot während der Phase des Vorbeifahrens kurzzeitig ab, um für eine Dauer $T_{\text{sync}}$ mit der gleichen Geschwindigkeit wie der TurtleBot zu fahren ($v_{\text{limo}} = v_{\text{tb}}$). In dieser Phase ist $\Delta v = 0\text{ m/s}$, sodass sich der Relativabstand $\Delta x$ nicht verändert.

Die Gesamtdauer des Überholmanövers verlängert sich um $T_{\text{sync}}$:

$$T_{\text{overtake, sync}} = T_{\text{overtake}} + T_{\text{sync}} = \frac{\Delta s_{\text{rel}}}{v_{\text{overtake}} - v_{\text{tb}}} + T_{\text{sync}}$$

Die neu prognostizierten Fahrtstrecken lauten:

$$s_{\text{tb, prog, sync}} = v_{\text{tb}} \cdot T_{\text{overtake, sync}} = v_{\text{tb}} \cdot \left( \frac{\Delta s_{\text{rel}}}{\Delta v} + T_{\text{sync}} \right)$$

$$s_{\text{limo, prog, sync}} = s_{\text{tb, prog, sync}} + \Delta s_{\text{rel}}$$

---

## 5. Trajektoriengenerierung für den Spurwechsel

Um plötzliche Rucke zu vermeiden, wird der Spurwechsel über ein kubisches Polynom $y(x)$ für die Querposition in Abhängigkeit der Längsposition $x$ modelliert:

$$y(x) = a_0 + a_1 x + a_2 x^2 + a_3 x^3$$

Mit den Randbedingungen für eine Spurwechselstrecke $x \in [0, X_{\text{lane}}]$:  
- $y(0) = 0, \quad y'(0) = 0$  
- $y(X_{\text{lane}}) = y_{\text{lane}}, \quad y'(X_{\text{lane}}) = 0$  

Ergeben sich die Koeffizienten zu:

$$a_0 = 0, \quad a_1 = 0, \quad a_2 = \frac{3 y_{\text{lane}}}{X_{\text{lane}}^2}, \quad a_3 = -\frac{2 y_{\text{lane}}}{X_{\text{lane}}^3}$$

Diese stetige Trajektorie garantiert ein weiches Ausscheren und Einscheren ohne abrupte Lenkbewegungen.
