# Inbetriebnahme am Roboter

LIMO Cobot und TurtleBot 4 sind **getrennte ROS-2-Systeme ohne Verbindung**. Ihr Programm läuft auf dem Onboard-PC des LIMO (ROS 2 Foxy, Python 3.8).

---

## Testablauf

1. LIMO ca. $1{,}0\text{ m}$ hinter dem TurtleBot auf derselben Spur aufstellen. Die Strecke vor beiden Robotern muss frei sein.  
2. **Terminal 1 auf dem LIMO** – Fahrgestell, LiDAR und Odometrie starten:  

   ```bash
   ros2 launch limo_bringup limo_start.launch.py
   ```

3. **Rechner des TurtleBots** – konstante Geschwindigkeit vorgeben (läuft bis `Strg+C`):  

   ```bash
   ros2 topic pub -r 10 /robot_1/cmd_vel geometry_msgs/msg/Twist "{linear: {x: 0.15}}"
   ```

4. **Terminal 2 auf dem LIMO** – Mission starten:  

   ```bash
   python3 overtaking_mission.py
   ```

---

## Prüfen vor dem ersten Lauf

```bash
ros2 topic hz /scan            # ca. 10 Hz
ros2 topic echo /odom --once
```

Kommen keine Scans an, läuft `limo_start.launch.py` nicht oder ROS 2 ist im Terminal nicht gesourced.

---

## Sicherheit

- Eine Person bleibt am LIMO und kann ihn jederzeit anheben oder ausschalten.  
- Abbruch mit `Strg+C`; das Gerüst stoppt das Fahrgestell beim Beenden.  
- Not-Aus aus einem zweiten Terminal:  

  ```bash
  ros2 topic pub /cmd_vel geometry_msgs/msg/Twist "{linear: {x: 0.0}, angular: {z: 0.0}}" --once
  ```

- Beginnen Sie mit niedrigen Geschwindigkeiten und testen Sie jeden Zustand einzeln, bevor Sie das ganze Manöver fahren.  

---

## Zusatzaufgabe: Arm

Der myCobot 280 hängt an `/dev/ttyACM0` und wird direkt über `pymycobot` angesprochen. Kein anderes Programm (z. B. `mycobot_ros2`) darf den Port belegen. Beim Freigeben der Servos den Arm festhalten, er sackt sonst ab.
