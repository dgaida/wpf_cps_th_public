# Aufgabenstellung: LIMO Cobot überholt TurtleBot 4

Die Formeln zu allen Schritten stehen in [theorie.md](./theorie.md). Die Dateinamen beziehen sich auf das bereitgestellte Gerüst; bei eigener Struktur gelten die Aufgaben sinngemäß.

---

## Aufbau und Parameter

| Größe | Wert |
|---|---|
| Geschwindigkeit TurtleBot $v_{\text{tb}}$ | konstant, unbekannt (z. B. $0{,}15\text{ m/s}$) |
| Startabstand | ca. $1{,}0\text{ m}$, gleiche Spur |
| Auslöseabstand $d_{\text{start}}$ | $0{,}3\text{ m}$ |
| Zielabstand nach dem Einscheren $d_{\text{target}}$ | $0{,}3\text{ m}$ vor dem TurtleBot |
| Spurversatz $y_{\text{lane}}$ | $0{,}4\text{ m}$ nach links |
| Länge LIMO $L_{\text{limo}}$ / Breite | $0{,}32\text{ m}$ / $0{,}22\text{ m}$ |
| Durchmesser TurtleBot $L_{\text{tb}}$ | $0{,}34\text{ m}$ |

Das Roboter-Objekt (`LimoRobot` bzw. `SimulatedLimo`) bietet:

| Methode | Bedeutung |
|---|---|
| `get_scan()` | aktueller LiDAR-Scan ($0^\circ$ = geradeaus, positiv = links), ca. $10\text{ Hz}$ |
| `get_speed()`, `get_travel()` | Eigengeschwindigkeit und gefahrene Strecke aus der Odometrie |
| `send_velocity(v, omega)`, `stop()` | Fahrbefehl; bleibt bis zum nächsten Befehl aktiv |
| `now()`, `sleep(t)` | Zeit und Warten – immer diese Methoden verwenden, nie `time.sleep` |

---

## Schritt 1: Abstand messen und $v_{\text{tb}}$ schätzen

Datei: [`src/speed_estimator.py`](../src/speed_estimator.py)

1. Bestimmen Sie den Abstand $d_k$ zum TurtleBot aus den LiDAR-Strahlen im Front-Sektor ($\pm 10^\circ$). Ungültige Messwerte und Wände dürfen das Ergebnis nicht verfälschen.  
2. Schätzen Sie die Geschwindigkeit aus der Abstandsänderung und der Eigengeschwindigkeit:  

   $$\hat{v}_{\text{tb}, k} = v_{\text{limo}, k} + \frac{d_k - d_{k-1}}{\Delta t}$$

3. Glätten Sie die Schätzung mit einem Tiefpassfilter ($\alpha \approx 0{,}2$):  

   $$\bar{v}_{\text{tb}} = (1 - \alpha) \cdot \bar{v}_{\text{tb}} + \alpha \cdot \hat{v}_{\text{tb}, k}$$

**Hinweis:** Der Differenzenquotient zweier Einzelscans rauscht stark ($8\text{ mm}$ Messrauschen bei $\Delta t = 0{,}1\text{ s}$). Überlegen Sie, wann die Schätzung stabil genug ist, um das Manöver zu starten.

---

## Schritt 2: Prognose

Datei: [`src/prediction.py`](../src/prediction.py)

Sobald $d \le d_{\text{start}}$ erreicht ist, frieren Sie $\bar{v}_{\text{tb}}$ ein und berechnen **vor** dem Ausscheren:

$$\Delta s_{\text{rel}} = d_{\text{start}} + L_{\text{limo}} + L_{\text{tb}} + d_{\text{target}}, \qquad T_{\text{overtake}} = \frac{\Delta s_{\text{rel}}}{v_{\text{overtake}} - \bar{v}_{\text{tb}}}$$

$$s_{\text{tb, prog}} = \bar{v}_{\text{tb}} \cdot T_{\text{overtake}}, \qquad s_{\text{limo, prog}} = v_{\text{overtake}} \cdot T_{\text{overtake}}$$

---

## Schritt 3: Überholmanöver

Dateien: [`src/lane_change.py`](../src/lane_change.py), [`overtaking_mission.py`](../overtaking_mission.py)

Implementieren Sie den kubischen Spurwechsel $y(x)$ und einen Zustandsautomaten:

| Zustand | Aufgabe |
|---|---|
| `FOLLOW` | hinter dem TurtleBot aufholen, $v_{\text{tb}}$ schätzen, bei $d \le d_{\text{start}}$ Prognose berechnen |
| `LANE_CHANGE_OUT` | Spurwechsel nach links auf $+y_{\text{lane}}$ |
| `PASSING` | parallel am TurtleBot vorbeifahren |
| `LANE_CHANGE_IN` | Spurwechsel zurück, Einscheren $d_{\text{target}}$ vor dem TurtleBot |
| `MAIN_LANE` | mit $v_{\text{tb}}$ weiterfahren, dann anhalten |

**Hinweise:**

- Beim Ausscheren fährt der LIMO weiter auf den TurtleBot zu. Der seitliche Abstand muss erreicht sein, bevor die LIMO-Front das Heck des TurtleBots erreicht. Wählen Sie Spurwechsellänge und Geschwindigkeit entsprechend.  
- Während der Spurwechsel fährt der LIMO schräg und kommt in Längsrichtung langsamer voran als $v_{\text{overtake}}$. Die einfache Prognose aus Schritt 2 berücksichtigt das nicht.  
- Die Simulation meldet den kleinsten Abstand und eine Kollision. Prüfen Sie Ihr Manöver dort mit mehreren TurtleBot-Geschwindigkeiten, bevor Sie an den Roboter gehen.  

---

## Schritt 4: Auswertung

1. Zeichnen Sie während des Manövers auf: Abstand $d(t)$, Schätzung $\bar{v}_{\text{tb}}(t)$ und die kommandierten Geschwindigkeiten. In der Simulation liefert `robot.history` zusätzlich die wahren Positionen.  
2. Plotten Sie die Zeitreihen und die Trajektorien $(x, y)$ beider Roboter mit `matplotlib`.  
3. Vergleichen Sie Prognose und Ergebnis: $T_{\text{overtake}}$, $s_{\text{limo}}$ und den erreichten Abstand vor dem TurtleBot. Woher kommen die Abweichungen?  

---

## Schritt 5: Versuch am Roboter

Führen Sie das Manöver am echten Aufbau aus ([Inbetriebnahme](./inbetriebnahme.md)) und vergleichen Sie es mit der Simulation. Rechnen Sie damit, dass das reale Fahrgestell von der Simulation abweicht:

- Kleine Drehraten setzt das Fahrgestell nicht um; der LIMO fährt nicht exakt geradeaus.  
- Der LIMO steht beim Start selten genau in Fahrtrichtung des TurtleBots.  
- Der Gierwinkel der Odometrie ist für langsame Drehungen ungenau.  

Dokumentieren Sie, welche Abweichungen auftreten und wie Sie darauf reagieren. Mit `SimulationConfig(initial_heading_deg=..., turn_rate_scale=...)` können Sie solche Effekte vorab nachstellen.

---

## Zusatzaufgabe: Würfelübergabe im Vorbeifahren

Der LIMO führt im Greifer einen Würfel mit. Auf gleicher Höhe neben dem TurtleBot ($\Delta x \approx 0$):

1. Geschwindigkeit auf $v_{\text{limo}} = \bar{v}_{\text{tb}}$ reduzieren.  
2. Arm nach rechts über den TurtleBot schwenken, Greifer öffnen, Arm zurück in die Transportpose ([`src/arm_helpers.py`](../src/arm_helpers.py)). Die Ablagepose lernen Sie im Stand ein: Servos freigeben, Arm von Hand führen, Gelenkwinkel auslesen.  
3. Wieder auf $v_{\text{overtake}}$ beschleunigen und einscheren.  
4. Die Prognose um die Synchronphase $T_{\text{sync}}$ erweitern.  

---

## Erwartete Ergebnisse

- Bestandene Selbsttests für Schritt 1 bis 3 (bzw. eigene Tests bei eigener Struktur).  
- Ein kollisionsfreies Überholmanöver in der Simulation für mindestens zwei TurtleBot-Geschwindigkeiten.  
- Plots und der Vergleich von Prognose und Ergebnis aus Schritt 4.  
- Eine Vorführung am Roboter mit kurzer Auswertung der Unterschiede zur Simulation.  
