# Praktikum: LIMO Cobot überholt TurtleBot 4

> **Geschwindigkeitsschätzung, Prognose und Trajektorienplanung für ein Überholmanöver**

Der **TurtleBot 4** fährt mit konstanter, unbekannter Geschwindigkeit geradeaus. Der **LIMO Cobot** startet ca. $1{,}0\text{ m}$ dahinter, misst den Abstand mit seinem LiDAR, schätzt daraus die Geschwindigkeit des TurtleBots und überholt ihn:

```text
1. Folgen & Schätzen     [LIMO] ───────►  [TurtleBot]          d: 1,0 m → 0,3 m
2. Ausscheren            [LIMO] ╱                              kubisches Polynom, +0,4 m
3. Vorbeifahren                 [LIMO] ═══►
                                 [TurtleBot] ──►
4. Einscheren                                  ╲ [LIMO]        0,3 m vor dem TurtleBot
```

Beide Roboter sind getrennte Systeme: Der LIMO erkennt den TurtleBot ausschließlich über seinen LiDAR.

---

## 📂 Unterlagen

- [**Aufgabenstellung**](./docs/aufgabenstellung.md) – die fünf Schritte und die erwarteten Ergebnisse  
- [**Theorie**](./docs/theorie.md) – Relativkinematik, Filter, Prognose, kubischer Spurwechsel  
- [**Inbetriebnahme am Roboter**](./docs/inbetriebnahme.md) – Start, Testablauf, Not-Aus  

---

## 🧱 Gerüst oder eigene Struktur

Sie haben zwei Möglichkeiten:

- **Mit dem Gerüst:** Schnittstellen und Simulation sind fertig; Sie lösen die mit `TODO` markierten Stellen.  
- **Von Grund auf:** Sie setzen das Projekt mit eigener Struktur um. Die bereitgestellten Module dürfen Sie übernehmen oder als Nachschlagewerk nutzen. Aufgabenstellung und erwartete Ergebnisse gelten für beide Wege.  

| Datei | Inhalt | Status |
|---|---|---|
| [`src/limo_interface.py`](./src/limo_interface.py) | LIMO am echten Roboter: LiDAR, Odometrie, Fahrbefehle (ROS 2) | fertig |
| [`src/simulation.py`](./src/simulation.py) | Simulation von LIMO, TurtleBot und LiDAR mit denselben Methoden | fertig |
| [`src/arm_helpers.py`](./src/arm_helpers.py) | Greifer und Arm für die Zusatzaufgabe | fertig |
| [`src/speed_estimator.py`](./src/speed_estimator.py) | Abstand im Front-Sektor, Schätzung von $v_{\text{tb}}$ | **TODO (Schritt 1)** |
| [`src/prediction.py`](./src/prediction.py) | Prognose von Dauer und Fahrstrecken | **TODO (Schritt 2)** |
| [`src/lane_change.py`](./src/lane_change.py) | kubischer Spurwechsel | **TODO (Schritt 3)** |
| [`overtaking_mission.py`](./overtaking_mission.py) | Zustandsautomat des Manövers | **TODO (Schritt 3–5)** |
| [`tests/`](./tests/) | Selbsttests für Schritt 1 bis 3 | fertig |

---

## 🚀 Arbeiten mit der Simulation

Die Simulation läuft ohne ROS 2 auf jedem Rechner (Python ≥ 3.8, keine weiteren Pakete). Ihr Missionscode läuft unverändert in der Simulation und am Roboter, solange er nur die Methoden des Roboter-Objekts verwendet.

```bash
python3 overtaking_mission.py --sim                  # so schnell wie möglich
python3 overtaking_mission.py --sim --realtime       # in Echtzeit
python3 overtaking_mission.py --sim --tb-speed 0.2   # anderer TurtleBot
python3 overtaking_mission.py                        # am echten Roboter
```

Am Ende gibt die Simulation die wahren Werte aus, u. a. den Abstand vor dem TurtleBot und den kleinsten Abstand während des Manövers (`KOLLISION`, falls sich die Roboter berührt haben).

## 🧪 Selbsttests

```bash
python3 -m pytest tests -v
```

Die Tests prüfen Schritt 1 bis 3 ohne Roboter. Zu Beginn schlagen die Tests der TODO-Module fehl. Sie sind auf das Gerüst zugeschnitten; bei eigener Struktur schreiben Sie eigene Tests.
