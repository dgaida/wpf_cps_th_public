"""Step 3: Cubic lane change trajectory.

TODO: Implement both functions. The tests in tests/test_lane_change.py check your implementation.
"""

from typing import Tuple


def cubic_lane_change(x: float, x_lane: float, y_lane: float) -> Tuple[float, float, float]:
    """Evaluate the cubic lane change polynomial y(x) (docs/theorie.md, section 5).

    Args:
        x (float): Longitudinal position within the lane change in meters; values outside
            [0, x_lane] are clipped to this range.
        x_lane (float): Longitudinal length of the lane change in meters.
        y_lane (float): Lateral offset in meters; positive is to the left, negative to the right.

    Returns:
        Tuple[float, float, float]: Lateral position y, slope dy/dx and second derivative d2y/dx2.
    """
    # TODO: y(x) = a2 * x^2 + a3 * x^3 with y(0) = 0, y'(0) = 0, y(x_lane) = y_lane, y'(x_lane) = 0
    raise NotImplementedError("TODO: implement cubic_lane_change")


def lane_change_command(x: float, x_lane: float, y_lane: float, speed: float) -> Tuple[float, float]:
    """Compute the motion of a differential drive vehicle that follows the lane change curve.

    Args:
        x (float): Current longitudinal position within the lane change in meters.
        x_lane (float): Longitudinal length of the lane change in meters.
        y_lane (float): Lateral offset in meters.
        speed (float): Path speed v of the vehicle in m/s.

    Returns:
        Tuple[float, float]: Longitudinal progress dx/dt in m/s and turn rate omega in rad/s.
    """
    # TODO: The heading along the curve is theta = atan(y'). From this follow
    # dx/dt = v * cos(theta) and omega = v * curvature = v * y'' / (1 + y'^2)^(3/2).
    raise NotImplementedError("TODO: implement lane_change_command")
