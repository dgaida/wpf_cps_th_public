"""Step 2: Prediction of duration and distances of the overtaking manoeuvre.

TODO: Implement predict_overtake. The tests in tests/test_prediction.py check your implementation.
"""

from dataclasses import dataclass


@dataclass
class OvertakePrediction:
    """Predicted course of the overtaking manoeuvre.

    Attributes:
        delta_s_rel (float): Distance the LIMO has to gain relative to the TurtleBot in meters.
        duration (float): Duration T_overtake of the manoeuvre in seconds (including t_sync).
        s_tb (float): Distance driven by the TurtleBot during the manoeuvre in meters.
        s_limo (float): Distance driven by the LIMO during the manoeuvre in meters.
    """

    delta_s_rel: float
    duration: float
    s_tb: float
    s_limo: float


def predict_overtake(
    v_tb: float,
    v_overtake: float,
    d_start: float = 0.3,
    d_target: float = 0.3,
    l_limo: float = 0.32,
    l_tb: float = 0.34,
    t_sync: float = 0.0,
) -> OvertakePrediction:
    """Predict the overtaking manoeuvre (docs/theorie.md, sections 3 and 4).

    Args:
        v_tb (float): Estimated speed of the TurtleBot in m/s.
        v_overtake (float): Overtaking speed of the LIMO in m/s.
        d_start (float): Distance at which the manoeuvre starts in meters. Defaults to 0.3.
        d_target (float): Distance in front of the TurtleBot after merging in meters. Defaults to 0.3.
        l_limo (float): Length of the LIMO in meters. Defaults to 0.32.
        l_tb (float): Length of the TurtleBot in meters. Defaults to 0.34.
        t_sync (float): Time span driven with v_tb next to the TurtleBot (optional task) in seconds.
            Defaults to 0.0.

    Returns:
        OvertakePrediction: Predicted relative distance, duration and driven distances.

    Raises:
        ValueError: If v_overtake is not larger than v_tb.
    """
    # TODO
    raise NotImplementedError("TODO: implement predict_overtake")
