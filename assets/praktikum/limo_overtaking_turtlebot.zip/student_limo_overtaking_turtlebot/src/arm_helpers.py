"""Provided helpers for the myCobot 280 on the LIMO (optional task: cube drop).

This module is complete. The arm is controlled directly via ``pymycobot`` over the serial port;
no other program (e.g. ``mycobot_ros2``) may use the port at the same time.
"""

import time
from typing import Any, List, Optional, Sequence


class CobotArm:
    """Thin wrapper around pymycobot for gripper and joint motions."""

    def __init__(self, port: str = "/dev/ttyACM0", baudrate: int = 115200, speed: int = 30) -> None:
        """Connect to the arm.

        Args:
            port (str): Serial port of the myCobot. Defaults to "/dev/ttyACM0".
            baudrate (int): Baud rate. Defaults to 115200.
            speed (int): Arm speed 0-100. Defaults to 30.
        """
        from pymycobot.mycobot import MyCobot

        self.speed = speed
        self.mc: Any = MyCobot(port, baudrate)
        time.sleep(0.5)

    def open_gripper(self, wait_s: float = 1.5) -> None:
        """Open the gripper.

        Args:
            wait_s (float): Waiting time until the gripper is open. Defaults to 1.5.
        """
        self.mc.set_gripper_state(0, 70)
        time.sleep(wait_s)

    def close_gripper(self, wait_s: float = 1.5) -> None:
        """Close the gripper.

        Args:
            wait_s (float): Waiting time until the gripper is closed. Defaults to 1.5.
        """
        self.mc.set_gripper_state(1, 70)
        time.sleep(wait_s)

    def move_to_angles(self, angles: Sequence[float], wait_s: float = 3.0) -> None:
        """Move all six joints to target angles.

        Args:
            angles (Sequence[float]): Six joint angles in degrees.
            wait_s (float): Waiting time for the motion. Defaults to 3.0.
        """
        self.mc.send_angles([float(a) for a in angles], self.speed)
        time.sleep(wait_s)

    def move_to_transport_pose(self) -> None:
        """Move to the compact upright pose [0, 0, 0, 0, 0, 0] used while driving."""
        self.move_to_angles([0.0] * 6)

    def read_angles(self) -> Optional[List[float]]:
        """Read the current joint angles, e.g. to teach in a drop pose by hand.

        Returns:
            Optional[List[float]]: Six joint angles in degrees, or None if reading failed.
        """
        angles = self.mc.get_angles()
        return list(angles) if angles and len(angles) == 6 else None

    def release_servos(self) -> None:
        """Switch the servos off so that the arm can be moved by hand. Hold the arm, it drops otherwise."""
        self.mc.release_all_servos()

    def power_on(self) -> None:
        """Switch the servos on again."""
        self.mc.power_on()
