"""Provided interface to the LIMO chassis: LiDAR, odometry and velocity commands (ROS 2).

This module is complete. You do not have to change it, but you should read and understand it.
``LimoRobot`` (real robot) and ``SimulatedLimo`` (src/simulation.py) offer the same methods,
so your mission code runs unchanged in the simulation and on the robot.
"""

import math
import threading
import time
from dataclasses import dataclass
from typing import Any, List, Optional

try:
    import rclpy
    from geometry_msgs.msg import Twist
    from nav_msgs.msg import Odometry
    from rclpy.executors import SingleThreadedExecutor
    from rclpy.node import Node
    from rclpy.qos import qos_profile_sensor_data
    from sensor_msgs.msg import LaserScan

    ROS2_AVAILABLE = True
except ImportError:  # laptop without ROS 2: only the simulation is available
    ROS2_AVAILABLE = False


@dataclass
class Scan:
    """One 2D LiDAR scan.

    Attributes:
        ranges (List[float]): Measured distances in meters; inf or nan if nothing was hit.
        angle_min (float): Angle of the first beam in rad. 0 is straight ahead, positive is left.
        angle_increment (float): Angle between two neighbouring beams in rad.
        stamp (float): Time of the scan in seconds (same clock as ``now()`` of the robot object).
    """

    ranges: List[float]
    angle_min: float
    angle_increment: float
    stamp: float

    def angle(self, index: int) -> float:
        """Get the angle of a beam.

        Args:
            index (int): Index into ``ranges``.

        Returns:
            float: Beam angle in rad.
        """
        return self.angle_min + index * self.angle_increment


class LimoRobot:
    """LIMO chassis on the real robot (ROS 2 Foxy, ``limo_start.launch.py`` must be running)."""

    def __init__(
        self,
        scan_topic: str = "/scan",
        odom_topic: str = "/odom",
        cmd_topic: str = "/cmd_vel",
        max_linear: float = 0.5,
        max_angular: float = 1.5,
    ) -> None:
        """Start the ROS 2 node and its background threads.

        Args:
            scan_topic (str): LaserScan topic. Defaults to "/scan".
            odom_topic (str): Odometry topic. Defaults to "/odom".
            cmd_topic (str): Twist topic of the chassis. Defaults to "/cmd_vel".
            max_linear (float): Limit of the forward speed in m/s. Defaults to 0.5.
            max_angular (float): Limit of the turn rate in rad/s. Defaults to 1.5.

        Raises:
            RuntimeError: If ROS 2 (rclpy) is not available.
        """
        if not ROS2_AVAILABLE:
            raise RuntimeError("rclpy not found. Source ROS 2 Foxy or use the simulation (--sim).")
        self.max_linear = max_linear
        self.max_angular = max_angular
        self._lock = threading.Lock()
        self._scan: Optional[Scan] = None
        self._speed: float = 0.0
        self._travel: float = 0.0
        self._odom_time: Optional[float] = None
        self._command = (0.0, 0.0)

        rclpy.init()
        self._node: Any = Node("limo_overtaking_student")
        # LiDAR drivers publish with sensor-data QoS (best effort); the subscriber must match.
        self._node.create_subscription(LaserScan, scan_topic, self._scan_callback, qos_profile_sensor_data)
        self._node.create_subscription(Odometry, odom_topic, self._odom_callback, 10)
        self._publisher = self._node.create_publisher(Twist, cmd_topic, 10)
        self._executor = SingleThreadedExecutor()
        self._executor.add_node(self._node)
        self._running = True
        threading.Thread(target=self._executor.spin, daemon=True).start()
        # The chassis stops if it receives no command for a while: repeat the last one at 10 Hz.
        threading.Thread(target=self._keepalive_loop, daemon=True).start()

    def _scan_callback(self, msg: Any) -> None:
        scan = Scan(list(msg.ranges), msg.angle_min, msg.angle_increment, time.time())
        with self._lock:
            self._scan = scan

    def _odom_callback(self, msg: Any) -> None:
        now = time.time()
        with self._lock:
            if self._odom_time is not None:
                self._travel += abs(self._speed) * (now - self._odom_time)
            self._speed = float(msg.twist.twist.linear.x)
            self._odom_time = now

    def _publish(self, linear: float, angular: float) -> None:
        msg = Twist()
        msg.linear.x = float(linear)
        msg.angular.z = float(angular)
        self._publisher.publish(msg)

    def _keepalive_loop(self) -> None:
        while self._running:
            with self._lock:
                linear, angular = self._command
            self._publish(linear, angular)
            time.sleep(0.1)

    def now(self) -> float:
        """Get the current time.

        Returns:
            float: Time in seconds.
        """
        return time.time()

    def sleep(self, seconds: float) -> None:
        """Wait while the robot keeps driving with the last velocity command.

        Args:
            seconds (float): Waiting time in seconds.
        """
        time.sleep(seconds)

    def get_scan(self) -> Optional[Scan]:
        """Get the most recent LiDAR scan.

        Returns:
            Optional[Scan]: Latest scan, or None if no scan was received yet.
        """
        with self._lock:
            return self._scan

    def get_speed(self) -> float:
        """Get the forward speed of the LIMO from the wheel odometry.

        Returns:
            float: Speed in m/s.
        """
        with self._lock:
            return self._speed

    def get_travel(self) -> float:
        """Get the distance driven since the start, integrated from the odometry speed.

        Returns:
            float: Distance in meters.
        """
        with self._lock:
            return self._travel

    def send_velocity(self, linear: float, angular: float = 0.0) -> None:
        """Command the chassis. The command stays active until the next one.

        Args:
            linear (float): Forward speed in m/s.
            angular (float): Turn rate in rad/s, positive turns left. Defaults to 0.0.
        """
        linear = max(-self.max_linear, min(self.max_linear, float(linear)))
        angular = max(-self.max_angular, min(self.max_angular, float(angular)))
        with self._lock:
            self._command = (linear, angular)
        self._publish(linear, angular)

    def stop(self) -> None:
        """Stop the chassis."""
        self.send_velocity(0.0, 0.0)

    def close(self) -> None:
        """Stop the chassis and shut down ROS 2. Call this at the end of the program."""
        self.stop()
        self._running = False
        time.sleep(0.2)
        self._publish(0.0, 0.0)
        self._executor.shutdown()
        rclpy.shutdown()


def wrap_angle(angle: float) -> float:
    """Normalise an angle to [-pi, pi).

    Args:
        angle (float): Angle in rad.

    Returns:
        float: Normalised angle in rad.
    """
    return (angle + math.pi) % (2.0 * math.pi) - math.pi
