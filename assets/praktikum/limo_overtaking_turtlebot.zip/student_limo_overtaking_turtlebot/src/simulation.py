"""Provided simulation of LIMO, TurtleBot and LiDAR for developing without the robots.

This module is complete. ``SimulatedLimo`` offers the same methods as ``LimoRobot``
(src/limo_interface.py) plus the ground truth for evaluating your solution.

The simulation only advances inside ``sleep()``. Without real-time pacing a whole manoeuvre is
simulated in a fraction of a second, which keeps development and tests fast.
"""

import math
import random
import time
from dataclasses import dataclass
from typing import List, Optional, Tuple

from src.limo_interface import Scan


@dataclass
class SimulationConfig:
    """Parameters of the simulated scenario.

    Attributes:
        v_tb (float): True speed of the TurtleBot in m/s.
        initial_gap (float): Distance LIMO front -> TurtleBot rear at the start in meters.
        l_limo (float): Length of the LIMO in meters.
        w_limo (float): Width of the LIMO in meters.
        tb_radius (float): Radius of the round TurtleBot base in meters.
        lidar_offset (float): Position of the LiDAR in front of the LIMO centre in meters.
        noise_std (float): Standard deviation of the LiDAR range noise in meters.
        fov_deg (float): Field of view of the LiDAR in degrees.
        beams (int): Number of beams per scan.
        wall_y (float): The corridor walls are at y = +-wall_y in meters.
        scan_rate_hz (float): Scan rate of the LiDAR.
        initial_heading_deg (float): Heading error of the LIMO at the start in degrees.
        turn_rate_scale (float): Actual turn rate = scale * commanded turn rate.
        seed (int): Seed of the noise generator.
    """

    v_tb: float = 0.15
    initial_gap: float = 1.0
    l_limo: float = 0.32
    w_limo: float = 0.22
    tb_radius: float = 0.17
    lidar_offset: float = 0.16
    noise_std: float = 0.008
    fov_deg: float = 220.0
    beams: int = 221
    wall_y: float = 1.2
    scan_rate_hz: float = 10.0
    initial_heading_deg: float = 0.0
    turn_rate_scale: float = 1.0
    seed: int = 1


class SimulatedLimo:
    """Simulated LIMO behind a TurtleBot driving with constant speed along the x axis."""

    def __init__(self, config: Optional[SimulationConfig] = None, realtime: bool = False) -> None:
        """Create the scenario.

        Args:
            config (Optional[SimulationConfig]): Scenario parameters. Defaults to SimulationConfig().
            realtime (bool): Let ``sleep()`` really wait, so that the run can be watched. Defaults to False.
        """
        self.cfg = config or SimulationConfig()
        self.realtime = realtime
        self._rng = random.Random(self.cfg.seed)
        self._command: Tuple[float, float] = (0.0, 0.0)
        self._scan: Optional[Scan] = None
        self._next_scan_time = 0.0

        # World frame: the TurtleBot centre drives along y = 0.
        self.t = 0.0
        self.x = 0.0
        self.y = 0.0
        self.theta = math.radians(self.cfg.initial_heading_deg)
        self.x_tb = self.cfg.l_limo / 2.0 + self.cfg.initial_gap + self.cfg.tb_radius
        self.s_limo = 0.0
        self.s_tb = 0.0
        self.min_clearance = float("inf")
        self.history: List[Tuple[float, float, float, float]] = []  # (t, x_limo, y_limo, x_tb)
        self._update_scan()

    # ------------------------------------------------------------------ same interface as LimoRobot
    def now(self) -> float:
        """Get the current simulation time.

        Returns:
            float: Time in seconds.
        """
        return self.t

    def sleep(self, seconds: float) -> None:
        """Advance the simulation while the LIMO keeps driving with the last velocity command.

        Args:
            seconds (float): Simulated time span in seconds.
        """
        remaining = seconds
        while remaining > 1e-9:
            dt = min(0.01, remaining)
            self._step(dt)
            remaining -= dt
        if self.realtime:
            time.sleep(seconds)

    def get_scan(self) -> Optional[Scan]:
        """Get the most recent LiDAR scan (updated with the scan rate of the LiDAR).

        Returns:
            Optional[Scan]: Latest scan.
        """
        return self._scan

    def get_speed(self) -> float:
        """Get the forward speed of the LIMO.

        Returns:
            float: Speed in m/s.
        """
        return self._command[0]

    def get_travel(self) -> float:
        """Get the distance driven since the start.

        Returns:
            float: Distance in meters.
        """
        return self.s_limo

    def send_velocity(self, linear: float, angular: float = 0.0) -> None:
        """Command the chassis. The command stays active until the next one.

        Args:
            linear (float): Forward speed in m/s.
            angular (float): Turn rate in rad/s, positive turns left. Defaults to 0.0.
        """
        self._command = (max(-0.5, min(0.5, float(linear))), max(-1.5, min(1.5, float(angular))))

    def stop(self) -> None:
        """Stop the chassis."""
        self.send_velocity(0.0, 0.0)

    def close(self) -> None:
        """Stop the chassis."""
        self.stop()

    # ------------------------------------------------------------------ simulation
    def _step(self, dt: float) -> None:
        v, w = self._command
        self.x += v * math.cos(self.theta) * dt
        self.y += v * math.sin(self.theta) * dt
        self.theta += self.cfg.turn_rate_scale * w * dt
        self.x_tb += self.cfg.v_tb * dt
        self.s_limo += abs(v) * dt
        self.s_tb += self.cfg.v_tb * dt
        self.t += dt
        self.min_clearance = min(self.min_clearance, self._clearance())
        if self.t >= self._next_scan_time:
            self._update_scan()

    def _update_scan(self) -> None:
        cfg = self.cfg
        lx = self.x + cfg.lidar_offset * math.cos(self.theta)
        ly = self.y + cfg.lidar_offset * math.sin(self.theta)
        angle_min = -math.radians(cfg.fov_deg / 2.0)
        increment = math.radians(cfg.fov_deg) / (cfg.beams - 1)
        ranges: List[float] = []
        for i in range(cfg.beams):
            a = self.theta + angle_min + i * increment
            dx, dy = math.cos(a), math.sin(a)
            r = float("inf")
            # TurtleBot (circle)
            ox, oy = lx - self.x_tb, ly
            b = 2.0 * (ox * dx + oy * dy)
            disc = b * b - 4.0 * (ox * ox + oy * oy - cfg.tb_radius ** 2)
            if disc >= 0.0:
                hit = (-b - math.sqrt(disc)) / 2.0
                if hit > 0.0:
                    r = hit
            # Corridor walls
            for wall in (cfg.wall_y, -cfg.wall_y):
                if abs(dy) > 1e-6:
                    hit = (wall - ly) / dy
                    if 0.0 < hit < r:
                        r = hit
            if math.isfinite(r):
                r += self._rng.gauss(0.0, cfg.noise_std)
            ranges.append(r)
        self._scan = Scan(ranges, angle_min, increment, self.t)
        self._next_scan_time = self.t + 1.0 / cfg.scan_rate_hz
        self.history.append((self.t, self.x, self.y, self.x_tb))

    def _clearance(self) -> float:
        """Smallest distance between the LIMO outline and the TurtleBot circle in meters."""
        cfg = self.cfg
        best = float("inf")
        for k in range(9):
            sx = -cfg.l_limo / 2.0 + k * cfg.l_limo / 8.0
            for sy in (-cfg.w_limo / 2.0, cfg.w_limo / 2.0):
                px = self.x + sx * math.cos(self.theta) - sy * math.sin(self.theta)
                py = self.y + sx * math.sin(self.theta) + sy * math.cos(self.theta)
                best = min(best, math.hypot(px - self.x_tb, py) - cfg.tb_radius)
        return best

    # ------------------------------------------------------------------ ground truth for the evaluation
    def gap_behind(self) -> float:
        """True distance LIMO front -> TurtleBot rear (positive while the LIMO is behind).

        Returns:
            float: Distance in meters.
        """
        return (self.x_tb - self.cfg.tb_radius) - (self.x + self.cfg.l_limo / 2.0)

    def gap_ahead(self) -> float:
        """True distance TurtleBot front -> LIMO rear (positive once the LIMO is ahead).

        Returns:
            float: Distance in meters.
        """
        return (self.x - self.cfg.l_limo / 2.0) - (self.x_tb + self.cfg.tb_radius)

    def collided(self) -> bool:
        """Check whether the LIMO touched the TurtleBot at any time.

        Returns:
            bool: True if a collision happened.
        """
        return self.min_clearance <= 0.0

    def summary(self) -> str:
        """Describe the current state of the scenario.

        Returns:
            str: One line with poses, gaps and the smallest clearance so far.
        """
        return (
            f"[Sim] t = {self.t:.1f} s | LIMO x = {self.x:.2f} m, y = {self.y:+.2f} m, "
            f"Kurs = {math.degrees(self.theta):+.1f}° | TurtleBot x = {self.x_tb:.2f} m | "
            f"Abstand vor dem TurtleBot = {self.gap_ahead():+.2f} m | "
            f"kleinster Abstand = {self.min_clearance:+.2f} m{' (KOLLISION)' if self.collided() else ''} | "
            f"s_limo = {self.s_limo:.2f} m, s_tb = {self.s_tb:.2f} m"
        )
