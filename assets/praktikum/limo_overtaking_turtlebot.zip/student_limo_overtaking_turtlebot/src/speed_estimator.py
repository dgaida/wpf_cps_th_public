"""Step 1: Distance measurement and estimation of the TurtleBot speed.

TODO: Implement the parts marked with TODO. The tests in tests/test_speed_estimator.py check
your implementation.
"""

from typing import Optional

from src.limo_interface import Scan


def front_distance(scan: Scan, sector_deg: float = 10.0, max_range: float = 3.5) -> Optional[float]:
    """Measure the distance to the vehicle ahead in the front sector of the LiDAR.

    Args:
        scan (Scan): LiDAR scan (0 rad is straight ahead).
        sector_deg (float): Half opening angle of the front sector in degrees. Defaults to 10.0.
        max_range (float): Larger distances do not belong to the TurtleBot. Defaults to 3.5.

    Returns:
        Optional[float]: Distance d in meters, or None if nothing is in the sector.
    """
    # TODO: Use only the beams with |angle| <= sector_deg, ignore invalid values (inf, nan, <= 0)
    # and values above max_range. Which statistic of the remaining values is robust?
    raise NotImplementedError("TODO: implement front_distance")


class SpeedEstimator:
    """Estimates the speed of the TurtleBot from distance changes and the own speed."""

    def __init__(self, alpha: float = 0.2) -> None:
        """Initialize the estimator.

        Args:
            alpha (float): Factor of the exponential low-pass filter (0 < alpha <= 1). Defaults to 0.2.
        """
        self.alpha = alpha
        self.v_tb: Optional[float] = None
        # TODO: Add the attributes you need to remember the previous measurement.

    def update(self, distance: float, v_limo: float, stamp: float) -> Optional[float]:
        """Process a new distance measurement.

        Args:
            distance (float): Measured distance d_k in meters.
            v_limo (float): Current speed of the LIMO in m/s.
            stamp (float): Time of the measurement in seconds.

        Returns:
            Optional[float]: Filtered estimate of the TurtleBot speed in m/s, or None as long as
                only one measurement is available.
        """
        # TODO: Raw estimate v_tb_raw = v_limo + (d_k - d_{k-1}) / dt, then the low-pass filter
        # v_tb = (1 - alpha) * v_tb + alpha * v_tb_raw. Store the result in self.v_tb.
        # Ignore calls with the same time stamp as the previous one (dt = 0).
        raise NotImplementedError("TODO: implement SpeedEstimator.update")
