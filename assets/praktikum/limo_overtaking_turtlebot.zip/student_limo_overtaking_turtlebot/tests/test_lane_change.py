"""Self-check tests for step 3 (src/lane_change.py)."""

import math

from src.lane_change import cubic_lane_change, lane_change_command


def test_cubic_boundary_conditions() -> None:
    """The polynomial starts and ends without lateral offset error and without slope."""
    y0, dy0, _ = cubic_lane_change(0.0, 1.0, 0.4)
    y1, dy1, _ = cubic_lane_change(1.0, 1.0, 0.4)
    assert math.isclose(y0, 0.0, abs_tol=1e-9) and math.isclose(dy0, 0.0, abs_tol=1e-9)
    assert math.isclose(y1, 0.4, abs_tol=1e-9) and math.isclose(dy1, 0.0, abs_tol=1e-9)


def test_cubic_midpoint_and_direction() -> None:
    """Half of the offset is reached in the middle; a negative offset changes to the right."""
    y, dy, d2y = cubic_lane_change(0.5, 1.0, 0.4)
    assert math.isclose(y, 0.2, abs_tol=1e-9)
    assert math.isclose(dy, 0.6, abs_tol=1e-9)
    assert math.isclose(d2y, 0.0, abs_tol=1e-9)
    assert math.isclose(cubic_lane_change(0.5, 1.0, -0.4)[0], -0.2, abs_tol=1e-9)


def test_cubic_is_clipped_outside_the_lane_change() -> None:
    """Before and after the lane change the vehicle drives straight."""
    assert cubic_lane_change(-0.5, 1.0, 0.4)[:2] == cubic_lane_change(0.0, 1.0, 0.4)[:2]
    y, dy, _ = cubic_lane_change(2.0, 1.0, 0.4)
    assert math.isclose(y, 0.4, abs_tol=1e-9) and math.isclose(dy, 0.0, abs_tol=1e-9)


def test_lane_change_command_midpoint() -> None:
    """In the middle the heading is steepest and the turn rate changes its sign."""
    x_dot, omega = lane_change_command(0.5, 1.0, 0.4, speed=0.3)
    assert math.isclose(x_dot, 0.3 * math.cos(math.atan(0.6)), abs_tol=1e-9)
    assert math.isclose(omega, 0.0, abs_tol=1e-9)
    assert lane_change_command(0.25, 1.0, 0.4, 0.3)[1] > 0.0  # turning left first
    assert lane_change_command(0.75, 1.0, 0.4, 0.3)[1] < 0.0  # then back to the right


def test_lane_change_command_reaches_the_lane() -> None:
    """Integrating the commands of a differential drive vehicle ends on the overtaking lane."""
    x_lane, y_lane, speed, dt = 1.0, 0.4, 0.3, 0.001
    x_ref, x, y, theta = 0.0, 0.0, 0.0, 0.0
    while x_ref < x_lane:
        x_dot, omega = lane_change_command(x_ref, x_lane, y_lane, speed)
        x_ref += x_dot * dt
        x += speed * math.cos(theta) * dt
        y += speed * math.sin(theta) * dt
        theta += omega * dt
    assert math.isclose(y, y_lane, abs_tol=0.01)
    assert math.isclose(theta, 0.0, abs_tol=0.02)
