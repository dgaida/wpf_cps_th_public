"""Tests of the provided simulation - they pass without any changes and show how to use it."""

import math

from src.simulation import SimulatedLimo, SimulationConfig


def test_scan_shows_turtlebot_ahead() -> None:
    """The beam straight ahead hits the TurtleBot at the initial gap."""
    sim = SimulatedLimo(SimulationConfig(initial_gap=1.0, noise_std=0.0))
    scan = sim.get_scan()
    center = min(range(len(scan.ranges)), key=lambda i: abs(scan.angle(i)))
    assert math.isclose(scan.ranges[center], 1.0, abs_tol=0.01)
    assert math.isclose(sim.gap_behind(), 1.0, abs_tol=1e-6)


def test_sleep_advances_the_scenario() -> None:
    """While sleeping, the LIMO drives with the commanded speed and the TurtleBot with v_tb."""
    sim = SimulatedLimo(SimulationConfig(v_tb=0.15, initial_gap=1.0))
    sim.send_velocity(0.30)
    sim.sleep(2.0)
    assert math.isclose(sim.now(), 2.0, abs_tol=1e-6)
    assert math.isclose(sim.get_travel(), 0.60, abs_tol=0.01)
    assert math.isclose(sim.gap_behind(), 1.0 - (0.30 - 0.15) * 2.0, abs_tol=0.01)
    assert not sim.collided()


def test_collision_is_detected() -> None:
    """Driving straight into the TurtleBot counts as collision."""
    sim = SimulatedLimo(SimulationConfig(v_tb=0.0, initial_gap=0.2))
    sim.send_velocity(0.3)
    sim.sleep(2.0)
    assert sim.collided()
