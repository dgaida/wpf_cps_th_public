"""Run the self-check tests from the task folder: python3 -m pytest tests -v"""

import os
import sys

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
