"""Self-check tests for step 2 (src/prediction.py)."""

import math

import pytest

from src.prediction import predict_overtake


def test_prediction_standard_case() -> None:
    """Relative distance, duration and driven distances without synchronous phase."""
    p = predict_overtake(v_tb=0.15, v_overtake=0.35, d_start=0.3, d_target=0.3, l_limo=0.32, l_tb=0.34)
    assert math.isclose(p.delta_s_rel, 1.26, abs_tol=1e-9)
    assert math.isclose(p.duration, 6.3, abs_tol=1e-9)
    assert math.isclose(p.s_tb, 0.945, abs_tol=1e-9)
    assert math.isclose(p.s_limo, 2.205, abs_tol=1e-9)
    assert math.isclose(p.s_limo - p.s_tb, p.delta_s_rel, abs_tol=1e-9)


def test_prediction_with_synchronous_phase() -> None:
    """Driving next to the TurtleBot for t_sync extends the manoeuvre, the relative distance stays."""
    p = predict_overtake(v_tb=0.15, v_overtake=0.35, t_sync=4.0)
    assert math.isclose(p.duration, 10.3, abs_tol=1e-9)
    assert math.isclose(p.s_tb, 0.15 * 10.3, abs_tol=1e-9)
    assert math.isclose(p.s_limo - p.s_tb, 1.26, abs_tol=1e-9)


def test_prediction_requires_faster_limo() -> None:
    """Without speed advantage, overtaking is impossible."""
    with pytest.raises(ValueError):
        predict_overtake(v_tb=0.2, v_overtake=0.2)
