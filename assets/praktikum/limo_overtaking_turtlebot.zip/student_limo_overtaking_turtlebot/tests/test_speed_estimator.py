"""Self-check tests for step 1 (src/speed_estimator.py)."""

import math

from src.limo_interface import Scan
from src.simulation import SimulatedLimo, SimulationConfig
from src.speed_estimator import SpeedEstimator, front_distance


def make_scan(ranges) -> Scan:
    """Scan with one beam per 5 degrees from -20 to +20 degrees."""
    return Scan(list(ranges), math.radians(-20.0), math.radians(5.0), 0.0)


def test_front_distance_uses_only_the_front_sector() -> None:
    """Objects outside +-10 degrees (e.g. walls) are ignored."""
    scan = make_scan([0.4, 0.4, 1.00, 1.01, 0.99, 1.00, 1.00, 0.4, 0.4])  # beams at -20, -15, ..., +20 degrees
    distance = front_distance(scan, sector_deg=10.0)
    assert distance is not None and math.isclose(distance, 1.0, abs_tol=0.02)


def test_front_distance_ignores_invalid_values() -> None:
    """inf, nan and zero are no measurements; values above max_range are not the TurtleBot."""
    nan, inf = float("nan"), float("inf")
    assert front_distance(make_scan([inf, inf, inf, nan, 0.0, 5.0, inf, inf, inf]), max_range=3.5) is None
    distance = front_distance(make_scan([inf, inf, inf, nan, 0.8, inf, 0.8, inf, inf]))
    assert distance is not None and math.isclose(distance, 0.8, abs_tol=1e-6)


def test_speed_estimator_needs_two_measurements() -> None:
    """The first measurement yields no estimate."""
    assert SpeedEstimator().update(1.0, 0.3, 0.0) is None


def test_speed_estimator_formula() -> None:
    """v_tb = v_limo + delta d / delta t; alpha = 1 switches the filter off."""
    estimator = SpeedEstimator(alpha=1.0)
    estimator.update(1.00, 0.30, 0.0)
    v_tb = estimator.update(0.985, 0.30, 0.1)  # gap shrinks by 0.15 m/s
    assert v_tb is not None and math.isclose(v_tb, 0.15, abs_tol=1e-6)
    assert estimator.v_tb == v_tb


def test_speed_estimator_low_pass() -> None:
    """With alpha < 1 the estimate follows a change only gradually."""
    estimator = SpeedEstimator(alpha=0.2)
    estimator.update(1.00, 0.30, 0.0)
    first = estimator.update(0.985, 0.30, 0.1)  # raw 0.15
    second = estimator.update(0.985, 0.30, 0.2)  # raw 0.30
    assert math.isclose(first, 0.15, abs_tol=1e-6)
    assert math.isclose(second, 0.8 * 0.15 + 0.2 * 0.30, abs_tol=1e-6)


def test_speed_estimator_in_simulation() -> None:
    """With noisy LiDAR data the estimate converges to the true TurtleBot speed."""
    sim = SimulatedLimo(SimulationConfig(v_tb=0.15, initial_gap=1.5))
    estimator = SpeedEstimator(alpha=0.2)
    sim.send_velocity(0.30)
    last_stamp = None
    while sim.gap_behind() > 0.4:
        sim.sleep(0.05)
        scan = sim.get_scan()
        if scan.stamp != last_stamp:
            last_stamp = scan.stamp
            estimator.update(front_distance(scan), sim.get_speed(), scan.stamp)
    assert estimator.v_tb is not None and abs(estimator.v_tb - 0.15) < 0.05
