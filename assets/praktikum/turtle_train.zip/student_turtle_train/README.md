# Praktikum: Turtle Train – Multi-Roboter Formationsfahrt mit TF2

Dieses Praktikum behandelt die Realisierung einer Roboter-Zugformation (**Turtle Train**) in **ROS 2 Humble**. Mehrere Schildkröten in *Turtlesim* (oder reale Roboter wie der TurtleBot 4) fahren hintereinander in einer Kolonne und halten dynamisch einen wählbaren Abstand zueinander ein.

---

## 📺 Inspiration & Referenzen

Dieses Praktikum basiert auf der bekannten ROS-Videoreihe von Shawn Hymel (DigiKey) und erweitert das dort gezeigte Beispiel um eine vollständige Zug-Steuerung für beliebige $N$ Roboter sowie den Transfer auf reale Hardware.

- 🎥 **ROS 2 Videoreihe (Playlist):** [DigiKey Introduction to ROS Video Series](https://www.youtube.com/playlist?list=PLEBQazB0HUySWueUF2zNyrA8LSX3rDvE7)  
- 🎥 **Challenge-Video (Turtle Train):** [Intro to ROS Part 11: TF2 Broadcasters and Listeners (Timestamp 20:16)](https://youtu.be/4bW7UxwGjl8?list=PLEBQazB0HUySWueUF2zNyrA8LSX3rDvE7&t=1216) – Vorstellung der Challenge zur Entwicklung eines Turtlesim-Zugs.  
- 📖 **Written Guide:** [DigiKey Tutorial: Intro to ROS Part 11 – TF2 Broadcasters and Listeners](https://www.digikey.com/en/maker/tutorials/2025/intro-to-ros-part-11-tf2-broadcasters-and-listeners)  
- 🐳 **TurtleBot 4 Docker Umgebung:** [GitHub Repository kscottz/turtlebot4_docker](https://github.com/kscottz/turtlebot4_docker) – 3D TurtleBot 4 Docker-Simulationsumgebung (K. Scottz / A. Zaid).  

---

## 📁 Ordnerstruktur

```text
turtle_train/
├── README.md                           # Diese Übersicht und Dokumentation
├── docs/
│   ├── zug_steuerung.md                # Funktionsweise der Turtlesim-Zugsteuerung
│   ├── docker_container.md             # Docker-Container unter Windows und Linux starten
│   └── reale_hardware.md               # Anleitung für die zwei TurtleBot 4 im Labor (robot_1, robot_2)
├── tests/                              # Selbsttests ohne ROS 2 (python3 -m pytest tests -v)
├── docker_container/
│   ├── Dockerfile                      # ROS 2 Humble + GUI/VNC Dockerfile
│   ├── docker-compose.yml              # Docker Compose Setup
│   ├── supervisord.conf                # Prozesssteuerung für VNC und ROS
│   ├── Dockerfile.tb4                  # ROS 2 Jazzy + TurtleBot 4 Gazebo + GUI/VNC Dockerfile
│   ├── docker-compose.tb4.yml          # Docker Compose Setup für die TurtleBot 4 3D-Simulation
│   ├── docker-compose.tb4.gpu.*.yml    # GPU-Einstellungen, automatisch je Betriebssystem bzw. GPU gewählt
│   ├── start_tb4.sh                    # Linux: startet die TurtleBot 4 Simulation mit erkannter GPU
│   ├── patch_tb4_sim.py                # Anpassung der Simulation für mehrere Roboter in einer Welt
│   ├── supervisord.tb4.conf            # Prozesssteuerung für VNC (TurtleBot 4 Container)
│   └── entrypoint.sh                   # Environment Startup Script
└── src/
    ├── __init__.py                     # Python Paket-Initialisierung
    ├── turtle_tf2_broadcaster.py       # TF2 Broadcaster Node (Pose -> Transform)
    ├── turtle_train_sim.py             # Aufgabe 1: Multi-Turtle Zug in Turtlesim
    ├── real_robot_train.py             # Aufgabe 2: Zug-Steuerung für reale Roboter (TurtleBot 4)
    └── tb4_multi_robot.launch.py       # Launchfile: Leader (robot_1) und Follower (robot_2) in Gazebo
```

---

## 💡 Theorie & TF2 Konzept

Das **TF2 Transformation System** in ROS 2 verwaltet räumliche Beziehungen zwischen verschiedenen Koordinatensystemen (Frames) über der Zeit in einer Baumstruktur (TF Tree).

### 1. TF Broadcaster

Der Broadcaster liest die aktuelle Position und Orientierung $(x, y, \theta)$ des Roboters aus (z. B. aus der Odometrie oder `/turtleX/pose`) und sendet fortlaufend ein `geometry_msgs/msg/TransformStamped` an das`/tf`-Topic.

$$
T_{\text{world} \to \text{turtle}_i} = \begin{bmatrix} \cos\theta_i & -\sin\theta_i & x_i \\ \sin\theta_i & \cos\theta_i & y_i \\ 0 & 0 & 1 \end{bmatrix}
$$

### 2. TF Listener & Transformation Lookup

Der Follower-Roboter $i$ fragt über den `tf2_ros.Buffer` die mathematische Transformation zum vorausfahrenden Roboter $i-1$ ab:

$$
T_{\text{turtle}_i \to \text{turtle}_{i-1}} = \left( T_{\text{world} \to \text{turtle}_i} \right)^{-1} \cdot T_{\text{world} \to \text{turtle}_{i-1}}
$$

Daraus ergeben sich die Relativkoordinaten $(\Delta x, \Delta y)$ des Vorgängers im lokalen Koordinatensystem des Followers.

### 3. P-Regler für den Folgeabstand

Der Fehler im Folgeabstand $e_d$ und der Orientierungsfehler $e_\alpha$ berechnen sich wie folgt:

$$
e_d = \sqrt{\Delta x^2 + \Delta y^2} - d_{\text{soll}}
$$

$$
e_\alpha = \text{atan2}(\Delta y, \Delta x)
$$

Die Regelungsbefehle für die Lineargeschwindigkeit $v$ und die Winkelgeschwindigkeit $w$ lauten:

$$
v = k_v \cdot e_d, \quad w = k_w \cdot e_\alpha
$$

Dabei wird $v$ durch Sättigungsgrenzen $[0, v_{\text{max}}]$ und einen Totbereich um $e_d \approx 0$ geglättet.

---

## 📋 Aufgabenstellung

Die Stellen, an denen Sie Code ergänzen, sind im Quellcode mit `TODO` markiert und lösen bis zur Umsetzung einen `NotImplementedError` aus. Der TF2 Broadcaster `src/turtle_tf2_broadcaster.py`, die Docker-Umgebung und die Launchdatei sind vorgegeben.

### Aufgabe 1: Turtle Train in Turtlesim (`src/turtle_train_sim.py`)

- **1a) P-Regler:** Implementieren Sie `compute_follower_control` nach dem Abschnitt *P-Regler für den Folgeabstand* oben und [docs/zug_steuerung.md](docs/zug_steuerung.md) (Distanz- und Winkelfehler, Totband, Begrenzung).  
- **1b) TF Broadcaster:** Senden Sie in `_pose_callback` für jede Schildkröte die Transformation `world -> turtleX` aus der empfangenen Pose. Vorlage ist `TurtleTF2Broadcaster.handle_turtle_pose`.  
- **1c) TF Listener & Regelschleife:** Fragen Sie in `_control_loop` für jeden Follower die Position des Vorgängers per `lookup_transform` ab, berechnen Sie die Stellgrößen mit Ihrem Regler und publizieren Sie sie auf `/turtleX/cmd_vel`.  

Prüfen Sie Ihren Regler zuerst ohne ROS 2 mit den Selbsttests und testen Sie anschließend in Turtlesim, wie die Formation auf Kurven und Stillstand des Leaders reagiert. Variieren Sie Abstand, Anzahl der Schildkröten und Verstärkungen.

### Aufgabe 2: Zug mit zwei TurtleBot 4 (`src/real_robot_train.py`)

Das Einlesen der TF-Daten aus den Namensräumen und die Kalibrierung beim Start sind vorgegeben, siehe [Anleitung für reale Hardware](docs/reale_hardware.md).

- **2a) 2D-Posen:** Implementieren Sie `_compose_2d` (Verkettung zweier Posen $(x, y, \psi)$) und `_invert_2d` (Inverse einer Pose). Die Kalibrierung berechnet damit $T_{\text{world} \to \text{odom}} = T_{\text{start}} \cdot \left(T_{\text{odom} \to \text{base}}\right)^{-1}$.  
- **2b) Sichere Regelschleife:** Implementieren Sie `_control_loop` mit Ihrem Regler aus Aufgabe 1 und den Sicherheitsregeln aus der Hardware-Anleitung: Stopp bei veralteten TF-Daten und unter dem Sicherheitsabstand, kein Rückwärtsfahren, Lineargeschwindigkeit mit $\max(0, \cos e_\alpha)$ skaliert, Null-Twist bei fehlgeschlagenem Lookup.  

Testen Sie den Controller zuerst in der 3D-Simulation mit zwei TurtleBot 4 ([Docker-Anleitung](docs/docker_container.md#-turtlebot-4-simulation-aufgabe-2)) und erst danach mit den realen Robotern.

### Selbsttests

```bash
cd praktikum/turtle_train
python3 -m pytest tests -v
```

---

## ⚙️ Ausführung der Simulation

### A. Lokale Ausführung (Nativ unter Linux/ROS 2)

1. **Turtlesim starten:**  

   ```bash
   ros2 run turtlesim turtlesim_node
   ```

2. **Zug-Controller starten:**  

   ```bash
   python3 praktikum/turtle_train/src/turtle_train_sim.py
   ```

3. **Leader (turtle1) fernsteuern:**  

   ```bash
   ros2 run turtlesim turtle_teleop_key
   ```

### B. Ausführung im Docker Container

Für Systeme ohne lokales ROS 2 (Windows, Linux oder macOS) stehen im Ordner `docker_container/` fertige Docker-Umgebungen inklusive noVNC Web-Interface bereit:

- **Turtlesim-Container** für Aufgabe 1  
- **TurtleBot 4 Simulation** in Gazebo für Aufgabe 2 (ressourcenaufwendig, GPU empfohlen)  

1. **Container starten** (Turtlesim, in PowerShell bzw. Linux-Terminal):  

   ```bash
   cd praktikum/turtle_train/docker_container
   docker compose up --build -d
   ```

2. **Webbrowser öffnen:** Rufen Sie [http://localhost:8080/vnc.html](http://localhost:8080/vnc.html) auf, um die grafische Oberfläche der Simulation zu sehen.  

Die vollständige Anleitung für Windows und Linux, inklusive TurtleBot 4 Simulation, finden Sie in der [Docker-Anleitung](docs/docker_container.md).  

---

## 🤖 Einsatz auf realer Hardware

Im Labor stehen zwei TurtleBot 4 mit den ROS-Namensräumen `robot_1` (Leader) und `robot_2` (Follower). Der Controller `src/real_robot_train.py` berücksichtigt die Besonderheiten der echten Roboter:

- TF-Daten kommen auf den **namensraum-spezifischen Topics** `/robot_1/tf`, `/robot_2/tf` an, die Frames darin heißen aber bei beiden Robotern gleich (`odom -> base_link`). Der Controller setzt den Namensraum vor die Frames und führt alles in einem gemeinsamen TF-Buffer zusammen.  
- Die getrennten Odometrie-Ursprünge `robot_1/odom` und `robot_2/odom` werden beim Start **kalibriert**: Der Controller legt `world -> robot_X/odom` so, dass die Roboter in der aufgestellten Formation stehen (Leader vorne, Follower 0,8 m dahinter).  
- Sicherheitslogik: Not-Halt bei Unterschreiten des Mindestabstands, Stopp bei veralteten TF-Daten, kein Rückwärtsfahren, Lineargeschwindigkeit an den Kurswinkelfehler gekoppelt.  

Schnellstart auf dem Steuerungs-PC (Roboter 0,8 m hintereinander aufstellen, Leader vorne):

```bash
source /opt/ros/humble/setup.bash
python3 src/real_robot_train.py --ros-args -p robot_namespaces:="['robot_1', 'robot_2']"
ros2 run teleop_twist_keyboard teleop_twist_keyboard --ros-args -r __ns:=/robot_1
```

Eine ausführliche Schritt-für-Schritt-Anleitung mit allen Parametern finden Sie im Dokument:

- 📖 **[Anleitung für reale Hardware](docs/reale_hardware.md)**  
