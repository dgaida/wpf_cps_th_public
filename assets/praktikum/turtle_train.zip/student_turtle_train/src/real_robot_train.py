"""Real Robot Train Controller (task 2).

This module implements a ROS 2 node that controls a fleet of physical robots
(e.g. two TurtleBot 4 with namespaces ``robot_1`` and ``robot_2``) to move in a
convoy/train formation while keeping a defined trailing distance.

Differences to the Turtlesim version that matter on real hardware:

* The TurtleBot 4 publishes its transforms on namespaced topics
  (``/robot_1/tf``, ``/robot_1/tf_static``), not on the global ``/tf``. The node
  therefore subscribes to the TF topics of every robot and feeds them into one
  shared ``tf2_ros.Buffer``. The frame names themselves are *not* namespaced by
  the robots (both send ``odom -> base_link``), so the node prefixes them with
  the namespace while storing them (``robot_1/odom -> robot_1/base_link``).
* Every robot has its own odometry root (``robot_1/odom``, ``robot_2/odom``),
  zeroed wherever the robot was switched on or undocked. To make a lookup
  between the robots possible the node calibrates once at start: it reads the
  current ``odom -> base_link`` pose of every robot and publishes static
  transforms ``world -> <ns>/odom`` such that the robots are exactly in the
  configured formation (parameter ``start_poses``). So: place the robots in
  formation, then start the controller.
* Transforms older than ``max_transform_age`` seconds stop the follower, so a
  robot that lost its Wi-Fi link does not keep driving on frozen data.
* Reverse driving is disabled by default and the linear speed is scaled with
  the heading error, so a follower turns towards its predecessor first instead
  of driving blindly.

All settings are ROS 2 parameters, e.g.::

    python3 real_robot_train.py --ros-args \\
        -p robot_namespaces:="['robot_1', 'robot_2']" \\
        -p follow_distance:=0.8
"""

import math
from typing import Any, Optional

try:
    import rclpy
    from rclpy.executors import ExternalShutdownException
    from rclpy.node import Node
    from rclpy.qos import DurabilityPolicy, QoSProfile
    from geometry_msgs.msg import TransformStamped, Twist
    from tf2_msgs.msg import TFMessage
    from tf2_ros import Buffer, StaticTransformBroadcaster, TransformException
    ROS2_AVAILABLE = True
except ImportError:
    ROS2_AVAILABLE = False
    Node = object  # type: ignore[misc,assignment]
    TFMessage = Any  # type: ignore[misc,assignment]

try:
    from .turtle_train_sim import compute_follower_control
    from .turtle_tf2_broadcaster import euler_to_quaternion
except ImportError:
    from turtle_train_sim import compute_follower_control
    from turtle_tf2_broadcaster import euler_to_quaternion


class RealRobotTrainController(Node):  # type: ignore[misc]
    """ROS 2 Node for controlling real robot convoys using TF2 transforms.

    The first namespace in ``robot_namespaces`` is the leader (driven manually),
    every further namespace is a follower that receives ``/<ns>/cmd_vel``.
    """

    def __init__(self) -> None:
        """Initialize the node and read all settings from ROS 2 parameters."""
        if not ROS2_AVAILABLE:
            raise RuntimeError("ROS 2 (rclpy, tf2_ros) is not available in the current Python environment.")

        super().__init__("real_robot_train_controller")

        # --- Parameters -----------------------------------------------------
        self.declare_parameter("robot_namespaces", ["robot_1", "robot_2"])
        self.declare_parameter("base_frame_suffix", "base_link")
        self.declare_parameter("odom_frame_suffix", "odom")
        self.declare_parameter("world_frame", "world")
        self.declare_parameter("follow_distance", 0.8)
        self.declare_parameter("min_safety_distance", 0.35)
        self.declare_parameter("max_linear_speed", 0.4)
        self.declare_parameter("max_angular_speed", 1.0)
        self.declare_parameter("kp_linear", 1.2)
        self.declare_parameter("kp_angular", 3.0)
        self.declare_parameter("deadband_distance", 0.1)
        self.declare_parameter("allow_reverse", False)
        self.declare_parameter("max_transform_age", 0.5)
        self.declare_parameter("control_rate_hz", 20.0)
        # Formation at controller start: pose (x, y, yaw) of every robot in the world
        # frame as a flat list [x1, y1, yaw1, x2, y2, yaw2, ...].
        # Default: robot_2 stands 0.8 m behind robot_1, both facing the same way.
        self.declare_parameter("start_poses", [0.0, 0.0, 0.0, -0.8, 0.0, 0.0])
        # True: read the current odom->base_link pose of every robot once at start and
        # place world->odom so that the robots are exactly at ``start_poses``. This makes
        # the result independent of where each robot was switched on or undocked.
        # False: use ``start_poses`` directly as world->odom (only correct if the odometry
        # was zeroed while the robots stood in the formation).
        self.declare_parameter("calibrate_on_start", True)
        # False: publish no world->odom at all (a shared map/localization connects the tree).
        self.declare_parameter("publish_world_to_odom", True)

        self.robot_namespaces: list[str] = list(self.get_parameter("robot_namespaces").value)
        self.base_frame_suffix: str = self.get_parameter("base_frame_suffix").value
        self.odom_frame_suffix: str = self.get_parameter("odom_frame_suffix").value
        self.world_frame: str = self.get_parameter("world_frame").value
        self.follow_distance: float = float(self.get_parameter("follow_distance").value)
        self.min_safety_distance: float = float(self.get_parameter("min_safety_distance").value)
        self.max_linear_speed: float = float(self.get_parameter("max_linear_speed").value)
        self.max_angular_speed: float = float(self.get_parameter("max_angular_speed").value)
        self.kp_linear: float = float(self.get_parameter("kp_linear").value)
        self.kp_angular: float = float(self.get_parameter("kp_angular").value)
        self.deadband_distance: float = float(self.get_parameter("deadband_distance").value)
        self.allow_reverse: bool = bool(self.get_parameter("allow_reverse").value)
        self.max_transform_age: float = float(self.get_parameter("max_transform_age").value)
        control_rate_hz: float = float(self.get_parameter("control_rate_hz").value)

        if len(self.robot_namespaces) < 2:
            raise ValueError("robot_namespaces needs at least a leader and one follower.")

        # --- TF: one shared buffer fed from the namespaced TF topics ---------
        self.tf_buffer: Buffer = Buffer()
        self.tf_subscriptions: list[Any] = []
        self._setup_tf_subscriptions()

        self.static_broadcaster: StaticTransformBroadcaster = StaticTransformBroadcaster(self)
        self.start_poses: list[float] = [float(v) for v in self.get_parameter("start_poses").value]
        expected = 3 * len(self.robot_namespaces)
        if len(self.start_poses) != expected:
            raise ValueError(f"start_poses needs {expected} values (x, y, yaw per robot), got {len(self.start_poses)}.")

        self.calibrated: bool = False
        self.calib_timer: Any = None
        if not bool(self.get_parameter("publish_world_to_odom").value):
            self.calibrated = True  # somebody else connects the TF tree
        elif bool(self.get_parameter("calibrate_on_start").value):
            self.get_logger().info("Warte auf Odometrie beider Roboter, um world -> odom zu kalibrieren ...")
            self.calib_timer = self.create_timer(0.1, self._try_calibrate)
        else:
            self._publish_world_to_odom(self._triples(self.start_poses))
            self.calibrated = True

        # --- Velocity publishers for the followers ---------------------------
        self.cmd_vel_publishers: dict[str, Any] = {}
        for ns in self.robot_namespaces[1:]:
            self.cmd_vel_publishers[ns] = self.create_publisher(Twist, self._topic(ns, "cmd_vel"), 10)

        self.timer = self.create_timer(1.0 / control_rate_hz, self._control_loop)
        self.get_logger().info(
            f"Realer Roboter-Zug Controller gestartet! Leader: '{self.robot_namespaces[0]}', "
            f"Follower: {self.robot_namespaces[1:]}, Soll-Abstand: {self.follow_distance:.2f} m, "
            f"Not-Halt-Abstand: {self.min_safety_distance:.2f} m, Rückwärts: {self.allow_reverse}"
        )

    # ------------------------------------------------------------------ helpers
    @staticmethod
    def _topic(ns: str, name: str) -> str:
        """Build an absolute topic name inside a robot namespace."""
        return f"/{ns}/{name}" if ns else f"/{name}"

    def _frame(self, ns: str, suffix: str) -> str:
        """Build a TF frame name with the robot namespace as prefix."""
        return f"{ns}/{suffix}" if ns else suffix

    def _setup_tf_subscriptions(self) -> None:
        """Subscribe to /<ns>/tf and /<ns>/tf_static of every robot and fill the shared buffer."""
        tf_qos = QoSProfile(depth=100)
        tf_static_qos = QoSProfile(depth=100, durability=DurabilityPolicy.TRANSIENT_LOCAL)

        for ns in self.robot_namespaces:
            self.tf_subscriptions.append(
                self.create_subscription(
                    TFMessage,
                    self._topic(ns, "tf"),
                    lambda msg, authority=ns: self._tf_callback(msg, authority, static=False),
                    tf_qos,
                )
            )
            self.tf_subscriptions.append(
                self.create_subscription(
                    TFMessage,
                    self._topic(ns, "tf_static"),
                    lambda msg, authority=ns: self._tf_callback(msg, authority, static=True),
                    tf_static_qos,
                )
            )

    def _prefixed_frame(self, ns: str, frame: str) -> str:
        """Prefix a frame name with the robot namespace unless it already carries it.

        The lab TurtleBot 4 publish ``odom -> base_link`` without any prefix on
        ``/robot_1/tf`` and ``/robot_2/tf``, so both robots would collide in one
        buffer. Robots that already prefix their frames are left untouched.
        """
        frame = frame.lstrip("/")
        if not ns or frame.startswith(f"{ns}/"):
            return frame
        return f"{ns}/{frame}"

    def _tf_callback(self, msg: TFMessage, authority: str, static: bool) -> None:
        """Store incoming transforms of one robot in the shared TF buffer (frames get namespaced)."""
        for transform in msg.transforms:
            transform.header.frame_id = self._prefixed_frame(authority, transform.header.frame_id)
            transform.child_frame_id = self._prefixed_frame(authority, transform.child_frame_id)
            if static:
                self.tf_buffer.set_transform_static(transform, authority)
            else:
                self.tf_buffer.set_transform(transform, authority)

    # ---------------------------------------------------- world -> odom handling
    @staticmethod
    def _triples(flat: list[float]) -> list[tuple[float, float, float]]:
        """Split a flat [x1, y1, yaw1, x2, ...] list into (x, y, yaw) triples."""
        return [(flat[i], flat[i + 1], flat[i + 2]) for i in range(0, len(flat), 3)]

    @staticmethod
    def _yaw_from_quaternion(q: Any) -> float:
        """Extract the yaw angle (rotation about z) from a geometry_msgs Quaternion."""
        return math.atan2(2.0 * (q.w * q.z + q.x * q.y), 1.0 - 2.0 * (q.y * q.y + q.z * q.z))

    @staticmethod
    def _compose_2d(a: tuple[float, float, float], b: tuple[float, float, float]) -> tuple[float, float, float]:
        """Compose two 2D poses: result = a * b (apply b in the frame described by a)."""
        # TODO (task 2a): Rotate (bx, by) by ayaw, add (ax, ay); the angles add up: (x, y, ayaw + byaw).
        raise NotImplementedError("TODO: implement _compose_2d")

    @staticmethod
    def _invert_2d(p: tuple[float, float, float]) -> tuple[float, float, float]:
        """Invert a 2D pose (x, y, yaw)."""
        # TODO (task 2a): Return the pose q with _compose_2d(p, q) == (0, 0, 0): angle -yaw, translation
        # -(x, y) rotated by -yaw.
        raise NotImplementedError("TODO: implement _invert_2d")

    def _try_calibrate(self) -> None:
        """Once odom->base_link of every robot is known, compute world->odom so that the
        robots are at ``start_poses`` right now, then publish those static transforms."""
        odom_poses: list[tuple[float, float, float]] = []
        for ns in self.robot_namespaces:
            odom_frame = self._frame(ns, self.odom_frame_suffix)
            base_frame = self._frame(ns, self.base_frame_suffix)
            try:
                tr = self.tf_buffer.lookup_transform(odom_frame, base_frame, rclpy.time.Time())
            except TransformException:
                self.get_logger().info(
                    f"Kalibrierung: warte auf {odom_frame} -> {base_frame} (Roboter '{ns}' undocked? Topic /{ns}/tf?)",
                    throttle_duration_sec=2.0,
                )
                return
            odom_poses.append((
                tr.transform.translation.x,
                tr.transform.translation.y,
                self._yaw_from_quaternion(tr.transform.rotation),
            ))

        # world->odom_i = start_pose_i * (odom_i->base_link_i)^-1
        world_to_odom = [
            self._compose_2d(start, self._invert_2d(odom))
            for start, odom in zip(self._triples(self.start_poses), odom_poses)
        ]
        for ns, odom in zip(self.robot_namespaces, odom_poses):
            self.get_logger().info(
                f"Kalibrierung '{ns}': aktuelle Odometrie-Pose x={odom[0]:.2f} y={odom[1]:.2f} yaw={odom[2]:.2f}"
            )
        self._publish_world_to_odom(world_to_odom)
        self.calibrated = True
        self.calib_timer.cancel()
        self.get_logger().info("Kalibrierung abgeschlossen, Regelung aktiv.")

    def _publish_world_to_odom(self, poses: list[tuple[float, float, float]]) -> None:
        """Publish static transforms world -> <ns>/odom.

        Args:
            poses: One (x, y, yaw) pose of the odom frame in the world frame per namespace.
        """
        transforms: list[TransformStamped] = []
        for ns, (x, y, yaw) in zip(self.robot_namespaces, poses):
            t = TransformStamped()
            t.header.stamp = self.get_clock().now().to_msg()
            t.header.frame_id = self.world_frame
            t.child_frame_id = self._frame(ns, self.odom_frame_suffix)
            t.transform.translation.x = float(x)
            t.transform.translation.y = float(y)
            t.transform.translation.z = 0.0
            qx, qy, qz, qw = euler_to_quaternion(0.0, 0.0, float(yaw))
            t.transform.rotation.x = qx
            t.transform.rotation.y = qy
            t.transform.rotation.z = qz
            t.transform.rotation.w = qw
            transforms.append(t)
            # Put it directly into our own buffer; we do not listen to the global /tf_static.
            self.tf_buffer.set_transform_static(t, "real_robot_train_controller")
            self.get_logger().info(
                f"Statischer Transform {self.world_frame} -> {t.child_frame_id}: "
                f"x={x:.2f} y={y:.2f} yaw={yaw:.2f}"
            )

        # Also broadcast on /tf_static so RViz or other tools can use the same tree.
        self.static_broadcaster.sendTransform(transforms)

    # ------------------------------------------------------------- control loop
    def _control_loop(self) -> None:
        """Compute and publish a velocity command for every follower robot."""
        if not self.calibrated:
            return  # no commands until world->odom is known

        # TODO (task 2b): For every follower (self.robot_namespaces[1:]) and its predecessor:
        # 1. Start with a zero Twist (safe default) and look up <follower>/base_link -> <predecessor>/base_link
        #    (frame names with self._frame, time rclpy.time.Time()).
        # 2. Stop if the transform is older than self.max_transform_age seconds (header.stamp vs. clock).
        # 3. Stop if the distance is below self.min_safety_distance.
        # 4. Otherwise compute (v, w) with compute_follower_control and the parameters of this node,
        #    scale v with max(0, cos(heading error)) and forbid v < 0 unless self.allow_reverse.
        # 5. On TransformException keep the zero Twist. Publish the Twist on self.cmd_vel_publishers[follower]
        #    in every case and log the state with throttle_duration_sec=1.0.
        raise NotImplementedError("TODO: implement _control_loop")


def main(args: Optional[list[str]] = None) -> None:
    """Main entry point for starting the real robot train controller node.

    Args:
        args: Command line arguments passed to rclpy.init.
    """
    if not ROS2_AVAILABLE:
        print("ROS 2 (rclpy) ist in dieser Umgebung nicht verfügbar.")
        return

    rclpy.init(args=args)
    node = RealRobotTrainController()

    try:
        rclpy.spin(node)
    except (KeyboardInterrupt, ExternalShutdownException):
        pass
    finally:
        # Send a final stop to every follower before shutting down (only while the context is alive).
        if rclpy.ok():
            for publisher in node.cmd_vel_publishers.values():
                publisher.publish(Twist())
        node.destroy_node()
        rclpy.try_shutdown()


if __name__ == "__main__":
    main()
