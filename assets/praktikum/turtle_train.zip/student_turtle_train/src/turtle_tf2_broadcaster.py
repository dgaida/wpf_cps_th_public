"""TF2 Transform Broadcaster for Turtlesim Turtles.

This module listens to turtlesim Pose topics and broadcasts corresponding 2D TF2
transforms from frame 'world' to frame 'turtleX'.
"""

import math
from typing import Any, Optional

try:
    import rclpy
    from rclpy.node import Node
    from geometry_msgs.msg import TransformStamped
    from turtlesim.msg import Pose
    from tf2_ros import TransformBroadcaster
    ROS2_AVAILABLE = True
except ImportError:
    ROS2_AVAILABLE = False
    Node = object  # type: ignore[misc,assignment]
    Pose = Any  # type: ignore[misc,assignment]


def euler_to_quaternion(roll: float, pitch: float, yaw: float) -> tuple[float, float, float, float]:
    """Convert Euler angles (roll, pitch, yaw) into quaternion coordinates (x, y, z, w).

    Args:
        roll: Rotation around x-axis in radians.
        pitch: Rotation around y-axis in radians.
        yaw: Rotation around z-axis in radians.

    Returns:
        Tuple containing quaternion components (x, y, z, w).
    """
    half_yaw = yaw * 0.5
    half_pitch = pitch * 0.5
    half_roll = roll * 0.5

    qx = math.sin(half_roll) * math.cos(half_pitch) * math.cos(half_yaw) - math.cos(half_roll) * math.sin(half_pitch) * math.sin(half_yaw)
    qy = math.cos(half_roll) * math.sin(half_pitch) * math.cos(half_yaw) + math.sin(half_roll) * math.cos(half_pitch) * math.sin(half_yaw)
    qz = math.cos(half_roll) * math.cos(half_pitch) * math.sin(half_yaw) - math.sin(half_roll) * math.sin(half_pitch) * math.cos(half_yaw)
    qw = math.cos(half_roll) * math.cos(half_pitch) * math.cos(half_yaw) + math.sin(half_roll) * math.sin(half_pitch) * math.sin(half_yaw)

    return (qx, qy, qz, qw)


class TurtleTF2Broadcaster(Node):  # type: ignore[misc]
    """ROS 2 Node that broadcasts TF2 coordinate frame transforms for turtlesim turtles.

    Subscribes to the pose topic `/{turtle_name}/pose` of a specified turtle and
    continuously broadcasts the dynamic 3D coordinate transform from the global
    world frame (`world`) to the turtle's frame (`{turtle_name}`) using TF2.
    """

    def __init__(self, turtle_name: str = "turtle1") -> None:
        """Initialize the TF2 broadcaster node for a given turtle.

        Args:
            turtle_name: The name of the turtle frame to broadcast (e.g., 'turtle1').
        """
        if not ROS2_AVAILABLE:
            raise RuntimeError("ROS 2 (rclpy, tf2_ros, turtlesim) is not available in the current Python environment.")

        super().__init__(f"{turtle_name}_tf2_broadcaster")
        self.turtle_name: str = turtle_name

        # Create a dynamic TF2 TransformBroadcaster instance for this node
        self.tf_broadcaster: TransformBroadcaster = TransformBroadcaster(self)

        # Subscribe to the turtle's pose topic (e.g., '/turtle1/pose').
        # Parameters:
        # - Pose: ROS 2 message type containing 2D position (x, y) and orientation (theta, linear/angular velocity)
        # - f"/{self.turtle_name}/pose": Topic name for the given turtle
        # - self.handle_turtle_pose: Callback function executed whenever a new pose message arrives
        # - 10: QoS profile depth (queue size for buffering incoming messages)
        self.subscription = self.create_subscription(
            Pose,
            f"/{self.turtle_name}/pose",
            self.handle_turtle_pose,
            10
        )
        self.get_logger().info(f"TF2 Broadcaster gestartet für Frame '{self.turtle_name}'")

    def handle_turtle_pose(self, msg: Pose) -> None:
        """Callback triggered upon receiving a Pose message from turtlesim to publish TF transform.

        Converts 2D pose coordinates (x, y, theta) into a 3D ROS 2 TransformStamped message
        and broadcasts it via TF2.

        Args:
            msg: Current Pose message received from turtlesim containing x, y, and theta.
        """
        # Create a new transform message object
        t = TransformStamped()

        # Fill timestamp and coordinate frame identifiers
        t.header.stamp = self.get_clock().now().to_msg()
        t.header.frame_id = "world"           # Parent reference frame
        t.child_frame_id = self.turtle_name   # Child frame being published

        # Set 3D translation coordinates from 2D pose (z = 0.0 for 2D turtlesim)
        t.transform.translation.x = float(msg.x)
        t.transform.translation.y = float(msg.y)
        t.transform.translation.z = 0.0

        # Convert 2D yaw angle (theta) around z-axis into a 3D unit quaternion (qx, qy, qz, qw)
        qx, qy, qz, qw = euler_to_quaternion(0.0, 0.0, float(msg.theta))
        t.transform.rotation.x = qx
        t.transform.rotation.y = qy
        t.transform.rotation.z = qz
        t.transform.rotation.w = qw

        # Broadcast the coordinate transform over the TF2 network
        self.tf_broadcaster.sendTransform(t)


def main(args: Optional[list[str]] = None) -> None:
    """Main execution function for launching the TF2 broadcaster standalone.

    Args:
        args: Command line arguments passed to rclpy.init.
    """
    if not ROS2_AVAILABLE:
        print("ROS 2 is not installed in this environment.")
        return

    rclpy.init(args=args)
    node = TurtleTF2Broadcaster(turtle_name="turtle1")
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        node.destroy_node()
        rclpy.shutdown()


if __name__ == "__main__":
    main()
