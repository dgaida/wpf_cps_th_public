"""Turtlesim Train Controller (task 1).

This module implements a ROS 2 node that manages a train formation of multiple turtles
in Turtlesim using TF2 broadcasters and listeners. The lead turtle (turtle1) is followed
by turtle2, turtle3, ..., turtleN with a user-defined follow distance offset.
"""

import math
import time
from typing import Any, Optional

try:
    import rclpy
    from rclpy.node import Node
    from geometry_msgs.msg import TransformStamped, Twist
    from turtlesim.msg import Pose
    from turtlesim.srv import Spawn
    from tf2_ros import Buffer, TransformBroadcaster, TransformException, TransformListener
    ROS2_AVAILABLE = True
except ImportError:
    ROS2_AVAILABLE = False
    Node = object  # type: ignore[misc,assignment]
    Pose = Any  # type: ignore[misc,assignment]
    Twist = Any  # type: ignore[misc,assignment]

try:
    from .turtle_tf2_broadcaster import euler_to_quaternion
except ImportError:
    from turtle_tf2_broadcaster import euler_to_quaternion


def normalize_angle(angle: float) -> float:
    """Normalize an angle in radians to the range [-pi, pi].

    Args:
        angle: Angle in radians.

    Returns:
        Normalized angle in radians within [-pi, pi].
    """
    while angle > math.pi:
        angle -= 2.0 * math.pi
    while angle < -math.pi:
        angle += 2.0 * math.pi
    return angle


def compute_follower_control(
    dx: float,
    dy: float,
    distance_offset: float,
    kp_linear: float = 1.5,
    kp_angular: float = 6.0,
    max_linear_speed: float = 2.0,
    max_angular_speed: float = 3.0,
    deadband_distance: float = 0.05,
) -> tuple[float, float]:
    """Calculate linear and angular velocity commands for a follower robot.

    Given the relative position (dx, dy) of the predecessor robot in the follower's
    local coordinate frame, compute appropriate velocity commands to maintain
    a trailing distance equal to `distance_offset`.

    Args:
        dx: Relative x-position of predecessor in follower frame (meters).
        dy: Relative y-position of predecessor in follower frame (meters).
        distance_offset: Target trailing distance behind predecessor (meters).
        kp_linear: Proportional gain for linear velocity controller.
        kp_angular: Proportional gain for angular velocity controller.
        max_linear_speed: Maximum allowable linear speed (m/s).
        max_angular_speed: Maximum allowable angular speed (rad/s).
        deadband_distance: Distance error threshold below which linear movement stops (meters).

    Returns:
        Tuple of (linear_velocity, angular_velocity).
    """
    # TODO (task 1a): P controller for the follow distance, see docs/zug_steuerung.md.
    # 1. Distance error: distance to the predecessor minus distance_offset.
    # 2. Heading error: angle to the predecessor (atan2), normalized with normalize_angle.
    # 3. v = kp_linear * distance error (0 inside the deadband), w = kp_angular * heading error.
    # 4. Clamp v to [-max_linear_speed, max_linear_speed] and w to [-max_angular_speed, max_angular_speed].
    raise NotImplementedError("TODO: implement compute_follower_control")


class TurtleTrainSimController(Node):  # type: ignore[misc]
    """ROS 2 Node that coordinates multiple turtles in Turtlesim to form a train.

    Spawns additional turtles if needed, broadcasts frame transforms, and controls
    each follower turtle using TF2 lookup transforms to track the predecessor turtle.
    """

    def __init__(
        self,
        num_turtles: int = 3,
        follow_distance: float = 1.0,
        kp_linear: float = 1.5,
        kp_angular: float = 6.0,
    ) -> None:
        """Initialize the Turtle Train simulation controller.

        Args:
            num_turtles: Total number of turtles in the train formation (minimum 2).
            follow_distance: Target distance between consecutive turtles in meters.
            kp_linear: Proportional gain for linear velocity.
            kp_angular: Proportional gain for angular velocity.
        """
        if not ROS2_AVAILABLE:
            raise RuntimeError("ROS 2 (rclpy, tf2_ros, turtlesim) is not available in the current Python environment.")

        super().__init__("turtle_train_sim_controller")

        self.num_turtles: int = max(2, num_turtles)
        self.follow_distance: float = follow_distance
        self.kp_linear: float = kp_linear
        self.kp_angular: float = kp_angular

        self.tf_broadcaster: TransformBroadcaster = TransformBroadcaster(self)
        self.tf_buffer: Buffer = Buffer()
        self.tf_listener: TransformListener = TransformListener(self.tf_buffer, self)

        self.cmd_vel_publishers: dict[int, rclpy.publisher.Publisher] = {}
        self.pose_subscriptions: dict[int, rclpy.subscription.Subscription] = {}
        self.latest_poses: dict[int, Pose] = {}

        self.spawn_client = self.create_client(Spawn, "/spawn")

        # Set up subscribers, publishers, and spawn extra turtles
        self._setup_turtles()

        # Control loop timer (20 Hz)
        self.timer = self.create_timer(0.05, self._control_loop)
        self.get_logger().info(
            f"Turtle Train Controller gestartet! Anz. Turtles: {self.num_turtles}, "
            f"Abstand: {self.follow_distance:.2f} m"
        )

    def _setup_turtles(self) -> None:
        """Subscribe to turtle poses and publish velocity commands for each turtle in the train."""
        for i in range(1, self.num_turtles + 1):
            turtle_name = f"turtle{i}"

            # Pose subscriber to broadcast TF transform
            self.pose_subscriptions[i] = self.create_subscription(
                Pose,
                f"/{turtle_name}/pose",
                lambda msg, idx=i: self._pose_callback(msg, idx),
                10,
            )

            # Velocity publisher for follower turtles (2..N)
            if i > 1:
                self.cmd_vel_publishers[i] = self.create_publisher(
                    Twist,
                    f"/{turtle_name}/cmd_vel",
                    10,
                )
                self._spawn_turtle_if_needed(i)

    def _spawn_turtle_if_needed(self, index: int) -> None:
        """Call Turtlesim spawn service to spawn turtle if it does not exist.

        Args:
            index: Integer index of the turtle (e.g., 2 for turtle2).
        """
        if not self.spawn_client.wait_for_service(timeout_sec=2.0):
            self.get_logger().warn(f"Service /spawn nicht erreichbar. Kann turtle{index} nicht automatisch spawnen.")
            return

        req = Spawn.Request()
        req.x = float(5.54 - (index - 1) * self.follow_distance)
        req.y = 5.54
        req.theta = 0.0
        req.name = f"turtle{index}"

        future = self.spawn_client.call_async(req)
        future.add_done_callback(
            lambda f, idx=index: self.get_logger().info(f"turtle{idx} erfolgreich gespawnt.")
            if f.result() is not None
            else None
        )

    def _pose_callback(self, msg: Pose, index: int) -> None:
        """Callback receiving Pose for turtle at index and broadcasting frame transform.

        Args:
            msg: Pose message from turtlesim.
            index: Integer index of the turtle.
        """
        self.latest_poses[index] = msg

        # TODO (task 1b): Broadcast the transform world -> turtle<index> built from msg (x, y, theta)
        # with self.tf_broadcaster, like TurtleTF2Broadcaster.handle_turtle_pose in turtle_tf2_broadcaster.py.
        raise NotImplementedError("TODO: implement _pose_callback")

    def _control_loop(self) -> None:
        """Control loop executed periodically to compute and publish follower velocity commands."""
        # TODO (task 1c): For every follower turtle i = 2..num_turtles:
        # 1. Look up the transform from frame turtle<i> to frame turtle<i-1> (self.tf_buffer.lookup_transform,
        #    time rclpy.time.Time() = latest available). Its translation is (dx, dy) of the predecessor
        #    in the follower frame.
        # 2. Compute (v, w) with compute_follower_control and publish them as Twist on self.cmd_vel_publishers[i].
        # 3. Catch TransformException (no data yet at start) and skip this follower.
        raise NotImplementedError("TODO: implement _control_loop")


def main(args: Optional[list[str]] = None) -> None:
    """Main function to launch the simulated Turtle Train controller node.

    Args:
        args: Command line arguments passed to rclpy.init.
    """
    if not ROS2_AVAILABLE:
        print("ROS 2 (rclpy) ist in dieser Umgebung nicht verfügbar.")
        return

    rclpy.init(args=args)
    controller = TurtleTrainSimController(num_turtles=3, follow_distance=1.0)

    try:
        rclpy.spin(controller)
    except KeyboardInterrupt:
        pass
    finally:
        controller.destroy_node()
        rclpy.shutdown()


if __name__ == "__main__":
    main()
