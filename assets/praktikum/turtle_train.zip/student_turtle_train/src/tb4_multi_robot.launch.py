"""ROS 2 launch file for multi-robot TurtleBot 4 simulation in Gazebo.

Starts the Gazebo world with the Leader (robot_1, TurtleBot 4) and spawns the
Follower (robot_2, iRobot Create 3 base without camera/lidar) into the same world.

The Follower is started as a separate ``ros2 launch`` process: the TurtleBot 4 and
Create 3 launch files start their controller spawners delayed (on process exit) and
read the launch configuration ``namespace`` only then. Included into the same launch
description, robot_2's namespace would override robot_1's and both diffdrive
controllers would end up in /robot_2.

Note: Two robots in one world additionally require the patched simulation of the
Docker container (``docker_container/patch_tb4_sim.py``), otherwise Gazebo crashes
with ``Ogre::ItemIdentityException: A scene node with the name sun already exists``.
"""

import os

from ament_index_python.packages import get_package_share_directory
from launch import LaunchDescription
from launch.actions import DeclareLaunchArgument, ExecuteProcess, IncludeLaunchDescription, TimerAction
from launch.launch_description_sources import PythonLaunchDescriptionSource
from launch.substitutions import LaunchConfiguration


def generate_launch_description() -> LaunchDescription:
    """Generates the launch description for multi-robot TurtleBot 4 simulation.

    Returns:
        LaunchDescription: ROS 2 launch description containing the Gazebo world with
            the Leader (robot_1) and the Follower (robot_2) spawn process.
    """
    pkg_tb4_gz_bringup = get_package_share_directory('turtlebot4_gz_bringup')

    world_arg = DeclareLaunchArgument(
        'world',
        default_value='maze',
        description='Gazebo world name (e.g. maze, depot, warehouse)',
    )

    # 'lite' has no OAK-D camera, which keeps the (software-rendered) simulation fast enough
    model_arg = DeclareLaunchArgument(
        'model',
        default_value='lite',
        description='TurtleBot 4 model of the Leader (lite or standard)',
    )

    # Robot 1 (Leader - TurtleBot 4 with sensors and Gazebo world)
    robot1_launch = IncludeLaunchDescription(
        PythonLaunchDescriptionSource(
            os.path.join(pkg_tb4_gz_bringup, 'launch', 'turtlebot4_gz.launch.py')
        ),
        launch_arguments={
            'namespace': 'robot_1',
            'robot_name': 'robot_1',
            'x': '0.0',
            'y': '0.0',
            'model': LaunchConfiguration('model'),
            'world': LaunchConfiguration('world'),
        }.items(),
    )

    # Robot 2 (Follower - iRobot Create 3 base) as separate process, delayed until the world is up
    robot2_launch = TimerAction(
        period=15.0,
        actions=[
            ExecuteProcess(
                cmd=[
                    'ros2', 'launch', 'irobot_create_gz_bringup', 'create3_spawn.launch.py',
                    'namespace:=robot_2',
                    'robot_name:=robot_2',
                    'x:=-1.0',
                    'y:=0.0',
                    ['world:=', LaunchConfiguration('world')],
                    'use_rviz:=false',
                    'spawn_dock:=false',
                ],
                output='screen',
            )
        ],
    )

    return LaunchDescription([
        world_arg,
        model_arg,
        robot1_launch,
        robot2_launch,
    ])
