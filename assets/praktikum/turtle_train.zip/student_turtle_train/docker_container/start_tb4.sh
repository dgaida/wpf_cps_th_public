#!/usr/bin/env bash
# Builds and starts the TurtleBot 4 simulation on Linux (and macOS) and uses the GPU if possible:
#   1. NVIDIA GPU with NVIDIA Container Toolkit -> docker-compose.tb4.gpu.nvidia.yml
#   2. Intel/AMD GPU (/dev/dri)                  -> docker-compose.tb4.gpu.dri.yml
#   3. otherwise                                 -> software rendering on the CPU
# The detection can be overridden, e.g.: GPU_MODE=software ./start_tb4.sh

set -euo pipefail
cd "$(dirname "$0")"

if ! docker info >/dev/null 2>&1; then
    echo "Fehler: Docker ist nicht erreichbar."
    echo "  - Läuft Docker? Prüfen mit: systemctl status docker"
    echo "  - Bei 'permission denied': Benutzer zur docker-Gruppe hinzufügen und neu anmelden:"
    echo "      sudo usermod -aG docker \$USER"
    exit 1
fi

has_nvidia_gpu() {
    [ -e /proc/driver/nvidia/version ]
}

has_nvidia_runtime() {
    docker info --format '{{json .Runtimes}}' 2>/dev/null | grep -q '"nvidia"'
}

# Render node of an Intel/AMD GPU (the nodes of the proprietary NVIDIA driver cannot be used by Mesa)
has_mesa_gpu() {
    local node driver
    for node in /dev/dri/renderD*; do
        [ -e "$node" ] || continue
        driver=$(basename "$(readlink -f "/sys/class/drm/$(basename "$node")/device/driver" 2>/dev/null)")
        [ "$driver" != "nvidia" ] && return 0
    done
    return 1
}

mode="${GPU_MODE:-auto}"
if [ "$mode" = "auto" ]; then
    mode="software"
    if has_nvidia_gpu; then
        if has_nvidia_runtime; then
            mode="nvidia"
        else
            echo "Hinweis: NVIDIA-GPU gefunden, aber das NVIDIA Container Toolkit ist nicht installiert."
            echo "  Installation siehe docs/docker_container.md, Abschnitt 'Linux mit NVIDIA-GPU'."
            echo
        fi
    fi
    if [ "$mode" = "software" ] && has_mesa_gpu; then
        mode="dri"
    fi
fi

compose_files=(-f docker-compose.tb4.yml)
case "$mode" in
    nvidia) echo "GPU: NVIDIA (über NVIDIA Container Toolkit)"; compose_files+=(-f docker-compose.tb4.gpu.nvidia.yml) ;;
    dri) echo "GPU: Intel/AMD (über /dev/dri)"; compose_files+=(-f docker-compose.tb4.gpu.dri.yml) ;;
    software) echo "Keine nutzbare GPU gefunden: Gazebo rendert auf der CPU (langsam)." ;;
    *) echo "Fehler: unbekannter GPU_MODE '$mode' (erlaubt: auto, nvidia, dri, software)"; exit 1 ;;
esac
echo

docker compose "${compose_files[@]}" up --build -d

echo
echo "Simulation gestartet: http://localhost:8081/vnc.html öffnen und auf 'Connect' klicken."
