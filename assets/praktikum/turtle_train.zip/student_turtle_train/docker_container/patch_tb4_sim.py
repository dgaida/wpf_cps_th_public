"""Patches the TurtleBot 4 Gazebo simulation so that several robots can share one world.

Every robot model (create3.urdf.xacro, included by the TurtleBot 4 description) loads its own
``gz::sim::systems::Sensors`` system. With a second robot, Gazebo creates a second rendering scene
and crashes with ``Ogre::ItemIdentityException: A scene node with the name sun already exists``.
This script removes the system from the robot model and enables it once in the world files instead.
"""

import glob
import re
import sys

CREATE3_XACRO = "/opt/ros/jazzy/share/irobot_create_description/urdf/create3.urdf.xacro"
# The TurtleBot 4 worlds come first in GZ_SIM_RESOURCE_PATH, so these are the ones Gazebo loads.
WORLD_GLOB = "/opt/ros/overlay_ws/src/turtlebot4_simulator/turtlebot4_gz_bringup/worlds/*.sdf"

ROBOT_SENSORS_BLOCK = re.compile(
    r"\s*<gazebo>\s*<plugin filename=\"libgz-sim-sensors-system\.so\" "
    r"name=\"gz::sim::systems::Sensors\">.*?</plugin>\s*</gazebo>",
    re.DOTALL,
)
COMMENTED_WORLD_SENSORS = re.compile(
    r"<!--\s*(<plugin name=\"gz::sim::systems::Sensors\".*?</plugin>)\s*-->",
    re.DOTALL,
)
WORLD_SENSORS = (
    '<plugin name="gz::sim::systems::Sensors" filename="gz-sim-sensors-system">\n'
    "        <render_engine>ogre</render_engine>\n"
    "    </plugin>"
)


def patch_robot_model(path: str) -> None:
    """Removes the per-robot Sensors system from the Create 3 model.

    Args:
        path: Path to create3.urdf.xacro.
    """
    with open(path, encoding="utf-8") as f:
        text = f.read()
    new_text, count = ROBOT_SENSORS_BLOCK.subn("", text)
    if count != 1:
        sys.exit(f"Expected exactly one Sensors system in {path}, found {count}")
    with open(path, "w", encoding="utf-8") as f:
        f.write(new_text)
    print(f"Removed Sensors system from {path}")


def patch_world(path: str) -> None:
    """Enables the commented-out Sensors system (with OGRE 1) in a world file.

    Args:
        path: Path to the world SDF file.
    """
    with open(path, encoding="utf-8") as f:
        text = f.read()
    new_text, count = COMMENTED_WORLD_SENSORS.subn(WORLD_SENSORS, text, count=1)
    if count != 1:
        sys.exit(f"No commented-out Sensors system found in {path}")
    with open(path, "w", encoding="utf-8") as f:
        f.write(new_text)
    print(f"Enabled Sensors system in {path}")


def main() -> None:
    """Applies all patches."""
    patch_robot_model(CREATE3_XACRO)
    worlds = sorted(glob.glob(WORLD_GLOB))
    if not worlds:
        sys.exit("No world files found")
    for world in worlds:
        patch_world(world)


if __name__ == "__main__":
    main()
