# Docker-Container für das Turtle-Train-Praktikum

Für das Praktikum stehen im Ordner `docker_container/` zwei fertige Docker-Umgebungen bereit. Sie benötigen damit **keine lokale ROS 2 Installation**. Die grafische Oberfläche (Turtlesim bzw. Gazebo) läuft im Container und wird über **noVNC direkt im Webbrowser** angezeigt. Beide Container funktionieren daher ohne Anpassung unter **Windows und Linux**.

| Container | Inhalt | Für | Web-Oberfläche |
|---|---|---|---|
| **Turtlesim** (`docker-compose.yml`) | ROS 2 Humble, Turtlesim | Aufgabe 1 | [http://localhost:8080/vnc.html](http://localhost:8080/vnc.html) |
| **TurtleBot 4 Simulation** (`docker-compose.tb4.yml`) | ROS 2 Jazzy, Gazebo, zwei TurtleBot 4 | Aufgabe 2 (Test vor der realen Hardware) | [http://localhost:8081/vnc.html](http://localhost:8081/vnc.html) |

---

## 🧰 Voraussetzungen

### Windows

1. **Docker Desktop** installieren: [https://docs.docker.com/desktop/setup/install/windows-install/](https://docs.docker.com/desktop/setup/install/windows-install/)  
   Wählen Sie bei der Installation das **WSL 2 Backend** (Standardeinstellung).  
2. Docker Desktop starten und warten, bis unten links *Engine running* angezeigt wird.  
3. Alle Befehle dieser Anleitung führen Sie in **PowerShell** oder **Windows Terminal** aus.  

### Linux

1. **Docker Engine** und das **Docker Compose Plugin** installieren: [https://docs.docker.com/engine/install/](https://docs.docker.com/engine/install/)  
2. Damit Docker ohne `sudo` funktioniert, Ihren Benutzer der Gruppe `docker` hinzufügen und sich danach einmal ab- und wieder anmelden:  

   ```bash
   sudo usermod -aG docker $USER
   ```

3. Prüfen, ob Docker Compose verfügbar ist:  

   ```bash
   docker compose version
   ```

*Hinweis:* Unter Linux mit lokal installiertem ROS 2 Humble können Sie Aufgabe 1 alternativ auch ohne Docker ausführen (siehe [README](../README.md)).

---

## 🐢 Turtlesim-Container (Aufgabe 1)

### 1. Container bauen und starten

Wechseln Sie in den Ordner `docker_container` und starten Sie den Container. Der erste Start dauert einige Minuten, da das Image (ca. 1,8 GB) gebaut wird.

**Windows (PowerShell):**

```powershell
cd praktikum\turtle_train\docker_container
docker compose up --build -d
```

**Linux (Terminal):**

```bash
cd praktikum/turtle_train/docker_container
docker compose up --build -d
```

### 2. Oberfläche im Webbrowser öffnen

Rufen Sie [http://localhost:8080/vnc.html](http://localhost:8080/vnc.html) auf und klicken Sie auf **Connect**. Sie sehen einen leeren virtuellen Desktop, in dem gleich das Turtlesim-Fenster erscheint.

### 3. Turtlesim und Zug-Steuerung starten

Öffnen Sie **drei Terminals** auf Ihrem Rechner (PowerShell bzw. Linux-Terminal) und verbinden Sie sich in jedem mit dem Container:

```bash
docker exec -it turtle_train_container bash
```

Führen Sie dann in den drei Terminals jeweils einen Befehl aus:

```bash
# Terminal 1: Turtlesim starten (Fenster erscheint im Browser)
ros2 run turtlesim turtlesim_node

# Terminal 2: Zug-Steuerung starten (spawnt turtle2 und turtle3)
python3 /ros2_ws/src/turtle_train_pkg/turtle_train_pkg/turtle_train_sim.py

# Terminal 3: Leader (turtle1) mit den Pfeiltasten steuern
ros2 run turtlesim turtle_teleop_key
```

Sobald `turtle1` fährt, folgen die weiteren Schildkröten in einer Zug-Formation. Damit die Pfeiltasten wirken, muss Terminal 3 im Vordergrund sein.

💡 **Tipp:** Arbeiten Sie in den Terminals Ihres Rechners und nicht im Browser-Desktop. Dort funktioniert Kopieren und Einfügen (`Strg+V` bzw. `Strg+Shift+V`) wie gewohnt; die Fenster erscheinen trotzdem im Browser.

Ihr Code aus `praktikum/turtle_train/src/` ist im Container eingebunden. Änderungen an den Dateien sind sofort im Container sichtbar; Sie müssen das Python-Skript nur neu starten.

### 4. Container beenden

```bash
docker compose down
```

---

## 🤖 TurtleBot 4 Simulation (Aufgabe 2)

In diesem Container fahren zwei **TurtleBot 4** (`robot_1` als Leader, `robot_2` als Follower) in einer 3D-Simulation mit **Gazebo**. So können Sie Ihren Controller `real_robot_train.py` testen, bevor Sie ihn auf den realen Robotern im Labor einsetzen. Grundlage ist [kscottz/turtlebot4_docker](https://github.com/kscottz/turtlebot4_docker) (vielen Dank an K. Scottz und A. Zaid).

> ⚠️ **Die TurtleBot 4 Simulation ist sehr ressourcenaufwendig.**  
>
> - **Speicherplatz:** ca. 9 GB für das Docker-Image (der erste Build lädt ein großes Basis-Image herunter)  
> - **Arbeitsspeicher:** mindestens 8 GB RAM, empfohlen 16 GB  
> - **Grafikkarte (GPU):** Gazebo rendert die Sensoren der Roboter (Lidar, IR-Sensoren). **Starten Sie die Simulation nach Möglichkeit mit GPU.** Ohne GPU rechnet die CPU alles selbst: Die Simulation läuft dann nur mit ca. 5–15 % der Echtzeit, und Ihr Rechner ist stark ausgelastet. Mit GPU ist die Simulation mehrfach schneller.  
>
> Schließen Sie andere rechenintensive Programme, bevor Sie die Simulation starten.

### 1. GPU-Nutzung

Die GPU wird **automatisch** erkannt und genutzt. Sie müssen keine Konfigurationsdatei anpassen:

| System | Verhalten |
|---|---|
| **Windows** | Die GPU wird automatisch genutzt (NVIDIA, AMD und Intel über DirectX 12 / WSL 2). Ist eine NVIDIA-GPU vorhanden, wird sie bevorzugt. |
| **Linux mit Intel- oder AMD-GPU** | Das Startskript `start_tb4.sh` erkennt die GPU und nutzt sie. Es ist **nichts weiter zu tun.** |
| **Linux mit NVIDIA-GPU** | Das Startskript `start_tb4.sh` nutzt die GPU, sobald **einmalig** das NVIDIA Container Toolkit installiert ist (siehe unten). Ohne Toolkit weist das Skript darauf hin und nutzt, falls vorhanden, die Prozessorgrafik. |
| **ohne GPU, macOS** | Software-Rendering über die CPU (langsam, aber funktionsfähig). |

<details>
<summary>Linux mit NVIDIA-GPU: NVIDIA Container Toolkit installieren (einmalig)</summary>

Voraussetzung ist der proprietäre NVIDIA-Treiber (`nvidia-smi` zeigt Ihre Grafikkarte an). Installation unter Ubuntu/Debian:

```bash
curl -fsSL https://nvidia.github.io/libnvidia-container/gpgkey \
  | sudo gpg --dearmor -o /usr/share/keyrings/nvidia-container-toolkit-keyring.gpg
curl -s -L https://nvidia.github.io/libnvidia-container/stable/deb/nvidia-container-toolkit.list \
  | sed 's#deb https://#deb [signed-by=/usr/share/keyrings/nvidia-container-toolkit-keyring.gpg] https://#g' \
  | sudo tee /etc/apt/sources.list.d/nvidia-container-toolkit.list
sudo apt update && sudo apt install -y nvidia-container-toolkit
sudo nvidia-ctk runtime configure --runtime=docker
sudo systemctl restart docker
```

Test: `docker run --rm --gpus all ubuntu nvidia-smi` muss Ihre Grafikkarte anzeigen. Anleitungen für andere Distributionen: [NVIDIA Container Toolkit](https://docs.nvidia.com/datacenter/cloud-native/container-toolkit/latest/install-guide.html).

</details>

<details>
<summary>Windows: andere GPU auswählen (optional)</summary>

Haben Sie mehrere Grafikkarten (z. B. Prozessorgrafik und NVIDIA-Karte), wird die NVIDIA-Karte bevorzugt. Eine andere GPU wählen Sie vor dem Start über einen Teil ihres Namens aus, z. B.:

```powershell
$env:GPU_ADAPTER = "AMD"
docker compose -f docker-compose.tb4.yml up --build -d
```

</details>

### 2. Container bauen und starten

**Windows (PowerShell):**

```powershell
cd praktikum\turtle_train\docker_container
docker compose -f docker-compose.tb4.yml up --build -d
```

**Linux (Terminal):**

```bash
cd praktikum/turtle_train/docker_container
./start_tb4.sh
```

Das Skript zeigt an, welche GPU es verwendet (z. B. `GPU: NVIDIA` oder `GPU: Intel/AMD`), und startet dann den Container. Starten Sie den Container unter Linux immer über das Skript; ein direktes `docker compose up` verwendet keine GPU.

Der erste Build kann je nach Internetverbindung **10–30 Minuten** dauern. Öffnen Sie danach [http://localhost:8081/vnc.html](http://localhost:8081/vnc.html) und klicken Sie auf **Connect**. Der Container nutzt Port `8081`, sodass er parallel zum Turtlesim-Container (Port `8080`) laufen kann.

<details>
<summary>Prüfen, ob die GPU genutzt wird (optional)</summary>

```bash
docker exec -it tb4_train_container bash
glxinfo -B | grep "renderer string"
```

Steht dort der Name Ihrer Grafikkarte, rendert Gazebo auf der GPU. `llvmpipe` bedeutet Software-Rendering über die CPU. Während Gazebo läuft, zeigt `gz topic -e -t /stats -n 1 | grep real_time_factor` an, wie schnell die Simulation im Verhältnis zur Echtzeit läuft (1,0 = Echtzeit).

Die automatische Erkennung lässt sich bei Problemen übersteuern, z. B. mit `GPU_MODE=software ./start_tb4.sh` (erlaubt: `nvidia`, `dri`, `software`).

</details>

### 3. Gazebo mit beiden Robotern starten (Terminal 1)

```bash
docker exec -it tb4_train_container bash
ros2 launch /opt/ros/overlay_ws/src/turtle_train_pkg/tb4_multi_robot.launch.py
```

Gazebo öffnet sich im Browser. Warten Sie, bis **beide Roboter** zu sehen sind; `robot_2` erscheint ca. 15 Sekunden nach `robot_1`. Das Labyrinth (`maze`) ist die Standard-Welt; mit `world:=depot` oder `world:=warehouse` wählen Sie eine andere.

### 4. Zug-Controller starten (Terminal 2)

```bash
docker exec -it tb4_train_container bash
python3 /opt/ros/overlay_ws/src/turtle_train_pkg/real_robot_train.py --ros-args \
  -p use_sim_time:=true \
  -p robot_namespaces:="['robot_1', 'robot_2']" \
  -p start_poses:="[0.0, 0.0, 0.0, -1.0, 0.0, 0.0]" \
  -r /robot_2/cmd_vel:=/robot_2/cmd_vel_unstamped
```

*Windows:* Kopieren Sie den Befehl am Stück. Die Zeilen enden mit `\`, weil der Befehl in der Linux-Shell des Containers ausgeführt wird.

Der Controller kalibriert beim Start `world -> robot_X/odom` so, dass die Roboter an ihren Startpositionen stehen (`robot_1` bei x = 0,0 m, `robot_2` bei x = −1,0 m).

Gegenüber der realen Hardware gibt es in der Simulation zwei Unterschiede:

- **`use_sim_time:=true`:** Gazebo hat eine eigene Simulationszeit. Ohne diesen Parameter hält der Controller die TF-Daten für veraltet und stoppt den Follower.  
- **`cmd_vel_unstamped`:** In der Simulation (ROS 2 Jazzy) erwartet `/robot_X/cmd_vel` Nachrichten vom Typ `TwistStamped`. Der Controller sendet `Twist`; diese werden auf `/robot_X/cmd_vel_unstamped` angenommen.  

### 5. Leader (robot_1) per Tastatur steuern (Terminal 3)

```bash
docker exec -it tb4_train_container bash
ros2 run teleop_twist_keyboard teleop_twist_keyboard --ros-args --remap cmd_vel:=/robot_1/cmd_vel_unstamped
```

Steuerung: `i` vorwärts, `j`/`l` drehen, `k` anhalten. Sobald `robot_1` fährt, folgt `robot_2` im eingestellten Abstand (`follow_distance`, Standard 0,8 m). Fährt ein Roboter gegen eine Wand, setzt er durch die Sicherheitsreflexe der Create-3-Basis selbstständig ein Stück zurück.

### 6. Container beenden

Beenden Sie die Programme in den Terminals mit `Strg+C` und stoppen Sie anschließend den Container:

```bash
docker compose -f docker-compose.tb4.yml down
```

---

## 🛠️ Fehlerbehebung

| Problem | Lösung |
|---|---|
| `docker: command not found` bzw. *Cannot connect to the Docker daemon* | Docker Desktop (Windows) bzw. den Docker-Dienst (Linux: `sudo systemctl start docker`) starten. |
| *permission denied* beim Zugriff auf `docker.sock` (Linux) | Benutzer der Gruppe `docker` hinzufügen und neu anmelden (siehe Voraussetzungen). |
| *port is already allocated* | Ein anderes Programm oder ein alter Container nutzt Port 8080/8081. Mit `docker ps` prüfen und alten Container mit `docker compose down` beenden. |
| Browser zeigt nur einen schwarzen Desktop | Normal: Fenster erscheinen erst, wenn Sie Turtlesim bzw. Gazebo starten. |
| Gazebo sehr langsam | Simulation ohne GPU (siehe [GPU-Nutzung](#1-gpu-nutzung)); unter Linux den Container mit `./start_tb4.sh` starten; andere Programme schließen. |
| `start_tb4.sh`: *NVIDIA-GPU gefunden, aber das NVIDIA Container Toolkit ist nicht installiert* | Toolkit einmalig installieren (siehe [GPU-Nutzung](#1-gpu-nutzung)) und das Skript erneut ausführen. |
| `./start_tb4.sh`: *Permission denied* | Skript ausführbar machen: `chmod +x start_tb4.sh` |
| `robot_2` folgt nicht | Prüfen, ob der Controller mit `use_sim_time:=true` und dem Remap auf `cmd_vel_unstamped` gestartet wurde. |

---

## ⚙️ Technischer Hintergrund

- **noVNC:** Im Container läuft ein virtueller Bildschirm (`Xvfb`) mit Fenstermanager (`fluxbox`). `x11vnc` und `websockify` übertragen ihn in den Webbrowser. Gestartet werden die Dienste über `supervisord` (`supervisord.conf` bzw. `supervisord.tb4.conf`).  
- **`entrypoint.sh` (Turtlesim):** Bindet beim Containerstart die ROS 2 Umgebung (`source /opt/ros/humble/setup.bash`) ein und übergibt dann an `supervisord`. Für `docker exec`-Terminals ist die Umgebung zusätzlich in `/root/.bashrc` eingetragen.  
- **GPU-Auswahl (TurtleBot 4):** `docker-compose.tb4.yml` bindet `docker-compose.tb4.gpu.${OS}.yml` ein. Windows setzt die Umgebungsvariable `OS=Windows_NT`, unter Linux/macOS ist sie nicht gesetzt und `docker-compose.tb4.gpu.Linux.yml` (Software-Rendering) wird verwendet. `start_tb4.sh` ergänzt unter Linux je nach Hardware `docker-compose.tb4.gpu.nvidia.yml` (NVIDIA Container Toolkit) oder `docker-compose.tb4.gpu.dri.yml` (`/dev/dri`, Intel/AMD).  
- **VirtualGL (Linux):** Der virtuelle Bildschirm `Xvfb` kann OpenGL nur auf der CPU berechnen. Mit GPU leitet VirtualGL die OpenGL-Aufrufe von Gazebo per EGL auf die Grafikkarte um und kopiert die fertigen Bilder auf `Xvfb`; die Oberfläche bleibt so im Browser. Aktiviert wird das in `/root/.bashrc` (`LD_PRELOAD`), sobald `VGL_DISPLAY` gesetzt ist. Unter Windows rendert Mesa stattdessen direkt über DirectX 12 (`GALLIUM_DRIVER=d3d12`).  
- **Mehrere Roboter in Gazebo:** Jedes Robotermodell lädt standardmäßig ein eigenes Gazebo-Sensors-System; beim zweiten Roboter stürzt Gazebo dann ab (`Ogre::ItemIdentityException: A scene node with the name sun already exists`). `patch_tb4_sim.py` verlegt das Sensors-System beim Image-Build einmalig in die Welt-Dateien.  
- **Launchfile `tb4_multi_robot.launch.py`:** Startet `robot_2` als eigenen Prozess. Würde es in dieselbe Launch-Beschreibung eingebunden, überschriebe dessen Namensraum den von `robot_1` und beide Fahrregler landeten in `/robot_2`.  
