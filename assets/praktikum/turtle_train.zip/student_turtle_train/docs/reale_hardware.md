# Anleitung zur Ausführung der Zug-Steuerung auf realer Hardware

Diese Anleitung beschreibt die Inbetriebnahme der Formationsfahrt (Controller `src/real_robot_train.py`, Aufgabe 2) mit den **zwei TurtleBot 4** im Labor. Die Roboter sind mit den ROS-Namensräumen `robot_1` (Leader) und `robot_2` (Follower) konfiguriert. Das Vorgehen lässt sich auf mehr Roboter (z. B. `robot_3`) oder andere Plattformen (LIMO Cobot) übertragen, solange diese `odom -> base_link` im eigenen Namensraum publizieren.

---

## 🎯 Überblick & Architektur

Im Vergleich zur Turtlesim-Simulation gibt es auf realer Hardware drei Besonderheiten, die der Controller berücksichtigt:

1. **Namensräume bei TF:** Der TurtleBot 4 veröffentlicht seine Transformationen nicht auf dem globalen `/tf`, sondern auf `/robot_1/tf` und `/robot_1/tf_static`. Die **Frame-Namen selbst tragen keinen Präfix**: Beide Labor-Roboter senden identisch `odom -> base_link`. Der Controller abonniert deshalb die TF-Topics jedes Roboters, setzt beim Einlesen den Namensraum vor jeden Frame (`robot_1/odom -> robot_1/base_link`) und führt alles in einem gemeinsamen `tf2_ros.Buffer` zusammen.  
2. **Getrennte Odometrie-Wurzeln:** Jeder Roboter hat seinen eigenen Ursprung (`robot_1/odom`, `robot_2/odom`), der dort liegt, wo der Roboter eingeschaltet bzw. abgedockt wurde, also meist an der Ladestation in beliebiger Ausrichtung. Damit TF2 den Abstand zwischen `robot_2/base_link` und `robot_1/base_link` berechnen kann, **kalibriert der Controller beim Start**: Er liest die aktuelle Odometrie-Pose jedes Roboters und legt `world -> robot_X/odom` so, dass die Roboter in diesem Moment genau in der konfigurierten Formation stehen (Parameter `start_poses`). Voraussetzung: Die Roboter stehen beim Start des Controllers in Formation.  
3. **Sicherheit:** Veraltete TF-Daten (z. B. WLAN-Abbruch), Unterschreiten des Sicherheitsabstands oder ein fehlgeschlagener Lookup führen sofort zu einem Null-Twist. Rückwärtsfahren ist standardmäßig gesperrt. Die Lineargeschwindigkeit wird mit dem Kurswinkelfehler skaliert, damit der Follower erst in Richtung des Leaders dreht und dann fährt.  

```text
world
 ├─ robot_1/odom ─ robot_1/base_link      (Leader, manuell per Teleop gesteuert)
 └─ robot_2/odom ─ robot_2/base_link      (Follower, erhält /robot_2/cmd_vel)

[ Leader: robot_1 ]  <--- (Soll-Abstand 0.8 m) ---  [ Follower: robot_2 ]
```

---

## 🌐 1. Netzwerk & ROS 2 Konfiguration

### A. Gemeinsames WLAN-Netzwerk

Beide Roboter und der Steuerungs-PC müssen im selben Subnetz sein:

```bash
ping <ip_robot_1>
ping <ip_robot_2>
```

### B. Discovery Server & ROS Domain ID

Der Steuerungs-PC im Labor ist als **Fast-DDS-Discovery-Server-Client** eingerichtet. Die beiden Roboter sind die Server. Die Konfiguration liegt in `/etc/turtlebot4_discovery/setup.bash` und wird in `~/.bashrc` gesourct:

```bash
export RMW_IMPLEMENTATION=rmw_fastrtps_cpp
export ROS_DOMAIN_ID=0
export ROS_DISCOVERY_SERVER="192.168.0.221:11811;192.168.0.222:11811;"
```

**Achtung:** Im Discovery-Server-Modus trennt die `ROS_DOMAIN_ID` nicht. Ein Node mit einer anderen Domain-ID erreicht die Roboter trotzdem. Wer den Controller ohne Roboterkontakt testen will (z. B. mit simulierten TF-Daten), muss den Discovery Server in dieser Shell abschalten:

```bash
unset ROS_DISCOVERY_SERVER
export ROS_LOCALHOST_ONLY=1
```

### C. Uhren synchronisieren

Der Controller verwirft TF-Daten, die älter als `max_transform_age` (0,5 s) sind. Dafür müssen die Uhren von Robotern und PC übereinstimmen. Prüfen Sie den Versatz mit `chronyc tracking` bzw. `timedatectl` auf allen Geräten. Bei größerem Versatz stoppt der Follower mit der Meldung *„TF-Daten sind x s alt“*.

### D. Verbindung prüfen

```bash
ros2 topic list | grep -E 'robot_[12]/(tf|cmd_vel|odom)'
ros2 topic echo /robot_1/tf --once
```

Erwartete Ausgabe: `/robot_1/tf`, `/robot_1/tf_static`, `/robot_1/cmd_vel`, `/robot_2/tf`, … Im Inhalt von `/robot_1/tf` stehen die Frames `odom`, `base_link`, `base_footprint`, `left_wheel`, … ohne Präfix. Das ist in Ordnung, der Controller ergänzt den Namensraum selbst.

---

## 🤖 2. Namensräume der Roboter

Auf dem TurtleBot 4 ist der Namensraum in `/etc/turtlebot4/setup.bash` hinterlegt:

```bash
export ROBOT_NAMESPACE=robot_1      # bzw. robot_2
```

Die Create-3-Basis publiziert ihre Odometrie `odom -> base_link` auf `/robot_1/tf` (Topic im Namensraum, Frames ohne Präfix). Eine Frame-Präfix-Konfiguration auf den Robotern ist nicht nötig.

---

## 🚀 3. Starten des Roboter-Zugs

### Schritt 1: Roboter aufstellen

Stellen Sie die Roboter **unmittelbar vor dem Start des Controllers** in Formation auf (Einschalten und Undock dürfen vorher irgendwo passiert sein):

- `robot_1` (Leader) vorne, Blickrichtung = Fahrtrichtung.  
- `robot_2` (Follower) genau **0,8 m dahinter** (Mitte zu Mitte), gleiche Blickrichtung.  

Das entspricht dem Standardwert `start_poses:=[0.0, 0.0, 0.0, -0.8, 0.0, 0.0]` (x, y, yaw je Roboter in Metern/Radiant). Andere Aufstellungen werden über diesen Parameter angegeben. Beim Start kalibriert der Controller die Beziehung der beiden Odometrie-Ursprünge aus dieser Aufstellung. Ein ungenaues Aufstellen (z. B. 5° Verdrehung) erscheint später als dauerhafter seitlicher Versatz. Hinweis: Die Odometrie driftet mit der Zeit; nach längerer Fahrt die Roboter neu aufstellen und den Controller neu starten.

### Schritt 2: Roboter-Bringup

Auf beiden TurtleBot 4 läuft das Bringup normalerweise automatisch als Dienst. Falls nicht:

```bash
ros2 launch turtlebot4_bringup robot.launch.py
```

Undocken Sie beide Roboter, damit die Odometrie läuft:

```bash
ros2 action send_goal /robot_1/undock irobot_create_msgs/action/Undock "{}"
ros2 action send_goal /robot_2/undock irobot_create_msgs/action/Undock "{}"
```

### Schritt 3: Zug-Controller auf dem Steuerungs-PC starten

```bash
source /opt/ros/humble/setup.bash
cd ~/Dokumente/turtle_train
python3 src/real_robot_train.py
```

Mit angepassten Parametern:

```bash
python3 src/real_robot_train.py --ros-args \
  -p robot_namespaces:="['robot_1', 'robot_2']" \
  -p follow_distance:=0.8 \
  -p min_safety_distance:=0.35 \
  -p max_linear_speed:=0.3 \
  -p start_poses:="[0.0, 0.0, 0.0, -0.8, 0.0, 0.0]"
```

Erwartete Ausgabe beim Start:

```text
[INFO] Realer Roboter-Zug Controller gestartet! Leader: 'robot_1', Follower: ['robot_2'], ...
[INFO] Warte auf Odometrie beider Roboter, um world -> odom zu kalibrieren ...
[INFO] Kalibrierung 'robot_1': aktuelle Odometrie-Pose x=1.23 y=-0.40 yaw=2.10
[INFO] Kalibrierung 'robot_2': aktuelle Odometrie-Pose x=0.05 y=0.01 yaw=-0.02
[INFO] Statischer Transform world -> robot_1/odom: ...
[INFO] Statischer Transform world -> robot_2/odom: ...
[INFO] Kalibrierung abgeschlossen, Regelung aktiv.
[INFO] 'robot_2': Abstand 0.80 m (Soll 0.80 m), dx=0.80 dy=0.00 -> v=0.00 m/s, w=0.00 rad/s
```

Bleibt die Ausgabe bei *„Kalibrierung: warte auf robot_X/odom -> robot_X/base_link“* stehen, kommen von diesem Roboter keine TF-Daten an (Undock, Namensraum, Netzwerk prüfen). Vor der Kalibrierung werden keine Fahrbefehle gesendet.

Sobald TF-Daten beider Roboter ankommen, meldet der Controller einmal pro Sekunde den aktuellen Zustand:

```text
[INFO] 'robot_2': Abstand 0.81 m (Soll 0.80 m), dx=0.81 dy=0.01 -> v=0.00 m/s, w=0.03 rad/s
```

Erscheint stattdessen dauerhaft *„TF Lookup fehlgeschlagen“*, kommen keine TF-Daten an (Namensraum, Domain ID oder Undock prüfen).

### Schritt 4: Leader fahren

```bash
ros2 run teleop_twist_keyboard teleop_twist_keyboard --ros-args -r __ns:=/robot_1
```

Alternativ per Bluetooth-Controller des TurtleBot 4. **Ergebnis:** `robot_2` folgt `robot_1` automatisch und regelt den Abstand auf 0,8 m ein. Steht der Leader still, kommt der Follower innerhalb des Totbands (±0,1 m) zum Stehen. Fährt der Leader eine Kurve, dreht der Follower zuerst in Richtung des Leaders und fährt dann nach.

Beobachten Sie den Stellbefehl mit:

```bash
ros2 topic echo /robot_2/cmd_vel
```

---

## ⚙️ 4. Parameter

| Parameter | Standard | Bedeutung |
| --- | --- | --- |
| `robot_namespaces` | `['robot_1', 'robot_2']` | Reihenfolge im Zug, erster Eintrag ist der Leader |
| `follow_distance` | `0.8` | Soll-Abstand in Metern |
| `min_safety_distance` | `0.35` | Not-Halt-Abstand in Metern |
| `max_linear_speed` | `0.4` | Maximale Lineargeschwindigkeit in m/s |
| `max_angular_speed` | `1.0` | Maximale Winkelgeschwindigkeit in rad/s |
| `kp_linear`, `kp_angular` | `1.2`, `3.0` | Verstärkungen des P-Reglers |
| `deadband_distance` | `0.1` | Totband um den Soll-Abstand in Metern |
| `allow_reverse` | `false` | Rückwärtsfahren erlauben |
| `max_transform_age` | `0.5` | Maximales Alter der TF-Daten in Sekunden |
| `start_poses` | `[0, 0, 0, -0.8, 0, 0]` | Formation beim Start: Pose (x, y, yaw) je Roboter im `world`-Frame |
| `calibrate_on_start` | `true` | `world -> odom` aus der aktuellen Odometrie so bestimmen, dass die Roboter jetzt in `start_poses` stehen. `false`: `start_poses` direkt als `world -> odom` verwenden (nur korrekt, wenn die Odometrie in der Formation genullt wurde) |
| `publish_world_to_odom` | `true` | Auf `false` setzen, wenn eine gemeinsame Karte/Lokalisierung den TF-Baum bereits verbindet |
| `base_frame_suffix`, `odom_frame_suffix` | `base_link`, `odom` | Frame-Namen hinter dem Namensraum |

---

## ⚠️ 5. Sicherheitshinweise & Not-Halt

1. **Sicherheitsabstand:** Unterschreitet der Abstand `min_safety_distance`, sendet der Controller sofort einen Null-Twist.  
2. **TF-Ausfall:** Bricht das WLAN ab oder sind die TF-Daten älter als `max_transform_age`, stoppt der Follower. Zusätzlich stoppt die Create-3-Basis selbstständig, wenn keine `cmd_vel`-Nachrichten mehr ankommen.  
3. **Kein blindes Rückwärtsfahren:** Standardmäßig fährt der Follower nur vorwärts. Ist er zu nah, wartet er, bis der Leader weiterfährt.  
4. **Manueller Eingriff:** `Ctrl+C` im Controller-Terminal sendet einen letzten Stopp an alle Follower. Die Stop-Taste am Bluetooth-Controller bzw. der Netzschalter des TurtleBot 4 bleiben die letzte Instanz.  
5. **Geschwindigkeit:** Für erste Versuche `max_linear_speed:=0.2` verwenden.  
