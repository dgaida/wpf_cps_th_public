# Funktionsweise der Zug-Steuerung (Turtle Train)

Diese Dokumentation beschreibt die Funktionsweise und Software-Architektur des **Turtlesim Zug-Controllers** (`turtle_train_sim.py`). Das System ermöglicht eine geordnete Formationsfahrt, bei der nachfolgende Schildkröten (`turtle2`, `turtle3`, ...) der Führungsschildkröte (`turtle1`) in einem definierten Abstand folgen.

---

## 🏗️ Systemarchitektur & TF2-Kommunikation

Die Koordination der Schildkröten basiert auf dem **ROS 2 TF2 Transformation Framework**. Das System besteht aus drei Hauptkomponenten:

1. **Pose Subscribers (`/turtleX/pose`):** Empfangen kontinuierlich die aktuelle 2D-Position ($x, y$) und Orientierung ($\theta$) jeder Schildkröte.  
2. **Transform Broadcasters (`world` $\rightarrow$ `turtleX`):** Konvertieren die 2D-Pose in eine 3D-Transformation (`TransformStamped`) inklusive Euler-zu-Quaternion-Umrechnung und senden diese an das globale TF2-Netzwerk.  
3. **Transform Listeners & Regler (`lookup_transform`):** Der Controller fragt für jedes nachfolgende Schildkröten-Paar die relative Position des Vorgängers im lokalen Koordinatensystem des Nachfolgers ab.  

### Kommunikationsstruktur (Mermaid-Diagramm)

```mermaid
graph TD
    subgraph Turtlesim Node
        T1[turtle1 Pose]
        T2[turtle2 Pose]
        T3[turtle3 Pose]
    end

    subgraph TF2 Broadcaster
        B1[Broadcaster turtle1]
        B2[Broadcaster turtle2]
        B3[Broadcaster turtle3]
    end

    subgraph Controller Loop 20 Hz
        TFBuffer[(TF2 Buffer)]
        Lookup[TF Lookup: turtle2 in turtle1 frame]
        Regler[P-Regler compute_follower_control]
    end

    T1 -->|/turtle1/pose| B1
    T2 -->|/turtle2/pose| B2
    T3 -->|/turtle3/pose| B3

    B1 -->|Transform: world -> turtle1| TFBuffer
    B2 -->|Transform: world -> turtle2| TFBuffer
    B3 -->|Transform: world -> turtle3| TFBuffer

    TFBuffer -->|Relative Translation dx, dy| Lookup
    Lookup --> Regler
    Regler -->|/turtle2/cmd_vel| T2
    Regler -->|/turtle3/cmd_vel| T3
```

---

## 🧮 Regelungsalgorithmus

Der Algorithmus `compute_follower_control` berechnet auf Basis der relativen Position $(dx, dy)$ des Vorgängers im lokalen Bezugssystem des Nachfolgers die Steuerbefehle (Lineargeschwindigkeit $v$ und Winkelgeschwindigkeit $\omega$).

```mermaid
sequenceDiagram
    autonumber
    participant Controller as TurtleTrainSimController
    participant TF as TF2 Buffer
    participant Turtle2 as /turtle2/cmd_vel

    loop Alle 50 ms (20 Hz)
        Controller->>TF: lookup_transform("turtle2", "turtle1")
        TF-->>Controller: Transform (dx, dy)
        Controller->>Controller: compute_follower_control(dx, dy, distance_offset)
        Controller->>Turtle2: Publish Twist (v_linear, w_angular)
    end
```

### 1. Distanz- und Winkelfehler

Der euklidische Abstand $d$ zum Vorgänger berechnet sich durch:

$$d = \sqrt{dx^2 + dy^2}$$

Der Distanzfehler $e_{\text{dist}}$ bezüglich des Soll-Abstands $d_{\text{offset}}$ lautet:

$$e_{\text{dist}} = d - d_{\text{offset}}$$

Der Ausrichtungsfehler $e_{\text{angle}}$ (Winkel zum Ziel im lokalen Koordinatensystem) berechnet sich über den Arkustangens:

$$e_{\text{angle}} = \text{atan2}(dy, dx)$$

Der Winkel wird anschließend mithilfe von `normalize_angle` auf den Bereich $[-\pi, \pi]$ normiert.

### 2. Proportional-Regler (P-Regler)

Die Stellgrößen berechnen sich mit den Verstärkungsfaktoren $K_{p, \text{linear}}$ und $K_{p, \text{angular}}$:

$$v_{\text{linear}} = K_{p, \text{linear}} \cdot e_{\text{dist}}$$

$$\omega_{\text{angular}} = K_{p, \text{angular}} \cdot e_{\text{angle}}$$

### 3. Totband (Deadband) & Geschwindigkeitsbegrenzung

- **Totband:** Um unruhiges Schwingen bei sehr kleinen Abstandsfehlern zu vermeiden, wird die Lineargeschwindigkeit auf $0$ gesetzt, wenn $|e_{\text{dist}}| < d_{\text{deadband}}$ (z. B. $0{,}05\,\text{m}$).  
- **Clamping:** Lineare und winkelbezogene Geschwindigkeiten werden auf Maximalwerte begrenzt:  

$$v_{\text{linear}} \in [-v_{\text{max}}, v_{\text{max}}], \quad \omega_{\text{angular}} \in [-\omega_{\text{max}}, \omega_{\text{max}}]$$

---

## 🔗 Weiterführende Informationen

- Implementierung (Aufgabe 1): `praktikum/turtle_train/src/turtle_train_sim.py`  
- Übertragung auf reale Hardware: [Anleitung für reale Hardware](reale_hardware.md)  
