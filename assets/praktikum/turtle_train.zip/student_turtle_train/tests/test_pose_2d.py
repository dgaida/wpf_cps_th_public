"""Self-check tests for task 2a (_compose_2d and _invert_2d in src/real_robot_train.py)."""

import math

import pytest

from src.real_robot_train import RealRobotTrainController

compose = RealRobotTrainController._compose_2d
invert = RealRobotTrainController._invert_2d


def assert_pose(actual, expected) -> None:
    """Compare two (x, y, yaw) poses, the angle modulo 2*pi."""
    assert actual[0] == pytest.approx(expected[0], abs=1e-9)
    assert actual[1] == pytest.approx(expected[1], abs=1e-9)
    assert math.cos(actual[2]) == pytest.approx(math.cos(expected[2]), abs=1e-9)
    assert math.sin(actual[2]) == pytest.approx(math.sin(expected[2]), abs=1e-9)


def test_compose_with_identity() -> None:
    """Composing with the zero pose changes nothing."""
    p = (1.0, -2.0, 0.7)
    assert_pose(compose(p, (0.0, 0.0, 0.0)), p)
    assert_pose(compose((0.0, 0.0, 0.0), p), p)


def test_compose_rotates_the_second_translation() -> None:
    """A step of 1 m forward after a 90 degree turn moves along +y."""
    assert_pose(compose((2.0, 1.0, math.pi / 2.0), (1.0, 0.0, 0.0)), (2.0, 2.0, math.pi / 2.0))


@pytest.mark.parametrize("p", [(1.0, 2.0, 0.0), (-0.5, 0.3, 1.2), (3.0, -1.0, -2.8)])
def test_invert_gives_identity(p) -> None:
    """p * p^-1 and p^-1 * p are the zero pose."""
    assert_pose(compose(p, invert(p)), (0.0, 0.0, 0.0))
    assert_pose(compose(invert(p), p), (0.0, 0.0, 0.0))


def test_calibration_places_robot_at_start_pose() -> None:
    """world->odom = start * (odom->base)^-1 puts the robot exactly at its start pose in the world frame."""
    start = (-0.8, 0.0, 0.0)
    odom_to_base = (1.23, -0.4, 2.1)
    world_to_odom = compose(start, invert(odom_to_base))
    assert_pose(compose(world_to_odom, odom_to_base), start)
