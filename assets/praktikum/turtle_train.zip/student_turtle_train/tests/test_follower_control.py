"""Self-check tests for task 1a (compute_follower_control in src/turtle_train_sim.py) and the quaternion helper."""

import math

import pytest

from src.turtle_tf2_broadcaster import euler_to_quaternion
from src.turtle_train_sim import compute_follower_control, normalize_angle


class TestTurtleTrainMath:
    """Tests for geometric and control loop math functions in turtle_train."""

    def test_euler_to_quaternion_zero(self) -> None:
        """Verify quaternion for identity orientation (0, 0, 0)."""
        qx, qy, qz, qw = euler_to_quaternion(0.0, 0.0, 0.0)
        assert pytest.approx(qx) == 0.0
        assert pytest.approx(qy) == 0.0
        assert pytest.approx(qz) == 0.0
        assert pytest.approx(qw) == 1.0

    def test_euler_to_quaternion_yaw(self) -> None:
        """Verify quaternion for 90 degree yaw rotation."""
        yaw = math.pi / 2.0
        qx, qy, qz, qw = euler_to_quaternion(0.0, 0.0, yaw)
        assert pytest.approx(qx) == 0.0
        assert pytest.approx(qy) == 0.0
        assert pytest.approx(qz) == math.sin(math.pi / 4.0)
        assert pytest.approx(qw) == math.cos(math.pi / 4.0)

    def test_normalize_angle(self) -> None:
        """Test angle normalization to [-pi, pi]."""
        assert pytest.approx(normalize_angle(0.0)) == 0.0
        assert pytest.approx(normalize_angle(math.pi)) == math.pi
        assert pytest.approx(normalize_angle(-math.pi)) == -math.pi
        assert pytest.approx(normalize_angle(3.0 * math.pi)) == math.pi
        assert pytest.approx(normalize_angle(-3.0 * math.pi)) == -math.pi

    def test_compute_follower_control_straight_ahead(self) -> None:
        """Test controller when predecessor is straight ahead at 2.0m with offset 1.0m."""
        v, w = compute_follower_control(
            dx=2.0,
            dy=0.0,
            distance_offset=1.0,
            kp_linear=1.5,
            kp_angular=6.0,
            max_linear_speed=2.0,
        )
        assert v > 0.0
        assert pytest.approx(w) == 0.0
        assert pytest.approx(v) == 1.5

    def test_compute_follower_control_in_deadband(self) -> None:
        """Test controller when follower is already at desired distance offset."""
        v, w = compute_follower_control(
            dx=1.0,
            dy=0.0,
            distance_offset=1.0,
            deadband_distance=0.05,
        )
        assert pytest.approx(v) == 0.0
        assert pytest.approx(w) == 0.0

    def test_compute_follower_control_angle_turn(self) -> None:
        """Test controller output when predecessor is to the left."""
        v, w = compute_follower_control(
            dx=1.0,
            dy=1.0,
            distance_offset=1.0,
            kp_angular=2.0,
        )
        assert v > 0.0
        assert w > 0.0  # Turn left towards predecessor

    def test_compute_follower_control_speed_limits(self) -> None:
        """Test speed limit clamping in follower controller."""
        v, w = compute_follower_control(
            dx=10.0,
            dy=10.0,
            distance_offset=1.0,
            kp_linear=5.0,
            kp_angular=10.0,
            max_linear_speed=1.5,
            max_angular_speed=2.0,
        )
        assert pytest.approx(v) == 1.5
        assert pytest.approx(w) == 2.0
