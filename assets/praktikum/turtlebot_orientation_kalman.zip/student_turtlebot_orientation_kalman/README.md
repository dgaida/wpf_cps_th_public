# Praktikum: Orientierungsschätzung für den TurtleBot 4 mit Nicla Sense ME & Kalman-Filter

Der **TurtleBot 4** bekommt einen zusätzlichen Sensor: den **Arduino Nicla Sense ME** mit Beschleunigungssensor, Gyroskop und Magnetometer. Aus dessen Daten schätzen Sie die Orientierung des Roboters – vor allem den Gierwinkel $\psi$ – und vergleichen sie mit der Odometrie des TurtleBots.

```text
Nicla Sense ME ──USB──► Raspberry Pi (ROS 2) ──► /nicla/imu, /nicla/mag ─┐
                                                                         ├─► FQA ─► Kalman-Filter ─► Vergleich & Plots
TurtleBot-Odometrie ─────────────────────────────► /odom ────────────────┘
```

- **FQA** (Factored Quaternion Algorithm) berechnet aus Beschleunigung und Magnetfeld eine absolute, aber verrauschte und störanfällige Orientierung.  
- Das **Kalman-Filter** integriert die Drehraten des Gyroskops, korrigiert mit der FQA-Messung und schätzt dabei den Gyroskop-Bias.  

---

## 📂 Unterlagen

- [**Aufgabenstellung**](./docs/aufgabenstellung.md) – Modell, fünf Aufgaben, erwartete Ergebnisse  
- [**Theorie**](./docs/theorie.md) – Herleitung von FQA und Kalman-Filter  
- [**Inbetriebnahme am Roboter**](./docs/inbetriebnahme.md) – Sketch, ROS-2-Knoten, Montage-Kalibrierung  

---

## 🧱 Gerüst oder eigene Struktur

Sie haben zwei Möglichkeiten:

- **Mit dem Gerüst:** Sie lösen die mit `TODO` markierten Stellen in der vorgegebenen Struktur.  
- **Von Grund auf:** Sie setzen das Projekt mit eigener Struktur um. Die bereitgestellten Teile dürfen Sie übernehmen oder als Nachschlagewerk nutzen. Aufgabenstellung und erwartete Ergebnisse gelten für beide Wege.  

| Datei | Inhalt | Status |
|---|---|---|
| [`src/arduino/`](./src/arduino/) | Sketch für den Nicla: Sensoren mit 100 Hz als JSON über USB | fertig |
| [`src/turtlebot/synthetic_data.py`](./src/turtlebot/synthetic_data.py) | synthetische Sensordaten mit wahrem Gierwinkel | fertig |
| [`calibrate_mount.py`](./calibrate_mount.py) | Einbaulage des Sensors am Roboter bestimmen | fertig |
| [`src/turtlebot/mount_calibration.py`](./src/turtlebot/mount_calibration.py) | Einbaulage aus den Messdaten berechnen (fertig), Rotationsmatrizen | **TODO (Aufgabe 2a)** |
| [`src/turtlebot/nicla_receiver_node.py`](./src/turtlebot/nicla_receiver_node.py) | serielle Daten lesen und als ROS-2-Topics veröffentlichen | **TODO (Aufgabe 1)** |
| [`src/turtlebot/fqa_filter.py`](./src/turtlebot/fqa_filter.py) | Quaternion-Hilfsfunktionen und FQA | **TODO (Aufgabe 2a, 2b)** |
| [`src/turtlebot/kalman_filter.py`](./src/turtlebot/kalman_filter.py) | Kalman-Filter | **TODO (Aufgabe 3)** |
| [`src/turtlebot/orientation_comparator_node.py`](./src/turtlebot/orientation_comparator_node.py) | Filterschritt und Vergleich mit der Odometrie | **TODO (Aufgabe 4)** |
| [`orientation_kalman.py`](./orientation_kalman.py) | Simulation und Live-Betrieb (fertig), Plots | **TODO (Aufgabe 4)** |
| [`tests/`](./tests/) | Selbsttests für Aufgabe 1 bis 4 | fertig |

---

## 🚀 Zuhause entwickeln, am Roboter messen

FQA und Kalman-Filter entwickeln Sie ohne Roboter mit synthetischen Daten (benötigt: `numpy`, `matplotlib`, `pytest`):

```bash
python3 -m pytest tests -v              # Selbsttests; zu Beginn schlagen die TODO-Tests fehl
python3 orientation_kalman.py --sim     # Filter auf synthetischen Daten, Fehler gegen den wahren Gierwinkel
```

Am Roboter (ROS 2 Humble):

```bash
python3 orientation_kalman.py --live --robot robot_2   # Beenden mit Strg+C, dann Auswertung
```

Die Tests sind auf das Gerüst zugeschnitten; bei eigener Struktur schreiben Sie eigene Tests. Die synthetischen Daten bilden einen ebenen, ideal montierten Sensor ab – ob Ihre Lösung am echten Roboter funktioniert, zeigt erst die Messung.
