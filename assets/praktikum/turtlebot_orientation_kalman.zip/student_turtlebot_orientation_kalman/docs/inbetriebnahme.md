# Inbetriebnahme am Roboter

---

## 1. Nicla Sense ME

1. Arduino IDE 2.x, Board-Paket `Arduino Mbed OS Nicla Boards`, Bibliothek `Arduino_BHY2`.  
2. Sketch [`src/arduino/nicla_sensor_stream.ino`](../src/arduino/nicla_sensor_stream.ino) hochladen (Details: [`src/arduino/README.md`](../src/arduino/README.md)).  
3. Im seriellen Monitor (115200 Baud) müssen JSON-Zeilen erscheinen.  
4. Sensor fest auf dem TurtleBot montieren und per USB an dessen Raspberry Pi anschließen.  

---

## 2. ROS-2-Knoten

```bash
# Auf dem Raspberry Pi des TurtleBots: serielle Daten -> /nicla/imu, /nicla/mag
python3 -m src.turtlebot.nicla_receiver_node

# Prüfen (auf dem Pi oder dem eigenen Rechner im selben Netz)
ros2 topic hz /nicla/imu
ros2 topic list | grep odom
```

Im Labor fahren mehrere TurtleBots; ihre Topics tragen einen Namespace, z. B. `/robot_2/odom`. Geben Sie ihn mit `--robot robot_2` an.

---

## 3. Einbaulage kalibrieren

Einmal nach jeder Montage des Sensors:

```bash
python3 calibrate_mount.py --robot robot_2
```

1. Roboter mindestens $2\text{ s}$ ruhig stehen lassen (Neigung aus der Schwerkraft).  
2. Per Teleop zügig geradeaus anfahren und abbremsen, nicht drehen (Gierwinkel der Montage).  

Das Ergebnis steht in `nicla_mount_calibration.yaml` und wird vom Live-Betrieb automatisch geladen. Die Ausgabe nennt eine Konfidenz; liegt sie unter $0{,}5$, wiederholen Sie die Fahrt mit deutlicherem Anfahren und Bremsen.

---

## 4. Messung

```bash
python3 orientation_kalman.py --live --robot robot_2
```

- Die ersten $5\text{ s}$ steht der Roboter still: In dieser Zeit wird der Winkelversatz zur Odometrie geschätzt.  
- Danach fahren Sie den Versuch per Teleop.  
- `Strg+C` beendet die Messung; anschließend erscheinen RMSE und Plots.  

Halten Sie die Fahrfläche frei und bleiben Sie beim Roboter.
