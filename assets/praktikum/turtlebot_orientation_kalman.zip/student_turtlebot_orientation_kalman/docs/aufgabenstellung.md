# Aufgabenstellung: Orientierungsschätzung mit FQA und Kalman-Filter

Die Herleitungen stehen in [theorie.md](./theorie.md). Die Dateinamen beziehen sich auf das bereitgestellte Gerüst; bei eigener Struktur gelten die Aufgaben sinngemäß.

---

## Modell

| Größe | Definition |
|---|---|
| Zustand | $x = [\phi,\ \theta,\ \psi,\ b_{\omega_x},\ b_{\omega_y},\ b_{\omega_z}]^T$ (Roll, Pitch, Gier, Gyroskop-Bias) |
| Eingang | $u = [\omega_x,\ \omega_y,\ \omega_z]^T$ (Gyroskop, rad/s) |
| Messung | $z = [\phi_{FQA},\ \theta_{FQA},\ \psi_{FQA}]^T$ |

$$A = \begin{bmatrix} I_3 & -\Delta t \cdot I_3 \\ 0 & I_3 \end{bmatrix}, \qquad
B = \begin{bmatrix} \Delta t \cdot I_3 \\ 0 \end{bmatrix}, \qquad
C = \begin{bmatrix} I_3 & 0 \end{bmatrix}$$

Startwerte: $Q = \text{diag}(10^{-4}, 10^{-4}, 10^{-4}, 10^{-6}, 10^{-6}, 10^{-6})$, $R = \text{diag}(10^{-2}, 10^{-2}, 10^{-1})$. Der Gierwinkel bekommt das größere Messrauschen, weil das Magnetfeld leicht gestört wird.

---

## Aufgabe 1: Sensorik und ROS-2-Streaming

Datei: [`src/turtlebot/nicla_receiver_node.py`](../src/turtlebot/nicla_receiver_node.py)

Der bereitgestellte Sketch sendet mit $100\text{ Hz}$ eine JSON-Zeile mit Beschleunigung ($\text{m/s}^2$), Drehrate ($\text{rad/s}$) und Magnetfeld ($\mu\text{T}$).

1. Lesen Sie den Sketch und erklären Sie die Umrechnung der Rohwerte in SI-Einheiten.  
2. Implementieren Sie `parse_nicla_line`. Serielle Daten können abgeschnitten oder fehlerhaft sein.  
3. Füllen und veröffentlichen Sie `/nicla/imu` (`sensor_msgs/Imu`) und `/nicla/mag` (`sensor_msgs/MagneticField`, Einheit Tesla).  
4. Prüfen Sie am Roboter mit `ros2 topic hz /nicla/imu`, ob die Daten mit ca. $100\text{ Hz}$ ankommen.  

---

## Aufgabe 2: Orientierung mit Quaternionen und FQA

### 2a: Quaternionen und Rotationsmatrizen

Dateien: [`src/turtlebot/fqa_filter.py`](../src/turtlebot/fqa_filter.py) (`quaternion_multiply`, `quaternion_to_euler`, `euler_to_quaternion`), [`src/turtlebot/mount_calibration.py`](../src/turtlebot/mount_calibration.py) (`rotation_x`, `rotation_y`, `rotation_z`, `rotation_to_euler`)

FQA, Kalman-Filter und Montage-Kalibrierung bauen auf diesen Funktionen auf. Es gelten folgende Konventionen:

- **Quaternion** $q = [w,\ x,\ y,\ z]$; eine Drehung um die Einheitsachse $\vec{n}$ um den Winkel $\alpha$ ist $q = [\cos\tfrac{\alpha}{2},\ \sin\tfrac{\alpha}{2}\,\vec{n}]$.  
- **Hamilton-Produkt** mit $p = [p_w,\ \vec{p}]$ und $q = [q_w,\ \vec{q}]$:  

  $$p \otimes q = \left[\,p_w q_w - \vec{p} \cdot \vec{q},\quad p_w \vec{q} + q_w \vec{p} + \vec{p} \times \vec{q}\,\right]$$

- **Rotationsmatrizen** $R_x(\alpha)$, $R_y(\alpha)$, $R_z(\alpha)$ nach der Rechte-Hand-Regel: Ein positiver Winkel dreht gegen den Uhrzeigersinn, wenn man entgegen der Achse blickt.  
- **Euler-Winkel** in der Reihenfolge ZYX: $R = R_z(\psi)\,R_y(\theta)\,R_x(\phi)$ bzw. $q = q_\psi \otimes q_\theta \otimes q_\phi$.  

Aufgaben:

1. Implementieren Sie die drei Rotationsmatrizen und `quaternion_multiply`.  
2. Multiplizieren Sie $R_z(\psi)\,R_y(\theta)\,R_x(\phi)$ symbolisch aus und lesen Sie daraus ab, aus welchen Matrixelementen sich $\phi$, $\theta$ und $\psi$ zurückgewinnen lassen (`rotation_to_euler`).  
3. Implementieren Sie `euler_to_quaternion` und `quaternion_to_euler` für dieselbe Konvention.  
4. Was passiert bei $\theta = \pm 90^\circ$? Warum sind Roll und Gier dort nicht mehr eindeutig, und wie verhindern Sie, dass `arcsin` durch Rundungsfehler `NaN` liefert?  

### 2b: FQA

Datei: [`src/turtlebot/fqa_filter.py`](../src/turtlebot/fqa_filter.py)

Implementieren Sie `compute_fqa_quaternion`:

1. Neigung aus der Schwerkraft: $\sin\theta = -a_x / g$, $\tan\phi = a_y / a_z$.  
2. Magnetfeldvektor mit Roll und Pitch in die Horizontalebene drehen ($\vec{m}'$).  
3. Gierwinkel $\psi = \text{atan2}(-m'_y,\ m'_x)$.  
4. $q_{FQA} = q_\psi \otimes q_\theta \otimes q_\phi$.  

Prüfen Sie die Winkel am Sensor durch Neigen und Drehen von Hand.

---

## Aufgabe 3: Kalman-Filter

Datei: [`src/turtlebot/kalman_filter.py`](../src/turtlebot/kalman_filter.py)

**Prädiktion** mit den Gyroskop-Drehraten:

$$\hat{x}_k^- = A \hat{x}_{k-1} + B u_k, \qquad P_k^- = A P_{k-1} A^T + Q$$

**Korrektur** mit der FQA-Messung:

$$K_k = P_k^- C^T (C P_k^- C^T + R)^{-1}, \qquad \hat{x}_k = \hat{x}_k^- + K_k (z_k - C \hat{x}_k^-), \qquad P_k = (I - K_k C) P_k^-$$

Der Gierwinkel springt bei $\pm\pi$. Normieren Sie das Residuum $z_k - C \hat{x}_k^-$ auf $[-\pi, \pi)$, sonst dreht das Filter an dieser Stelle einmal um die ganze Achse.

Testen Sie mit `python3 orientation_kalman.py --sim`: Die synthetischen Daten enthalten einen Gyroskop-Bias von $0{,}05\text{ rad/s}$ und zwischen $12\text{ s}$ und $17\text{ s}$ eine Magnetfeldstörung.

---

## Aufgabe 4: Vergleich mit der Odometrie

Dateien: [`src/turtlebot/orientation_comparator_node.py`](../src/turtlebot/orientation_comparator_node.py), [`orientation_kalman.py`](../orientation_kalman.py)

1. **`process_step`:** Bei jedem IMU-Datensatz FQA, Prädiktion und Korrektur ausführen und die Ergebnisse aufzeichnen.  
2. **`_update_yaw_offset`:** Die Odometrie startet beim Einschalten bei $0$, der Magnetometer-Gierwinkel bezieht sich auf magnetisch Nord. Beide unterscheiden sich um einen konstanten Winkel, den Sie in den ersten Sekunden im Stand schätzen.  
3. **`plot_results`:** drei Diagramme über der Zeit – Gierwinkel von Referenz, FQA und Kalman-Filter; Betrag der Abweichung $|\psi_{Kalman} - \psi_{Ref}|$; geschätzter Bias $b_{\omega_z}$.  

**Einbaulage:** Der Sensor ist nicht exakt in Roboterrichtung montiert, eventuell liegt er auf dem Kopf. Bestimmen Sie die Einbaulage vor den Messungen mit `calibrate_mount.py` ([Inbetriebnahme](./inbetriebnahme.md)); der Knoten dreht dann alle Sensorvektoren in das Roboter-Koordinatensystem.

---

## Aufgabe 5: Experimente und Reflexion

Fahrversuche mit dem TurtleBot, jeweils mit Plots und RMSE gegen die Odometrie:

- **Test A:** Drehung auf der Stelle um $360^\circ$.  
- **Test B:** Zick-Zack-Fahrt mit schnellen Richtungswechseln.  
- **Test C:** Vorbeifahrt an eisenhaltigen Gegenständen (Tischbeine, Heizkörper).  

Fragen:

1. Wie verhält sich FQA bei starken Beschleunigungen des Roboters, und warum?  
2. Wie entwickelt sich die Schätzung von $b_{\omega_z}$ im Stand und während der Fahrt?  
3. Variieren Sie $R$ und $Q$: Wie verändern sich Einschwingverhalten und Reaktion auf Magnetfeldstörungen?  
4. Die Odometrie ist selbst keine perfekte Referenz. Woran erkennen Sie das in Ihren Messungen?  
5. Wo weichen die Ergebnisse am Roboter von der Simulation ab?  

---

## Erwartete Ergebnisse

- Bestandene Selbsttests (bzw. eigene Tests bei eigener Struktur).  
- Plots und RMSE aus der Simulation sowie aus den Tests A bis C.  
- Antworten auf die Fragen aus Aufgabe 1 und 5.  
