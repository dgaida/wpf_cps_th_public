# Theoretische Grundlagen & Algorithmen: Orientierungsschätzung mittels FQA und Kalman-Filter

Diese Dokumentation beschreibt die mathematischen Grundlagen, Algorithmen und Systemgleichungen für die Orientierungsschätzung des TurtleBot 4 unter Verwendung der Inertialmesseinheit (IMU) und des Magnetometers des Arduino Nicla Sense ME.

---

## 📑 Inhaltsverzeichnis  
1. [Einordnung: Rolle des Gyroskops im Kalman-Filter](#1-einordnung-rolle-des-gyroskops-im-kalman-filter)  
2. [Factored Quaternion Algorithm (FQA)](#2-factored-quaternion-algorithm-fqa)  
3. [Kalman-Filter System- und Messmodell](#3-kalman-filter-system--und-messmodell)  
4. [Literatur & Referenzen](#4-literatur--referenzen)  

---

## 1. Einordnung: Rolle des Gyroskops im Kalman-Filter

Eine häufige Frage beim Entwurf von Kalman-Filtern für Orientierungsschätzungen (AHRS / Sensorfusion) lautet:
*„Ist die gemessene Gyroskop-Winkelgeschwindigkeit nicht auch Teil des Messmodells $C$?“*

### Antwort & Konzept
In der klassischen IMU-Sensorfusion wird das **Gyroskop NICHT als Messung im Messmodell $C$** verwendet, sondern dient als **Systemeingang $u_k$ im Prädiktionsschritt (Prozessmodell)**:

1. **Prädiktion (Prozessmodell):**  
   Das Gyroskop misst die Winkelgeschwindigkeiten $\vec{\omega}_{meas} = [\omega_x, \omega_y, \omega_z]^T$ mit hoher Abtastrate und geringem Rauschen. Diese Messwerte treiben das Systemmodell an, d. h. sie werden zeitlich integriert, um die Orientierung $(\phi, \theta, \psi)$ fortzuschreiben. Gyroskope unterliegen jedoch einer Drift (Gyro-Bias $b_\omega$), wodurch die reine Integration über die Zeit abweicht.

2. **Korrektur (Messmodell $C$):**  
   Der **Factored Quaternion Algorithm (FQA)** berechnet aus den Beschleunigungssensor- ($\vec{a}$) und Magnetometerdaten ($\vec{m}$) eine absolut orientierte Beobachtung $z_k = [\phi_{FQA}, \theta_{FQA}, \psi_{FQA}]^T$. Das Messmodell $C$ vergleicht diesen FQA-Zustand direkt mit dem geschätzten Systemzustand $x_k$, um die Drift des Gyroskops zu korrigieren und den Gyro-Bias $b_\omega$ schätzbar zu machen.

---

## 2. Factored Quaternion Algorithm (FQA)

Der **Factored Quaternion Algorithm (FQA)** bestimmt das Orientierungsquaternion $q = [q_w, q_x, q_y, q_z]^T$ entkoppelt aus Beschleunigungs- und Magnetometerdaten. Im Gegensatz zu vereinfachten Euler-Winkel-Berechnungen verhindert FQA, dass Neigungswinkel (Pitch und Roll) die Azimut-/Gierwinkelbestimmung (Yaw) verfälschen.

### Schritt 1: Roll ($\phi$) und Pitch ($\theta$) aus Beschleunigungssensor
Unter der Annahme quasistatischer Bewegung misst der Beschleunigungssensor $\vec{a} = [a_x, a_y, a_z]^T$ vorwiegend die Erdbeschleunigung $\vec{g}$:

$$
\sin\theta = -\frac{a_x}{g}, \quad \tan\phi = \frac{a_y}{a_z}
$$

Daraus ergeben sich die Neigungsquaternionen für Pitch $q_\theta$ und Roll $q_\phi$:

$$
q_\theta = \left[\cos\left(\frac{\theta}{2}\right), \, 0, \, \sin\left(\frac{\theta}{2}\right), \, 0\right]^T
$$

$$
q_\phi = \left[\cos\left(\frac{\phi}{2}\right), \, \sin\left(\frac{\phi}{2}\right), \, 0, \, 0\right]^T
$$

### Schritt 2: Transformation der Magnetometerdaten
Das vom Magnetometer gemessene Vektorfeld $\vec{m} = [m_x, m_y, m_z]^T$ wird durch das Neigungsquaternion $q_{\theta\phi} = q_\theta \otimes q_\phi$ in die Horizontalebene rotiert:

$$
\vec{m}' = q_{\theta\phi}^{-1} \otimes \vec{m} \otimes q_{\theta\phi}
$$

### Schritt 3: Yaw ($\psi$) aus horizontalem Magnetfeld
Aus den transformierten Komponenten $m'_x$ und $m'_y$ wird der raumbezogene Gierwinkel $\psi$ ermittelt:

$$
\cos\psi = \frac{m'_x}{\sqrt{(m'_x)^2 + (m'_y)^2}}, \quad \sin\psi = \frac{-m'_y}{\sqrt{(m'_x)^2 + (m'_y)^2}}
$$

$$
q_\psi = \left[\cos\left(\frac{\psi}{2}\right), \, 0, \, 0, \, \sin\left(\frac{\psi}{2}\right)\right]^T
$$

### Schritt 4: Gesamt-Quaternion
Das resultierende FQA-Quaternion ergibt sich durch Multiplikation der Teilquaternionen:

$$
q_{FQA} = q_\psi \otimes q_\theta \otimes q_\phi
$$

Aus $q_{FQA}$ lassen sich die gefilterten Winkel $\phi_{FQA}, \theta_{FQA}, \psi_{FQA}$ eindeutig extrahieren.

---

## 3. Kalman-Filter System- und Messmodell

### Zustandsvektor $x_k$
Der Zustandsvektor $x_k \in \mathbb{R}^6$ umfasst die drei Orientierungswinkel (Euler-Winkel: Roll $\phi$, Pitch $\theta$, Yaw $\psi$) sowie die drei langsam variierenden Gyroskop-Biases $b_{\omega_x}, b_{\omega_y}, b_{\omega_z}$:

$$
x_k = \begin{bmatrix} \phi_k \\ \theta_k \\ \psi_k \\ b_{\omega_x, k} \\ b_{\omega_y, k} \\ b_{\omega_z, k} \end{bmatrix}
$$

### Systemgleichungen (Prozessmodell)
Die kontinuierliche Kinematik für die Orientierungswinkel lautet (unter der Annahme moderner ebener Bewegung bzw. kleiner Neigungswinkel):

$$
\dot{\phi} = \omega_x - b_{\omega_x} + w_\phi
$$

$$
\dot{\theta} = \omega_y - b_{\omega_y} + w_\theta
$$

$$
\dot{\psi} = \omega_z - b_{\omega_z} + w_\psi
$$

$$
\dot{b}_\omega = w_b
$$

In diskreter Form mit Abtastzeit $\Delta t$ ergibt sich das Systemmodell:

$$
x_k = A x_{k-1} + B u_k + w_{k-1}
$$

wobei der Steuerungs-/Eingangsvektor $u_k \in \mathbb{R}^3$ die Rohmessungen des Gyroskops enthält:

$$
u_k = \begin{bmatrix} \omega_{x, k} \\ \omega_{y, k} \\ \omega_{z, k} \end{bmatrix}
$$

#### Systemmatrix $A \in \mathbb{R}^{6 \times 6}$
$$
A = \begin{bmatrix}
1 & 0 & 0 & -\Delta t & 0 & 0 \\
0 & 1 & 0 & 0 & -\Delta t & 0 \\
0 & 0 & 1 & 0 & 0 & -\Delta t \\
0 & 0 & 0 & 1 & 0 & 0 \\
0 & 0 & 0 & 0 & 1 & 0 \\
0 & 0 & 0 & 0 & 0 & 1
\end{bmatrix}
$$

#### Steuermatrix $B \in \mathbb{R}^{6 \times 3}$
$$
B = \begin{bmatrix}
\Delta t & 0 & 0 \\
0 & \Delta t & 0 \\
0 & 0 & \Delta t \\
0 & 0 & 0 \\
0 & 0 & 0 \\
0 & 0 & 0
\end{bmatrix}
$$

#### Prozessrausch-Kovarianz matrix $Q \in \mathbb{R}^{6 \times 6}$
$$
Q = \text{diag}\left(\sigma_{\omega}^2 \Delta t^2, \, \sigma_{\omega}^2 \Delta t^2, \, \sigma_{\omega}^2 \Delta t^2, \, \sigma_{b}^2 \Delta t, \, \sigma_{b}^2 \Delta t, \, \sigma_{b}^2 \Delta t\right)
$$

---

### Messgleichungen (Messmodell)
Als Messgröße $z_k \in \mathbb{R}^3$ dient der aus FQA ermittelte Orientierungsvektor:

$$
z_k = \begin{bmatrix} \phi_{FQA, k} \\ \theta_{FQA, k} \\ \psi_{FQA, k} \end{bmatrix}
$$

Die Messgleichung lautet:

$$
z_k = C x_k + v_k
$$

#### Messmatrix $C \in \mathbb{R}^{3 \times 6}$
$$
C = \begin{bmatrix}
1 & 0 & 0 & 0 & 0 & 0 \\
0 & 1 & 0 & 0 & 0 & 0 \\
0 & 0 & 1 & 0 & 0 & 0
\end{bmatrix} = \begin{bmatrix} I_{3\times 3} & 0_{3\times 3} \end{bmatrix}
$$

#### Messrausch-Kovarianzmatrix $R \in \mathbb{R}^{3 \times 3}$
$$
R = \begin{bmatrix}
\sigma_{\phi, FQA}^2 & 0 & 0 \\
0 & \sigma_{\theta, FQA}^2 & 0 \\
0 & 0 & \sigma_{\psi, FQA}^2
\end{bmatrix}
$$

---

## 4. Literatur & Referenzen

* **FQA Originalpaper:**  
  Yun, X., Bachmann, E. R., & McGhee, R. B. (2008). *A Simplified Quaternion-Based Algorithm for Orientation Estimation From Body-Mounted Sensors*. IEEE Transactions on Robotics, 24(5), 1022–1036.
  [DOI: 10.1109/TRO.2008.2003271](https://doi.org/10.1109/TRO.2008.2003271)

* **Kalman Filtering & AHRS:**  
  Yun, X., & Bachmann, E. R. (2006). *Design, Implementation, and Experimental Results of a Quaternion-Based Kalman Filter for Human Body Motion Tracking*. IEEE Transactions on Robotics, 22(6), 1216–1227.
