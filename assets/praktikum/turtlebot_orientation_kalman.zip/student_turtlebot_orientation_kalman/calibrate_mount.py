#!/usr/bin/env python3
"""Provided tool: determine how the Nicla Sense ME is mounted on the TurtleBot.

The sensor is mounted with an unknown, constant rotation relative to the robot (e.g. upside down
or turned about the vertical axis). This script estimates the rotation sensor -> robot and stores
it in nicla_mount_calibration.yaml, which orientation_kalman.py --live loads automatically.

    python3 calibrate_mount.py --robot robot_2

Phase 1: leave the robot at rest for at least 2 s (tilt from gravity).
Phase 2: drive straight ahead by teleop, accelerate and brake briskly, do not turn (yaw from the
         horizontal acceleration compared with the odometry).
"""

import argparse
import sys
from pathlib import Path
from typing import Any, Optional

import numpy as np

from src.turtlebot.mount_calibration import MountCalibrator

try:
    import rclpy
    from rclpy.node import Node
    from sensor_msgs.msg import Imu
    from nav_msgs.msg import Odometry
    ROS2_AVAILABLE = True
except ImportError:
    ROS2_AVAILABLE = False
    Node = object

DEFAULT_CALIB_FILE = Path(__file__).parent.resolve() / "nicla_mount_calibration.yaml"


class MountCalibrationNode(Node if ROS2_AVAILABLE else object):
    """Records IMU and odometry samples and estimates the mounting rotation of the Nicla.

    Standstill samples feed the tilt estimate, straight driving samples the yaw estimate; the
    phases are detected automatically from the odometry twist.
    """

    def __init__(self, imu_topic: str = "/nicla/imu", odom_topic: str = "/odom") -> None:
        super().__init__("mount_calibration_node")
        self.calibrator = MountCalibrator()
        self.odom_received = False
        self.latest_odom_v = 0.0
        self.latest_odom_w = 0.0
        self.latest_odom_accel = 0.0
        self._last_odom_t: Optional[float] = None
        self.create_subscription(Imu, imu_topic, self._imu_callback, 10)
        self.create_subscription(Odometry, odom_topic, self._odom_callback, 10)

    def _odom_callback(self, msg: Any) -> None:
        t = msg.header.stamp.sec + msg.header.stamp.nanosec * 1e-9
        v = float(msg.twist.twist.linear.x)
        if self._last_odom_t is not None and t > self._last_odom_t:
            raw_accel = (v - self.latest_odom_v) / (t - self._last_odom_t)
            self.latest_odom_accel = 0.7 * self.latest_odom_accel + 0.3 * raw_accel
        self._last_odom_t = t
        self.latest_odom_v = v
        self.latest_odom_w = float(msg.twist.twist.angular.z)
        self.odom_received = True

    def _imu_callback(self, msg: Any) -> None:
        if not self.odom_received:
            return
        accel = np.array([msg.linear_acceleration.x, msg.linear_acceleration.y, msg.linear_acceleration.z])
        gyro = np.array([msg.angular_velocity.x, msg.angular_velocity.y, msg.angular_velocity.z])
        self.calibrator.add_sample(accel, gyro, self.latest_odom_v, self.latest_odom_w, self.latest_odom_accel)

    def ready(self) -> bool:
        return self.calibrator.tilt_ready() and self.calibrator.yaw_ready()


def run_calibration(imu_topic: str, odom_topic: str, calib_file: Path, timeout: float = 90.0) -> None:
    """Runs the calibration and stores the result as YAML.

    Args:
        imu_topic: Topic of the Nicla IMU messages.
        odom_topic: Topic of the TurtleBot odometry.
        calib_file: Output YAML file.
        timeout: Abort after this many seconds without sufficient data.
    """
    if not ROS2_AVAILABLE:
        sys.exit("ROS 2 (rclpy) ist nicht verfügbar. Bitte zuerst ROS 2 sourcen.")

    rclpy.init()
    node = MountCalibrationNode(imu_topic=imu_topic, odom_topic=odom_topic)
    print("Montage-Kalibrierung des Nicla Sense ME")
    print(f"  IMU: {imu_topic}   Odom: {odom_topic}")
    print("  Phase 1: Roboter mind. 2 s ruhig stehen lassen.")
    print("  Phase 2: per Teleop zügig geradeaus anfahren und abbremsen (nicht drehen).")
    print("  Abbruch mit Ctrl-C (dann wird nur die Neigung gespeichert, falls vorhanden).")

    def _status() -> None:
        c = node.calibrator
        if not node.odom_received:
            node.get_logger().warn(f"Noch keine Odometrie auf {odom_topic}.")
            return
        node.get_logger().info(
            f"Stillstand {c.n_still}/{c.min_still} | Fahrt {c.n_drive}/{c.min_drive} "
            f"(Beschl.-Energie {c.accel_energy:.1f}) | v={node.latest_odom_v:.2f} m/s"
        )

    node.create_timer(1.0, _status)
    t0 = node.get_clock().now().nanoseconds * 1e-9
    require_yaw = True
    try:
        while rclpy.ok():
            rclpy.spin_once(node, timeout_sec=0.1)
            if node.ready():
                break
            if node.get_clock().now().nanoseconds * 1e-9 - t0 > timeout:
                print("Timeout: nicht genügend Daten für die Yaw-Schätzung.")
                require_yaw = False
                break
    except KeyboardInterrupt:
        require_yaw = False

    try:
        calib = node.calibrator.compute(require_yaw=require_yaw)
    except ValueError as exc:
        node.destroy_node()
        rclpy.shutdown()
        sys.exit(f"Kalibrierung fehlgeschlagen: {exc}")
    node.destroy_node()
    if rclpy.ok():
        rclpy.shutdown()

    roll, pitch, yaw = calib.euler_deg
    print("Ergebnis der Montage-Kalibrierung (Sensor -> Roboter):")
    print(f"  Roll:   {roll:8.2f}°   (≈180° bedeutet: Sensor liegt auf dem Kopf)")
    print(f"  Pitch:  {pitch:8.2f}°")
    print(f"  Yaw:    {yaw:8.2f}°" + ("   (nicht bestimmt, nur Neigung)" if calib.n_drive == 0 else ""))
    print(f"  Konfidenz Yaw-Fit:  {calib.confidence:.2f}  (>0.5 gut)")
    print(f"  Gyro-Konsistenz:    {calib.gyro_consistency:+.2f}  (nahe +1 gut)")
    print(f"  Gespeichert in: {calib_file}")
    if calib.n_drive > 0 and calib.confidence < 0.5:
        print("WARNUNG: Yaw-Fit unsicher. Bitte mit deutlicherem Anfahren/Bremsen wiederholen.")
    calib.save(calib_file)


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Montage-Kalibrierung des Nicla Sense ME")
    parser.add_argument("--robot", type=str, default=None, help="Namespace des Roboters, z. B. robot_2 (Odometrie = /robot_2/odom).")
    parser.add_argument("--odom-topic", type=str, default=None, help="Odometrie-Topic (überschreibt --robot).")
    parser.add_argument("--imu-topic", type=str, default="/nicla/imu", help="IMU-Topic des Nicla.")
    parser.add_argument("--calib-file", type=Path, default=DEFAULT_CALIB_FILE, help="Ausgabedatei.")
    args = parser.parse_args()
    odom = args.odom_topic or (f"/{args.robot}/odom" if args.robot else "/odom")
    run_calibration(args.imu_topic, odom, args.calib_file)
