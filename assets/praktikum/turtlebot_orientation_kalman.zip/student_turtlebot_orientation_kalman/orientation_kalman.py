#!/usr/bin/env python3
"""Tasks 4 and 5: run the orientation estimation on synthetic data or live on the TurtleBot.

    python3 orientation_kalman.py --sim                    # synthetic data, no ROS 2 needed
    python3 orientation_kalman.py --sim --no-plot
    python3 orientation_kalman.py --live --robot robot_2   # real data; stop with Ctrl-C

TODO: Implement plot_results. Simulation run, live run and evaluation are provided.
"""

import argparse
import sys
from pathlib import Path
from typing import Dict, Optional

import numpy as np

from src.turtlebot.fqa_filter import FQAFilter
from src.turtlebot.kalman_filter import OrientationKalmanFilter, normalize_angle
from src.turtlebot.mount_calibration import MountCalibration
from src.turtlebot.synthetic_data import generate_run

DEFAULT_CALIB_FILE = Path(__file__).parent.resolve() / "nicla_mount_calibration.yaml"


def plot_results(results: Dict[str, np.ndarray], reference_label: str) -> None:
    """Plots the comparison of FQA, Kalman filter and reference.

    Args:
        results: Time series of equal length with the keys 'time' (s), 'reference_yaw', 'fqa_yaw',
            'kalman_yaw', 'yaw_error' and 'gyro_bias_z' (angles in rad, bias in rad/s).
        reference_label: Name of the reference for the legend, e.g. "Odometrie".
    """
    # TODO: Three diagrams below each other (matplotlib):
    # 1. yaw of reference, FQA and Kalman filter in degrees,
    # 2. absolute error |Kalman - reference| in degrees,
    # 3. estimated gyroscope bias b_wz.
    raise NotImplementedError("TODO: implement plot_results")


def rmse_deg(estimate: np.ndarray, reference: np.ndarray) -> float:
    """Root mean square angular error in degrees (wrap-around safe).

    Args:
        estimate: Estimated angles in rad.
        reference: Reference angles in rad.

    Returns:
        RMSE in degrees.
    """
    error = np.array([normalize_angle(a - b) for a, b in zip(estimate, reference)])
    return float(np.degrees(np.sqrt(np.mean(np.square(error)))))


def run_simulation(duration: float = 30.0, dt: float = 0.01, show_plot: bool = True) -> Dict[str, np.ndarray]:
    """Runs FQA and Kalman filter on synthetic data and compares them with the true yaw.

    Args:
        duration: Length of the run in seconds.
        dt: Sampling time in seconds.
        show_plot: Whether to call plot_results.

    Returns:
        Time series as described in plot_results.
    """
    run = generate_run(duration=duration, dt=dt)
    fqa = FQAFilter()
    kalman = OrientationKalmanFilter(dt=dt)
    fqa_yaw, kalman_yaw, bias_z = [], [], []
    for k in range(len(run.time)):
        _, (roll, pitch, yaw) = fqa.update(run.accel[k], run.mag[k])
        kalman.predict(run.gyro[k], dt=dt)
        kalman.update(np.array([roll, pitch, yaw]))
        fqa_yaw.append(yaw)
        kalman_yaw.append(kalman.get_euler_angles()[2])
        bias_z.append(kalman.get_gyro_biases()[2])

    results = {
        "time": run.time,
        "reference_yaw": run.true_yaw,
        "fqa_yaw": np.array(fqa_yaw),
        "kalman_yaw": np.array(kalman_yaw),
        "gyro_bias_z": np.array(bias_z),
    }
    results["yaw_error"] = np.abs([normalize_angle(a - b) for a, b in zip(results["kalman_yaw"], run.true_yaw)])

    print("Auswertung (Simulation, Referenz = wahrer Gierwinkel):")
    print(f"  FQA Yaw RMSE:            {rmse_deg(results['fqa_yaw'], run.true_yaw):.2f}°")
    print(f"  Kalman Yaw RMSE:         {rmse_deg(results['kalman_yaw'], run.true_yaw):.2f}°")
    print(f"  Gyro-Bias z:             geschätzt {bias_z[-1]:.4f} rad/s, wahr {run.true_gyro_bias[2]:.4f} rad/s")
    print(f"  Magnetfeldstörung:       {run.disturbance[0]:.0f} s bis {run.disturbance[1]:.0f} s")
    if show_plot:
        plot_results(results, "wahrer Gierwinkel")
    return results


def run_live(
    imu_topic: str,
    mag_topic: str,
    odom_topic: str,
    dt: float = 0.01,
    show_plot: bool = True,
    calib_file: Optional[Path] = DEFAULT_CALIB_FILE,
    yaw_offset_window: float = 5.0,
) -> Optional[Dict[str, np.ndarray]]:
    """Runs the comparator node on live data until Ctrl-C, then evaluates against the odometry.

    Args:
        imu_topic: Topic of the Nicla IMU.
        mag_topic: Topic of the Nicla magnetometer.
        odom_topic: Topic of the TurtleBot odometry.
        dt: Time step of the Kalman filter in seconds.
        show_plot: Whether to call plot_results.
        calib_file: Mount calibration created by calibrate_mount.py (None = do not load).
        yaw_offset_window: Seconds of standstill at the start used to estimate the heading offset.

    Returns:
        Time series as described in plot_results, or None if no data was received.
    """
    from src.turtlebot.orientation_comparator_node import ROS2_AVAILABLE, OrientationComparatorNode

    if not ROS2_AVAILABLE:
        sys.exit("ROS 2 (rclpy) ist nicht verfügbar. Bitte ROS 2 sourcen oder --sim verwenden.")
    import rclpy

    mount = None
    if calib_file is not None and Path(calib_file).exists():
        mount = MountCalibration.load(calib_file)
        print(f"Montage-Kalibrierung geladen: {calib_file}")
    else:
        print("Keine Montage-Kalibrierung gefunden - Sensorachsen werden unverändert verwendet (calibrate_mount.py).")

    rclpy.init()
    node = OrientationComparatorNode(dt=dt, imu_topic=imu_topic, mag_topic=mag_topic, odom_topic=odom_topic,
                                     mount_calibration=mount, yaw_offset_window=yaw_offset_window)

    def _status() -> None:
        if not node.history["timestamps"]:
            node.get_logger().warn(f"Noch keine IMU-Daten auf {imu_topic}. Läuft der nicla_receiver_node?")
        elif not node.odom_received:
            node.get_logger().warn(f"Noch keine Odometrie auf {odom_topic}.")
        else:
            node.get_logger().info(
                f"n={len(node.history['timestamps'])} | Fehler={np.degrees(node.history['yaw_error'][-1]):6.2f}° | "
                f"Bias z={node.history['gyro_bias_z'][-1]:+.4f} rad/s"
            )

    node.create_timer(1.0, _status)
    print(f"Live-Modus: imu={imu_topic}, mag={mag_topic}, odom={odom_topic}.")
    print(f"Roboter die ersten {yaw_offset_window:.0f} s stehen lassen (Offset-Schätzung). Beenden mit Ctrl-C.")
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        history = {key: np.array(values, dtype=np.float64) for key, values in node.history.items()}
        node.destroy_node()
        if rclpy.ok():
            rclpy.shutdown()

    if len(history["timestamps"]) == 0:
        print("Keine IMU-Daten empfangen - keine Auswertung möglich.")
        return None

    # Align the filter yaw with the odometry using the constant heading offset
    offset = float(history["yaw_offset"][-1])
    results = {
        "time": history["timestamps"] - history["timestamps"][0],
        "reference_yaw": history["odom_yaw"],
        "fqa_yaw": np.array([normalize_angle(a + offset) for a in history["fqa_yaw"]]),
        "kalman_yaw": np.array([normalize_angle(a + offset) for a in history["kalman_yaw"]]),
        "yaw_error": history["yaw_error"],
        "gyro_bias_z": history["gyro_bias_z"],
    }
    print("Auswertung (Live, Referenz = Odometrie):")
    print(f"  Yaw-Offset Odometrie - Filter: {np.degrees(offset):.2f}° (kompensiert)")
    print(f"  FQA Yaw RMSE:            {rmse_deg(results['fqa_yaw'], results['reference_yaw']):.2f}°")
    print(f"  Kalman Yaw RMSE:         {rmse_deg(results['kalman_yaw'], results['reference_yaw']):.2f}°")
    print(f"  Geschätzter Gyro-Bias z: {results['gyro_bias_z'][-1]:.4f} rad/s")
    if show_plot:
        plot_results(results, f"Odometrie ({odom_topic})")
    return results


def main() -> None:
    """Parses the command line and starts the simulation or the live run."""
    parser = argparse.ArgumentParser(description="Orientierungsschätzung mit FQA und Kalman-Filter")
    mode = parser.add_mutually_exclusive_group()
    mode.add_argument("--sim", action="store_true", help="Synthetische Daten (Standard).")
    mode.add_argument("--live", action="store_true", help="Echte Sensordaten über ROS 2.")
    parser.add_argument("--robot", type=str, default=None, help="Namespace des Roboters, z. B. robot_2 (Odometrie = /robot_2/odom).")
    parser.add_argument("--odom-topic", type=str, default=None, help="Odometrie-Topic (überschreibt --robot).")
    parser.add_argument("--imu-topic", type=str, default="/nicla/imu", help="IMU-Topic des Nicla.")
    parser.add_argument("--mag-topic", type=str, default="/nicla/mag", help="Magnetometer-Topic des Nicla.")
    parser.add_argument("--no-calib", action="store_true", help="Im Live-Modus keine Montage-Kalibrierung laden.")
    parser.add_argument("--no-plot", action="store_true", help="Keine Plots anzeigen.")
    parser.add_argument("--duration", type=float, default=30.0, help="Dauer der Simulation in s.")
    parser.add_argument("--dt", type=float, default=0.01, help="Zeitschritt in s (0.01 = 100 Hz).")
    args = parser.parse_args()

    if args.live:
        odom_topic = args.odom_topic or (f"/{args.robot}/odom" if args.robot else "/odom")
        run_live(args.imu_topic, args.mag_topic, odom_topic, dt=args.dt, show_plot=not args.no_plot,
                 calib_file=None if args.no_calib else DEFAULT_CALIB_FILE)
    else:
        run_simulation(duration=args.duration, dt=args.dt, show_plot=not args.no_plot)


if __name__ == "__main__":
    main()
