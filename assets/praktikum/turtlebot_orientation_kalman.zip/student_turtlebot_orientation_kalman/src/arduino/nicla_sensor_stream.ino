/*
 * Nicla Sensor Stream for TurtleBot Orientation Estimation
 *
 * Hardware: Arduino Nicla Sense ME (Bosch BHI260AP + BMM150)
 * Core: Mbed OS Nicla Boards
 * Library: Arduino_BHY2
 *
 * Description:
 * Reads Accelerometer, Gyroscope, and Magnetometer at 100 Hz
 * and streams formatted JSON lines over USB Serial at 115200 baud.
 */

#include "Arduino_BHY2.h"

// Sensor instances
SensorXYZ accel(SENSOR_ID_ACC);
SensorXYZ gyro(SENSOR_ID_GYRO);
SensorXYZ mag(SENSOR_ID_MAG);

// Sampling period: 10ms -> 100 Hz
const unsigned long SAMPLE_INTERVAL_MS = 10;
unsigned long lastSampleTime = 0;

void setup() {
  Serial.begin(115200);
  while (!Serial && millis() < 4000) {
    // Wait for serial connection or timeout
  }

  // Initialize sensor hub
  BHY2.begin();

  // Configure sensor sampling rates (100 Hz)
  accel.begin(100, 0);
  gyro.begin(100, 0);
  mag.begin(100, 0);
}

void loop() {
  // Update sensor hub state
  BHY2.update();

  unsigned long currentMillis = millis();
  if (currentMillis - lastSampleTime >= SAMPLE_INTERVAL_MS) {
    lastSampleTime = currentMillis;

    // Read raw sensor values and convert to standard SI units
    // BHY2 accel output: scaling factor / 4096.0 for g, multiply by 9.80665 for m/s^2
    float ax = accel.x() / 4096.0f * 9.80665f;
    float ay = accel.y() / 4096.0f * 9.80665f;
    float az = accel.z() / 4096.0f * 9.80665f;

    // BHY2 gyro output: deg/s to rad/s
    float gx = gyro.x() * (3.14159265358979323846f / 180.0f) / 16.0f;
    float gy = gyro.y() * (3.14159265358979323846f / 180.0f) / 16.0f;
    float gz = gyro.z() * (3.14159265358979323846f / 180.0f) / 16.0f;

    // BHY2 mag output: microtesla (uT)
    float mx = mag.x() / 16.0f;
    float my = mag.y() / 16.0f;
    float mz = mag.z() / 16.0f;

    // Output JSON string
    Serial.print("{\"ax\":");
    Serial.print(ax, 4);
    Serial.print(",\"ay\":");
    Serial.print(ay, 4);
    Serial.print(",\"az\":");
    Serial.print(az, 4);
    Serial.print(",\"gx\":");
    Serial.print(gx, 4);
    Serial.print(",\"gy\":");
    Serial.print(gy, 4);
    Serial.print(",\"gz\":");
    Serial.print(gz, 4);
    Serial.print(",\"mx\":");
    Serial.print(mx, 4);
    Serial.print(",\"my\":");
    Serial.print(my, 4);
    Serial.print(",\"mz\":");
    Serial.print(mz, 4);
    Serial.print(",\"timestamp_ms\":");
    Serial.print(currentMillis);
    Serial.println("}");
  }
}
