# Arduino Nicla Sense ME Sensor Streamer

Inhalt und Anleitung zur Inbetriebnahme der Sensorik für die Praktikumsaufgabe **Orientierungsschätzung für den TurtleBot 4**.

---

## 📌 Übersicht

Das Arduino-Sketch `nicla_sensor_stream.ino` liest die verbauten Sensoren des **Arduino Nicla Sense ME** aus:  
- **Bosch BHI260AP:** 6-Achs-IMU (3D-Beschleunigung $\vec{a}$ in $\text{m/s}^2$ und 3D-Winkelgeschwindigkeit $\vec{\omega}$ in $\text{rad/s}$)  
- **Bosch BMM150:** 3-Achs-Magnetometer ($\vec{m}$ in $\mu\text{T}$)  

Die Sensordaten werden mit einer Abtastfrequenz von $100\text{ Hz}$ erfasst und als JSON-Format über die serielle USB-Schnittstelle (`115200 Baud`) gestreamt.

---

## ⚙️ Installation & Board-Setup

1. **Arduino IDE 2.x** installieren.  
2. Im **Board-Manager** nach `Arduino Mbed OS Nicla Boards` suchen und installieren.  
3. Über den **Bibliotheks-Manager** das Paket `Arduino_BHY2` (v1.x) installieren.  
4. Das Board `Arduino Nicla Sense ME` auswählen und den Micro-USB-Anschluss an den PC oder Raspberry Pi des TurtleBot anschließen.  
5. Das Sketch `nicla_sensor_stream.ino` kompilieren und hochladen.  

---

## 📡 Datenformat (JSON-Stream)

Beispiel einer erzeugten Zeile im Seriellen Monitor:

```json
{"ax":0.0123,"ay":-0.0456,"az":9.8012,"gx":0.0012,"gy":-0.0034,"gz":0.0005,"mx":21.4500,"my":-8.3200,"mz":-42.1100,"timestamp_ms":123450}
```

Die Daten werden von dem Python ROS 2 Knoten `nicla_receiver_node.py` eingelesen und auf die ROS 2 Topics `/nicla/imu` und `/nicla/mag` verteilt.
