"""Provided generator of synthetic sensor data for developing the filters without the robot.

This module is complete. It simulates a TurtleBot turning on level ground: the gyroscope has a
constant bias, all sensors are noisy, and the magnetic field is disturbed for a few seconds.
"""

from dataclasses import dataclass
from typing import Tuple

import numpy as np

G = 9.80665
# Magnetic field in the world frame in uT: horizontal component along x, vertical component down
MAG_WORLD = np.array([20.0, 0.0, -40.0])


@dataclass
class SyntheticRun:
    """Synthetic measurement series with ground truth.

    Attributes:
        time (np.ndarray): Time stamps in seconds, shape (N,).
        accel (np.ndarray): Accelerometer readings in m/s^2, shape (N, 3).
        gyro (np.ndarray): Gyroscope readings in rad/s, shape (N, 3).
        mag (np.ndarray): Magnetometer readings in uT, shape (N, 3).
        true_yaw (np.ndarray): True yaw angle in rad within [-pi, pi), shape (N,).
        true_gyro_bias (np.ndarray): True constant gyroscope bias in rad/s, shape (3,).
        disturbance (Tuple[float, float]): Start and end time of the magnetic disturbance in seconds.
        dt (float): Sampling time in seconds.
    """

    time: np.ndarray
    accel: np.ndarray
    gyro: np.ndarray
    mag: np.ndarray
    true_yaw: np.ndarray
    true_gyro_bias: np.ndarray
    disturbance: Tuple[float, float]
    dt: float


def generate_run(
    duration: float = 30.0,
    dt: float = 0.01,
    seed: int = 0,
    gyro_bias: Tuple[float, float, float] = (0.01, -0.01, 0.05),
    disturbance: Tuple[float, float] = (12.0, 17.0),
    acc_noise_std: float = 0.15,
    gyro_noise_std: float = 0.01,
    mag_noise_std: float = 0.8,
) -> SyntheticRun:
    """Generate one synthetic run.

    Args:
        duration (float): Length of the run in seconds. Defaults to 30.0.
        dt (float): Sampling time in seconds. Defaults to 0.01 (100 Hz).
        seed (int): Seed of the noise generator. Defaults to 0.
        gyro_bias (Tuple[float, float, float]): Constant gyroscope bias in rad/s.
        disturbance (Tuple[float, float]): Time interval with a disturbed magnetic field in seconds.
        acc_noise_std (float): Accelerometer noise in m/s^2. Defaults to 0.15.
        gyro_noise_std (float): Gyroscope noise in rad/s. Defaults to 0.01.
        mag_noise_std (float): Magnetometer noise in uT. Defaults to 0.8.

    Returns:
        SyntheticRun: Measurements and ground truth.
    """
    rng = np.random.default_rng(seed)
    steps = int(round(duration / dt))
    time = np.arange(steps) * dt
    bias = np.array(gyro_bias, dtype=np.float64)

    yaw_rate = 0.3 * np.sin(2.0 * np.pi * 0.1 * time) + 0.1 * np.cos(2.0 * np.pi * 0.05 * time)
    true_yaw = np.concatenate([[0.0], np.cumsum(yaw_rate[:-1] * dt)])
    true_yaw = (true_yaw + np.pi) % (2.0 * np.pi) - np.pi

    accel = np.tile([0.0, 0.0, G], (steps, 1)) + rng.normal(0.0, acc_noise_std, (steps, 3))
    gyro = np.column_stack([np.zeros(steps), np.zeros(steps), yaw_rate]) + bias + rng.normal(0.0, gyro_noise_std, (steps, 3))

    mag = np.zeros((steps, 3))
    for k in range(steps):
        field = MAG_WORLD.copy()
        if disturbance[0] <= time[k] <= disturbance[1]:
            field += np.array([5.0, -3.0, 0.0])
        c, s = np.cos(true_yaw[k]), np.sin(true_yaw[k])
        world_to_sensor = np.array([[c, s, 0.0], [-s, c, 0.0], [0.0, 0.0, 1.0]])
        mag[k] = world_to_sensor @ field
    mag += rng.normal(0.0, mag_noise_std, (steps, 3))

    return SyntheticRun(time, accel, gyro, mag, true_yaw, bias, disturbance, dt)
