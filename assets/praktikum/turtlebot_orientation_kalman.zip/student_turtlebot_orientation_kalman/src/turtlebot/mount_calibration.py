"""Automatic detection of the Nicla Sense ME mounting orientation on the TurtleBot 4.

TODO (task 2a): Implement rotation_x, rotation_y, rotation_z and rotation_to_euler. Everything
else is provided. The tests in tests/test_mount_calibration.py check your implementation.

The Nicla is mounted with an unknown, constant rotation relative to the robot frame
(e.g. upside down and/or rotated about the vertical axis). This module estimates that
rotation ``R_mount`` (sensor frame -> robot frame) in two stages:

1. Tilt (roll/pitch) from gravity while the robot stands still: the mean accelerometer
   vector must map onto ``[0, 0, +g]``.
2. Yaw from a straight forward drive: after tilt correction, the horizontal acceleration
   measured by the IMU must point along the robot x-axis. The yaw angle is obtained as a
   least-squares fit against the forward acceleration derived from the odometry twist.

Additionally :func:`circular_mean_offset` estimates the constant heading offset between
odometry yaw (starts at 0 at power-on) and the magnetometer based yaw (magnetic north).
"""

from dataclasses import dataclass, field
from pathlib import Path
from typing import Dict, List, Optional, Tuple

import numpy as np

G_DEFAULT = 9.80665


def normalize_angle(angle: float) -> float:
    """Wraps an angle to (-pi, pi]."""
    return float((angle + np.pi) % (2.0 * np.pi) - np.pi)


def circular_mean_offset(reference: np.ndarray, estimate: np.ndarray) -> float:
    """Computes the circular mean of ``reference - estimate`` in radians.

    Used to determine the constant offset between odometry yaw and filter yaw. The circular
    mean is required because the difference wraps around +-pi.

    Args:
        reference: Reference angles in radians (e.g. odometry yaw).
        estimate: Estimated angles in radians (e.g. Kalman yaw).

    Returns:
        Offset in radians such that ``estimate + offset ~= reference``.
    """
    d = np.asarray(reference, dtype=np.float64) - np.asarray(estimate, dtype=np.float64)
    if d.size == 0:
        return 0.0
    return float(np.arctan2(np.mean(np.sin(d)), np.mean(np.cos(d))))


def rotation_from_vectors(u: np.ndarray, v: np.ndarray) -> np.ndarray:
    """Returns the shortest rotation matrix R with ``R @ u_hat = v_hat`` (Rodrigues formula).

    Args:
        u: Source vector (not necessarily normalised).
        v: Target vector (not necessarily normalised).

    Returns:
        3x3 proper rotation matrix.
    """
    u_hat = np.asarray(u, dtype=np.float64) / np.linalg.norm(u)
    v_hat = np.asarray(v, dtype=np.float64) / np.linalg.norm(v)
    axis = np.cross(u_hat, v_hat)
    s = np.linalg.norm(axis)
    c = float(np.dot(u_hat, v_hat))

    if s < 1e-9:
        if c > 0.0:
            return np.eye(3)
        # Antiparallel: rotate 180 degrees about an axis perpendicular to u.
        perp = np.array([1.0, 0.0, 0.0]) if abs(u_hat[0]) < 0.9 else np.array([0.0, 1.0, 0.0])
        axis = np.cross(u_hat, perp)
        axis /= np.linalg.norm(axis)
        k = _skew(axis)
        return np.eye(3) + 2.0 * (k @ k)

    k = _skew(axis)
    return np.eye(3) + k + (k @ k) * ((1.0 - c) / (s * s))


def _skew(v: np.ndarray) -> np.ndarray:
    return np.array([
        [0.0, -v[2], v[1]],
        [v[2], 0.0, -v[0]],
        [-v[1], v[0], 0.0],
    ], dtype=np.float64)


def rotation_z(angle: float) -> np.ndarray:
    """Rotation matrix about the z-axis."""
    # TODO: 3x3 rotation matrix about the z-axis (positive angle = counter-clockwise).
    raise NotImplementedError("TODO: implement rotation_z")


def rotation_to_euler(R: np.ndarray) -> Tuple[float, float, float]:
    """Extracts (roll, pitch, yaw) in radians from a rotation matrix (ZYX convention)."""
    # TODO: R = Rz(yaw) @ Ry(pitch) @ Rx(roll). Multiply the three matrices symbolically and read
    # the angles off suitable entries (arcsin for pitch, arctan2 for roll and yaw).
    raise NotImplementedError("TODO: implement rotation_to_euler")


def rotation_x(angle: float) -> np.ndarray:
    """Rotation matrix about the x-axis."""
    # TODO: 3x3 rotation matrix about the x-axis.
    raise NotImplementedError("TODO: implement rotation_x")


def rotation_y(angle: float) -> np.ndarray:
    """Rotation matrix about the y-axis."""
    # TODO: 3x3 rotation matrix about the y-axis.
    raise NotImplementedError("TODO: implement rotation_y")


def tilt_rotation_from_gravity(accel_mean: np.ndarray, g: float = G_DEFAULT) -> np.ndarray:
    """Computes the tilt rotation that maps the measured rest acceleration onto ``[0, 0, +g]``.

    Detects roll/pitch mounting angles including an upside-down mounted sensor. The rotation
    is built as ``Ry(pitch) @ Rx(roll)`` and therefore contains no yaw component, so the
    sensor x-axis direction is preserved (unlike the shortest rotation between the two
    vectors, whose axis is arbitrary for an upside-down sensor).

    Args:
        accel_mean: Mean accelerometer vector [ax, ay, az] at standstill in m/s^2.
        g: Gravitational acceleration (only used for a plausibility check).

    Returns:
        3x3 rotation matrix ``R_tilt`` (sensor frame -> level sensor frame).

    Raises:
        ValueError: If the magnitude of ``accel_mean`` is not close to g.
    """
    norm = float(np.linalg.norm(accel_mean))
    if not (0.7 * g < norm < 1.3 * g):
        raise ValueError(
            f"|accel| = {norm:.2f} m/s^2 ist nicht plausibel für Stillstand (erwartet ~{g:.2f})."
        )
    ax, ay, az = (float(v) for v in accel_mean)
    roll = np.arctan2(ay, az)                       # Rx(roll) removes the y component
    z_after_roll = np.hypot(ay, az)
    pitch = -np.arctan2(ax, z_after_roll)           # Ry(pitch) removes the x component
    return rotation_y(pitch) @ rotation_x(roll)


def yaw_from_forward_drive(
    accel_level: np.ndarray, odom_accel: np.ndarray
) -> Tuple[float, float]:
    """Least-squares estimate of the mount yaw from a straight drive.

    Model: ``a_horizontal(t) ~= a_odom(t) * [cos(psi), sin(psi)]`` where ``psi`` is the direction
    of the robot x-axis expressed in the (tilt-corrected) sensor frame.

    Args:
        accel_level: Nx3 tilt-corrected accelerometer samples in m/s^2.
        odom_accel: N forward accelerations of the robot derived from odometry in m/s^2.

    Returns:
        Tuple ``(psi, confidence)``. ``confidence`` is the correlation (0..1) between the
        measured and the modelled horizontal acceleration; values below ~0.5 indicate an
        unreliable fit (too little acceleration during the drive).
    """
    a = np.asarray(accel_level, dtype=np.float64)
    w = np.asarray(odom_accel, dtype=np.float64)
    if a.shape[0] < 10 or np.sum(w * w) < 1e-6:
        raise ValueError("Zu wenige Beschleunigungsdaten für die Yaw-Schätzung.")

    sx = float(np.sum(w * a[:, 0]))
    sy = float(np.sum(w * a[:, 1]))
    psi = float(np.arctan2(sy, sx))

    model = np.outer(w, [np.cos(psi), np.sin(psi)])
    meas = a[:, :2]
    denom = np.linalg.norm(model) * np.linalg.norm(meas)
    confidence = float(np.sum(model * meas) / denom) if denom > 0 else 0.0
    return psi, max(0.0, min(1.0, confidence))


@dataclass
class MountCalibration:
    """Result of the mount calibration: rotation from sensor frame to robot frame."""

    R: np.ndarray = field(default_factory=lambda: np.eye(3))
    confidence: float = 1.0
    gyro_consistency: float = 1.0
    n_still: int = 0
    n_drive: int = 0

    def apply(self, vec: np.ndarray) -> np.ndarray:
        """Rotates a sensor-frame vector (accel, gyro or mag) into the robot frame."""
        return self.R @ np.asarray(vec, dtype=np.float64)

    @property
    def euler_deg(self) -> Tuple[float, float, float]:
        """Mount roll/pitch/yaw in degrees."""
        return tuple(float(np.degrees(a)) for a in rotation_to_euler(self.R))

    def to_dict(self) -> Dict:
        roll, pitch, yaw = self.euler_deg
        return {
            "rotation_sensor_to_robot": [[float(x) for x in row] for row in self.R],
            "mount_roll_deg": roll,
            "mount_pitch_deg": pitch,
            "mount_yaw_deg": yaw,
            "confidence": float(self.confidence),
            "gyro_consistency": float(self.gyro_consistency),
            "n_still": int(self.n_still),
            "n_drive": int(self.n_drive),
        }

    def save(self, path: Path) -> None:
        import yaml

        path = Path(path)
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(yaml.safe_dump(self.to_dict(), sort_keys=False))

    @classmethod
    def load(cls, path: Path) -> "MountCalibration":
        import yaml

        data = yaml.safe_load(Path(path).read_text())
        return cls(
            R=np.array(data["rotation_sensor_to_robot"], dtype=np.float64),
            confidence=float(data.get("confidence", 1.0)),
            gyro_consistency=float(data.get("gyro_consistency", 1.0)),
            n_still=int(data.get("n_still", 0)),
            n_drive=int(data.get("n_drive", 0)),
        )


class MountCalibrator:
    """Collects IMU and odometry samples and estimates the mounting rotation.

    Samples are segmented automatically with the odometry twist: while the robot is at rest
    they are used for the tilt estimate, while it drives straight they are used for the yaw
    estimate. Call :meth:`add_sample` for every IMU message and :meth:`compute` afterwards.

    Attributes:
        min_still: Minimum number of standstill samples required.
        min_drive: Minimum number of driving samples required.
    """

    def __init__(
        self,
        g: float = G_DEFAULT,
        min_still: int = 100,
        min_drive: int = 150,
        still_v_thresh: float = 0.01,
        still_w_thresh: float = 0.02,
        drive_w_thresh: float = 0.15,
    ) -> None:
        self.g = g
        self.min_still = min_still
        self.min_drive = min_drive
        self.still_v_thresh = still_v_thresh
        self.still_w_thresh = still_w_thresh
        self.drive_w_thresh = drive_w_thresh

        self.still_accel: List[np.ndarray] = []
        self.still_gyro: List[np.ndarray] = []
        self.drive_accel: List[np.ndarray] = []
        self.drive_gyro: List[np.ndarray] = []
        self.drive_odom_accel: List[float] = []
        self.drive_odom_omega: List[float] = []
        self.accel_energy = 0.0

    def add_sample(
        self,
        accel: np.ndarray,
        gyro: np.ndarray,
        odom_v: float,
        odom_w: float,
        odom_accel: float,
    ) -> str:
        """Adds one IMU sample together with the current odometry state.

        Args:
            accel: Accelerometer [ax, ay, az] in m/s^2 (sensor frame).
            gyro: Gyroscope [gx, gy, gz] in rad/s (sensor frame).
            odom_v: Forward velocity from odometry in m/s.
            odom_w: Yaw rate from odometry in rad/s.
            odom_accel: Forward acceleration from odometry in m/s^2.

        Returns:
            Phase the sample was assigned to: "still", "drive" or "ignored".
        """
        if abs(odom_v) < self.still_v_thresh and abs(odom_w) < self.still_w_thresh:
            self.still_accel.append(np.asarray(accel, dtype=np.float64))
            self.still_gyro.append(np.asarray(gyro, dtype=np.float64))
            return "still"
        if abs(odom_w) < self.drive_w_thresh:
            self.drive_accel.append(np.asarray(accel, dtype=np.float64))
            self.drive_gyro.append(np.asarray(gyro, dtype=np.float64))
            self.drive_odom_accel.append(float(odom_accel))
            self.drive_odom_omega.append(float(odom_w))
            self.accel_energy += float(odom_accel) ** 2
            return "drive"
        return "ignored"

    @property
    def n_still(self) -> int:
        return len(self.still_accel)

    @property
    def n_drive(self) -> int:
        return len(self.drive_accel)

    def tilt_ready(self) -> bool:
        return self.n_still >= self.min_still

    def yaw_ready(self, min_accel_energy: float = 2.0) -> bool:
        """True once enough driving samples with sufficient acceleration were collected."""
        return self.n_drive >= self.min_drive and self.accel_energy >= min_accel_energy

    def compute_tilt(self) -> np.ndarray:
        """Computes the tilt rotation from the collected standstill samples."""
        if not self.tilt_ready():
            raise ValueError(f"Nur {self.n_still}/{self.min_still} Stillstand-Samples vorhanden.")
        accel_mean = np.mean(np.array(self.still_accel), axis=0)
        return tilt_rotation_from_gravity(accel_mean, self.g)

    def compute(self, require_yaw: bool = True) -> MountCalibration:
        """Computes the full mounting rotation ``R_mount = Rz(-psi) @ R_tilt``.

        Args:
            require_yaw: If False and no drive data is available, only the tilt is corrected.

        Returns:
            MountCalibration instance.
        """
        R_tilt = self.compute_tilt()
        gyro_bias = np.mean(np.array(self.still_gyro), axis=0)

        if self.n_drive < self.min_drive or self.accel_energy < 1e-6:
            if require_yaw:
                raise ValueError(
                    f"Nur {self.n_drive}/{self.min_drive} Fahrt-Samples (Beschleunigungsenergie "
                    f"{self.accel_energy:.2f}). Bitte geradeaus anfahren und bremsen."
                )
            return MountCalibration(R=R_tilt, confidence=0.0, n_still=self.n_still, n_drive=0)

        accel_level = (R_tilt @ np.array(self.drive_accel).T).T
        psi, confidence = yaw_from_forward_drive(accel_level, np.array(self.drive_odom_accel))
        R_mount = rotation_z(-psi) @ R_tilt

        # Consistency check: gyro z (bias corrected, rotated) should follow the odometry yaw rate.
        gyro_rot = (R_mount @ (np.array(self.drive_gyro) - gyro_bias).T).T
        omega = np.array(self.drive_odom_omega)
        gz = gyro_rot[:, 2]
        denom = np.linalg.norm(gz) * np.linalg.norm(omega)
        gyro_consistency = float(np.dot(gz, omega) / denom) if denom > 1e-9 else 1.0

        return MountCalibration(
            R=R_mount,
            confidence=confidence,
            gyro_consistency=gyro_consistency,
            n_still=self.n_still,
            n_drive=self.n_drive,
        )
