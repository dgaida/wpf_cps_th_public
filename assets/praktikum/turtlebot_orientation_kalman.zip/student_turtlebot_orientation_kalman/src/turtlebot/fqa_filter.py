"""Task 2: Factored Quaternion Algorithm (FQA) for orientation estimation.

TODO: Implement the quaternion helpers (task 2a) and compute_fqa_quaternion (task 2b). The
FQAFilter wrapper is provided. The tests in tests/test_fqa_filter.py check your implementation.

Computes roll, pitch, and tilt-compensated yaw orientation from 3-axis accelerometer
and 3-axis magnetometer measurements.
"""

from typing import Tuple
import numpy as np


def quaternion_multiply(q1: np.ndarray, q2: np.ndarray) -> np.ndarray:
    """Multiplies two quaternions in [w, x, y, z] order.

    Args:
        q1: First quaternion array [w, x, y, z].
        q2: Second quaternion array [w, x, y, z].

    Returns:
        Quaternion product array [w, x, y, z].
    """
    # TODO: Hamilton product q1 (x) q2, see docs/aufgabenstellung.md, task 2a.
    # The product is not commutative: q1 (x) q2 != q2 (x) q1.
    raise NotImplementedError("TODO: implement quaternion_multiply")


def quaternion_to_euler(q: np.ndarray) -> Tuple[float, float, float]:
    """Converts a unit quaternion [w, x, y, z] to Euler angles (roll, pitch, yaw) in radians.

    Args:
        q: Unit quaternion array [w, x, y, z].

    Returns:
        Tuple containing (roll, pitch, yaw) in radians.
    """
    # TODO: Convention ZYX: q = q_yaw (x) q_pitch (x) q_roll. Derive roll and yaw with arctan2 and
    # pitch with arcsin from the components w, x, y, z. Rounding can push the argument of arcsin
    # slightly beyond +-1 - clip it (gimbal lock at pitch = +-90 deg).
    raise NotImplementedError("TODO: implement quaternion_to_euler")


def euler_to_quaternion(roll: float, pitch: float, yaw: float) -> np.ndarray:
    """Converts Euler angles (roll, pitch, yaw) in radians to a quaternion [w, x, y, z].

    Args:
        roll: Roll angle in radians.
        pitch: Pitch angle in radians.
        yaw: Yaw angle in radians.

    Returns:
        Quaternion array [w, x, y, z].
    """
    # TODO: q = q_yaw (x) q_pitch (x) q_roll with the elementary rotations
    # q_axis(alpha) = [cos(alpha/2), sin(alpha/2) * axis]. Expanding the product gives closed-form
    # expressions in the half-angle sines and cosines.
    raise NotImplementedError("TODO: implement euler_to_quaternion")


def compute_fqa_quaternion(
    accel: np.ndarray, mag: np.ndarray, g: float = 9.80665
) -> Tuple[np.ndarray, Tuple[float, float, float]]:
    """Computes orientation quaternion and Euler angles using the Factored Quaternion Algorithm (FQA).

    Args:
        accel: Accelerometer readings [ax, ay, az] in m/s^2.
        mag: Magnetometer readings [mx, my, mz] in uT or standard magnetic field units.
        g: Gravitational acceleration in m/s^2 (default 9.80665).

    Returns:
        Tuple containing:
            - Unit quaternion [w, x, y, z] representing the total orientation q_FQA.
            - Euler angles (roll, pitch, yaw) in radians.
    """
    # TODO (docs/theorie.md):
    # 1. Pitch from sin(theta) = -ax / g (clip to [-1, 1]) and roll from tan(phi) = ay / az.
    # 2. Rotate the magnetometer vector into the horizontal plane using roll and pitch.
    # 3. Yaw from the horizontal components: psi = atan2(-m'_y, m'_x).
    # 4. q_FQA = q_yaw (x) q_pitch (x) q_roll (quaternion_multiply), normalised.
    raise NotImplementedError("TODO: implement compute_fqa_quaternion")


class FQAFilter:
    """Class wrapper for Factored Quaternion Algorithm (FQA) filter state and calculations."""

    def __init__(self, g: float = 9.80665) -> None:
        """Initializes FQA filter parameters.

        Args:
            g: Gravitational acceleration constant in m/s^2.
        """
        self.g = g
        self.last_quaternion = np.array([1.0, 0.0, 0.0, 0.0], dtype=np.float64)
        self.last_euler = (0.0, 0.0, 0.0)

    def update(self, accel: np.ndarray, mag: np.ndarray) -> Tuple[np.ndarray, Tuple[float, float, float]]:
        """Processes accelerometer and magnetometer measurements to compute orientation.

        Args:
            accel: 3D accelerometer readings [ax, ay, az] in m/s^2.
            mag: 3D magnetometer readings [mx, my, mz] in uT.

        Returns:
            Tuple containing:
                - Quaternion array [w, x, y, z].
                - Euler angles tuple (roll, pitch, yaw) in radians.
        """
        q_fqa, euler = compute_fqa_quaternion(accel, mag, g=self.g)
        self.last_quaternion = q_fqa
        self.last_euler = euler
        return q_fqa, euler
