"""Task 1: ROS 2 node reading the Nicla Sense ME over serial and publishing IMU and magnetometer.

TODO: Implement parse_nicla_line and the message filling in read_and_publish. Serial connection
and node setup are provided. The tests in tests/test_nicla_receiver.py check parse_nicla_line.

Run on the Raspberry Pi of the TurtleBot:  python3 -m src.turtlebot.nicla_receiver_node
"""

import json
import time
from typing import Any, Optional, Tuple

import numpy as np

try:
    import serial
except ImportError:
    serial = None

try:
    import rclpy
    from rclpy.node import Node
    from sensor_msgs.msg import Imu, MagneticField
    ROS2_AVAILABLE = True
except ImportError:
    ROS2_AVAILABLE = False
    Node = object  # Fallback base class for non-ROS2 environments


def parse_nicla_line(line: str) -> Optional[Tuple[np.ndarray, np.ndarray, np.ndarray]]:
    """Parses one JSON line of the Nicla sketch (see src/arduino/README.md).

    Args:
        line: Text line, e.g. '{"ax":0.01,"ay":-0.04,"az":9.80,"gx":0.001,...,"mz":-42.1,"timestamp_ms":1234}'.

    Returns:
        Tuple (accel in m/s^2, gyro in rad/s, mag in uT), each as array of shape (3,), or None if
        the line is empty, incomplete or no valid JSON.
    """
    # TODO: json.loads, read the nine values ax..mz. Serial data can be corrupted: never raise.
    raise NotImplementedError("TODO: implement parse_nicla_line")


class NiclaReceiverNode(Node if ROS2_AVAILABLE else object):
    """ROS 2 node publishing /nicla/imu (sensor_msgs/Imu) and /nicla/mag (sensor_msgs/MagneticField)."""

    def __init__(self, port: str = "/dev/ttyACM0", baudrate: int = 115200) -> None:
        """Initializes publishers and opens the serial port.

        Args:
            port: Serial device of the Nicla Sense ME.
            baudrate: Baud rate of the sketch.
        """
        if ROS2_AVAILABLE:
            super().__init__("nicla_receiver_node")
            self.imu_pub = self.create_publisher(Imu, "/nicla/imu", 10)
            self.mag_pub = self.create_publisher(MagneticField, "/nicla/mag", 10)
        self.serial_conn: Optional[Any] = None
        if serial is not None:
            try:
                self.serial_conn = serial.Serial(port, baudrate, timeout=0.1)
            except Exception as e:
                print(f"Could not open serial port {port}: {e}")

    def read_and_publish(self) -> bool:
        """Reads one line from the serial port and publishes both messages.

        Returns:
            True if a valid line was read and published, False otherwise.
        """
        if self.serial_conn is None or not self.serial_conn.is_open:
            return False
        line = self.serial_conn.readline().decode("utf-8", errors="ignore").strip()
        parsed = parse_nicla_line(line)
        if parsed is None or not ROS2_AVAILABLE:
            return False
        accel, gyro, mag = parsed

        imu_msg = Imu()
        mag_msg = MagneticField()
        # TODO: Fill both messages: header.stamp (self.get_clock().now().to_msg()), header.frame_id,
        # linear_acceleration, angular_velocity and magnetic_field. MagneticField uses Tesla, not uT.
        raise NotImplementedError("TODO: fill and publish the messages")

        self.imu_pub.publish(imu_msg)
        self.mag_pub.publish(mag_msg)
        return True


def main(args=None) -> None:
    """Runs the receiver node until Ctrl-C."""
    if not ROS2_AVAILABLE:
        print("ROS 2 (rclpy) is not available. Please run in a ROS 2 environment.")
        return
    rclpy.init(args=args)
    node = NiclaReceiverNode()
    try:
        while rclpy.ok():
            node.read_and_publish()
            time.sleep(0.002)
    except KeyboardInterrupt:
        pass
    finally:
        node.destroy_node()
        rclpy.shutdown()


if __name__ == "__main__":
    main()
