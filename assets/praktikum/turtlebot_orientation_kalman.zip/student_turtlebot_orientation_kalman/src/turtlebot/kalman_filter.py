"""Task 3: Kalman filter for orientation and gyroscope bias estimation.

TODO: Implement the parts marked with TODO. The tests in tests/test_kalman_filter.py check your
implementation. The matrices are specified in docs/aufgabenstellung.md.
"""

from typing import Optional, Tuple

import numpy as np


def normalize_angle(angle: float) -> float:
    """Normalizes an angle to the interval [-pi, pi).

    Args:
        angle: Angle in radians.

    Returns:
        Normalized angle in radians.
    """
    # TODO
    raise NotImplementedError("TODO: implement normalize_angle")


class OrientationKalmanFilter:
    """Kalman filter estimating the state x = [phi, theta, psi, b_wx, b_wy, b_wz]^T.

    Attributes:
        dt: Sampling time interval in seconds.
        x: State vector of shape (6, 1).
        P: Covariance matrix of shape (6, 6).
        Q: Process noise covariance matrix of shape (6, 6).
        R: Measurement noise covariance matrix of shape (3, 3).
        C: Measurement matrix of shape (3, 6).
    """

    def __init__(
        self,
        dt: float = 0.01,
        q_angle: float = 1e-4,
        q_bias: float = 1e-6,
        r_tilt: float = 1e-2,
        r_yaw: float = 1e-1,
        initial_state: Optional[np.ndarray] = None,
        initial_covariance: Optional[np.ndarray] = None,
    ) -> None:
        """Initializes state, covariance and the constant matrices.

        Args:
            dt: Sampling time step in seconds (default 0.01 s for 100 Hz).
            q_angle: Process noise variance of the three angles.
            q_bias: Process noise variance of the three gyroscope biases.
            r_tilt: Measurement noise variance of roll and pitch (FQA).
            r_yaw: Measurement noise variance of yaw (FQA / magnetometer).
            initial_state: Optional initial state of shape (6,) or (6, 1). Defaults to zeros.
            initial_covariance: Optional initial covariance of shape (6, 6). Defaults to 0.1 * I.
        """
        self.dt = float(dt)
        self.x = (
            np.array(initial_state, dtype=np.float64).reshape(6, 1)
            if initial_state is not None else np.zeros((6, 1), dtype=np.float64)
        )
        self.P = (
            np.array(initial_covariance, dtype=np.float64).reshape(6, 6)
            if initial_covariance is not None else np.eye(6, dtype=np.float64) * 0.1
        )

        # TODO: Build Q = diag(q_angle x3, q_bias x3), R = diag(r_tilt, r_tilt, r_yaw) and the
        # measurement matrix C (3 x 6).
        self.Q = np.zeros((6, 6), dtype=np.float64)
        self.R = np.zeros((3, 3), dtype=np.float64)
        self.C = np.zeros((3, 6), dtype=np.float64)

    def _get_system_matrices(self, dt: float) -> Tuple[np.ndarray, np.ndarray]:
        """Constructs system matrix A and control matrix B for the time step dt.

        Args:
            dt: Time step in seconds.

        Returns:
            Tuple containing A (6 x 6) and B (6 x 3).
        """
        # TODO
        raise NotImplementedError("TODO: implement _get_system_matrices")

    def predict(self, gyro: np.ndarray, dt: Optional[float] = None) -> Tuple[np.ndarray, np.ndarray]:
        """Prediction step with the gyroscope rates as input u_k.

        Args:
            gyro: Angular velocities [gx, gy, gz] in rad/s.
            dt: Optional time step in seconds. If None, self.dt is used.

        Returns:
            Tuple containing the predicted state (6, 1) and covariance (6, 6).
        """
        # TODO: x = A x + B u, P = A P A^T + Q. Keep the yaw state within [-pi, pi).
        raise NotImplementedError("TODO: implement predict")

    def update(self, z_fqa: np.ndarray) -> Tuple[np.ndarray, np.ndarray]:
        """Correction step with the FQA measurement.

        Args:
            z_fqa: Measurement [phi_fqa, theta_fqa, psi_fqa] in radians.

        Returns:
            Tuple containing the corrected state (6, 1) and covariance (6, 6).
        """
        # TODO: residual y = z - C x (normalise the yaw residual, otherwise the filter jumps at
        # the transition between -pi and +pi), K = P C^T (C P C^T + R)^-1, x = x + K y,
        # P = (I - K C) P. Keep the yaw state within [-pi, pi).
        raise NotImplementedError("TODO: implement update")

    def get_euler_angles(self) -> Tuple[float, float, float]:
        """Returns the estimated (roll, pitch, yaw) in radians."""
        return float(self.x[0, 0]), float(self.x[1, 0]), float(self.x[2, 0])

    def get_gyro_biases(self) -> Tuple[float, float, float]:
        """Returns the estimated gyroscope biases (b_wx, b_wy, b_wz) in rad/s."""
        return float(self.x[3, 0]), float(self.x[4, 0]), float(self.x[5, 0])
