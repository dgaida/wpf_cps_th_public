"""Task 4: ROS 2 node comparing FQA, Kalman filter and TurtleBot odometry.

TODO: Implement _update_yaw_offset and process_step. Subscriptions and callbacks are provided.
The tests in tests/test_comparator.py check your implementation without ROS 2.
"""

from typing import Any, Dict, List, Optional, Tuple

import numpy as np

from .fqa_filter import FQAFilter, quaternion_to_euler
from .kalman_filter import OrientationKalmanFilter, normalize_angle
from .mount_calibration import MountCalibration, circular_mean_offset

try:
    import rclpy
    from rclpy.node import Node
    from sensor_msgs.msg import Imu, MagneticField
    from nav_msgs.msg import Odometry
    ROS2_AVAILABLE = True
except ImportError:
    ROS2_AVAILABLE = False
    Node = object


class OrientationComparatorNode(Node if ROS2_AVAILABLE else object):
    """Evaluation node: runs FQA and Kalman filter on the Nicla data and compares with the odometry.

    Attributes:
        fqa: FQAFilter instance.
        kalman: OrientationKalmanFilter instance.
        latest_accel, latest_gyro, latest_mag: Most recent sensor vectors in the robot frame
            (m/s^2, rad/s, uT).
        latest_odom_yaw: Most recent yaw of the odometry in radians.
        odom_received: True as soon as one odometry message arrived.
        yaw_offset: Constant heading offset odometry minus filter in radians.
        yaw_offset_locked: True once the offset is fixed.
        history: Time series with the keys 'timestamps', 'fqa_yaw', 'kalman_yaw', 'odom_yaw',
            'yaw_error', 'gyro_bias_z' and 'yaw_offset' (one entry per processed IMU sample).
    """

    def __init__(
        self,
        dt: float = 0.01,
        imu_topic: str = "/nicla/imu",
        mag_topic: str = "/nicla/mag",
        odom_topic: str = "/odom",
        mount_calibration: Optional[MountCalibration] = None,
        yaw_offset_window: float = 5.0,
    ) -> None:
        """Initializes filters, history and (with ROS 2) the subscriptions.

        Args:
            dt: Time step of the Kalman filter in seconds.
            imu_topic: Topic of the Nicla IMU (sensor_msgs/Imu).
            mag_topic: Topic of the Nicla magnetometer (sensor_msgs/MagneticField).
            odom_topic: Topic of the TurtleBot odometry, e.g. "/odom" or "/robot_2/odom".
            mount_calibration: Rotation sensor -> robot frame applied to all sensor vectors
                (see calibrate_mount.py). None = identity.
            yaw_offset_window: Seconds at the start during which the constant heading offset
                between odometry and filter is estimated (0 disables the compensation).
        """
        self.imu_topic, self.mag_topic, self.odom_topic = imu_topic, mag_topic, odom_topic
        self.mount = mount_calibration if mount_calibration is not None else MountCalibration()
        self.yaw_offset_window = float(yaw_offset_window)
        self.yaw_offset = 0.0
        self.yaw_offset_locked = self.yaw_offset_window <= 0.0
        self.odom_received = False

        if ROS2_AVAILABLE:
            super().__init__("orientation_comparator_node")
            self.imu_sub = self.create_subscription(Imu, imu_topic, self._imu_callback, 10)
            self.mag_sub = self.create_subscription(MagneticField, mag_topic, self._mag_callback, 10)
            self.odom_sub = self.create_subscription(Odometry, odom_topic, self._odom_callback, 10)

        self.fqa = FQAFilter()
        self.kalman = OrientationKalmanFilter(dt=dt)
        self.latest_accel = np.array([0.0, 0.0, 9.80665], dtype=np.float64)
        self.latest_gyro = np.zeros(3, dtype=np.float64)
        self.latest_mag = np.array([20.0, 0.0, -40.0], dtype=np.float64)
        self.latest_odom_yaw = 0.0
        self.history: Dict[str, List[float]] = {
            key: [] for key in
            ["timestamps", "fqa_yaw", "kalman_yaw", "odom_yaw", "yaw_error", "gyro_bias_z", "yaw_offset"]
        }

    # ------------------------------------------------------------------ provided ROS callbacks
    def _mag_callback(self, msg: Any) -> None:
        """Stores the magnetic field in uT, rotated into the robot frame."""
        self.latest_mag = self.mount.apply(np.array([
            msg.magnetic_field.x * 1e6, msg.magnetic_field.y * 1e6, msg.magnetic_field.z * 1e6
        ]))

    def _odom_callback(self, msg: Any) -> None:
        """Stores the yaw angle of the odometry."""
        q = msg.pose.pose.orientation
        _, _, self.latest_odom_yaw = quaternion_to_euler(np.array([q.w, q.x, q.y, q.z]))
        self.odom_received = True

    def _imu_callback(self, msg: Any) -> None:
        """Stores acceleration and angular rate in the robot frame and triggers one filter step."""
        self.latest_accel = self.mount.apply(np.array([
            msg.linear_acceleration.x, msg.linear_acceleration.y, msg.linear_acceleration.z
        ]))
        self.latest_gyro = self.mount.apply(np.array([
            msg.angular_velocity.x, msg.angular_velocity.y, msg.angular_velocity.z
        ]))
        self.process_step(msg.header.stamp.sec + msg.header.stamp.nanosec * 1e-9)

    # ------------------------------------------------------------------ your part
    def _update_yaw_offset(self, timestamp: float, yaw_fqa: float) -> None:
        """Estimates the constant heading offset between odometry and filter.

        The odometry yaw starts at 0 when the robot is switched on, the magnetometer based yaw
        refers to magnetic north. Both differ by a constant angle.

        Args:
            timestamp: Time of the current sample in seconds.
            yaw_fqa: FQA yaw of the current sample in radians.
        """
        # TODO: While the offset is not locked and odometry has been received, collect
        # latest_odom_yaw and yaw_fqa and set self.yaw_offset to their mean angular difference
        # (mount_calibration.circular_mean_offset). Lock the offset (self.yaw_offset_locked) once
        # yaw_offset_window seconds have passed since the first collected sample.
        raise NotImplementedError("TODO: implement _update_yaw_offset")

    def process_step(self, timestamp: float) -> Tuple[float, float, float]:
        """Executes one filter step with the latest sensor values and records the results.

        Args:
            timestamp: Time of the current IMU sample in seconds.

        Returns:
            Tuple (yaw_fqa, yaw_kalman, yaw_error) in radians, where
            yaw_error = |normalize(yaw_kalman + yaw_offset - latest_odom_yaw)|.
        """
        # TODO:
        # 1. FQA with latest_accel and latest_mag.
        # 2. Kalman prediction with latest_gyro, correction with the FQA angles.
        # 3. Update the yaw offset, compute the error against the odometry.
        # 4. Append one entry to every list of self.history.
        raise NotImplementedError("TODO: implement process_step")
