"""Tests of the provided synthetic data - they pass without any changes and show how to use it."""

import numpy as np

from src.turtlebot.synthetic_data import G, generate_run


def test_shapes_and_ground_truth() -> None:
    """One sample per time step; the yaw is the integrated true yaw rate."""
    run = generate_run(duration=10.0, dt=0.01, gyro_noise_std=0.0)
    assert run.time.shape == (1000,)
    assert run.accel.shape == run.gyro.shape == run.mag.shape == (1000, 3)
    integrated = np.cumsum((run.gyro[:, 2] - run.true_gyro_bias[2]) * run.dt)
    assert abs(integrated[-1] - run.true_yaw[-1]) < 0.02


def test_level_robot_measures_gravity() -> None:
    """The robot drives on level ground: gravity acts on the z axis only."""
    run = generate_run(duration=5.0)
    assert np.allclose(run.accel.mean(axis=0), [0.0, 0.0, G], atol=0.05)
