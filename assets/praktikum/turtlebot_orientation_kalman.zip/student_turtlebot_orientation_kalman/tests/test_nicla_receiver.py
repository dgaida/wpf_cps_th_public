"""Self-check tests for task 1 (src/turtlebot/nicla_receiver_node.py)."""

import numpy as np

from src.turtlebot.nicla_receiver_node import parse_nicla_line

LINE = '{"ax":0.0123,"ay":-0.0456,"az":9.8012,"gx":0.0012,"gy":-0.0034,"gz":0.0005,"mx":21.45,"my":-8.32,"mz":-42.11,"timestamp_ms":123450}'


def test_parse_valid_line() -> None:
    """The nine values are returned as three vectors in the units of the sketch."""
    accel, gyro, mag = parse_nicla_line(LINE)
    assert np.allclose(accel, [0.0123, -0.0456, 9.8012])
    assert np.allclose(gyro, [0.0012, -0.0034, 0.0005])
    assert np.allclose(mag, [21.45, -8.32, -42.11])


def test_parse_rejects_broken_lines() -> None:
    """Empty, truncated or incomplete lines yield None instead of an exception."""
    assert parse_nicla_line("") is None
    assert parse_nicla_line("BHY2 init ok") is None
    assert parse_nicla_line(LINE[:40]) is None
    assert parse_nicla_line('{"ax":0.1,"ay":0.2}') is None
    assert parse_nicla_line('{"ax":"x","ay":0,"az":0,"gx":0,"gy":0,"gz":0,"mx":0,"my":0,"mz":0}') is None
