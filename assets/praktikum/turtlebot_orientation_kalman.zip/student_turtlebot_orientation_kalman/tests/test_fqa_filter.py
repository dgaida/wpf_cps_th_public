"""Self-check tests for task 2 (src/turtlebot/fqa_filter.py)."""

import numpy as np
import pytest

from src.turtlebot.fqa_filter import compute_fqa_quaternion, euler_to_quaternion, quaternion_multiply, quaternion_to_euler

G = 9.80665
MAG_WORLD = np.array([20.0, 0.0, -40.0])


def mag_for_yaw(yaw: float) -> np.ndarray:
    """Magnetometer reading of a level sensor turned by yaw (world field rotated into the sensor frame)."""
    c, s = np.cos(yaw), np.sin(yaw)
    return np.array([[c, s, 0.0], [-s, c, 0.0], [0.0, 0.0, 1.0]]) @ MAG_WORLD


def axis_quaternion(axis: str, angle: float) -> np.ndarray:
    """Quaternion [w, x, y, z] of a rotation by angle about one coordinate axis."""
    q = np.array([np.cos(angle / 2.0), 0.0, 0.0, 0.0])
    q["xyz".index(axis) + 1] = np.sin(angle / 2.0)
    return q


def test_quaternion_multiply_identity_and_axes() -> None:
    """The identity changes nothing; two rotations about the same axis add up."""
    q = axis_quaternion("x", 0.3)
    assert np.allclose(quaternion_multiply(np.array([1.0, 0.0, 0.0, 0.0]), q), q)
    assert np.allclose(quaternion_multiply(axis_quaternion("z", 0.2), axis_quaternion("z", 0.5)), axis_quaternion("z", 0.7))


def test_quaternion_multiply_is_not_commutative() -> None:
    """i * j = k, but j * i = -k."""
    i, j, k = np.array([0.0, 1.0, 0.0, 0.0]), np.array([0.0, 0.0, 1.0, 0.0]), np.array([0.0, 0.0, 0.0, 1.0])
    assert np.allclose(quaternion_multiply(i, j), k)
    assert np.allclose(quaternion_multiply(j, i), -k)


@pytest.mark.parametrize("roll_deg,pitch_deg,yaw_deg", [(0.0, 0.0, 0.0), (20.0, -10.0, 135.0), (-170.0, 45.0, -60.0)])
def test_euler_quaternion_round_trip(roll_deg: float, pitch_deg: float, yaw_deg: float) -> None:
    """euler_to_quaternion follows q = q_yaw (x) q_pitch (x) q_roll and quaternion_to_euler inverts it."""
    roll, pitch, yaw = np.radians([roll_deg, pitch_deg, yaw_deg])
    q = euler_to_quaternion(roll, pitch, yaw)
    expected = quaternion_multiply(axis_quaternion("z", yaw), quaternion_multiply(axis_quaternion("y", pitch), axis_quaternion("x", roll)))
    assert np.allclose(q, expected)
    assert np.isclose(np.linalg.norm(q), 1.0)
    assert np.allclose(quaternion_to_euler(q), (roll, pitch, yaw), atol=1e-9)


def test_quaternion_to_euler_gimbal_lock() -> None:
    """At pitch = 90 deg rounding errors must not produce NaN."""
    q = euler_to_quaternion(0.0, np.pi / 2.0, 0.0) * (1.0 + 1e-12)
    roll, pitch, yaw = quaternion_to_euler(q)
    assert np.all(np.isfinite([roll, pitch, yaw]))
    assert np.isclose(pitch, np.pi / 2.0, atol=1e-5)


def test_level_and_aligned() -> None:
    """A level sensor pointing along the horizontal field has zero roll, pitch and yaw."""
    q, (roll, pitch, yaw) = compute_fqa_quaternion(np.array([0.0, 0.0, G]), MAG_WORLD)
    assert np.allclose([roll, pitch, yaw], 0.0, atol=1e-9)
    assert np.allclose(q, [1.0, 0.0, 0.0, 0.0], atol=1e-9)


@pytest.mark.parametrize("yaw_deg", [30.0, 90.0, 170.0, -45.0, -120.0])
def test_yaw_from_magnetometer(yaw_deg: float) -> None:
    """The yaw of a level sensor follows from the horizontal field components."""
    yaw_true = np.radians(yaw_deg)
    q, (roll, pitch, yaw) = compute_fqa_quaternion(np.array([0.0, 0.0, G]), mag_for_yaw(yaw_true))
    assert np.isclose(yaw, yaw_true, atol=1e-6)
    assert np.allclose([roll, pitch], 0.0, atol=1e-9)


def test_roll_and_pitch_from_gravity() -> None:
    """tan(roll) = ay / az and sin(pitch) = -ax / g."""
    roll_true, pitch_true = np.radians(20.0), np.radians(-15.0)
    _, (roll, _, _) = compute_fqa_quaternion(np.array([0.0, G * np.sin(roll_true), G * np.cos(roll_true)]), MAG_WORLD)
    assert np.isclose(roll, roll_true, atol=1e-6)
    _, (_, pitch, _) = compute_fqa_quaternion(np.array([-G * np.sin(pitch_true), 0.0, G * np.cos(pitch_true)]), MAG_WORLD)
    assert np.isclose(pitch, pitch_true, atol=1e-6)


def test_quaternion_is_normalised_and_consistent() -> None:
    """The quaternion has unit length and encodes the returned Euler angles."""
    accel = np.array([-G * np.sin(0.1), 0.0, G * np.cos(0.1)])
    q, euler = compute_fqa_quaternion(accel, mag_for_yaw(0.7))
    assert np.isclose(np.linalg.norm(q), 1.0, atol=1e-9)
    assert np.allclose(quaternion_to_euler(q), euler, atol=1e-6)


def test_acceleration_outside_gravity_does_not_crash() -> None:
    """|ax| > g (e.g. a shock) must not produce NaN."""
    _, euler = compute_fqa_quaternion(np.array([-15.0, 0.0, 1.0]), MAG_WORLD)
    assert np.all(np.isfinite(euler))


@pytest.mark.parametrize("roll_deg,pitch_deg,yaw_deg", [(20.0, 0.0, 40.0), (0.0, 10.0, 40.0), (-15.0, 25.0, -100.0)])
def test_tilt_compensation(roll_deg: float, pitch_deg: float, yaw_deg: float) -> None:
    """A tilted sensor still measures the correct yaw (rotation order yaw, pitch, roll)."""
    roll, pitch, yaw_true = np.radians([roll_deg, pitch_deg, yaw_deg])
    cr, sr, cp, sp, cy, sy = np.cos(roll), np.sin(roll), np.cos(pitch), np.sin(pitch), np.cos(yaw_true), np.sin(yaw_true)
    rot_x = np.array([[1, 0, 0], [0, cr, -sr], [0, sr, cr]])
    rot_y = np.array([[cp, 0, sp], [0, 1, 0], [-sp, 0, cp]])
    rot_z = np.array([[cy, -sy, 0], [sy, cy, 0], [0, 0, 1]])
    sensor_to_world = rot_z @ rot_y @ rot_x
    accel = sensor_to_world.T @ np.array([0.0, 0.0, G])
    mag = sensor_to_world.T @ MAG_WORLD

    _, (roll_fqa, pitch_fqa, yaw_fqa) = compute_fqa_quaternion(accel, mag)
    assert np.allclose([roll_fqa, pitch_fqa], [roll, pitch], atol=1e-6)
    assert np.isclose(yaw_fqa, yaw_true, atol=1e-6)
