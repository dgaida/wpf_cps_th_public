"""Self-check tests for task 4 (src/turtlebot/orientation_comparator_node.py), without ROS 2."""

import numpy as np
import pytest

from src.turtlebot.orientation_comparator_node import ROS2_AVAILABLE, OrientationComparatorNode

pytestmark = pytest.mark.skipif(ROS2_AVAILABLE, reason="These tests construct the node without a ROS 2 context.")

HISTORY_KEYS = ["timestamps", "fqa_yaw", "kalman_yaw", "odom_yaw", "yaw_error", "gyro_bias_z", "yaw_offset"]


def mag_for_yaw(yaw: float) -> np.ndarray:
    c, s = np.cos(yaw), np.sin(yaw)
    return np.array([[c, s, 0.0], [-s, c, 0.0], [0.0, 0.0, 1.0]]) @ np.array([20.0, 0.0, -40.0])


def test_process_step_records_history() -> None:
    """Every step appends one entry to all history lists and returns the three angles."""
    node = OrientationComparatorNode(dt=0.01, yaw_offset_window=0.0)
    node.latest_mag = mag_for_yaw(0.4)
    for k in range(200):
        yaw_fqa, yaw_kalman, yaw_error = node.process_step(k * 0.01)
    assert all(len(node.history[key]) == 200 for key in HISTORY_KEYS)
    assert np.isclose(yaw_fqa, 0.4, atol=1e-6)
    assert abs(yaw_kalman - 0.4) < 0.05  # the filter converges to the measurement
    assert np.isclose(yaw_error, abs(yaw_kalman - node.latest_odom_yaw), atol=1e-9)


def test_yaw_offset_is_estimated_and_locked() -> None:
    """Odometry and magnetometer differ by a constant angle that is estimated at standstill."""
    node = OrientationComparatorNode(dt=0.01, yaw_offset_window=1.0)
    node.latest_mag = mag_for_yaw(0.9)   # filter yaw 0.9 rad (magnetic north)
    node.latest_odom_yaw = 0.2           # odometry starts near zero
    node.odom_received = True
    for k in range(300):
        node.process_step(k * 0.01)
    assert node.yaw_offset_locked is True
    assert np.isclose(node.yaw_offset, 0.2 - 0.9, atol=0.01)
    assert node.history["yaw_error"][-1] < 0.05

    # After locking, the offset stays fixed even if the robot turns
    node.latest_odom_yaw = 1.0
    node.process_step(3.0)
    assert np.isclose(node.yaw_offset, 0.2 - 0.9, atol=0.01)


def test_no_offset_without_odometry() -> None:
    """Without odometry there is nothing to align to."""
    node = OrientationComparatorNode(dt=0.01, yaw_offset_window=1.0)
    node.latest_mag = mag_for_yaw(0.9)
    for k in range(300):
        node.process_step(k * 0.01)
    assert node.yaw_offset == 0.0 and node.yaw_offset_locked is False
