"""Self-check tests for task 3 (src/turtlebot/kalman_filter.py)."""

import numpy as np

from src.turtlebot.kalman_filter import OrientationKalmanFilter, normalize_angle
from src.turtlebot.synthetic_data import generate_run


def test_normalize_angle() -> None:
    """Angles are mapped into [-pi, pi)."""
    assert np.isclose(normalize_angle(0.5), 0.5)
    assert np.isclose(normalize_angle(np.pi + 0.2), -np.pi + 0.2)
    assert np.isclose(normalize_angle(-np.pi - 0.2), np.pi - 0.2)
    assert np.isclose(normalize_angle(4.0 * np.pi + 0.1), 0.1)


def test_matrices() -> None:
    """A, B, C, Q and R follow the model specification."""
    kf = OrientationKalmanFilter(dt=0.01)
    A, B = kf._get_system_matrices(0.02)
    expected_A = np.eye(6)
    expected_A[0, 3] = expected_A[1, 4] = expected_A[2, 5] = -0.02
    expected_B = np.vstack([0.02 * np.eye(3), np.zeros((3, 3))])
    assert np.allclose(A, expected_A) and np.allclose(B, expected_B)
    assert np.allclose(kf.C, np.hstack([np.eye(3), np.zeros((3, 3))]))
    assert np.allclose(kf.Q, np.diag([1e-4, 1e-4, 1e-4, 1e-6, 1e-6, 1e-6]))
    assert np.allclose(kf.R, np.diag([1e-2, 1e-2, 1e-1]))


def test_predict_integrates_the_gyro_minus_bias() -> None:
    """The angle changes by (omega - bias) * dt and the covariance grows."""
    kf = OrientationKalmanFilter(dt=0.1, initial_state=np.array([0.0, 0.0, 0.3, 0.0, 0.0, 0.2]))
    trace_before = np.trace(kf.P)
    x, P = kf.predict(np.array([0.0, 0.0, 1.0]))
    assert x.shape == (6, 1) and P.shape == (6, 6)
    assert np.isclose(x[2, 0], 0.3 + (1.0 - 0.2) * 0.1)
    assert np.isclose(x[5, 0], 0.2)
    assert np.trace(P) > trace_before

    A, _ = kf._get_system_matrices(0.1)
    assert np.allclose(P, A @ (np.eye(6) * 0.1) @ A.T + kf.Q)


def test_predict_uses_the_given_time_step() -> None:
    """An explicit dt overrides the default time step."""
    kf = OrientationKalmanFilter(dt=0.01)
    kf.predict(np.array([1.0, 0.0, 0.0]), dt=0.5)
    assert np.isclose(kf.x[0, 0], 0.5)


def test_update_moves_towards_the_measurement() -> None:
    """The corrected state lies between prediction and measurement; the covariance shrinks."""
    kf = OrientationKalmanFilter()
    P_before = kf.P.copy()
    K = P_before @ kf.C.T @ np.linalg.inv(kf.C @ P_before @ kf.C.T + kf.R)
    z = np.array([0.1, -0.2, 0.5])
    x, P = kf.update(z)
    assert np.allclose(x, K @ z.reshape(3, 1))
    assert np.allclose(P, (np.eye(6) - K @ kf.C) @ P_before)
    assert 0.0 < x[2, 0] < 0.5 and np.trace(P) < np.trace(P_before)


def test_update_handles_the_wrap_around() -> None:
    """Between +179 deg and -179 deg lie 2 deg, not 358 deg."""
    kf = OrientationKalmanFilter(initial_state=np.array([0.0, 0.0, np.radians(179.0), 0.0, 0.0, 0.0]))
    kf.update(np.array([0.0, 0.0, np.radians(-179.0)]))
    yaw = kf.get_euler_angles()[2]
    assert -np.pi <= yaw <= np.pi
    assert abs(normalize_angle(yaw - np.radians(179.0))) < np.radians(2.0)


def test_filter_on_synthetic_run() -> None:
    """The fusion is better than FQA alone and finds the gyroscope bias."""
    from src.turtlebot.fqa_filter import compute_fqa_quaternion

    run = generate_run(duration=30.0, dt=0.01, seed=1)
    kf = OrientationKalmanFilter(dt=run.dt)
    fqa_error, kalman_error = [], []
    for k in range(len(run.time)):
        _, euler = compute_fqa_quaternion(run.accel[k], run.mag[k])
        kf.predict(run.gyro[k])
        kf.update(np.array(euler))
        fqa_error.append(normalize_angle(euler[2] - run.true_yaw[k]))
        kalman_error.append(normalize_angle(kf.get_euler_angles()[2] - run.true_yaw[k]))
    rmse_fqa, rmse_kalman = np.sqrt(np.mean(np.square(fqa_error))), np.sqrt(np.mean(np.square(kalman_error)))
    print(f"RMSE FQA {np.degrees(rmse_fqa):.2f} deg, Kalman {np.degrees(rmse_kalman):.2f} deg, bias z {kf.get_gyro_biases()[2]:.4f}")
    assert rmse_kalman < rmse_fqa
    assert abs(kf.get_gyro_biases()[2] - run.true_gyro_bias[2]) < 0.02
