"""Self-check tests for task 2a (rotation matrices in src/turtlebot/mount_calibration.py)."""

import numpy as np
import pytest

from src.turtlebot.mount_calibration import rotation_to_euler, rotation_x, rotation_y, rotation_z, tilt_rotation_from_gravity

G = 9.80665


@pytest.mark.parametrize("rotation", [rotation_x, rotation_y, rotation_z])
def test_rotation_matrices_are_proper(rotation) -> None:
    """Every rotation matrix is orthogonal with determinant +1; angle 0 is the identity."""
    R = rotation(0.7)
    assert R.shape == (3, 3)
    assert np.allclose(R @ R.T, np.eye(3))
    assert np.isclose(np.linalg.det(R), 1.0)
    assert np.allclose(rotation(0.0), np.eye(3))


def test_rotation_directions() -> None:
    """Positive angles rotate counter-clockwise (right-hand rule) about the respective axis."""
    a = np.pi / 2.0
    assert np.allclose(rotation_z(a) @ [1.0, 0.0, 0.0], [0.0, 1.0, 0.0])
    assert np.allclose(rotation_x(a) @ [0.0, 1.0, 0.0], [0.0, 0.0, 1.0])
    assert np.allclose(rotation_y(a) @ [0.0, 0.0, 1.0], [1.0, 0.0, 0.0])


@pytest.mark.parametrize("roll_deg,pitch_deg,yaw_deg", [(0.0, 0.0, 0.0), (30.0, -20.0, 110.0), (179.0, 5.0, -45.0)])
def test_rotation_to_euler_inverts_zyx(roll_deg: float, pitch_deg: float, yaw_deg: float) -> None:
    """rotation_to_euler returns the angles of R = Rz(yaw) @ Ry(pitch) @ Rx(roll)."""
    roll, pitch, yaw = np.radians([roll_deg, pitch_deg, yaw_deg])
    R = rotation_z(yaw) @ rotation_y(pitch) @ rotation_x(roll)
    assert np.allclose(rotation_to_euler(R), (roll, pitch, yaw), atol=1e-9)


def test_upside_down_sensor() -> None:
    """With your rotations, the provided tilt estimate recognises a sensor mounted upside down."""
    R = tilt_rotation_from_gravity(np.array([0.0, 0.0, -G]))
    assert np.allclose(R @ [0.0, 0.0, -G], [0.0, 0.0, G], atol=1e-9)
    assert np.isclose(abs(np.degrees(rotation_to_euler(R)[0])), 180.0)
