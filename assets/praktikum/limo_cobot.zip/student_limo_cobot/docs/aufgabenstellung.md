# Aufgabenstellung: LIMO Cobot – Autonomes Greifen & Navigieren

Die Dateinamen beziehen sich auf das bereitgestellte Gerüst; bei eigener Struktur gelten die Aufgaben sinngemäß.

Schritt 2, 3 und die Anfahrt aus Schritt 5 können Sie zuhause in der [Gazebo-Simulation](../docker_container/README.md) testen. Der Arm wird dort nicht simuliert; Schritt 4 und die vollständige Mission prüfen Sie am echten Roboter.

---

## Schritt 1: Kennenlernen

1. Verbinden Sie sich mit dem LIMO und starten Sie die Treiber ([Inbetriebnahme](./inbetriebnahme.md)).  
2. Steuern Sie das Fahrgestell mit dem PS4-Controller (L1/R1 gedrückt halten).  
3. Schreiben Sie ein kurzes Skript, das über einen ROS-2-Publisher auf `/cmd_vel` (`geometry_msgs/Twist`) $3\text{ s}$ lang mit $0{,}2\text{ m/s}$ vorwärts fährt und dann stoppt.  

---

## Schritt 2: Fahrgestell

Datei: [`src/limo_drive_controller.py`](../src/limo_drive_controller.py)

Implementieren Sie `drive_distance` und `turn_angle` als zeitbasierte Steuerung:

$$t = \frac{|d|}{|v|}, \qquad t = \frac{|\theta_{\text{rad}}|}{|\omega_{\text{rad}}|}$$

Der Fahrbefehl muss während der Fahrt laufend wiederholt werden, sonst hält das Fahrgestell an.

**Fragen:**

- Fahren Sie $1{,}0\text{ m}$ und drehen Sie $90^\circ$. Wie groß sind die Abweichungen, und sind sie reproduzierbar?  
- Warum reicht diese Steuerung ohne Rückführung nicht, um den Würfel zum Greifen anzufahren?  

---

## Schritt 3: Würfel erkennen

Datei: [`src/limo_vision_detector.py`](../src/limo_vision_detector.py)

Implementieren Sie die Erkennung in fünf Stufen:

1. **Farbraum:** BGR → HSV (`cv2.cvtColor`). In OpenCV gilt $H \in [0, 180]$; Gelb ($60^\circ$) liegt bei $H \approx 30$.  
2. **Schwellwert:** Binärmaske mit `cv2.inRange`.  
3. **Morphologie:** Opening gegen Rauschpunkte, Closing gegen Löcher ($5 \times 5$).  
4. **Kontur:** größte Kontur mit Fläche $\ge 300\text{ px}^2$, Schwerpunkt $(c_x, c_y)$ über die Bildmomente.  
5. **3D-Position:** mit Tiefe $Z$ und Brennweite $f$:  

$$X = \frac{(c_x - c_x^0) \cdot Z}{f_x}, \qquad Y = \frac{(c_y - c_y^0) \cdot Z}{f_y}$$

`get_intermediate_images` liefert die Zwischenbilder aller Stufen und zusätzlich eine naive RGB-Maske zum Vergleich.

Für das Greifen misst der Baustein `observe_cube` die Entfernung genauer: Median der Tiefenwerte innerhalb der Würfelmaske über mehrere Bilder, plus Korrektur. Voraussetzung ist die Kamera mit `depth_registration:=true`.

**Experimente und Fragen:**

- **RGB gegen HSV:** Vergleichen Sie beide Masken bei mindestens zwei Lichtverhältnissen und zwei Hintergründen. Warum scheitert der RGB-Schwellwert bei Schatten?  
- **Wertebereich:** Wie eng darf das Hue-Intervall sein, damit Gelb sicher erkannt, Orange und Hellgrün aber ausgeschlossen werden? Warum bräuchte Rot zwei Intervalle?  
- **Sättigung und Helligkeit:** Was bewirken zu niedrige Untergrenzen für $S$ und $V$?  
- **Morphologie:** Zeigen Sie an Beispielbildern, was Opening und Closing verändern.  
- **Grenzen:** Ab welchem Abstand oder welcher Beleuchtung geht der Würfel verloren, wann entstehen Fehlerkennungen?  
- **Tiefe:** Vergleichen Sie bei drei Abständen `obs.distance` mit `obs.est_distance` (Schätzung aus der Würfelbreite). Ist die Abweichung konstant? Die Kamera liefert unter ca. $0{,}18\text{ m}$ keine Tiefe.  

---

## Schritt 4: Arm

Datei: [`src/cobot_arm_controller.py`](../src/cobot_arm_controller.py)

Implementieren Sie `pick_cube` und `place_cube` mit Griff senkrecht von oben:

| `pick_cube` | `place_cube` |
|---|---|
| Greifer öffnen | Vorposition $10\text{ cm}$ über dem Ziel |
| Vorposition $10\text{ cm}$ über dem Ziel | zum Ziel absenken |
| zum Ziel absenken | Greifer öffnen |
| Greifer schließen | zurück zur Vorposition |
| zurück zur Vorposition | Home-Pose |

Am echten LIMO reicht der Griff von oben nicht: Der Arm würde mit Kamera und Fahrgestell kollidieren. Der Baustein `grasp_cube` greift deshalb schräg von vorne ($60^\circ$) und berücksichtigt Greiferlänge und Montagedrehung.

**Fragen:**

- Wozu dient die Vorposition?  
- Lesen Sie `compute_grasp_targets` in `src/cube_grasp.py`: Wie entsteht der Greifpunkt aus Entfernung und Pixelposition? Warum wird der Flansch um die Greiferlänge zurückgesetzt?  

---

## Schritt 5: Mission

Datei: [`src/limo_cobot_mission.py`](../src/limo_cobot_mission.py)

**`approach_cube`:** Die Steuerung aus Schritt 2 ist zu ungenau für eine einmalige Positionierung. Beobachten Sie deshalb nach jeder Bewegung den Würfel erneut und korrigieren Sie in kleinen Schritten:

- nicht zentriert ($|\text{Winkel}| > 3^\circ$): zum Würfel drehen,  
- zentriert, aber Entfernung nicht bei $0{,}23 \pm 0{,}03\text{ m}$: höchstens $0{,}15\text{ m}$ fahren,  
- nach höchstens 8 Schritten oder ohne Beobachtung: abbrechen.  

**`execute_full_mission`:** die fünf Phasen aus dem README. Ohne Kamera (Stand-alone) arbeitet die Erkennung auf einem Testbild und der Arm greift mit `pick_cube`; mit Kamera werden `approach_cube` und der Greifbaustein verwendet. Wird der Würfel nicht gefunden oder ist er nicht erreichbar, bricht die Mission ab.

---

## Erwartete Ergebnisse

- Bestandene Selbsttests (bzw. eigene Tests bei eigener Struktur).  
- Antworten auf die Fragen mit Beispielbildern aus `get_intermediate_images`.  
- Messwerte zur Fahrgenauigkeit (Schritt 2) und zur Tiefenmessung (Schritt 3).  
- Eine Vorführung der vollständigen Mission am Roboter.  
