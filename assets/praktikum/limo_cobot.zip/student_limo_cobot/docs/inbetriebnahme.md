# Inbetriebnahme am Roboter

Der LIMO hat einen Onboard-PC (Ubuntu 20.04, ROS 2 Foxy, Python 3.8). Ihr Programm läuft direkt darauf.

---

## Verbindung

Laptop und LIMO müssen im selben WLAN sein. IP-Adresse und Zugangsdaten erhalten Sie von den Betreuenden.

- **NoMachine (grafisch, empfohlen):** neue Verbindung zur IP des LIMO, Protokoll NX (Port 4000).  
- **SSH:** `ssh <benutzer>@<ip>`  

---

## Treiber starten

```bash
# Terminal 1: Fahrgestell und Sensorik
ros2 launch limo_bringup limo_start.launch.py

# Terminal 2: Kamera - depth_registration ist Pflicht für das Greifen
ros2 launch orbbec_camera dabai.launch.py depth_registration:=true
```

Prüfen: `ros2 topic list | grep camera` muss `/camera/color/image_raw` und `/camera/depth/image_raw` zeigen.

Der Arm hängt an `/dev/ttyACM0` und wird direkt über `pymycobot` angesprochen. Kein anderes Programm darf den Port belegen.

---

## Vor der ersten Mission

1. Fahrgestell einzeln testen (Schritt 2), mit freiem Platz um den Roboter.  
2. Erkennung im Stand prüfen: `observe_cube` aufrufen und mit `save_observation` Kontrollbilder speichern.  
3. Greifen im Stand prüfen: Würfel ca. $0{,}23\text{ m}$ mittig vor die Kamera stellen und `grasp_cube(..., dry_run=True)` ausführen; erst danach ohne `dry_run`.  

---

## Sicherheit

- Eine Person bleibt am Roboter. Niemand greift in den Arbeitsbereich des Arms, solange ein Programm läuft.  
- Abbruch mit `Strg+C`.  
- Fahrgestell sofort stoppen:  

  ```bash
  ros2 topic pub /cmd_vel geometry_msgs/msg/Twist "{linear: {x: 0.0}, angular: {z: 0.0}}" --once
  ```

- Arm stromlos schalten (er sackt dabei ab, vorher festhalten):  

  ```bash
  ros2 service call /mycobot/release_all_servos std_srvs/srv/Trigger
  ```
