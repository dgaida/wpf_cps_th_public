#!/usr/bin/env python3
"""Main execution script for the LIMO Cobot Pick-and-Place mission (provided).

This script acts as the main entry point to run the autonomous pick-and-place task
on the AgileX LIMO Cobot onboard PC or in simulation. It initializes ROS 2 node context
when available and orchestrates the chassis, vision detector, and 6DOF arm controllers
defined in the `src/` package.

Usage:
    python3 main_mission.py          # real LIMO (or stand-alone without ROS 2)
    python3 main_mission.py --sim    # Gazebo simulation, see docker_container/README.md
"""

import argparse

try:
    import rclpy
    ROS2_AVAILABLE = True
except ImportError:
    ROS2_AVAILABLE = False

from src.limo_drive_controller import LimoDriveController
from src.limo_vision_detector import LimoVisionDetector
from src.cobot_arm_controller import CobotArmController
from src.cube_grasp import CubeCamera, GraspCalibration
from src.limo_cobot_mission import LimoCobotMission


def main() -> None:
    """Execute the main autonomous LIMO Cobot mission routine.

    Initializes ROS 2 (if installed on the robot environment), instantiates
    the subsystem controllers from `src/`, and executes the complete autonomous
    5-phase mission pipeline (Drive, Detect & Approach, Pick, Return, Place).

    Mit ROS 2 wird die Kamera über src.cube_grasp.CubeCamera eingebunden. Erkennung,
    Anfahrt und Greifen laufen dann mit den kalibrierten Werten aus
    src/cube_grasp.py (GraspCalibration). Ohne ROS 2 läuft die Mission in Simulation.
    """
    parser = argparse.ArgumentParser(description="LIMO Cobot pick-and-place mission")
    parser.add_argument("--sim", action="store_true",
                        help="Gazebo simulation: camera topics of the simulated LIMO, no depth correction")
    args = parser.parse_args()

    print("===========================================================")
    print("🤖 LIMO COBOT — AUTONOMES GREIFEN & NAVIGIEREN")
    print("===========================================================")

    # Initialize ROS 2 context if available
    if ROS2_AVAILABLE:
        rclpy.init()
        print("✅ ROS 2 Kontext erfolgreich initialisiert.")
    else:
        print("⚠️  ROS 2 nicht gefunden. Skript läuft im Standalone-/Simulationsmodus.")

    try:
        # Step 1: Instantiate subsystem controllers from src/
        print("\n[Init] Initialisiere Subsystem-Controller...")
        drive_ctrl = LimoDriveController(topic_name="/cmd_vel")
        vision_det = LimoVisionDetector()
        arm_ctrl = CobotArmController()

        # Kamera (Farb- und Tiefenbild) nur mit ROS 2; sonst Simulation mit Testbild
        calibration = GraspCalibration()
        if not ROS2_AVAILABLE:
            camera = None
        elif args.sim:
            # Die simulierte Kamera publiziert unter /limo/... und misst die Tiefe ohne den
            # systematischen Fehler der echten Kamera.
            camera = CubeCamera(color_topic="/limo/color/image_raw", info_topic="/limo/color/camera_info",
                                depth_topic="/limo/depth/image_raw")
            calibration = calibration.with_(depth_offset_m=0.0)
        else:
            camera = CubeCamera()
        if camera is not None:
            print("✅ Kamera-Subscriber gestartet (Erkennung und Greifen mit den Kalibrierwerten aus src/cube_grasp.py).")

        # Step 2: Instantiate high-level mission orchestrator
        mission_manager = LimoCobotMission(
            drive_controller=drive_ctrl,
            vision_detector=vision_det,
            arm_controller=arm_ctrl,
            camera=camera,
            calibration=calibration,
        )

        # Step 3: Execute full autonomous mission
        print("[Mission] Starte Hauptmission...\n")
        success: bool = mission_manager.execute_full_mission()

        # Step 4: Output summary status
        if success:
            print("\n🎉 Mission wurde erfolgreich beendet!")
        else:
            print("\n❌ Mission wurde mit Fehlern abgebrochen.")

    except KeyboardInterrupt:
        print("\n⚠️ Mission manuell durch Benutzer abgebrochen.")
    finally:
        # Cleanup ROS 2 context
        if ROS2_AVAILABLE:
            rclpy.shutdown()
            print("✅ ROS 2 Kontext ordnungsgemäß heruntergefahren.")


if __name__ == "__main__":
    main()
