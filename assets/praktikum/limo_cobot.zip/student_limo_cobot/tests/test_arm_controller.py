"""Self-check tests for step 4 (src/cobot_arm_controller.py)."""

from typing import List, Tuple

import pytest

from src.cobot_arm_controller import CobotArmController


class RecordingArm(CobotArmController):
    """Arm controller without hardware that records the sequence of commands."""

    def __init__(self) -> None:
        super().__init__()
        self.mc = None
        self.calls: List[Tuple] = []

    def open_gripper(self, speed: int = 50) -> None:
        self.calls.append(("open",))

    def close_gripper(self, speed: int = 50) -> None:
        self.calls.append(("close",))

    def move_to_coords(self, coords_3d, rx_ry_rz=(-180.0, 0.0, 0.0), speed=50, mode=1) -> None:
        self.calls.append(("move", tuple(round(float(c), 3) for c in coords_3d)))

    def move_to_joint_angles(self, angles, speed=50) -> None:
        self.calls.append(("joints", tuple(float(a) for a in angles)))


def test_pick_sequence(fake_clock) -> None:
    """Open, pre-pick pose above the target, target, close, back to the pre-pick pose."""
    arm = RecordingArm()
    assert arm.pick_cube((0.2, 0.0, 0.1)) is True
    assert arm.calls == [
        ("open",),
        ("move", (0.2, 0.0, 0.2)),
        ("move", (0.2, 0.0, 0.1)),
        ("close",),
        ("move", (0.2, 0.0, 0.2)),
    ]


def test_place_sequence(fake_clock) -> None:
    """Pose above the target, target, open, back up, home pose."""
    arm = RecordingArm()
    assert arm.place_cube((0.2, 0.05, 0.05)) is True
    assert arm.calls == [
        ("move", (0.2, 0.05, 0.15)),
        ("move", (0.2, 0.05, 0.05)),
        ("open",),
        ("move", (0.2, 0.05, 0.15)),
        ("joints", (0.0, 0.0, 0.0, 0.0, 0.0, 0.0)),
    ]
