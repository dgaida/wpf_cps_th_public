"""Self-check tests for step 2 (src/limo_drive_controller.py)."""

import math
from typing import List, Tuple

from src.limo_drive_controller import LimoDriveController


class RecordingDrive(LimoDriveController):
    """Drive controller that records all velocity commands together with the time."""

    def __init__(self, clock) -> None:
        super().__init__()
        self.clock = clock
        self.commands: List[Tuple[float, float, float]] = []

    def send_velocity(self, linear_x: float, angular_z: float) -> None:
        self.commands.append((self.clock.time(), float(linear_x), float(angular_z)))


def test_drive_distance_duration_and_stop(fake_clock) -> None:
    """1.0 m with 0.2 m/s takes 5 s, the command is repeated and the chassis stops at the end."""
    drive = RecordingDrive(fake_clock)
    start = fake_clock.time()
    drive.drive_distance(distance_m=1.0, speed_mps=0.2)

    assert math.isclose(fake_clock.time() - start, 5.0, abs_tol=0.1)
    moving = [c for c in drive.commands if c[1] != 0.0]
    assert len(moving) >= 50                     # repeated at least every 0.1 s
    assert all(math.isclose(c[1], 0.2) and c[2] == 0.0 for c in moving)
    assert drive.commands[-1][1:] == (0.0, 0.0)  # stopped


def test_drive_distance_backwards(fake_clock) -> None:
    """A negative distance drives backwards; the sign of the speed is ignored."""
    drive = RecordingDrive(fake_clock)
    drive.drive_distance(distance_m=-0.5, speed_mps=-0.25)
    moving = [c for c in drive.commands if c[1] != 0.0]
    assert moving and all(math.isclose(c[1], -0.25) for c in moving)
    assert math.isclose(moving[-1][0] - moving[0][0], 2.0, abs_tol=0.1)


def test_turn_angle(fake_clock) -> None:
    """45 deg with 20 deg/s takes 2.25 s; positive angles turn left with positive rad/s."""
    drive = RecordingDrive(fake_clock)
    start = fake_clock.time()
    drive.turn_angle(angle_deg=45.0, angular_speed_degps=20.0)

    assert math.isclose(fake_clock.time() - start, 2.25, abs_tol=0.1)
    turning = [c for c in drive.commands if c[2] != 0.0]
    assert turning and all(c[1] == 0.0 and math.isclose(c[2], math.radians(20.0)) for c in turning)
    assert drive.commands[-1][1:] == (0.0, 0.0)

    drive.commands.clear()
    drive.turn_angle(angle_deg=-90.0, angular_speed_degps=30.0)
    assert all(math.isclose(c[2], -math.radians(30.0)) for c in drive.commands if c[2] != 0.0)


def test_zero_speed_does_nothing(fake_clock) -> None:
    """A speed of zero must not end in an endless loop."""
    drive = RecordingDrive(fake_clock)
    drive.drive_distance(1.0, 0.0)
    drive.turn_angle(90.0, 0.0)
    assert all(c[1] == 0.0 and c[2] == 0.0 for c in drive.commands)
