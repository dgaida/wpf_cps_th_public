"""Self-check tests for step 3 (src/limo_vision_detector.py)."""

import cv2
import numpy as np

from src.limo_vision_detector import LimoVisionDetector

YELLOW_BGR = (0, 255, 255)


def scene(color=YELLOW_BGR, top_left=(280, 200), bottom_right=(360, 280), background=0) -> np.ndarray:
    """Synthetic 640x480 BGR image with one filled rectangle."""
    img = np.full((480, 640, 3), background, dtype=np.uint8)
    cv2.rectangle(img, top_left, bottom_right, color, -1)
    return img


def test_yellow_cube_found() -> None:
    """The centroid of a yellow rectangle is found; without depth image the default depth is used."""
    found, (cx, cy), depth, coords = LimoVisionDetector().detect_yellow_cube(scene())
    assert found is True
    assert abs(cx - 320) <= 2 and abs(cy - 240) <= 2
    assert depth == 0.35
    assert np.allclose(coords, (0.0, 0.0, 0.35), atol=0.005)


def test_3d_coordinates_off_centre() -> None:
    """x and y follow from the pinhole model with fx = fy = 525 px and the image centre."""
    found, (cx, cy), depth, (x, y, z) = LimoVisionDetector().detect_yellow_cube(scene(top_left=(480, 100), bottom_right=(560, 180)))
    assert found is True
    assert np.isclose(x, (cx - 320) * 0.35 / 525.0, atol=1e-6) and x > 0
    assert np.isclose(y, (cy - 240) * 0.35 / 525.0, atol=1e-6) and y < 0
    assert z == depth


def test_depth_from_depth_image() -> None:
    """With a depth image in millimeters, the depth at the centroid is used."""
    depth_img = np.full((480, 640), 420, dtype=np.uint16)
    found, _, depth, coords = LimoVisionDetector().detect_yellow_cube(scene(), depth_img)
    assert found is True
    assert np.isclose(depth, 0.42) and np.isclose(coords[2], 0.42)


def test_other_colours_are_ignored() -> None:
    """Black, red, blue, green and white objects are no yellow cube."""
    detector = LimoVisionDetector()
    assert detector.detect_yellow_cube(np.zeros((480, 640, 3), dtype=np.uint8))[0] is False
    for color in [(0, 0, 255), (255, 0, 0), (0, 255, 0), (255, 255, 255)]:
        assert detector.detect_yellow_cube(scene(color=color))[0] is False


def test_small_objects_are_ignored() -> None:
    """Yellow spots smaller than 300 px^2 are noise."""
    assert LimoVisionDetector().detect_yellow_cube(scene(top_left=(300, 200), bottom_right=(310, 210)))[0] is False


def test_largest_yellow_object_wins() -> None:
    """With several yellow objects, the largest one is reported."""
    img = scene(top_left=(100, 100), bottom_right=(130, 130))
    cv2.rectangle(img, (400, 300), (500, 400), YELLOW_BGR, -1)
    found, (cx, cy), _, _ = LimoVisionDetector().detect_yellow_cube(img)
    assert found is True and abs(cx - 450) <= 2 and abs(cy - 350) <= 2


def test_empty_image() -> None:
    """An empty image yields no detection instead of an exception."""
    assert LimoVisionDetector().detect_yellow_cube(np.zeros((0, 0, 3), dtype=np.uint8)) == (False, (0, 0), 0.0, (0.0, 0.0, 0.0))


def test_intermediate_images() -> None:
    """All pipeline stages are returned; opening removes noise that the raw mask still contains."""
    img = scene()
    img[50:52, 50:52] = YELLOW_BGR  # small noise spot
    stages = LimoVisionDetector().get_intermediate_images(img)

    for key in ["hsv", "rgb_mask", "hsv_raw_mask", "mask_opened", "mask_closed", "result_visualization"]:
        assert key in stages
    assert stages["hsv"].shape == (480, 640, 3)
    assert stages["result_visualization"].shape == (480, 640, 3)
    for key in ["rgb_mask", "hsv_raw_mask", "mask_opened", "mask_closed"]:
        assert stages[key].shape == (480, 640)
    assert stages["hsv_raw_mask"][50, 50] == 255 and stages["mask_opened"][50, 50] == 0
    assert stages["mask_closed"][240, 320] == 255 and stages["mask_closed"][10, 10] == 0
