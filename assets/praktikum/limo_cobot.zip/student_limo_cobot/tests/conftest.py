"""Run the self-check tests from the task folder: python3 -m pytest tests -v"""

import os
import sys

import pytest

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))


class FakeClock:
    """Replacement for the time module: sleep() advances the clock without waiting."""

    def __init__(self) -> None:
        self.now = 1000.0

    def time(self) -> float:
        return self.now

    def monotonic(self) -> float:
        return self.now

    def sleep(self, seconds: float) -> None:
        self.now += max(0.0, float(seconds))


@pytest.fixture
def fake_clock(monkeypatch) -> FakeClock:
    """Let all controller modules use a fake clock, so that the tests do not wait in real time."""
    import src.cobot_arm_controller as arm_module
    import src.limo_cobot_mission as mission_module
    import src.limo_drive_controller as drive_module

    clock = FakeClock()
    for module in (drive_module, arm_module, mission_module):
        monkeypatch.setattr(module, "time", clock)
    return clock
