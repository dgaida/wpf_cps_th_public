"""Self-check tests for step 5 (src/limo_cobot_mission.py)."""

from typing import List, Optional, Tuple

import numpy as np
import pytest

from src.limo_cobot_mission import LimoCobotMission


class Observation:
    """Minimal stand-in for CubeObservation."""

    def __init__(self, angle_deg: float, distance: float) -> None:
        self.angle_deg = angle_deg
        self.distance = distance


class FakeDrive:
    def __init__(self) -> None:
        self.moves: List[Tuple[str, float]] = []

    def drive_distance(self, distance_m: float, speed_mps: float = 0.2) -> None:
        self.moves.append(("drive", round(float(distance_m), 3)))

    def turn_angle(self, angle_deg: float, angular_speed_degps: float = 30.0) -> None:
        self.moves.append(("turn", round(float(angle_deg), 3)))

    def stop(self) -> None:
        pass


class FakeArm:
    def __init__(self, pick_ok: bool = True) -> None:
        self.pick_ok = pick_ok
        self.calls: List[Tuple] = []

    def pick_cube(self, target_coords_3d) -> bool:
        self.calls.append(("pick", tuple(target_coords_3d)))
        return self.pick_ok

    def place_cube(self, target_coords_3d) -> bool:
        self.calls.append(("place", tuple(target_coords_3d)))
        return True

    def move_to_home_pose(self, speed: int = 50) -> None:
        self.calls.append(("home",))


class FakeVision:
    def __init__(self, found: bool = True) -> None:
        self.found = found

    def detect_yellow_cube(self, color_img, depth_img=None):
        return self.found, (320, 240), 0.35, (0.01, 0.0, 0.35)


def make_mission(found: bool = True, pick_ok: bool = True) -> LimoCobotMission:
    return LimoCobotMission(FakeDrive(), FakeVision(found), FakeArm(pick_ok))


def scripted(observations: List[Optional[Observation]]):
    """Observation function returning one prepared observation per call."""
    queue = list(observations)
    return lambda: queue.pop(0) if queue else None


def test_approach_already_in_position(fake_clock) -> None:
    """A centred cube at grasp distance needs no motion."""
    mission = make_mission()
    obs = Observation(angle_deg=1.0, distance=0.24)
    assert mission.approach_cube(scripted([obs])) is obs
    assert mission.drive.moves == []


def test_approach_turns_towards_the_cube_first(fake_clock) -> None:
    """A cube right of the image centre (positive angle) requires a turn to the right (negative)."""
    mission = make_mission()
    final = Observation(0.5, 0.23)
    result = mission.approach_cube(scripted([Observation(10.0, 0.50), Observation(0.0, 0.50), Observation(0.0, 0.35), final]))
    assert result is final
    assert mission.drive.moves == [("turn", -10.0), ("drive", 0.15), ("drive", 0.12)]


def test_approach_backs_up_if_too_close(fake_clock) -> None:
    """Closer than the grasp distance means driving backwards."""
    mission = make_mission()
    mission.approach_cube(scripted([Observation(0.0, 0.18), Observation(0.0, 0.23)]))
    assert mission.drive.moves == [("drive", -0.05)]


def test_approach_gives_up_without_observation(fake_clock) -> None:
    """If the cube cannot be observed, the approach fails without moving."""
    mission = make_mission()
    assert mission.approach_cube(scripted([None])) is None
    assert mission.drive.moves == []


def test_approach_is_limited(fake_clock) -> None:
    """A cube that never gets centred ends the approach after the maximum number of steps."""
    mission = make_mission()
    assert mission.approach_cube(lambda: Observation(20.0, 0.60)) is None
    assert 1 <= len(mission.drive.moves) <= 8


def test_full_mission_in_simulation(fake_clock) -> None:
    """Without camera: drive to the cube, pick, drive the same path back, place."""
    mission = make_mission()
    assert mission.execute_full_mission() is True
    assert mission.drive.moves == [
        ("drive", 1.0), ("turn", 45.0), ("drive", 0.5),
        ("drive", -0.5), ("turn", -45.0), ("drive", -1.0),
    ]
    assert mission.arm.calls == [("pick", (0.01, 0.0, 0.35)), ("place", (0.2, 0.0, 0.05))]


def test_full_mission_aborts_without_cube(fake_clock) -> None:
    """If no cube is detected, nothing is picked and the mission reports the failure."""
    mission = make_mission(found=False)
    assert mission.execute_full_mission(np.zeros((480, 640, 3), dtype=np.uint8)) is False
    assert mission.arm.calls == []
