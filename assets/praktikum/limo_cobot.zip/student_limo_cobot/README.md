# Praktikum: LIMO Cobot – Autonomes Greifen & Navigieren

Der **AgileX LIMO Cobot** ist eine mobile Manipulationsplattform: Fahrgestell, 6-Achs-Arm (myCobot 280, Reichweite ca. $0{,}28\text{ m}$) und RGB-D-Kamera (Orbbec Dabai). In diesem Praktikum fährt der Roboter selbstständig zu einem **gelben Würfel** (Kantenlänge $3\text{ cm}$), greift ihn und bringt ihn zum Startpunkt zurück:

```text
1. Navigation   1,0 m vor ─► 45° links ─► 0,5 m vor
2. Erkennung    Würfel im Kamerabild finden, zentrieren, auf ca. 0,23 m heranfahren
3. Greifen      Arm greift den Würfel
4. Rückfahrt    denselben Weg rückwärts
5. Ablegen      Würfel am Startpunkt ablegen
```

---

## 📂 Unterlagen

- [**Aufgabenstellung**](./docs/aufgabenstellung.md) – die fünf Schritte, Fragen und erwartete Ergebnisse  
- [**Inbetriebnahme am Roboter**](./docs/inbetriebnahme.md) – Verbindung, Start der Treiber, Not-Aus  
- [**Gazebo-Simulation für zuhause**](./docker_container/README.md) – Fahrgestell und Kamera ohne Roboter testen  

---

## 🧱 Gerüst oder eigene Struktur

Sie haben zwei Möglichkeiten:

- **Mit dem Gerüst:** Sie lösen die mit `TODO` markierten Stellen in der vorgegebenen Struktur.  
- **Von Grund auf:** Sie setzen das Projekt mit eigener Struktur um. Die bereitgestellten Teile dürfen Sie übernehmen oder als Nachschlagewerk nutzen. Aufgabenstellung und erwartete Ergebnisse gelten für beide Wege.  

| Datei | Inhalt | Status |
|---|---|---|
| [`src/cube_grasp.py`](./src/cube_grasp.py) | Kamera, Entfernungsmessung und am Roboter eingemessener Greifvorgang | fertig |
| [`main_mission.py`](./main_mission.py) | Startskript der Mission | fertig |
| [`docker_container/`](./docker_container/) | Gazebo-Simulation mit Würfel auf einem Podest | fertig |
| [`src/limo_drive_controller.py`](./src/limo_drive_controller.py) | Strecke fahren, auf der Stelle drehen | **TODO (Schritt 2)** |
| [`src/limo_vision_detector.py`](./src/limo_vision_detector.py) | gelben Würfel im Farbbild erkennen | **TODO (Schritt 3)** |
| [`src/cobot_arm_controller.py`](./src/cobot_arm_controller.py) | Greif- und Ablegesequenz (Grundbefehle sind fertig) | **TODO (Schritt 4)** |
| [`src/limo_cobot_mission.py`](./src/limo_cobot_mission.py) | Anfahrt an den Würfel und Gesamtablauf | **TODO (Schritt 5)** |
| [`tests/`](./tests/) | Selbsttests für Schritt 2 bis 5 | fertig |

### Der fertige Greifbaustein

Den Würfel am echten Roboter zu greifen erfordert eine Kalibrierung (Tiefenkorrektur, Versatz Kamera–Arm, Anfahrwinkel, Montagedrehung des Arms). Diese ist eingemessen und steht in `src/cube_grasp.py` bereit. Wie der Roboter zum Würfel kommt, bleibt Ihre Aufgabe.

```python
from src.cube_grasp import CubeCamera, GraspCalibration, observe_cube, grasp_cube

obs = observe_cube(camera, detector, calib)    # Entfernung (m) und Winkel (°) zum Würfel
if obs is not None and obs.distance < 0.30:    # ab 0,30 m außerhalb der Armreichweite
    grasp_cube(arm, camera, detector, calib)   # greifen, endet in der Home-Pose
```

Der Baustein verwendet Ihren `LimoVisionDetector`; behalten Sie deshalb dessen Methodensignaturen bei.

---

## 🧪 Selbsttests und Start

Die Tests laufen ohne Roboter und ohne ROS 2 (benötigt: `numpy`, `opencv-python`, `pytest`). Zu Beginn schlagen alle fehl. Sie sind auf das Gerüst zugeschnitten; bei eigener Struktur schreiben Sie eigene Tests.

```bash
python3 -m pytest tests -v
```

Ihren Code können Sie auf drei Stufen ausführen:

| Stufe | Start | Was getestet wird |
|---|---|---|
| Stand-alone (ohne ROS 2) | `python3 main_mission.py` | Ablauf; Fahr- und Armbefehle werden nur ausgegeben, Erkennung auf einem Testbild |
| Gazebo-Simulation | `./docker_container/run_in_sim.sh main_mission.py --sim` | Fahren, Erkennung und Anfahrt an den Würfel; der Arm wird nicht simuliert |
| Echter Roboter | `python3 main_mission.py` auf dem LIMO | alles – hier muss die Lösung am Ende funktionieren |
