#!/bin/bash
# Put robot and cube back to their start poses.
docker exec limo_cobot_simulation bash -c \
  "source /opt/ros/noetic/setup.bash && rosservice call /gazebo/reset_world"
