#!/bin/bash
# Run a Python script of the task folder inside the simulation container with ROS 2 (Foxy).
#   ./docker_container/run_in_sim.sh main_mission.py --sim
#   ./docker_container/run_in_sim.sh -m pytest tests -v
docker exec -it limo_cobot_simulation bash -c \
  "source /opt/ros/foxy/setup.bash && cd /root/student_limo_cobot && python3 $*"
