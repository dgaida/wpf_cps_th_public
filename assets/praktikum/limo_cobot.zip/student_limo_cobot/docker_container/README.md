# Gazebo-Simulation für zuhause

Mit diesem Docker-Container testen Sie Ihren Code ohne Roboter: Der LIMO Cobot steht in einer Gazebo-Welt vor einem Podest mit gelbem Würfel. Am Ende muss Ihre Lösung auf dem echten Roboter laufen; die Simulation ersetzt den Versuch im Labor nicht.

---

## Was die Simulation abdeckt

| Teil | In der Simulation |
|---|---|
| Fahrgestell (`/cmd_vel`, `/odom`) | ja – Ihr `LimoDriveController` bewegt den simulierten LIMO |
| Kamera (Farb- und Tiefenbild) | ja – Erkennung und Anfahrt an den Würfel (`approach_cube`) |
| Arm und Greifer | **nein** – die Armbefehle werden nur im Terminal ausgegeben, der Würfel bleibt liegen |

Die Simulation läuft intern mit ROS 1; eine Brücke (`ros1_bridge`) verbindet sie mit Ihrem ROS-2-Code. Abweichungen zum echten Roboter:

- Die Kamera publiziert unter `/limo/color/image_raw` und `/limo/depth/image_raw` statt `/camera/...`. `main_mission.py --sim` stellt das um.  
- Das simulierte Tiefenbild hat keinen Messfehler; `--sim` setzt die Tiefenkorrektur deshalb auf null.  
- Farben, Beleuchtung und Fahrverhalten sind idealisiert. HSV-Grenzen, die in der Simulation funktionieren, müssen am echten Würfel überprüft werden.  

---

## Voraussetzungen

Docker Desktop (Windows, macOS) oder Docker Engine mit Docker Compose (Linux). Der erste Build lädt mehrere Gigabyte und dauert einige Minuten.

---

## Verwendung

Alle Befehle im Ordner `student_limo_cobot/` ausführen.

```bash
# 1. Container bauen und starten
docker compose -f docker_container/docker-compose.yml up --build -d

# 2. Gazebo im Browser öffnen
#    http://localhost:8080

# 3. Mission in der Simulation ausführen
./docker_container/run_in_sim.sh main_mission.py --sim

# Selbsttests im Container
./docker_container/run_in_sim.sh -m pytest tests -v

# Roboter und Würfel auf die Startposition zurücksetzen
./docker_container/reset_sim.sh

# Container stoppen
docker compose -f docker_container/docker-compose.yml down
```

Ihr Ordner ist in den Container eingebunden: Änderungen am Code wirken sofort, ein neuer Build ist nicht nötig. Unter Windows führen Sie statt der `.sh`-Skripte den darin stehenden `docker exec`-Befehl direkt aus.

---

## Fehlersuche

```bash
docker compose -f docker_container/docker-compose.yml logs -f      # Ausgaben von Gazebo und Brücke
docker exec -it limo_cobot_simulation bash                         # Terminal im Container (ROS 1)
```

- **Der Roboter bewegt sich nicht:** Die Brücke startet ca. 20 s nach dem Container. Prüfen Sie in den Logs, ob `ros1_bridge` läuft.  
- **Kein Kamerabild:** Im Container-Terminal `rostopic hz /limo/color/image_raw` ausführen.  
