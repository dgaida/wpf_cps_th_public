"""Step 2: LIMO drive controller for time-based chassis motions.

TODO: Implement drive_distance and turn_angle. Publisher, send_velocity and stop are provided.
The tests in tests/test_drive_controller.py check your implementation.
"""

import math
import time

try:
    import rclpy
    from rclpy.node import Node
    from geometry_msgs.msg import Twist
    ROS2_AVAILABLE = True
except ImportError:
    ROS2_AVAILABLE = False
    Node = object  # type: ignore[misc, assignment]


class LimoDriveController(Node):
    """Controller for velocity commands and simple motions of the LIMO chassis.

    Without ROS 2 the controller runs in stand-alone mode and only prints the commands.
    """

    def __init__(self, topic_name: str = "/cmd_vel") -> None:
        """Initialize the controller and set up the ROS 2 publisher.

        Args:
            topic_name (str): Topic name for velocity commands. Defaults to '/cmd_vel'.
        """
        if ROS2_AVAILABLE:
            super().__init__("limo_drive_controller")
            self.publisher_ = self.create_publisher(Twist, topic_name, 10)
        else:
            self.publisher_ = None
            print("[Stand-alone Mode] LimoDriveController started without ROS 2.")

    def send_velocity(self, linear_x: float, angular_z: float) -> None:
        """Publish a velocity command. The chassis stops if no command arrives for a short time.

        Args:
            linear_x (float): Forward velocity in m/s.
            angular_z (float): Rotational velocity in rad/s (positive = counter-clockwise).
        """
        if ROS2_AVAILABLE and self.publisher_ is not None:
            msg = Twist()
            msg.linear.x = float(linear_x)
            msg.angular.z = float(angular_z)
            self.publisher_.publish(msg)
        print(f"[Drive] v = {linear_x:.2f} m/s, w = {angular_z:.2f} rad/s")

    def stop(self) -> None:
        """Stop all chassis movement immediately."""
        self.send_velocity(0.0, 0.0)

    def drive_distance(self, distance_m: float, speed_mps: float = 0.2) -> None:
        """Drive straight for a given distance.

        Args:
            distance_m (float): Distance in meters; negative values drive backwards.
            speed_mps (float): Speed in m/s (the sign is ignored). Defaults to 0.2.
        """
        # TODO: Compute the duration t = |d| / |v| and repeat the velocity command every 0.05 s
        # (time.time() and time.sleep()) until the time is over. Stop the chassis afterwards.
        # A speed of 0 does nothing.
        raise NotImplementedError("TODO: implement drive_distance")

    def turn_angle(self, angle_deg: float, angular_speed_degps: float = 30.0) -> None:
        """Rotate in place by a given angle.

        Args:
            angle_deg (float): Angle in degrees (positive = counter-clockwise / left).
            angular_speed_degps (float): Angular speed in degrees per second (the sign is ignored).
                Defaults to 30.0.
        """
        # TODO: Same principle as drive_distance; send_velocity expects rad/s (math.radians).
        raise NotImplementedError("TODO: implement turn_angle")
