"""Kalibrierter Greifvorgang für den gelben Würfel (LIMO Cobot mit myCobot 280 und Orbbec Dabai).

Dieses Modul stellt den am Roboter eingemessenen Greifvorgang als Baustein bereit.
Es enthält KEINE Missionslogik (keine Fahrbefehle, keine Anfahrt): Wie der Roboter
zum Würfel kommt und was danach passiert, bleibt Ihre Aufgabe.

Voraussetzungen auf dem LIMO:

    ros2 launch orbbec_camera dabai.launch.py depth_registration:=true

Die Registrierung (depth_registration) ist Pflicht: Nur dann liegt das Tiefenbild
pixelgenau auf dem Farbbild und die Würfelmaske aus dem Farbbild trifft im
Tiefenbild den Würfel.

Typische Verwendung::

    import rclpy
    from src import CobotArmController, LimoVisionDetector
    from src.cube_grasp import CubeCamera, GraspCalibration, observe_cube, grasp_cube

    rclpy.init()
    camera = CubeCamera()
    detector = LimoVisionDetector()
    arm = CobotArmController()
    calib = GraspCalibration()                # getestete Werte

    obs = observe_cube(camera, detector, calib)   # Würfel suchen, Entfernung und Winkel messen
    if obs is not None:
        print(obs.distance, obs.angle_deg)        # z. B. für die eigene Anfahrt nutzen
        grasp_cube(arm, camera, detector, calib)  # greifen, endet in der Home-Pose

Wie der Greifpunkt entsteht:

    1. Der Würfel wird im Farbbild erkannt (LimoVisionDetector). Aus der Pixelposition
       ergibt sich über das Lochkameramodell der seitliche Versatz zur Bildmitte.
    2. Die Entfernung ist der Median der Tiefenwerte innerhalb der Würfelmaske plus
       einer festen Korrektur (die Kamera misst am Würfel zu kurz).
    3. Würfelmitte vor der Armbasis = Entfernung + halbe Kantenlänge + Versatz
       Kamera -> Armbasis. Die Greifhöhe ist fest (Würfel steht auf der Platte).
    4. Der Greifer kommt schräg von oben (Anfahrwinkel). Die Armkoordinate bezeichnet
       den Flansch, deshalb wird der Flansch um die Greiferlänge entgegen der
       Anfahrrichtung zurückgesetzt; die Vorposition liegt noch weiter zurück.
    5. Der Arm ist gegenüber der Simulation um 90° gedreht montiert, die Zielpunkte
       werden entsprechend in das Basissystem des Arms gedreht.
"""

import math
import os
import statistics
import time
from dataclasses import dataclass, field, replace
from datetime import datetime
from typing import List, Optional, Tuple

import cv2
import numpy as np

from .cobot_arm_controller import CobotArmController
from .limo_vision_detector import LimoVisionDetector

try:
    import rclpy
    from rclpy.node import Node
    from rclpy.qos import QoSProfile, ReliabilityPolicy
    from sensor_msgs.msg import CameraInfo, Image
    ROS2_AVAILABLE = True
except ImportError:  # Tests und Simulation ohne ROS 2
    ROS2_AVAILABLE = False
    Node = object  # type: ignore[misc, assignment]


# ---------------------------------------------------------------------------
# Kamera-Topics des LIMO (Orbbec Dabai)
# ---------------------------------------------------------------------------
COLOR_TOPIC = "/camera/color/image_raw"
INFO_TOPIC = "/camera/color/camera_info"
DEPTH_TOPIC = "/camera/depth/image_raw"     # mit depth_registration:=true auf das Farbbild registriert

MARKER_BGR = (255, 0, 255)   # Magenta, damit die Markierung auf dem gelben Würfel sichtbar bleibt


@dataclass
class GraspCalibration:
    """Am LIMO eingemessene Werte. Standardwerte = getesteter Stand.

    Zum Überschreiben einzelner Werte: ``replace(GraspCalibration(), grasp_pitch_deg=45)``.
    """
    # Entfernung
    depth_offset_m: float = 0.05        # Korrektur der Tiefenmessung (Kamera misst am Würfel zu kurz)
    camera_to_arm_x_m: float = 0.03     # Würfelmitte vor der Armbasis = Entfernung + halbe Kante + dieser Versatz
    cube_size_m: float = 0.03           # Kantenlänge des Würfels (nachgemessen: 3 cm)
    # Greifpunkt und Greifer
    pick_z_m: float = 0.05              # Höhe der Würfelmitte über der Armbasis
    gripper_length_m: float = 0.06      # Flansch -> Mitte der Greifbacken
    pre_pick_dist_m: float = 0.06       # Vorposition: so weit vor dem Greifpunkt entgegen der Anfahrrichtung
    grasp_pitch_deg: float = 60.0       # Anfahrwinkel: 0 = senkrecht von oben, 90 = waagerecht von vorne
    gripper_rz_deg: float = -45.0       # Drehung des Greifers um die eigene Achse (Backen quer zum Würfel)
    # Montage des Arms
    base_rotation_deg: float = -90.0    # Arm ist um 90° nach rechts gedreht montiert
    lateral_scale: float = -1.0         # Kamera-x zeigt nach rechts, Arm-y nach links
    lateral_offset_m: float = 0.0       # seitlicher Versatz Kamera <-> Armbasis
    lateral_max_m: float = 0.10         # kein Greifen, wenn der Würfel weiter seitlich liegt
    arm_reach_m: float = 0.28           # Reichweite myCobot 280 (für die Warnung)
    # Ablauf
    frames: int = 5                     # Bilder pro Beobachtung (Median)
    min_hits: int = 3                   # Mindestanzahl Bilder mit Erkennung
    timeout_s: float = 5.0              # Wartezeit auf ein Bild
    arm_speed: int = 30                 # Armgeschwindigkeit 0-100
    move_wait_s: float = 3.0            # Wartezeit pro Armbewegung
    home_first: bool = True             # Arm vor der Beobachtung in die Home-Pose (aus dem Kamerabild)
    out_dir: str = "cube_detection_output"  # Ordner für die gespeicherten Kontrollbilder
    # Plausibilität der Tiefe
    depth_plausible_rel: float = 0.4    # Tiefenwerte müssen auf +-40 % zur Schätzung aus der Würfelbreite passen
    depth_min_pixels: int = 50          # weniger passende Pixel gelten als Rauschen
    fx_fallback_px: float = 487.6       # Brennweite, falls kein camera_info kommt (Orbbec Dabai, 640x480)

    def with_(self, **changes) -> "GraspCalibration":
        """Kopie mit geänderten Werten, z. B. ``calib.with_(grasp_pitch_deg=45)``."""
        return replace(self, **changes)


# ---------------------------------------------------------------------------
# Bild-Hilfsfunktionen
# ---------------------------------------------------------------------------
def image_msg_to_cv(msg: "Image") -> Optional[np.ndarray]:
    """sensor_msgs/Image ohne cv_bridge in ein NumPy-Array wandeln.

    Farbbilder kommen als BGR zurück, Tiefenbilder (16UC1 in mm, 32FC1 in m) roh.
    """
    enc = msg.encoding.lower()
    h, w, step = msg.height, msg.width, msg.step
    raw = np.frombuffer(msg.data, dtype=np.uint8).reshape(h, step)
    big = ">" if msg.is_bigendian else "<"
    if enc in ("bgr8", "8uc3"):
        return raw[:, : w * 3].reshape(h, w, 3).copy()
    if enc == "rgb8":
        return cv2.cvtColor(raw[:, : w * 3].reshape(h, w, 3), cv2.COLOR_RGB2BGR)
    if enc == "bgra8":
        return cv2.cvtColor(raw[:, : w * 4].reshape(h, w, 4), cv2.COLOR_BGRA2BGR)
    if enc == "rgba8":
        return cv2.cvtColor(raw[:, : w * 4].reshape(h, w, 4), cv2.COLOR_RGBA2BGR)
    if enc in ("mono8", "8uc1"):
        return cv2.cvtColor(raw[:, :w].reshape(h, w), cv2.COLOR_GRAY2BGR)
    if enc in ("16uc1", "mono16"):
        return raw[:, : w * 2].copy().view(np.dtype(big + "u2")).reshape(h, w)
    if enc == "32fc1":
        return raw[:, : w * 4].copy().view(np.dtype(big + "f4")).reshape(h, w)
    print(f"[Kamera] Unbekanntes Bild-Encoding '{msg.encoding}', Bild wird ignoriert.")
    return None


def draw_marker_x(img: np.ndarray, cx: int, cy: int, size: int = 20, thickness: int = 3) -> None:
    """Magentafarbenes X mit Mittelpunkt (cx, cy)."""
    cv2.line(img, (cx - size, cy - size), (cx + size, cy + size), MARKER_BGR, thickness)
    cv2.line(img, (cx - size, cy + size), (cx + size, cy - size), MARKER_BGR, thickness)


def depth_to_colormap(depth_img: np.ndarray) -> np.ndarray:
    """Eingefärbte Tiefenkarte zur Sichtkontrolle (nah = blau, fern = rot, ungültig = schwarz)."""
    d = depth_img.astype(np.float64)
    valid = np.isfinite(d) & (d > 0)
    vis = np.zeros(depth_img.shape[:2], dtype=np.uint8)
    if valid.any():
        lo, hi = np.percentile(d[valid], [2, 98])
        if hi > lo:
            vis[valid] = np.clip((d[valid] - lo) / (hi - lo) * 255.0, 0, 255).astype(np.uint8)
    cmap = cv2.applyColorMap(vis, cv2.COLORMAP_JET)
    cmap[~valid] = (0, 0, 0)
    return cmap


def depth_to_raw_png(depth_img: np.ndarray) -> np.ndarray:
    """Rohes Tiefenbild als 16-Bit-Millimeterbild (für cv2.imwrite / spätere Analyse)."""
    if depth_img.dtype == np.uint16:
        return depth_img
    return np.clip(depth_img * 1000.0, 0, 65535).astype(np.uint16)


def measure_depth_in_mask(
    depth_img: np.ndarray, mask: np.ndarray, expected_m: float, calib: GraspCalibration
) -> Tuple[Optional[float], int]:
    """Entfernung des Würfels als Median der Tiefenwerte innerhalb der Würfelmaske.

    Setzt ein registriertes Tiefenbild voraus (gleiche Auflösung wie das Farbbild).
    Es zählen nur Werte nahe der Schätzung aus der Würfelbreite (expected_m), damit
    Löcher in der Tiefe oder Hintergrundpixel am Maskenrand nicht verfälschen.

    Returns:
        (median_in_m oder None, anzahl_verwendeter_pixel)
    """
    core = cv2.erode(mask, np.ones((5, 5), np.uint8))
    if np.count_nonzero(core) < calib.depth_min_pixels:
        core = mask
    vals = depth_img[core > 0].astype(np.float64)
    vals = vals[np.isfinite(vals) & (vals > 0)]
    if vals.size == 0:
        return None, 0
    if np.median(vals) > 10.0:  # 16UC1 in mm
        vals = vals / 1000.0
    lo = expected_m * (1.0 - calib.depth_plausible_rel)
    hi = expected_m * (1.0 + calib.depth_plausible_rel)
    plausible = vals[(vals >= lo) & (vals <= hi)]
    if plausible.size < calib.depth_min_pixels:
        return None, int(plausible.size)
    return float(np.median(plausible)), int(plausible.size)


# ---------------------------------------------------------------------------
# Kamera
# ---------------------------------------------------------------------------
class CubeCamera(Node):
    """ROS-2-Subscriber für Farbbild, Tiefenbild und Kameraparameter. Publiziert nichts.

    Der Kamera-Knoten des LIMO publiziert RELIABLE; ein Best-Effort-Abonnement
    verliert auf diesem System fast alle Bilder, deshalb wird hier RELIABLE abonniert.
    """

    def __init__(self, color_topic: str = COLOR_TOPIC, info_topic: str = INFO_TOPIC,
                 depth_topic: str = DEPTH_TOPIC, node_name: str = "cube_camera") -> None:
        if not ROS2_AVAILABLE:
            raise RuntimeError("rclpy nicht gefunden: ROS 2 Setup sourcen und auf dem LIMO starten.")
        super().__init__(node_name)
        self.color_img: Optional[np.ndarray] = None
        self.depth_img: Optional[np.ndarray] = None
        self.fx: Optional[float] = None
        self.ppx: Optional[float] = None
        qos = QoSProfile(depth=5, reliability=ReliabilityPolicy.RELIABLE)
        self.create_subscription(Image, color_topic, self._on_color, qos)
        self.create_subscription(CameraInfo, info_topic, self._on_info, qos)
        self.create_subscription(Image, depth_topic, self._on_depth, qos)
        self.get_logger().info(f"Abonniere {color_topic}, {depth_topic} und {info_topic}")

    def _on_color(self, msg: "Image") -> None:
        img = image_msg_to_cv(msg)
        if img is not None and img.ndim == 3:
            self.color_img = img

    def _on_depth(self, msg: "Image") -> None:
        img = image_msg_to_cv(msg)
        if img is not None and img.ndim == 2:
            self.depth_img = img

    def _on_info(self, msg: "CameraInfo") -> None:
        if msg.k[0] > 0:
            self.fx, self.ppx = float(msg.k[0]), float(msg.k[2])

    def next_frame(self, timeout_s: float) -> Optional[np.ndarray]:
        """Wartet auf ein neues Farbbild."""
        self.color_img = None
        deadline = time.monotonic() + timeout_s
        while rclpy.ok() and time.monotonic() < deadline:
            rclpy.spin_once(self, timeout_sec=0.1)
            if self.color_img is not None:
                return self.color_img
        return None

    def wait_for_depth(self, timeout_s: float) -> Optional[np.ndarray]:
        """Wartet, bis mindestens ein Tiefenbild empfangen wurde."""
        deadline = time.monotonic() + timeout_s
        while rclpy.ok() and time.monotonic() < deadline and self.depth_img is None:
            rclpy.spin_once(self, timeout_sec=0.1)
        return self.depth_img


# ---------------------------------------------------------------------------
# Beobachtung
# ---------------------------------------------------------------------------
@dataclass
class CubeObservation:
    """Ergebnis einer Würfelbeobachtung über mehrere Kamerabilder."""
    cx: int                        # Würfelmitte im Farbbild (px)
    cy: int
    w_px: float                    # Breite der Bounding-Box (px)
    n_hits: int                    # Bilder mit Erkennung
    n_frames: int                  # aufgenommene Bilder
    n_depth: int                   # Bilder mit gültiger Tiefe
    raw_distance: float            # Median der Tiefenkamera (m), ohne Korrektur
    distance: float                # korrigierte Entfernung Kamera -> Würfelvorderseite (m)
    est_distance: float            # Entfernung aus der Würfelbreite (m), nur zur Kontrolle
    x_cam: float                   # seitlicher Versatz im Kamerasystem (m, + = rechts von der Bildmitte)
    y_arm: float                   # seitlicher Versatz im Armsystem (m)
    pick_x: float                  # Würfelmitte vor der Armbasis (m)
    last_img: np.ndarray = field(repr=False)
    last_depth: Optional[np.ndarray] = field(repr=False)

    @property
    def angle_deg(self) -> float:
        """Winkel zum Würfel aus Kamerasicht in Grad (+ = Würfel rechts von der Bildmitte)."""
        return math.degrees(math.atan2(self.x_cam, self.distance))


def _detect_cube_in_frame(
    img: np.ndarray, depth: Optional[np.ndarray], detector: LimoVisionDetector,
    fx: float, calib: GraspCalibration,
) -> Optional[Tuple[int, int, int, Optional[float]]]:
    """Erkennung in einem Bild: (cx, cy, breite_px, tiefe_m oder None) oder None."""
    found, (cx, cy), _, _ = detector.detect_yellow_cube(img)
    if not found:
        return None
    mask = detector.get_intermediate_images(img)["mask_closed"]
    contours, _ = cv2.findContours(mask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
    _, _, w, _ = cv2.boundingRect(max(contours, key=cv2.contourArea))
    depth_m = None
    if depth is not None and w > 0:
        if depth.shape[:2] != img.shape[:2]:
            print(f"[Tiefe] Tiefenbild {depth.shape[1]}x{depth.shape[0]} passt nicht zum Farbbild "
                  f"{img.shape[1]}x{img.shape[0]}. Kamera mit depth_registration:=true starten.")
        else:
            expected_m = fx * calib.cube_size_m / w
            depth_m, _ = measure_depth_in_mask(depth, mask, expected_m, calib)
    return cx, cy, w, depth_m


def observe_cube(
    camera: CubeCamera, detector: LimoVisionDetector, calib: GraspCalibration = GraspCalibration(),
    save_on_failure: bool = True,
) -> Optional[CubeObservation]:
    """Nimmt mehrere Bilder auf, erkennt den Würfel und misst Entfernung und Seitenversatz.

    Der Arm sollte vorher aus dem Kamerabild sein (Home-Pose). Bei Misserfolg wird
    ein Kontrollbild gespeichert und None zurückgegeben.
    """
    if camera.wait_for_depth(calib.timeout_s) is None:
        print(f"[Tiefe] Kein Tiefenbild innerhalb von {calib.timeout_s:.0f} s. Läuft die Kamera?")

    fx = camera.fx if camera.fx is not None else calib.fx_fallback_px
    print(f"[Kamera] Nehme {calib.frames} Bilder auf ...")
    hits: List[Tuple[int, int, int, Optional[float]]] = []
    last_img: Optional[np.ndarray] = None
    for i in range(calib.frames):
        img = camera.next_frame(calib.timeout_s)
        if img is None:
            print(f"[Kamera] Bild {i + 1}/{calib.frames}: kein Bild innerhalb von {calib.timeout_s:.0f} s.")
            continue
        last_img = img
        hit = _detect_cube_in_frame(img, camera.depth_img, detector, fx, calib)
        if hit is not None:
            hits.append(hit)
    last_depth = camera.depth_img

    if last_img is None:
        print(f"[Fehler] Kein Farbbild auf '{COLOR_TOPIC}'. Läuft die Kamera?")
        return None
    if len(hits) < calib.min_hits:
        print(f"[Abbruch] Würfel nur in {len(hits)} von {calib.frames} Bildern erkannt "
              f"(mindestens {calib.min_hits} nötig).")
        if save_on_failure:
            save_images(last_img, last_depth, None, None, "KEIN Wuerfel erkannt", "", calib.out_dir)
        return None

    cx = int(statistics.median(h[0] for h in hits))
    cy = int(statistics.median(h[1] for h in hits))
    w_px = float(statistics.median(h[2] for h in hits))
    depths = [h[3] for h in hits if h[3] is not None]
    ppx = camera.ppx if camera.ppx is not None else last_img.shape[1] / 2.0
    est_distance = fx * calib.cube_size_m / w_px if w_px > 0 else float("nan")

    if not depths:
        print(f"[Abbruch] Keine plausible Entfernung aus dem Tiefenbild (erwartet ca. {est_distance:.2f} m "
              "aus der Würfelbreite). Läuft die Kamera mit depth_registration:=true? "
              "Ist der Würfel im IR-Bild übersteuert?")
        if save_on_failure:
            save_images(last_img, last_depth, cx, cy, f"Cube ({cx},{cy})  KEINE TIEFE",
                        f"keine plausible Tiefe, erwartet ~{est_distance:.2f}m", calib.out_dir)
        return None

    raw_distance = float(statistics.median(depths))
    distance = raw_distance + calib.depth_offset_m
    x_cam = (cx - ppx) * distance / fx
    y_arm = calib.lateral_scale * x_cam + calib.lateral_offset_m
    pick_x = distance + calib.cube_size_m / 2.0 + calib.camera_to_arm_x_m

    print(f"[Erkennung] Pixel ({cx}, {cy}) in {len(hits)}/{calib.frames} Bildern, Breite {w_px:.0f} px, "
          f"seitlich {x_cam * 100:+.1f} cm, Winkel {math.degrees(math.atan2(x_cam, distance)):+.1f}°")
    print(f"[Tiefe]     Tiefenkamera {raw_distance:.3f} m {calib.depth_offset_m * 100:+.1f} cm = "
          f"{distance:.3f} m zur Würfelvorderseite ({len(depths)}/{len(hits)} Bilder), "
          f"Schätzung aus Breite {est_distance:.2f} m")
    print(f"[Tiefe]     Würfelmitte vor der Armbasis = {distance:.3f} + {calib.cube_size_m / 2 * 100:.1f} cm "
          f"+ {calib.camera_to_arm_x_m * 100:+.1f} cm = {pick_x:.3f} m")
    return CubeObservation(cx, cy, w_px, len(hits), calib.frames, len(depths), raw_distance, distance,
                           est_distance, x_cam, y_arm, pick_x, last_img, last_depth)


# ---------------------------------------------------------------------------
# Geometrie: Greifpunkte im Arm-Basissystem
# ---------------------------------------------------------------------------
@dataclass
class GraspTargets:
    """Flanschpositionen (m) im Arm-Basissystem und Werkzeugorientierung (Grad)."""
    cube_l: np.ndarray                      # Würfelmitte, logisches System (x vorne, y links, z oben)
    flange_l: np.ndarray                    # Flansch am Greifpunkt, logisches System
    pre_l: np.ndarray                       # Flansch an der Vorposition, logisches System
    target: Tuple[float, float, float]      # Greifpunkt im Arm-Basissystem
    pre_pick: Tuple[float, float, float]    # Vorposition im Arm-Basissystem
    orient: Tuple[float, float, float]      # rx, ry, rz für send_coords
    reach_pick: float                       # Abstand Greifpunkt -> Armbasis
    reach_pre: float                        # Abstand Vorposition -> Armbasis

    def within_reach(self, calib: GraspCalibration) -> bool:
        return max(self.reach_pick, self.reach_pre) <= calib.arm_reach_m


def rotate_to_arm_base(x: float, y: float, angle_deg: float) -> Tuple[float, float]:
    """Dreht einen Punkt (x nach vorne, y nach links) um die Hochachse in das Basissystem des Arms."""
    a = math.radians(angle_deg)
    return x * math.cos(a) - y * math.sin(a), x * math.sin(a) + y * math.cos(a)


def approach_direction(pitch_deg: float) -> np.ndarray:
    """Richtung, in die der Greifer zeigt: 0° -> senkrecht nach unten, 90° -> waagerecht nach vorne."""
    t = math.radians(pitch_deg)
    return np.array([math.sin(t), 0.0, -math.cos(t)])


def _rot_x(a: float) -> np.ndarray:
    c, s = math.cos(a), math.sin(a)
    return np.array([[1, 0, 0], [0, c, -s], [0, s, c]])


def _rot_y(a: float) -> np.ndarray:
    c, s = math.cos(a), math.sin(a)
    return np.array([[c, 0, s], [0, 1, 0], [-s, 0, c]])


def _rot_z(a: float) -> np.ndarray:
    c, s = math.cos(a), math.sin(a)
    return np.array([[c, -s, 0], [s, c, 0], [0, 0, 1]])


def tool_orientation(base_rotation_deg: float, pitch_deg: float, gripper_rz_deg: float) -> Tuple[float, float, float]:
    """Werkzeugorientierung (rx, ry, rz) in Grad für send_coords.

    Der myCobot interpretiert rx, ry, rz als Euler-Winkel R = Rz(rz) * Ry(ry) * Rx(rx).
    Ausgangslage ist der Griff von oben (-180, 0, 0); der Greifer wird um den
    Anfahrwinkel nach vorne gekippt, um die Montagedrehung gedreht und zuletzt um
    gripper_rz um seine eigene Achse.
    """
    r = (_rot_z(math.radians(base_rotation_deg))
         @ _rot_y(math.radians(-pitch_deg))
         @ _rot_x(math.radians(-180.0))
         @ _rot_z(math.radians(gripper_rz_deg)))
    sy = math.hypot(r[0, 0], r[1, 0])
    if sy > 1e-6:
        rx, ry, rz = math.atan2(r[2, 1], r[2, 2]), math.atan2(-r[2, 0], sy), math.atan2(r[1, 0], r[0, 0])
    else:  # Gimbal-Lock bei ry = +-90°
        rx, ry, rz = 0.0, math.atan2(-r[2, 0], sy), math.atan2(-r[0, 1], r[1, 1])
    return tuple(round(math.degrees(v), 1) for v in (rx, ry, rz))  # type: ignore[return-value]


def compute_grasp_targets(obs: CubeObservation, calib: GraspCalibration = GraspCalibration()) -> GraspTargets:
    """Greifpunkt und Vorposition aus einer Beobachtung berechnen (siehe Modul-Docstring)."""
    cube_l = np.array([obs.pick_x, obs.y_arm, calib.pick_z_m])
    direction = approach_direction(calib.grasp_pitch_deg)
    flange_l = cube_l - calib.gripper_length_m * direction
    pre_l = flange_l - calib.pre_pick_dist_m * direction

    def to_base(p: np.ndarray) -> Tuple[float, float, float]:
        xb, yb = rotate_to_arm_base(float(p[0]), float(p[1]), calib.base_rotation_deg)
        return (xb, yb, float(p[2]))

    target, pre_pick = to_base(flange_l), to_base(pre_l)
    orient = tool_orientation(calib.base_rotation_deg, calib.grasp_pitch_deg, calib.gripper_rz_deg)
    t = GraspTargets(cube_l, flange_l, pre_l, target, pre_pick, orient,
                     float(np.linalg.norm(target)), float(np.linalg.norm(pre_pick)))
    print(f"[Ziel] Würfelmitte vor dem Arm x={cube_l[0]:.3f} y={cube_l[1]:+.3f} z={cube_l[2]:.3f} m, "
          f"Anfahrwinkel {calib.grasp_pitch_deg:.0f}°, Greiferlänge {calib.gripper_length_m * 100:.0f} cm")
    print(f"[Ziel] Arm-Basissystem: Greifpunkt x={target[0]:+.3f} y={target[1]:+.3f} z={target[2]:.3f} m, "
          f"Vorposition x={pre_pick[0]:+.3f} y={pre_pick[1]:+.3f} z={pre_pick[2]:.3f} m, "
          f"rpy=({orient[0]:.1f}, {orient[1]:.1f}, {orient[2]:.1f})")
    print(f"[Ziel] Abstand zur Armbasis: Greifpunkt {t.reach_pick:.3f} m, Vorposition {t.reach_pre:.3f} m"
          f"{'' if t.within_reach(calib) else f'  -> AUSSERHALB der Reichweite ({calib.arm_reach_m:.2f} m)'}")
    return t


# ---------------------------------------------------------------------------
# Kontrollbilder
# ---------------------------------------------------------------------------
def save_images(
    color_img: np.ndarray, depth_img: Optional[np.ndarray], cx: Optional[int], cy: Optional[int],
    text: str, depth_text: str, out_dir: str, prefix: str = "grab",
) -> List[str]:
    """Markiertes Farbbild, eingefärbte Tiefenkarte und rohes Tiefenbild speichern. Liefert die Pfade."""
    os.makedirs(out_dir, exist_ok=True)
    base = os.path.join(out_dir, f"{prefix}_{datetime.now().strftime('%Y%m%d_%H%M%S')}")
    marked = color_img.copy()
    if cx is not None and cy is not None:
        draw_marker_x(marked, cx, cy)
    cv2.putText(marked, text, (10, 30), cv2.FONT_HERSHEY_SIMPLEX, 0.6, MARKER_BGR, 2)
    cv2.imwrite(base + ".png", marked)
    paths = [base + ".png"]
    if depth_img is not None:
        cmap = depth_to_colormap(depth_img)
        if cx is not None and cy is not None and depth_img.shape[:2] == color_img.shape[:2]:
            draw_marker_x(cmap, cx, cy)
        cv2.putText(cmap, depth_text, (10, 30), cv2.FONT_HERSHEY_SIMPLEX, 0.6, MARKER_BGR, 2)
        cv2.imwrite(base + "_depth.png", cmap)
        cv2.imwrite(base + "_depth_raw.png", depth_to_raw_png(depth_img))
        paths += [base + "_depth.png", base + "_depth_raw.png"]
    for p in paths:
        print(f"[Gespeichert] {p}")
    return paths


def save_observation(obs: CubeObservation, calib: GraspCalibration = GraspCalibration()) -> List[str]:
    return save_images(
        obs.last_img, obs.last_depth, obs.cx, obs.cy,
        f"Cube ({obs.cx},{obs.cy})  y_arm={obs.y_arm * 100:+.1f}cm  d={obs.distance:.3f}m",
        f"Tiefe {obs.raw_distance:.3f}m {calib.depth_offset_m * 100:+.0f}cm = {obs.distance:.3f}m "
        f"({obs.n_depth}/{obs.n_hits} Bilder)", calib.out_dir)


# ---------------------------------------------------------------------------
# Greifen
# ---------------------------------------------------------------------------
def run_pick_sequence(arm: CobotArmController, targets: GraspTargets, calib: GraspCalibration = GraspCalibration()) -> None:
    """Greifsequenz: Greifer auf, Vorposition, Greifpunkt, Greifer zu, Vorposition, Home-Pose."""
    wait, speed, orient = calib.move_wait_s, calib.arm_speed, targets.orient

    def fmt(p: Tuple[float, float, float]) -> str:
        return f"x={p[0]:+.3f} y={p[1]:+.3f} z={p[2]:.3f} m"

    print("[Greifen] Greifer öffnen ...")
    arm.open_gripper()
    time.sleep(wait * 0.5)
    print(f"[Greifen] Vorposition anfahren: {fmt(targets.pre_pick)}, rpy={orient}")
    arm.move_to_coords(targets.pre_pick, rx_ry_rz=orient, speed=speed)
    time.sleep(wait)
    print(f"[Greifen] Zum Greifpunkt fahren: {fmt(targets.target)}")
    arm.move_to_coords(targets.target, rx_ry_rz=orient, speed=speed)
    time.sleep(wait)
    print("[Greifen] Greifer schließen ...")
    arm.close_gripper()
    time.sleep(wait * 0.5)
    print("[Greifen] Zurück zur Vorposition ...")
    arm.move_to_coords(targets.pre_pick, rx_ry_rz=orient, speed=speed)
    time.sleep(wait)
    print("[Greifen] Arm in Home-Pose, damit er das Kamerabild nicht verdeckt ...")
    arm.move_to_home_pose(speed=speed)
    time.sleep(wait)
    print("[Greifen] Sequenz abgeschlossen. Der Würfel wird in der Home-Pose gehalten.")


def grasp_cube(
    arm: Optional[CobotArmController], camera: CubeCamera, detector: LimoVisionDetector,
    calib: GraspCalibration = GraspCalibration(), dry_run: bool = False,
) -> bool:
    """Kompletter Greifvorgang: Home-Pose, Beobachten, Zielberechnung, Kontrollbilder, Greifen.

    Args:
        arm: Armcontroller; None oder dry_run=True bedeutet: nur beobachten und rechnen.
        camera: CubeCamera (Farb- und Tiefenbild).
        detector: LimoVisionDetector.
        calib: Kalibrierwerte (Standard = getestete Werte).
        dry_run: Arm nicht bewegen.

    Returns:
        True, wenn gegriffen wurde (bzw. im Dry-Run: wenn ein gültiges Ziel berechnet wurde).
    """
    if arm is not None and not dry_run and calib.home_first:
        arm.move_to_home_pose(speed=calib.arm_speed)
        time.sleep(calib.move_wait_s)

    obs = observe_cube(camera, detector, calib)
    if obs is None:
        return False
    targets = compute_grasp_targets(obs, calib)
    save_observation(obs, calib)

    if abs(obs.y_arm) > calib.lateral_max_m:
        print(f"[Abbruch] Würfel liegt {abs(obs.y_arm) * 100:.1f} cm seitlich, erlaubt sind "
              f"{calib.lateral_max_m * 100:.0f} cm. Roboter mittiger vor den Würfel stellen.")
        return False
    if not targets.within_reach(calib):
        print(f"[Abbruch] Zielpose außerhalb der Reichweite ({calib.arm_reach_m:.2f} m). "
              "Roboter näher an den Würfel fahren.")
        return False
    if arm is None or dry_run:
        print("[Dry-Run] Arm wird nicht bewegt.")
        return True
    run_pick_sequence(arm, targets, calib)
    return True
