"""Step 3: Vision detector for the yellow cube (HSV thresholding).

TODO: Implement detect_yellow_cube and get_intermediate_images. The tests in
tests/test_vision_detector.py check your implementation. The provided grasp module
src/cube_grasp.py uses both methods, so keep their signatures.
"""

from typing import Dict, Optional, Tuple

import cv2
import numpy as np


class LimoVisionDetector:
    """Image processing pipeline to locate a yellow cube in a BGR camera image.

    Attributes:
        hsv_lower (np.ndarray): Lower HSV bound of the yellow colour range.
        hsv_upper (np.ndarray): Upper HSV bound of the yellow colour range.
    """

    MIN_AREA_PX: float = 300.0       # smaller contours are noise
    DEFAULT_DEPTH_M: float = 0.35    # used if no depth image is given
    FOCAL_LENGTH_PX: float = 525.0   # fx = fy for the 3D estimate of this method

    def __init__(self) -> None:
        """Initialize the HSV colour range for yellow."""
        # TODO: Choose the bounds [H, S, V]. In OpenCV, H is in [0, 180], S and V in [0, 255].
        self.hsv_lower: np.ndarray = np.array([0, 0, 0], dtype=np.uint8)
        self.hsv_upper: np.ndarray = np.array([0, 0, 0], dtype=np.uint8)

    def detect_yellow_cube(
        self,
        color_img: np.ndarray,
        depth_img: Optional[np.ndarray] = None,
    ) -> Tuple[bool, Tuple[int, int], float, Tuple[float, float, float]]:
        """Detect the yellow cube.

        Args:
            color_img (np.ndarray): BGR image from the camera.
            depth_img (Optional[np.ndarray]): Depth image in millimeters, registered to the colour
                image. Defaults to None.

        Returns:
            Tuple[bool, Tuple[int, int], float, Tuple[float, float, float]]:
                (found, (cx, cy), depth_m, (x, y, z)). If nothing is found or the image is empty:
                (False, (0, 0), 0.0, (0.0, 0.0, 0.0)).
        """
        # TODO: Pipeline of docs/aufgabenstellung.md, step 3:
        # 1. BGR -> HSV, 2. cv2.inRange, 3. opening and closing (5 x 5 kernel),
        # 4. largest contour with area >= MIN_AREA_PX, centroid (cx, cy) from the image moments,
        # 5. depth_m = depth image at (cx, cy) in meters, or DEFAULT_DEPTH_M without depth image,
        #    x = (cx - width / 2) * depth_m / FOCAL_LENGTH_PX, y analogous, z = depth_m.
        raise NotImplementedError("TODO: implement detect_yellow_cube")

    def get_intermediate_images(self, color_img: np.ndarray) -> Dict[str, np.ndarray]:
        """Return the intermediate images of the pipeline for inspection.

        Args:
            color_img (np.ndarray): BGR image from the camera.

        Returns:
            Dict[str, np.ndarray]: Images with the keys
                'hsv' (HSV image), 'rgb_mask' (naive threshold on the R, G, B channels for comparison),
                'hsv_raw_mask' (mask after cv2.inRange), 'mask_opened' (after opening),
                'mask_closed' (after closing) and 'result_visualization' (BGR image with the
                detected contour and centroid drawn).
        """
        # TODO
        raise NotImplementedError("TODO: implement get_intermediate_images")
