"""Step 5: Mission controller orchestrating chassis, vision and arm.

TODO: Implement approach_cube and execute_full_mission. The tests in tests/test_mission.py check
your implementation.
"""

import time
from typing import Callable, Optional, Tuple

import cv2
import numpy as np

from .cobot_arm_controller import CobotArmController
from .cube_grasp import (
    CubeCamera, CubeObservation, GraspCalibration, compute_grasp_targets, observe_cube,
    run_pick_sequence, save_observation,
)
from .limo_drive_controller import LimoDriveController
from .limo_vision_detector import LimoVisionDetector

# Approach to the cube (phase 2). The distance is the corrected distance camera -> front of the
# cube as measured by src/cube_grasp.observe_cube.
APPROACH_TARGET_DISTANCE_M = 0.23    # desired distance camera -> cube for grasping
APPROACH_DISTANCE_TOL_M = 0.03       # tolerance around the target distance
APPROACH_CRITICAL_DISTANCE_M = 0.30  # from here on the cube is out of reach of the arm
APPROACH_ANGLE_TOL_DEG = 3.0         # the cube counts as centred below this angle
APPROACH_MAX_STEP_M = 0.15           # maximum forward motion per step
APPROACH_MAX_STEPS = 8               # maximum number of observe/correct cycles
APPROACH_DRIVE_SPEED_MPS = 0.1
APPROACH_TURN_SPEED_DEGPS = 15.0
APPROACH_SETTLE_S = 0.5              # waiting time after a motion before the next observation


class LimoCobotMission:
    """High-level mission manager for the autonomous pick-and-place task.

    Attributes:
        drive (LimoDriveController): Chassis controller.
        vision (LimoVisionDetector): Vision pipeline.
        arm (CobotArmController): Arm controller.
        camera (Optional[CubeCamera]): Camera for real images. Without camera, the mission runs in
            simulation mode with a synthetic test image.
        calib (GraspCalibration): Calibration values for detection and grasping.
    """

    def __init__(
        self,
        drive_controller: LimoDriveController,
        vision_detector: LimoVisionDetector,
        arm_controller: CobotArmController,
        camera: Optional[CubeCamera] = None,
        calibration: Optional[GraspCalibration] = None,
    ) -> None:
        """Initialize the mission with its subsystems.

        Args:
            drive_controller (LimoDriveController): Chassis controller.
            vision_detector (LimoVisionDetector): Vision pipeline.
            arm_controller (CobotArmController): Arm controller.
            camera (Optional[CubeCamera]): Camera subscriber (None = simulation). Defaults to None.
            calibration (Optional[GraspCalibration]): Calibration values (None = tested defaults).
        """
        self.drive: LimoDriveController = drive_controller
        self.vision: LimoVisionDetector = vision_detector
        self.arm: CobotArmController = arm_controller
        self.camera = camera
        self.calib: GraspCalibration = calibration if calibration is not None else GraspCalibration()

    def approach_cube(self, observe: Callable[[], Optional[CubeObservation]]) -> Optional[CubeObservation]:
        """Turn towards the cube and drive up to the grasp distance in small steps.

        Args:
            observe (Callable[[], Optional[CubeObservation]]): Function returning an observation
                with the attributes ``angle_deg`` (positive = cube right of the image centre) and
                ``distance`` (meters), or None. Usually
                ``lambda: observe_cube(camera, vision, calib)``.

        Returns:
            Optional[CubeObservation]: The last observation if the cube is centred and within the
                grasp distance, otherwise None.
        """
        # TODO: Repeat at most APPROACH_MAX_STEPS times:
        #   observe -> None: give up.
        #   centred (|angle| <= APPROACH_ANGLE_TOL_DEG) and
        #   close (|distance - APPROACH_TARGET_DISTANCE_M| <= APPROACH_DISTANCE_TOL_M): done.
        #   not centred: turn towards the cube (turn_angle is positive to the LEFT).
        #   centred but not close: drive the remaining distance, at most APPROACH_MAX_STEP_M.
        #   Wait APPROACH_SETTLE_S (time.sleep) before the next observation.
        raise NotImplementedError("TODO: implement approach_cube")

    def execute_full_mission(self, simulated_rgb_img: Optional[np.ndarray] = None) -> bool:
        """Execute the complete mission.

        Args:
            simulated_rgb_img (Optional[np.ndarray]): Test image for the simulation mode (only
                used without camera). Defaults to None.

        Returns:
            bool: True if the mission was completed, False if it was aborted.
        """
        # TODO: Five phases, see docs/aufgabenstellung.md, step 5.
        #   1. Navigation: 1.0 m forward, 45 deg left, 0.5 m forward.
        #   2. Detection:
        #        with camera: home pose, approach_cube; abort if the cube is not reachable.
        #        without camera: detect_yellow_cube on simulated_rgb_img (create a test image with
        #        a yellow rectangle if it is None).
        #   3. Pick:
        #        with camera: compute_grasp_targets, check within_reach, run_pick_sequence.
        #        without camera: arm.pick_cube with the detected 3D coordinates.
        #   4. Return: the same path backwards.
        #   5. Place: arm.place_cube at (0.2, 0.0, 0.05).
        raise NotImplementedError("TODO: implement execute_full_mission")
