"""Step 4: Cobot arm controller for the myCobot 280 and its gripper.

TODO: Implement pick_cube and place_cube. Connection, gripper and motion commands are provided.
The tests in tests/test_arm_controller.py check your implementation.
"""

import time
from typing import Any, Optional, Tuple

try:
    from pymycobot.mycobot import MyCobot
    MYCOBOT_AVAILABLE = True
except ImportError:
    MYCOBOT_AVAILABLE = False
    MyCobot = None  # type: ignore[misc, assignment]


class CobotArmController:
    """Controller for managing joint positions and gripper for the Cobot Arm.

    Attributes:
        is_gripper_closed (bool): Current state indicator of the gripper.
        port (str): Serial port for communicating with myCobot manipulator.
        baudrate (int): Baud rate for myCobot serial communication.
        mc (Optional[Any]): MyCobot driver instance if hardware connection is active.
    """

    def __init__(self, port: str = "/dev/ttyACM0", baudrate: int = 115200) -> None:
        """Initialize the CobotArmController instance and hardware interface if available.

        Args:
            port (str): Serial port path for myCobot hardware connection. Defaults to '/dev/ttyACM0'.
            baudrate (int): Communication speed for serial connection. Defaults to 115200.
        """
        self.is_gripper_closed: bool = False
        self.port: str = port
        self.baudrate: int = baudrate
        self.mc: Optional[Any] = None

        if MYCOBOT_AVAILABLE:
            try:
                self.mc = MyCobot(self.port, self.baudrate)
                print(f"[Arm] CobotArmController connected to myCobot on {self.port} @ {self.baudrate} baud.")
            except Exception as err:
                print(f"[Arm] Failed to connect to myCobot on {self.port}: {err}")
                print("[Arm] Operating in Simulation / Stand-alone Mode.")
        else:
            print("[Simulation/Stand-alone Mode] CobotArmController started without pymycobot.")

    def open_gripper(self, speed: int = 50) -> None:
        """Open the end-effector parallel gripper.

        Args:
            speed (int): Movement speed for gripper opening (0 to 100). Defaults to 50.
        """
        self.is_gripper_closed = False
        if self.mc is not None:
            try:
                self.mc.set_gripper_state(0, speed)
            except Exception as err:
                print(f"[Arm] Hardware command error during open_gripper: {err}")
        print("[Arm] Gripper opened.")
        time.sleep(0.1)

    def close_gripper(self, speed: int = 50) -> None:
        """Close the end-effector parallel gripper to grasp an object.

        Args:
            speed (int): Movement speed for gripper closing (0 to 100). Defaults to 50.
        """
        self.is_gripper_closed = True
        if self.mc is not None:
            try:
                self.mc.set_gripper_state(1, speed)
            except Exception as err:
                print(f"[Arm] Hardware command error during close_gripper: {err}")
        print("[Arm] Gripper closed (object grasped).")
        time.sleep(0.1)

    def move_to_joint_angles(
        self,
        angles: Tuple[float, float, float, float, float, float],
        speed: int = 50
    ) -> None:
        """Move all 6 joints to specified target angles in degrees.

        Args:
            angles (Tuple[float, float, float, float, float, float]): Target joint angles [J1, J2, J3, J4, J5, J6] in degrees.
            speed (int): Joint movement speed (0 to 100). Defaults to 50.
        """
        if self.mc is not None:
            try:
                self.mc.send_angles(list(angles), speed)
            except Exception as err:
                print(f"[Arm] Hardware command error during move_to_joint_angles: {err}")
        formatted_angles = ", ".join(f"{a:.1f}°" for a in angles)
        print(f"[Arm] Moving joints to [{formatted_angles}] at speed {speed}...")
        time.sleep(0.1)

    def move_to_coords(
        self,
        coords_3d: Tuple[float, float, float],
        rx_ry_rz: Tuple[float, float, float] = (-180.0, 0.0, 0.0),
        speed: int = 50,
        mode: int = 1
    ) -> None:
        """Move the end-effector/gripper to target Cartesian 3D coordinates in meters.

        Args:
            coords_3d (Tuple[float, float, float]): Target Cartesian coordinates (x, y, z) in meters.
            rx_ry_rz (Tuple[float, float, float]): End-effector orientation angles (rx, ry, rz) in degrees. Defaults to (-180.0, 0.0, 0.0).
            speed (int): Movement speed (0 to 100). Defaults to 50.
            mode (int): Interpolation mode (0: angular / non-linear, 1: linear). Defaults to 1.
        """
        x, y, z = coords_3d
        rx, ry, rz = rx_ry_rz
        if self.mc is not None:
            try:
                # Convert Cartesian coordinates from meters to millimeters for myCobot API
                mc_coords = [x * 1000.0, y * 1000.0, z * 1000.0, rx, ry, rz]
                self.mc.send_coords(mc_coords, speed, mode)
            except Exception as err:
                print(f"[Arm] Hardware command error during move_to_coords: {err}")
        print(f"[Arm] Moving gripper to target x={x:.3f}m, y={y:.3f}m, z={z:.3f}m (rx={rx:.1f}°, ry={ry:.1f}°, rz={rz:.1f}°)...")
        time.sleep(0.1)

    def move_to_home_pose(self, speed: int = 50) -> None:
        """Move all 6 joints to the safe home posture [0°, 0°, 0°, 0°, 0°, 0°].

        Args:
            speed (int): Movement speed (0 to 100). Defaults to 50.
        """
        print("[Arm] Moving to safe home posture...")
        self.move_to_joint_angles((0.0, 0.0, 0.0, 0.0, 0.0, 0.0), speed=speed)

    def pick_cube(self, target_coords_3d: Tuple[float, float, float]) -> bool:
        """Execute a pick sequence from above.

        Args:
            target_coords_3d (Tuple[float, float, float]): Grasp point (x, y, z) in meters.

        Returns:
            bool: True if the sequence was completed.
        """
        # TODO: Open the gripper, move to the pre-pick pose 0.10 m above the target, move down to
        # the target, close the gripper, move back up to the pre-pick pose.
        raise NotImplementedError("TODO: implement pick_cube")

    def place_cube(self, target_coords_3d: Tuple[float, float, float]) -> bool:
        """Execute a place sequence from above and return to the home pose.

        Args:
            target_coords_3d (Tuple[float, float, float]): Place point (x, y, z) in meters.

        Returns:
            bool: True if the sequence was completed.
        """
        # TODO: Move to the pose 0.10 m above the target, move down, open the gripper, move back up,
        # move to the home pose.
        raise NotImplementedError("TODO: implement place_cube")
