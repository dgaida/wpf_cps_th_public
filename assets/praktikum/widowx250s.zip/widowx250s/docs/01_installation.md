# Installation & Systemanforderungen: WidowX-250s Roboterarm

Diese Anleitung beschreibt die Einrichtung der Entwicklungsumgebung für das Praktikum mit dem **WidowX-250s Roboterarm (6DOF)**.

---

## 📋 Systemvoraussetzungen

- **Betriebssystem:** Ubuntu 22.04 LTS (empfohlen für ROS 2 Humble) oder macOS / Windows mit Docker Container.  
- **ROS 2 Version:** ROS 2 Humble Hawksbill.  
- **Python Version:** Python 3.10 oder 3.11.  

---

## 🐍 1. Python-Umgebung einrichten

### Option A: Mit Conda (Empfohlen)

```bash
# 1. Conda-Umgebung aus environment.yml erstellen
conda env create -f environment.yml

# 2. Umgebung aktivieren
conda activate widowx250s
```

### Option B: Mit pip und Virtual Environment (venv)

```bash
# 1. Virtuelle Umgebung erstellen
python3 -m venv venv

# 2. Virtuelle Umgebung aktivieren
source venv/bin/activate

# 3. Abhängigkeiten installieren
pip install -r requirements.txt
```

---

## 🤖 2. ROS 2 & Interbotix XS Driver Installation

Für die Ansteuerung des realen Roboterarms oder der lokalen Simulation wird der **Interbotix ROS 2 Packages Stack** benötigt.

### A) Interbotix ROS 2 Installation Script

Interbotix bietet ein automatisierte Installationsskript für ROS 2 Humble an:

```bash
curl 'https://raw.githubusercontent.com/Interbotix/interbotix_ros_toolboxes/main/interbotix_xs_ros_control/file/xsarm_amd64_install.sh' > xsarm_amd64_install.sh
chmod +x xsarm_amd64_install.sh
./xsarm_amd64_install.sh -d humble
```

### B) Interbotix Python SDK (`interbotix_xs_modules`)

Die Python-Klassen zur Ansteuerung (`InterbotixManipulatorXS`) werden im Zuge der ROS 2 Interbotix Stack Installation im Python-Pfad registriert.

Prüfen Sie die Installation in Python:

```python
from interbotix_xs_modules.xs_arm import InterbotixManipulatorXS
print("Interbotix SDK erfolgreich installiert!")
```

---

## 🐳 Alternative: Docker Container

Falls kein physisches Linux mit ROS 2 Humble bereitsteht, nutzen Sie den mitgelieferten Docker Container.
Details hierzu finden Sie in der Anleitung [`02_docker_container.md`](./02_docker_container.md).
