# Aufgabenstellung: Kameraeinbindung & QR-Code Tracking (WidowX-250s)

In dieser Praktikumsaufgabe lernen Sie, wie Sie eine externe Kamera (Intel RealSense D415/D435 oder USB-Webcam) zur visuellen Überwachung und Tracking-Steuerung des WidowX-250s Roboterarms einsetzen.

---

## 🎯 Lernziele

1. **Kamera-Streams initialisieren**: Einbinden der Intel RealSense via `pyrealsense2` (mit automatischer Fallback-Möglichkeit auf OpenCV `VideoCapture`).  
2. **Kameraausrichtung via Live-Vorschau**: Anzeige des Kamerafeeds in einem eigenen OpenCV-Fenster zur manuellen Kameraausrichtung vor Roboterbewegungen.  
3. **QR-Code & AprilTag Erkennung**: Echtzeit-Detektion und Dekodierung von QR-Codes, AprilTags (`tag36h11`) und ArUco-Markern.  
4. **Endeffektor-Pose erfassen**: Auslesen der aktuellen 3D-Transformation $T_{w,ee}$ ($x, y, z$) des Greifers aus dem ROS 2 Treibersystem.  
5. **Simultane Trajektorien-Überwachung**: Überlagerung von Koordinateninformationen auf dem Kamerabild und Logging erkannter QR-Codes während Roboterbewegungen.  

---

## 🛠️ Voraussetzungen

1. **Kamera-Treiber & Abhängigkeiten**:  
   Stellen Sie sicher, dass die Intel RealSense Treiber und Python-Pakete gemäß [`03_realsense_installation.md`](./03_realsense_installation.md) installiert sind.

2. **ROS 2 Treiber starten**:  
   Vor der Ausführung von Python-Skripten muss der Interbotix ROS 2 Treiber im Terminal gestartet werden:

   ```bash
   ros2 launch interbotix_xsarm_control xsarm_control.launch.py robot_model:=wx250s
   ```

   > **Wichtiger Sicherheitshinweis:** Bevor Sie das Terminal des ROS 2 Treibers schließen oder abbrechen, stellen Sie sicher, dass der Roboterarm in die Ruheposition (`go_to_sleep_pose()`) gefahren wurde, damit der Arm beim Abschalten des Drehmoments nicht herunterfällt.

---

## 📝 Ablauf & Durchführung

Das Praktikum wird mit dem Skript `3-widowx250s_realsense_qr_tracking.py` durchgeführt.

### Schritt 1: Starten des Python-Skripts
```bash
python3 3-widowx250s_realsense_qr_tracking.py
```

### Schritt 2: Live-Kameraausrichtung  
1. Das Skript öffnet ein OpenCV-Fenster (*"Camera Stream / QR Tracking"*), das das Live-Kamerabild anzeigt.  
2. Richten Sie die Kamera so aus, dass der Arbeitsbereich des Roboterarms und der am Greifer befestigte QR-Code gut sichtbar sind.  
3. Drücken Sie **'q'** oder **Enter** im Bildfenster, um die Kameraausrichtung zu bestätigen und mit den Roboterbewegungen zu beginnen.  

### Schritt 3: Automatischer Bewegungsablauf & QR-Tracking  
1. Der Roboterarm fährt zunächst in die **Home-Position**.  
2. Anschließend fährt er nacheinander vier definierte Ziel-Wegpunkte ($x, y, z$) an:  
   - Wegpunkt 1: $(0{,}30\,\text{m}, 0{,}00\,\text{m}, 0{,}20\,\text{m})$  
   - Wegpunkt 2: $(0{,}35\,\text{m}, 0{,}10\,\text{m}, 0{,}25\,\text{m})$  
   - Wegpunkt 3: $(0{,}35\,\text{m}, -0{,}10\,\text{m}, 0{,}25\,\text{m})$  
   - Wegpunkt 4: $(0{,}25\,\text{m}, 0{,}00\,\text{m}, 0{,}15\,\text{m})$  
3. An jedem Wegpunkt führt die Funktion `capture_and_log_pose()` aus `src/realsense_qr_tracker.py` Folgendes aus:  
   - Erfassung des aktuellen Kamerabilds.  
   - Detektion des QR-Codes bzw. AprilTags/ArUco-Markers und Einzeichnen eines grünen Rahmens sowie der ID/Inhalte im Bild.  
   - Auslesen der Endeffektor-Koordinaten ($X, Y, Z$) aus der Transformationsmatrix $T_{w,ee}$.  
   - Einblenden der Koordinaten als Textoverlay im Live-Bildfenster.  
   - Protokollieren von QR-Erkennungen in der Konsole.  

### Schritt 4: Abschluss & Sicheres Parken
Nach Durchlaufen der Trajektorie fährt das Skript den Roboterarm automatisch in die **Sleep-Position** (`go_to_sleep_pose()`), schließt das Fenster und gibt die Kameraressourcen frei.

---

## 📂 Relevante Dateien

- 🐍 **`3-widowx250s_realsense_qr_tracking.py`**: Hauptskript zur Durchführung der Aufgabe.  
- 📦 **`src/realsense_qr_tracker.py`**: Modul mit `CameraStreamHandler` und `capture_and_log_pose()`.  
