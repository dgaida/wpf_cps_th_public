# Aufgabenstellung: Kameraeinbindung & Perception Pick-and-Place (WidowX-250s)

In dieser Praktikumsaufgabe lernen Sie, wie Sie eine Tiefenkamera (z. B. Intel RealSense D435) in Kombination mit dem Interbotix Perception Stack zur automatischen Kamerakalibrierung und visuellen Objekterkennung beim WidowX-250s Roboterarm einsetzen.

Das Skript basiert auf der offiziellen Pick-and-Place Demo von Trossen Robotics:  
- 🔗 **Quellcode**: [`pick_place.py` (Interbotix ROS Manipulators)](https://github.com/Interbotix/interbotix_ros_manipulators/blob/main/interbotix_ros_xsarms/interbotix_xsarm_perception/scripts/pick_place.py)  
- 🎬 **Video-Tutorials**:  
  - [Interbotix Tutorials: Python Perception](https://www.youtube.com/watch?v=03BZ6PLFOac)  
  - [Interbotix Tutorials: Perception Pipeline Tuning](https://www.youtube.com/watch?v=UesfMYM4qcc)  

---

## 🎯 Lernziele

1. **Perception Stack starten**: Starten des ROS 2 Perception-Launchfiles zur Punktwolken-Verarbeitung und ArmTag-Kamerakalibrierung.  
2. **Automatisierte Kamera-Roboter-Kalibrierung**: Anfahren der AR-Tag Sichtposition zur Bestimmung der Transformation zwischen Kamera und Roboterbasis (`InterbotixArmTagInterface`).  
3. **Punktwolken-Objekterkennung**: Segmentieren und Erfassen von Objekt-Clustern im 3D-Raum über die Interbotix PointCloud-Schnittstelle (`InterbotixPointCloudInterface`).  
4. **Automatisches Greifen & Ablegen (Pick-and-Place)**: Anfahren der erkannten Cluster-Positionen im Roboter-Koordinatensystem (`wx250s/base_link`) und geordnetes Ablegen der Objekte.  

---

## 📦 Benötigte Pakete & Installation

Auf dem mit dem WidowX-250s Roboterarm verbundenen Steuerungsrechner (Nvidia Jetson) wird **ROS 2 Galactic** eingesetzt. Für die Ausführung des Perception Stacks und des Python-Skripts werden die folgenden System-Pakete, ROS 2 Module und Python-Bibliotheken benötigt:

### 1. Intel RealSense SDK 2.0 & ROS 2 Kamera-Treiber
```bash
# GPG-Schlüssel und Intel Repository hinzufügen
sudo mkdir -p /etc/apt/keyrings
curl -sSf https://librealsense.intel.com/Debian/librealsense.pgp | sudo tee /etc/apt/keyrings/librealsense.pgp > /dev/null
echo "deb [signed-by=/etc/apt/keyrings/librealsense.pgp] https://librealsense.intel.com/Debian/apt-repo $(lsb_release -cs) main" | sudo tee /etc/apt/sources.list.d/librealsense.list
sudo apt-get update

# RealSense SDK & Utilities installieren
sudo apt-get install -y librealsense2-dkms librealsense2-utils librealsense2-dev

# ROS 2 RealSense Kamera-Treiber (ROS 2 Galactic)
sudo apt-get install -y ros-galactic-realsense2-camera
```

### 2. ROS 2 Perception, AprilTag & PCL Pakete
```bash
sudo apt-get update && sudo apt-get install -y \
    ros-galactic-apriltag-ros \
    ros-galactic-apriltag \
    ros-galactic-image-proc \
    ros-galactic-pcl-ros \
    ros-galactic-pcl-conversions \
    ros-galactic-rtabmap-ros \
    ros-galactic-rviz2 \
    ros-galactic-rviz-default-plugins
```

### 3. Interbotix ROS 2 Workspace Repositories (Branch `galactic`)
Die folgenden Repositories müssen sich im ROS 2 Workspace (z. B. `~/interbotix_ws/src`) befinden und mittels `colcon build` kompiliert sein:  
- **`interbotix_ros_manipulators`** (enthält das Package `interbotix_xsarm_perception`)  
- **`interbotix_ros_toolboxes`** (enthält `interbotix_perception_modules` / `interbotix_perception_toolbox`)  
- **`interbotix_ros_core`** (enthält Treiber und Python SDK `interbotix_xs_modules`)  

```bash
cd ~/interbotix_ws/src
git clone -b galactic https://github.com/Interbotix/interbotix_ros_core.git
git clone -b galactic https://github.com/Interbotix/interbotix_ros_manipulators.git
git clone -b galactic https://github.com/Interbotix/interbotix_ros_toolboxes.git

cd ~/interbotix_ws
rosdep update && rosdep install --from-paths src --ignore-src -r -y
colcon build --symlink-install
source install/setup.bash
```

### 4. Python-Abhängigkeiten
```bash
pip install pyrealsense2 opencv-python pillow modern_robotics pyyaml numpy
```

---

## 🛠️ Voraussetzungen & Aufbau

1. **Kamera- und Hardware-Aufbau**:  
   Die Tiefenkamera (z. B. Intel RealSense D435) wird vor dem Roboterarm positioniert. Am Greifer des WidowX-250s ist die AR Tag Plate montiert.

2. **ROS 2 Perception Treiber starten**:  
   Vor der Ausführung des Skripts muss das Interbotix Perception Launchfile im Terminal gestartet werden:

   ```bash
   ros2 launch interbotix_xsarm_perception xsarm_perception.launch.py robot_model:=wx250s
   ```

   > **Wichtiger Sicherheitshinweis:** Bevor Sie das Terminal des ROS 2 Treibers schließen oder abbrechen, stellen Sie sicher, dass der Roboterarm in die Ruheposition (`go_to_sleep_pose()`) gefahren wurde, damit der Arm beim Abschalten des Drehmoments nicht herunterfällt.

---

## 🎛️ Perception Pipeline Tuning & Kalibrier-GUIs

Für die visuelle Feinjustierung der Punktwolken-Filter (z. B. Zuschneiden des Arbeitsbereichs/Cropping, Rauschfilterung) sowie der ArmTag-Transformation stehen interaktive Kalibrier-GUIs zur Verfügung (siehe Video-Tutorial [Interbotix Tutorials: Perception Pipeline Tuning](https://www.youtube.com/watch?v=UesfMYM4qcc)):

### 1. PointCloud Tuner GUI starten
Zum Öffnen der GUI zur Feinabstimmung der Punktwolken-Filter (PassThrough, Crop, Downsampling) führen Sie aus:

```bash
ros2 launch interbotix_xsarm_perception xsarm_perception.launch.py robot_model:=wx250s use_pointcloud_tuner_gui:=true
```

### 2. ArmTag Tuner GUI starten
Zum Öffnen der Kalibrier-GUI für die AR-Tag-basierte Transformationsbestimmung zwischen Kamera und Roboterbasis nutzen Sie:

```bash
ros2 launch interbotix_xsarm_perception xsarm_perception.launch.py robot_model:=wx250s use_armtag_tuner_gui:=true
```

### 3. Kombinierter Start (Beide Tuning-GUIs)
Um sowohl die Punktwolken-Filter als auch die ArmTag-Kalibrier-GUI gleichzeitig in RViz2 / GUI-Fenstern zu öffnen:

```bash
ros2 launch interbotix_xsarm_perception xsarm_perception.launch.py robot_model:=wx250s use_pointcloud_tuner_gui:=true use_armtag_tuner_gui:=true
```

### Parameter-Übersicht für Perception Pipeline Tuning  
- `use_pointcloud_tuner_gui:=true`: Aktiviert die grafische Oberfläche zur interaktiven Einstellung der Punktwolken-Filtergrenzen ($X$-, $Y$-, $Z$-Bounds).  
- `use_armtag_tuner_gui:=true`: Öffnet die GUI zur Kalibrierung und Speicherung der Posen-Transformation von `camera_frame` zu `wx250s/base_link`.  
- `enable_pipeline:=true`: Schaltet die kontinuierliche Verarbeitung der Punktwolke ein (wird bei aktiviertem Tuner automatisch gesetzt).  
- `filter_params`: Pfad zur Konfigurationsdatei (YAML) für gespeicherte Filterparameter.  
- `transform_filepath`: Pfad zur Datei `static_transforms.yaml`, in der berechnete Kamera-Roboter-Transformationen abgespeichert werden.  

---

## 📝 Ablauf & Durchführung

Das Praktikum wird mit dem Skript `3-widowx250s_realsense_qr_tracking.py` durchgeführt.

### Schritt 1: Starten des Python-Skripts
```bash
python3 3-widowx250s_realsense_qr_tracking.py
```

### Schritt 2: ArmTag-Kalibrierung  
1. Der Roboterarm fährt in eine vordefinierte Position (`y=-0.3m`, `z=0.2m`), an der der montierte AR-Tag für die Overhead-Kamera gut sichtbar ist.  
2. Das Modul `InterbotixArmTagInterface` berechnet automatisch die Transformation von der Kamera zur Roboterbasis (`wx250s/base_link`).  

### Schritt 3: Punktwolken-Segmentierung  
1. Über `InterbotixPointCloudInterface.get_cluster_positions()` werden alle im Arbeitsbereich befindlichen Objekt-Cluster ermittelt.  
2. Die Objekte werden anhand ihrer Positionen entlang der $X$-Achse sortiert.  

### Schritt 4: Automatischer Pick-and-Place Ablauf  
1. Für jedes erkannte Objekt fährt der Roboterarm nacheinander:  
   - die Vorposition oberhalb des Objekts ($z + 0{,}05\,\text{m}$) an,  
   - steigt auf Objekt-Höhe $z$ ab,  
   - schließt den Greifer (`grasp()`),  
   - hebt das Objekt an,  
   - transportiert es zur Ablageposition und öffnet den Greifer (`release()`).  
2. Nach Abschluss aller Objekte fährt der Roboterarm automatisch in die **Sleep-Position** (`go_to_sleep_pose()`).  

---

## 📂 Relevante Dateien

- 🐍 **`3-widowx250s_realsense_qr_tracking.py`**: Skript für die Kamerakalibrierung, Punktwolken-Clustererfassung und Perception Pick-and-Place.  
