# Aufgabenstellung: Kameraeinbindung & Perception Pick-and-Place (WidowX-250s)

In dieser Praktikumsaufgabe lernen Sie, wie Sie eine Tiefenkamera (z. B. Intel RealSense D435) in Kombination mit dem Interbotix Perception Stack zur automatischen Kamerakalibrierung und visuellen Objekterkennung beim WidowX-250s Roboterarm einsetzen.

Das Skript basiert auf der offiziellen Pick-and-Place Demo von Trossen Robotics:
- 🔗 **Quellcode**: [`pick_place.py` (Interbotix ROS Manipulators)](https://github.com/Interbotix/interbotix_ros_manipulators/blob/main/interbotix_ros_xsarms/interbotix_xsarm_perception/scripts/pick_place.py)
- 🎬 **Video-Tutorial**: [Interbotix Perception & Camera Calibration Demo (YouTube)](https://www.youtube.com/watch?v=03BZ6PLFOac)

---

## 🎯 Lernziele

1. **Perception Stack starten**: Starten des ROS 2 Perception-Launchfiles zur Punktwolken-Verarbeitung und ArmTag-Kamerakalibrierung.
2. **Automatisierte Kamera-Roboter-Kalibrierung**: Anfahren der AR-Tag Sichtposition zur Bestimmung der Transformation zwischen Kamera und Roboterbasis (`InterbotixArmTagInterface`).
3. **Punktwolken-Objekterkennung**: Segmentieren und Erfassen von Objekt-Clustern im 3D-Raum über die Interbotix PointCloud-Schnittstelle (`InterbotixPointCloudInterface`).
4. **Automatisches Greifen & Ablegen (Pick-and-Place)**: Anfahren der erkannten Cluster-Positionen im Roboter-Koordinatensystem (`wx250s/base_link`) und geordnetes Ablegen der Objekte.

---

## 🛠️ Voraussetzungen & Aufbau

1. **Kamera- und Hardware-Aufbau**:
   Die Tiefenkamera (z. B. Intel RealSense D435) wird vor dem Roboterarm positioniert. Am Greifer des WidowX-250s ist die AR Tag Plate montiert.

2. **ROS 2 Perception Treiber starten**:
   Vor der Ausführung des Skripts muss das Interbotix Perception Launchfile im Terminal gestartet werden:

   ```bash
   ros2 launch interbotix_xsarm_perception xsarm_perception.launch.py robot_model:=wx250s
   ```

   > **Wichtiger Sicherheitshinweis:** Bevor Sie das Terminal des ROS 2 Treibers schließen oder abbrechen, stellen Sie sicher, dass der Roboterarm in die Ruheposition (`go_to_sleep_pose()`) gefahren wurde, damit der Arm beim Abschalten des Drehmoments nicht herunterfällt.

---

## 📝 Ablauf & Durchführung

Das Praktikum wird mit dem Skript `3-widowx250s_realsense_qr_tracking.py` durchgeführt.

### Schritt 1: Starten des Python-Skripts
```bash
python3 3-widowx250s_realsense_qr_tracking.py
```

### Schritt 2: ArmTag-Kalibrierung
1. Der Roboterarm fährt in eine vordefinierte Position (`y=-0.3m`, `z=0.2m`), an der der montierte AR-Tag für die Overhead-Kamera gut sichtbar ist.
2. Das Modul `InterbotixArmTagInterface` berechnet automatisch die Transformation von der Kamera zur Roboterbasis (`wx250s/base_link`).

### Schritt 3: Punktwolken-Segmentierung
1. Über `InterbotixPointCloudInterface.get_cluster_positions()` werden alle im Arbeitsbereich befindlichen Objekt-Cluster ermittelt.
2. Die Objekte werden anhand ihrer Positionen entlang der $X$-Achse sortiert.

### Schritt 4: Automatischer Pick-and-Place Ablauf
1. Für jedes erkannte Objekt fährt der Roboterarm nacheinander:
   - die Vorposition oberhalb des Objekts ($z + 0{,}05\,\text{m}$) an,
   - steigt auf Objekt-Höhe $z$ ab,
   - schließt den Greifer (`grasp()`),
   - hebt das Objekt an,
   - transportiert es zur Ablageposition und öffnet den Greifer (`release()`).
2. Nach Abschluss aller Objekte fährt der Roboterarm automatisch in die **Sleep-Position** (`go_to_sleep_pose()`).

---

## 📂 Relevante Dateien

- 🐍 **`3-widowx250s_realsense_qr_tracking.py`**: Skript für die Kamerakalibrierung, Punktwolken-Clustererfassung und Perception Pick-and-Place.
