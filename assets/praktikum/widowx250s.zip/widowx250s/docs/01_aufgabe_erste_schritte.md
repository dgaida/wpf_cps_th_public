# Praktikumsaufgabe 1: Erste Schritte, Kinematik & Pick-and-Place

Diese Anleitung beschreibt den Ablauf und die Aufgabenstellung für das erste Teilpraktikum mit dem **WidowX-250s Roboterarm (6DOF)**.

---

## 🎯 Lernziele

1. **Interbotix Python SDK**: Initialisierung und Nutzung der Steuerungsklasse `InterbotixManipulatorXS`.  
2. **Vorwärtskinematik (Forward Kinematics)**: Anfahren definierter Posen (`go_to_home_pose()`, `go_to_sleep_pose()`) sowie direkte Steuerung einzelner Gelenke in Radiant.  
3. **Inverse Kinematik (Inverse Kinematics)**: Kartesische Positionierung des Endeffektors im 3D-Koordinatensystem ($x, y, z, \text{pitch}$) bezüglich der Roboterbasis (`wx250s/base_link`).  
4. **Greifersteuerung**: Öffnen (`release()`), Schließen (`grasp()`) und Druckeinstellung des elektrischen Parallelgreifers.  
5. **Pick-and-Place Ablauf**: Implementierung einer strukturierten Klasse `WidowXPickAndPlace` in `src/widowx_pick_and_place.py` für automatisierte Greif- und Ablegevorgänge.  

---

## 🚀 ROS 2 Launch Commands & Start der Steuerung

Bevor Sie das Jupyter-Notebook ausführen, muss die Steuerung des Roboterarms auf dem Steuerungsrechner gestartet werden.

### A) Steuerung für den realen Roboterarm (im Labor)

Startet den Interbotix-Treiber-Node (`xs_sdk`) und die ROS 2 Control-Hardware-Schnittstelle für den physischen WidowX-250s Arm:

```bash
ros2 launch interbotix_xsarm_control xsarm_control.launch.py robot_model:=wx250s
```

> **Was macht dieser Befehl?** Er stellt die Verbindung über USB zu den Dynamixel-Servomotoren her, initialisiert die Gelenk-Controller und stellt die ROS 2 Services bereit, die von der Python-API `InterbotixManipulatorXS` benötigt werden.

### B) Steuerung in der Simulation (ohne reale Hardware)

Falls kein physischer Roboter zur Verfügung steht, kann die Steuerung zusammen mit einer RViz2-Visualisierung simuliert werden:

```bash
ros2 launch interbotix_xsarm_sim xsarm_sim.launch.py robot_model:=wx250s use_sim:=true
```

---

## ⚠️ Wichtige Sicherheitshinweise

### 1. Festhalten des Arms bei Drehmoment-Deaktivierung
Über den ROS 2 Service `/wx250s/torque_enable` können die Motoren stromlos geschaltet werden:

```bash
# Drehmoment deaktivieren (Freilauf)
ros2 service call /wx250s/torque_enable interbotix_xs_msgs/srv/TorqueEnable "{cmd_type: 'group', name: 'all', enable: false}"

# Drehmoment wieder aktivieren
ros2 service call /wx250s/torque_enable interbotix_xs_msgs/srv/TorqueEnable "{cmd_type: 'group', name: 'all', enable: true}"
```

> **ACHTUNG:** Bevor Sie das Drehmoment auf `enable: false` schalten, **müssen Sie den Roboterarm unbedingt mit der Hand festhalten und abstützen!** Sobald das Drehmoment deaktiviert wird, schalten die Motoren ab und der Arm fällt durch sein Eigengewicht ungebremst nach unten. Dies kann zu Hardware-Schäden führen.

### 2. Sicheres Beenden (Sleep-Position)
Bevor Sie das Terminal beenden oder unterbrechen, in dem `ros2 launch ...` läuft, fahren Sie den Roboterarm **stets** über den Befehl `bot.arm.go_to_sleep_pose()` in seine kompakte Ruheposition. Falls die Steuerung bei gestrecktem Arm beendet wird, fällt der Arm nach dem Abschalten der Motoren herab.

---

## 📝 Ablauf & Durchführung

Die Bearbeitung erfolgt im Jupyter-Notebook [`1-widowx250s_erste_schritte.ipynb`](../1-widowx250s_erste_schritte.ipynb).

### Schritt 1: Notebook öffnen
Öffnen Sie JupyterLab (z. B. im Browser unter `http://localhost:8888/lab` bei Docker-Nutzung oder direkt auf dem Steuerungsrechner) und starten Sie das Notebook `1-widowx250s_erste_schritte.ipynb`.

### Schritt 2: Initialisierung der Python-API
Führen Sie den Initialisierungscode aus:
```python
from interbotix_xs_modules.xs_arm import InterbotixManipulatorXS

bot = InterbotixManipulatorXS(
    robot_model="wx250s",
    group_name="arm",
    gripper_name="gripper"
)
```

### Schritt 3: Kinematik & Gelenksteuerung  
- Testen Sie das Anfahren der Standard-Posen `bot.arm.go_to_home_pose()` und `bot.arm.go_to_sleep_pose()`.  
- Steuern Sie einzelne Gelenke gezielt mit `bot.arm.set_single_joint_position()`.  
- Nutzen Sie `bot.arm.set_ee_pose_components(x, y, z, pitch)` für kartesische Zielpositionen.  

### Schritt 4: Pick-and-Place Klasse implementieren
Vervollständigen Sie die Methoden `pick()` und `place()` in `src/widowx_pick_and_place.py` (bzw. direkt im Notebook), sodass ein Objekt an einer Startkoordinate aufgenommen, auf eine sichere Höhe angehoben, zur Zielkoordinate transportiert und geordnet abgelegt wird.

---

## 📂 Relevante Dateien

- 📓 **`1-widowx250s_erste_schritte.ipynb`**: Hauptnotebook für Teil 1.  
- 🐍 **`src/widowx_pick_and_place.py`**: Python-Klasse für die Pick-and-Place Ablaufsteuerung.  
