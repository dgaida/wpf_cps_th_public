# Praktikumsaufgabe 2: Simulation in Gazebo & MoveIt

Diese Anleitung beschreibt den Ablauf und die Aufgabenstellung für das zweite Teilpraktikum mit dem **WidowX-250s Roboterarm (6DOF)** in der Gazebo-Physiksimulation und MoveIt-Umgebung.

---

## 🎯 Lernziele

1. **Gazebo & MoveIt Umgebungsverständnis**: Steuerung des WidowX-250s in einer vollständigen Physiksimulation mit Kollisionen, Kontakten und Gravitation.  
2. **ROS 2 Action-Interface**: Direct Trajectory Control über das `FollowJointTrajectory`-Action-Interface (`/wx250s/arm_controller` und `/wx250s/gripper_controller`), unabhängig vom `xs_sdk`-Treiber.  
3. **Modulare Hilfsfunktionen**: Nutzung der in `src/gazebo_moveit_helper.py` definierten Hilfsfunktionen `move_arm()` und `move_gripper()`.  
4. **Teach & Repeat Pick-and-Place**: Auslesen der aktuellen Gelenkwinkel aus `/wx250s/joint_states` über `record_pose()`, Teachen von Zielposen an Blöcken in der Gazebo-Welt und automatisierte Pick-and-Place Sequenzierung.  

---

## 🎲 Gazebo-Simulationswelt mit Objekten (`wx250s_blocks.world`)

Damit das **"Teachen" von Posen** einen praktischen Sinn ergibt, enthält die Simulation eine Arbeitsbereich-Plattform mit vier farbigen Blöcken (`cube_red`, `cube_green`, `cube_blue`, `cube_yellow`):

- **Tischplattform**: Befindet sich bei $x = 0{,}35\,\text{m}$ vor dem Roboterarm (Oberkante bei $z = 0{,}02\,\text{m}$).  
- **Würfel (2,5 cm Kantenlänge, ~20 g)**: Befinden sich im direkten Greifbereich des WidowX-250s (Mittelpunkt bei $z = 0{,}0325\,\text{m}$).  
- **Physik**: Greiferfinger und Würfel besitzen definierte Reibungskoeffizienten, sodass der Greifer die Blöcke bei ausreichendem Schließdruck physically anheben und versetzen kann.  

### 📍 Genaue Koordinaten der Objekte in der Welt

| Objekt | X-Koordinate | Y-Koordinate | Z-Koordinate |
| :--- | :--- | :--- | :--- |
| **`cube_red`** | $0{,}30\,\text{m}$ | $-0{,}06\,\text{m}$ | $0{,}0325\,\text{m}$ |
| **`cube_green`** | $0{,}30\,\text{m}$ | $+0{,}06\,\text{m}$ | $0{,}0325\,\text{m}$ |
| **`cube_blue`** | $0{,}40\,\text{m}$ | $-0{,}06\,\text{m}$ | $0{,}0325\,\text{m}$ |
| **`cube_yellow`** | $0{,}40\,\text{m}$ | $+0{,}06\,\text{m}$ | $0{,}0325\,\text{m}$ |
| **`place_drop` (Ablage)** | $0{,}35\,\text{m}$ | $0{,}00\,\text{m}$ | $0{,}0325\,\text{m}$ |
| **`place_above` (Anfahrhöhe)** | $0{,}35\,\text{m}$ | $0{,}00\,\text{m}$ | $0{,}1500\,\text{m}$ |

> **💡 Hinweis zu RViz vs. Gazebo:**
> In RViz wird nur das 3D-Modell des Roboterarms angezeigt – die 4 Blöcke sind in RViz **nicht** sichtbar. Zur visuellen Ausrichtung nutzen Sie das 3D-Fenster von Gazebo oder steuern den Arm per Python `move_arm(...)` direkt an die Würfelkoordinaten.
> **Achtung bei Winkeleinheiten:** In RViz werden Gelenkwinkel in **Grad (°)** dargestellt und eingegeben, während ROS 2 (`/wx250s/joint_states`) und `move_arm()` ausschließlich mit **Radiant (rad)** arbeiten.

---

## 💻 Start der Simulationsumgebung (Lokales ROS 2 mit Gazebo)

Sofern auf Ihrem ROS-2-System Gazebo Classic und MoveIt 2 installiert sind, kann die Physiksimulation mit folgendem Befehl gestartet werden:

```bash
ros2 launch interbotix_xsarm_moveit xsarm_moveit.launch.py robot_model:=wx250s hardware_type:=gz_classic world_filepath:=$(pwd)/worlds/wx250s_blocks.world
```

> **Wichtiger Hinweis zu Docker-Containern:**
> Aufgrund technischer Einschränkungen bei der Software-Rasterierung unter virtuellem X11/Xvfb (z. B. Absturz des 3D-Fensters `gzclient` sowie fehlendes Kamerasensor-Rendering) sind die vorgefertigten Gazebo-Docker-Container nicht im Studierenden-Paket enthalten. Details dazu finden Sie im Dokument [`docs/gazebo_container_probleme.md`](./gazebo_container_probleme.md).
> **Hinweis zur Architektur:** In dieser Simulationsvariante läuft kein `xs_sdk`-Node. Deshalb schlagen Aufrufe von `InterbotixManipulatorXS` fehl. Stattdessen wird direkt über ROS 2 Action-Clients mit den ROS 2 Controllers (`arm_controller` und `gripper_controller`) kommuniziert.

---

## 📝 Ablauf & Durchführung

Die Bearbeitung erfolgt im Notebook [`2-widowx250s_gazebo_moveit.ipynb`](../2-widowx250s_gazebo_moveit.ipynb).

### Schritt 1: Action-Clients & Hilfsfunktionen initialisieren
In den ersten Zellen werden die ROS 2 Action-Clients für den Arm und den Greifer initialisiert sowie die Hilfsfunktionen aus `src/gazebo_moveit_helper.py` importiert:

```python
from rclpy.action import ActionClient
from control_msgs.action import FollowJointTrajectory
from src.gazebo_moveit_helper import ARM_JOINTS, move_arm, move_gripper

arm_client = ActionClient(node, FollowJointTrajectory, "/wx250s/arm_controller/follow_joint_trajectory")
gripper_client = ActionClient(node, FollowJointTrajectory, "/wx250s/gripper_controller/follow_joint_trajectory")
```

### Schritt 2: Arm & Greifer per Python bewegen  
- **Arm bewegen**: `move_arm(arm_client, node, [0.0, -0.3, 0.3, 0.0, 0.5, 0.0], duration_sec=3.0)`  
- **Greifer bewegen**: `move_gripper(gripper_client, node, left_finger_position=0.015, duration_sec=1.0)`  
  *(0.037 m = geöffnet, 0.015 m = geschlossen)*

### Schritt 3: Posen teachen mit `record_pose()`

#### Was macht die Funktion `record_pose(name)`
Die Funktion `record_pose(name)` ist eine Teach-Hilfsfunktion:  
1. Sie abonniert das ROS 2 Topic `/wx250s/joint_states` und liest die aktuellen Gelenkwinkel aller 6 Armgelenke aus.  
2. Sie speichert diese Gelenkwinkel-Liste in einem Python-Dictionary (`waypoints[name]`).  

#### Ablauf des Teach-Vorgangs
Fahren Sie den Roboterarm entweder manuell über die MoveIt-RViz-GUI (Drag & Drop + *Plan & Execute*) oder per `move_arm()` an einen der Würfel in Gazebo heran und speichern Sie die Zielposen:

Benötigte Posen für einen Würfel-Greifvorgang (z. B. für den roten Würfel):  
1. `cube_red_above`: Vorposition oberhalb des roten Würfels (Greifer offen)  
2. `cube_red_grasp`: Absenkposition am roten Würfel (Finger umschließen den Würfel)  
3. `place_above`: Vorposition oberhalb der Ziel-Ablagefläche  
4. `place_drop`: Absenkposition an der Ziel-Ablagefläche  

Aufruf im Notebook:
```python
record_pose("cube_red_above")
record_pose("cube_red_grasp")
record_pose("place_above")
record_pose("place_drop")
```

### Schritt 4: Automatisches Pick-and-Place ausführen
Führen Sie die Funktion `pick_and_place()` aus, um die aufgenommenen Posen in korrekter Sequenz (Anfahren → Absenken → Greifen → Anheben → Verflogen → Ablegen → Freigeben) abzufahren:

```python
pick_and_place("cube_red_above", "cube_red_grasp", "place_above", "place_drop")
```

Beobachten Sie in der Gazebo-Visualisierung, wie der Roboterarm den roten Würfel aufnimmt, anhebt und an der Ablageposition ablegt.

---

## 📂 Relevante Dateien

- 📓 **`2-widowx250s_gazebo_moveit.ipynb`**: Hauptnotebook für Teil 2.  
- 🐍 **`src/gazebo_moveit_helper.py`**: Python-Hilfsskript für `move_arm()` und `move_gripper()`.  
