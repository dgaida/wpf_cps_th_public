# Praktikumsaufgabe 2: Simulation in Gazebo & MoveIt

Diese Anleitung beschreibt den Ablauf und die Aufgabenstellung für das zweite Teilpraktikum mit dem **WidowX-250s Roboterarm (6DOF)** in der Gazebo-Physiksimulation und MoveIt-Umgebung.

---

## 🎯 Lernziele

1. **Gazebo & MoveIt Umgebungsverständnis**: Steuerung des WidowX-250s in einer vollständigen Physiksimulation mit Kollisionen, Kontakten und Gravitation.  
2. **ROS 2 Action-Interface**: Direct Trajectory Control über das `FollowJointTrajectory`-Action-Interface (`/wx250s/arm_controller` und `/wx250s/gripper_controller`), unabhängig vom `xs_sdk`-Treiber.  
3. **Modulare Hilfsfunktionen**: Nutzung der in `src/gazebo_moveit_helper.py` definierten Hilfsfunktionen `move_arm()` und `move_gripper()`.  
4. **Teach & Repeat Pick-and-Place**: Auslesen der aktuellen Gelenkwinkel aus `/wx250s/joint_states` über `record_pose()`, Teachen von Zielposen an Blöcken in der Gazebo-Welt und automatisierte Pick-and-Place Sequenzierung.  

---

## 🎲 Gazebo-Simulationswelt mit Objekten (`wx250s_blocks.world`)

Damit das **"Teachen" von Posen** einen praktischen Sinn ergibt, enthält die Simulation eine Arbeitsbereich-Plattform mit vier farbigen Blöcken (`cube_red`, `cube_green`, `cube_blue`, `cube_yellow`):

- **Tischplattform**: Befindet sich bei $x = 0{,}35\,\text{m}$ vor dem Roboterarm.  
- **Würfel (2,5 cm Kantenlänge, ~20 g)**: Befinden sich im direkten Greifbereich des WidowX-250s.  
- **Physik**: Greiferfinger und Würfel besitzen definierte Reibungskoeffizienten, sodass der Greifer die Blöcke bei ausreichendem Schließdruck physically anheben und versetzen kann.  

---

## 🐳 Start der Simulationsumgebung (Docker Container)

Für diese Aufgabe wird die Docker-Simulationsumgebung mit Gazebo & MoveIt genutzt:

```bash
cd praktikum/widowx250s/docker_container_gz
docker compose up --build
```

### Benutzeroberflächen im Browser

- 🖥️ **noVNC Desktop (Gazebo & RViz2)**: [http://localhost:8081](http://localhost:8081)  
  *(In Gazebo sehen Sie den Roboterarm und die vier Blöcke; in RViz2 können Sie den Endeffektor per Drag & Drop mit dem interaktiven Marker positionieren)*  
- 📓 **JupyterLab**: [http://localhost:8888/lab](http://localhost:8888/lab)  
  *(Enthält das Notebook `2-widowx250s_gazebo_moveit.ipynb`)*

> **Hinweis zur Architektur:** In dieser Simulationsvariante läuft kein `xs_sdk`-Node. Deshalb schlagen Aufrufe von `InterbotixManipulatorXS` fehl. Stattdessen kommuniziert das Notebook direkt über ROS 2 Action-Clients mit den ROS 2 Controllers (`arm_controller` und `gripper_controller`).

---

## 📝 Ablauf & Durchführung

Die Bearbeitung erfolgt im Notebook [`2-widowx250s_gazebo_moveit.ipynb`](../2-widowx250s_gazebo_moveit.ipynb).

### Schritt 1: Action-Clients & Hilfsfunktionen initialisieren
In den ersten Zellen werden die ROS 2 Action-Clients für den Arm und den Greifer initialisiert sowie die Hilfsfunktionen aus `src/gazebo_moveit_helper.py` importiert:

```python
from rclpy.action import ActionClient
from control_msgs.action import FollowJointTrajectory
from src.gazebo_moveit_helper import ARM_JOINTS, move_arm, move_gripper

arm_client = ActionClient(node, FollowJointTrajectory, "/wx250s/arm_controller/follow_joint_trajectory")
gripper_client = ActionClient(node, FollowJointTrajectory, "/wx250s/gripper_controller/follow_joint_trajectory")
```

### Schritt 2: Arm & Greifer per Python bewegen  
- **Arm bewegen**: `move_arm(arm_client, node, [0.0, -0.3, 0.3, 0.0, 0.5, 0.0], duration_sec=3.0)`  
- **Greifer bewegen**: `move_gripper(gripper_client, node, left_finger_position=0.015, duration_sec=1.0)`  
  *(0.037 m = geöffnet, 0.015 m = geschlossen)*

### Schritt 3: Posen teachen mit `record_pose()`

#### Was macht die Funktion `record_pose(name)`
Die Funktion `record_pose(name)` ist eine Teach-Hilfsfunktion:  
1. Sie abonniert das ROS 2 Topic `/wx250s/joint_states` und liest die aktuellen Gelenkwinkel aller 6 Armgelenke aus.  
2. Sie speichert diese Gelenkwinkel-Liste in einem Python-Dictionary (`waypoints[name]`).  

#### Ablauf des Teach-Vorgangs
Fahren Sie den Roboterarm entweder manuell über die MoveIt-RViz-GUI (Drag & Drop + *Plan & Execute*) oder per `move_arm()` an einen der Würfel in Gazebo heran und speichern Sie die Zielposen:

Benötigte Posen für einen Würfel-Greifvorgang (z. B. für den roten Würfel):  
1. `cube_red_above`: Vorposition oberhalb des roten Würfels (Greifer offen)  
2. `cube_red_grasp`: Absenkposition am roten Würfel (Finger umschließen den Würfel)  
3. `place_above`: Vorposition oberhalb der Ziel-Ablagefläche  
4. `place_drop`: Absenkposition an der Ziel-Ablagefläche  

Aufruf im Notebook:
```python
record_pose("cube_red_above")
record_pose("cube_red_grasp")
record_pose("place_above")
record_pose("place_drop")
```

### Schritt 4: Automatisches Pick-and-Place ausführen
Führen Sie die Funktion `pick_and_place()` aus, um die aufgenommenen Posen in korrekter Sequenz (Anfahren → Absenken → Greifen → Anheben → Verflogen → Ablegen → Freigeben) abzufahren:

```python
pick_and_place("cube_red_above", "cube_red_grasp", "place_above", "place_drop")
```

Beobachten Sie in der Gazebo-Visualisierung (noVNC unter http://localhost:8081), wie der Roboterarm den roten Würfel aufnimmt, anhebt und an der Ablageposition ablegt.

---

## 📂 Relevante Dateien

- 📓 **`2-widowx250s_gazebo_moveit.ipynb`**: Hauptnotebook für Teil 2.  
- 🐍 **`src/gazebo_moveit_helper.py`**: Python-Hilfsskript für `move_arm()` und `move_gripper()`.  
- 🌐 **`docker_container_gz/worlds/wx250s_blocks.world`**: Gazebo-SDF-Welt mit Tisch und 4 farbigen Blöcken.  
