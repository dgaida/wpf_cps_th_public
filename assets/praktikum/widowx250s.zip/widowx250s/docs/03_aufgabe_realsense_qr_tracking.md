# Praktikumsaufgabe 3: Kameraeinbindung, ArmTag-Kalibrierung & Perception Pick-and-Place

In dieser Praktikumsaufgabe lernen Sie, wie Sie eine Tiefenkamera (z. B. Intel RealSense D435) in Kombination mit dem Interbotix Perception Stack zur automatischen Kamerakalibrierung und visuellen Objekterkennung beim WidowX-250s Roboterarm einsetzen.

Das Skript basiert auf der offiziellen Pick-and-Place Demo von Trossen Robotics:  
- 🔗 **Quellcode**: [`pick_place.py` (Interbotix ROS Manipulators)](https://github.com/Interbotix/interbotix_ros_manipulators/blob/main/interbotix_ros_xsarms/interbotix_xsarm_perception/scripts/pick_place.py)  
- 🎬 **Video-Tutorials**:  
  - [Interbotix Tutorials: Python Perception](https://www.youtube.com/watch?v=03BZ6PLFOac)  
  - [Interbotix Tutorials: Perception Pipeline Tuning](https://www.youtube.com/watch?v=UesfMYM4qcc)  

---

## 🎯 Lernziele

1. **Perception Stack starten**: Starten des ROS 2 Perception-Launchfiles zur Punktwolken-Verarbeitung und ArmTag-Kamerakalibrierung.  
2. **Automatisierte Kamera-Roboter-Kalibrierung**: Anfahren der AR-Tag Sichtposition zur Bestimmung der Transformation zwischen Kamera und Roboterbasis (`InterbotixArmTagInterface`).  
3. **Punktwolken-Objekterkennung**: Segmentieren und Erfassen von Objekt-Clustern im 3D-Raum über die Interbotix PointCloud-Schnittstelle (`InterbotixPointCloudInterface`).  
4. **Automatisches Greifen & Ablegen (Pick-and-Place)**: Anfahren der erkannten Cluster-Positionen im Roboter-Koordinatensystem (`wx250s/base_link`) und geordnetes Ablegen der Objekte.  

---

## 📦 Systemvoraussetzungen & Treiber-Installation

Auf dem Steuerungsrechner (Nvidia Jetson im Labor) sind alle benötigten Pakete (`librealsense2`, `realsense2-camera`, `apriltag-ros`, `pcl-ros` und `interbotix_xsarm_perception`) bereits installiert.

> **Hinweis zur Neuinstallation / Setup:**
> Eine vollständige Schritt-für-Schritt-Anleitung zur Erstinstallation aller Systempakete, ROS 2 Galactic Module und Interbotix Repositories finden Sie in der Dokumentation [📷 `docs/install/03_realsense_installation.md`](./install/03_realsense_installation.md).

---

## 🚀 ROS 2 Perception Stack starten

Vor der Ausführung des Python-Skripts muss das Interbotix Perception Launchfile im Terminal gestartet werden:

```bash
ros2 launch interbotix_xsarm_perception xsarm_perception.launch.py robot_model:=wx250s rs_camera_depth_module_profile:=424x240x30
```

> **Wichtiger Hinweis zur Robotersteuerung:**
> Das Launchfile `xsarm_perception.launch.py` bindet die Roboterarmsteuerung (`xsarm_control.launch.py`) bereits intern mit ein!
> **Achtung:** Es darf **kein** separates `xsarm_control.launch.py` im Hintergrund laufen! Falls `xsarm_control.launch.py` bereits läuft, muss dieses zuvor beendet werden, da sonst USB-Schnittstellen und Treiber doppelt belegt werden.
>
> **Warum `rs_camera_depth_module_profile:=424x240x30`?**
> Die reduzierte Tiefenauflösung verhindert Frame Drops beim Color-Stream, die bei der Standard-Auflösung von 640×480 auftreten und das AprilTag-Tracking blockieren würden (Details siehe [Troubleshooting-Guide](./install/05_realsense_pointcloud_fps_troubleshooting.md)).

---

## ⚠️ Wichtige Sicherheitshinweise

### 1. Festhalten des Arms bei Drehmoment-Deaktivierung
Falls der Roboterarm für die AR-Tag-Kalibrierung manuell positioniert werden muss, kann das Drehmoment der Arm-Gelenke über den ROS 2 Service deaktiviert (Freilauf) und anschließend wieder aktiviert werden:

```bash
# Drehmoment der Arm-Gelenke deaktivieren (Freilauf)
ros2 service call /wx250s/torque_enable interbotix_xs_msgs/srv/TorqueEnable "{cmd_type: 'group', name: 'arm', enable: false}"

# Drehmoment der Arm-Gelenke wieder aktivieren
ros2 service call /wx250s/torque_enable interbotix_xs_msgs/srv/TorqueEnable "{cmd_type: 'group', name: 'arm', enable: true}"
```

> **WARNUNG:** Wenn Sie das Drehmoment deaktivieren (`enable: false`), **müssen Sie den Roboterarm zwingend mit der Hand festhalten und abstützen!** Ohne Halte-Drehmoment fällt der Arm durch sein Eigengewicht sofort nach unten.

### 2. Sicheres Beenden (Sleep-Position)
Bevor Sie das Terminal des Perception-Treibers schließen oder abbrechen, stellen Sie sicher, dass der Roboterarm in die Ruheposition (`go_to_sleep_pose()`) gefahren wurde.

---

## 🎛️ Perception Pipeline Tuning & Kalibrier-GUIs

Für die visuelle Feinjustierung der Punktwolken-Filter (z. B. Zuschneiden des Arbeitsbereichs/Cropping, Rauschfilterung) sowie der ArmTag-Transformation stehen interaktive Kalibrier-GUIs zur Verfügung (siehe Video-Tutorial [Interbotix Tutorials: Perception Pipeline Tuning](https://www.youtube.com/watch?v=UesfMYM4qcc)):

### 1. PointCloud Tuner GUI starten
Zum Öffnen der GUI zur Feinabstimmung der Punktwolken-Filter (PassThrough, Crop, Downsampling) führen Sie aus:

```bash
ros2 launch interbotix_xsarm_perception xsarm_perception.launch.py robot_model:=wx250s use_pointcloud_tuner_gui:=true rs_camera_depth_module_profile:=424x240x30
```

### 2. ArmTag Tuner GUI starten
Zum Öffnen der Kalibrier-GUI für die AR-Tag-basierte Transformationsbestimmung zwischen Kamera und Roboterbasis nutzen Sie:

```bash
ros2 launch interbotix_xsarm_perception xsarm_perception.launch.py robot_model:=wx250s use_armtag_tuner_gui:=true rs_camera_depth_module_profile:=424x240x30
```

### 3. Kombinierter Start (Beide Tuning-GUIs)
Um sowohl die Punktwolken-Filter als auch die ArmTag-Kalibrier-GUI gleichzeitig in RViz2 / GUI-Fenstern zu öffnen:

```bash
ros2 launch interbotix_xsarm_perception xsarm_perception.launch.py robot_model:=wx250s use_pointcloud_tuner_gui:=true use_armtag_tuner_gui:=true rs_camera_depth_module_profile:=424x240x30
```

---

## 💡 Fehlerbehebung & Troubleshooting

1. **`AttributeError: 'InterbotixAprilTagInterface' object has no attribute '_logger'`**:  
   - **Ursache**: Tritt auf, wenn das Skript `3-widowx250s_realsense_qr_tracking.py` gestartet wird, ohne dass das ROS 2 Perception Launchfile im Hintergrund aktiv ist, oder wenn hängende ROS 2 Hintergrundprozesse vorliegen.  
   - **Lösung**:  
     1. Das Launchfile in einem eigenen Terminal starten:  
        ```bash
        ros2 launch interbotix_xsarm_perception xsarm_perception.launch.py robot_model:=wx250s rs_camera_depth_module_profile:=424x240x30
        ```
     2. Falls der Fehler weiterhin auftritt, den ROS 2 Daemon neu starten und verwaiste Prozesse beenden:  
        ```bash
        ros2 daemon stop && ros2 daemon start
        pkill -f xsarm_perception
        ```

2. **Punktwolkengröße ändert sich in RViz2 / Tuner GUI nicht**:  
   - **Ursache**: In RViz2 ist im Display-Panel `PointCloud2` häufig das rohe Kamerathema `/camera/depth/color/points` ausgewählt statt des gefilterten Themas `/perception/filter/points`.  
   - **Lösung**:  
     - In RViz2 unter **PointCloud2 -> Topic** das Thema auf `/perception/filter/points` umstellen.  
     - Prüfen, ob `enable_pipeline:=true` gesetzt ist, damit die Punktwolkenfilter kontinuierlich neu berechnet werden.  

3. **Kein Color-Stream / AprilTag wird nicht erkannt (Pointcloud verwirft Color-Frames)**:  
   - **Ursache**: Bei aktiver Punktwolke führt die Standard-Tiefenauflösung von 640×480 zu hohen Rechenzeiten (~50 ms/Frame) im Kamera-Syncer, wodurch der Color-Stream blockiert wird.  
   - **Lösung**: Starten Sie das Launchfile mit der reduzierten Tiefenauflösung `rs_camera_depth_module_profile:=424x240x30` (Details siehe [Troubleshooting-Dokumentation](./install/05_realsense_pointcloud_fps_troubleshooting.md)).  

---

## 📝 Ablauf & Durchführung

Das Praktikum wird mit dem Skript `3-widowx250s_realsense_qr_tracking.py` durchgeführt.

### Schritt 1: Starten des Python-Skripts
```bash
python3 3-widowx250s_realsense_qr_tracking.py
```

### Schritt 2: ArmTag-Kalibrierung  
1. Der Roboterarm fährt in eine vordefinierte Position (`y=-0.3m`, `z=0.2m`), an der der montierte AR-Tag für die Overhead-Kamera gut sichtbar ist.  
2. Das Modul `InterbotixArmTagInterface` berechnet automatisch die Transformation von der Kamera zur Roboterbasis (`wx250s/base_link`).  

### Schritt 3: Punktwolken-Segmentierung  
1. Über `InterbotixPointCloudInterface.get_cluster_positions()` werden alle im Arbeitsbereich befindlichen Objekt-Cluster ermittelt.  
2. Die Objekte werden anhand ihrer Positionen entlang der $X$-Achse sortiert.  

### Schritt 4: Automatischer Pick-and-Place Ablauf  
1. Für jedes erkannte Objekt fährt der Roboterarm nacheinander:  
   - die Vorposition oberhalb des Objekts ($z + 0{,}05\,\text{m}$) an,  
   - steigt auf Objekt-Höhe $z$ ab,  
   - schließt den Greifer (`grasp()`),  
   - hebt das Objekt an,  
   - transportiert es zur Ablageposition und öffnet den Greifer (`release()`).  
2. Nach Abschluss aller Objekte fährt der Roboterarm automatisch in die **Sleep-Position** (`go_to_sleep_pose()`).  

---

## 📂 Relevante Dateien

- 🐍 **`3-widowx250s_realsense_qr_tracking.py`**: Skript für die Kamerakalibrierung, Punktwolken-Clustererfassung und Perception Pick-and-Place.  
