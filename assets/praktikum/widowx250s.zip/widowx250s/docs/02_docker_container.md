# Nutzung des Docker Containers für WidowX-250s Simulation

Diese Anleitung beschreibt Schritt für Schritt, wie Sie die **WidowX-250s Simulationsumgebung** im Docker Container ausführen und nutzen.

---

## 📋 Übersicht

Der Docker-Container beinhaltet:  
- **ROS 2 Humble** auf Ubuntu 22.04 LTS.  
- **Interbotix ROS 2 Packages** für den WidowX-250s (`wx250s`).  
- **Gazebo & RViz2** zur physikalischen und visuellen Roboterarm-Simulation.  
- **noVNC Web-Oberfläche** zur Betrachtung der GUI im Browser ohne lokale Display-Konfiguration.  

---

## 🚀 Schritt-für-Schritt Anleitung

### 1. Navigieren in das Docker-Verzeichnis

```bash
cd praktikum/widowx250s/docker_container
```

### 2. Container bauen und starten

Führen Sie folgenden Befehl aus, um den Container zu bauen und zu starten:

```bash
docker compose up --build
```

> **Hinweis beim ersten Start:** Das Erstellen des Docker-Images kann je nach Internetverbindung einige Minuten dauern, da ROS 2 Pakete und Interbotix-Software kompiliert werden.

### 3. Simulation im Webbrowser öffnen

Öffnen Sie Ihren bevorzugten Browser und rufen Sie die Adresse auf:

[http://localhost:8080](http://localhost:8080)

Klicken Sie auf **Connect**. Sie sehen die Linux-Desktopoberfläche mit dem bereits gestarteten Gazebo/RViz Fenster für den WidowX-250s Roboterarm.

---

## 💻 Interaktive Befehle im Container ausführen

Öffnen Sie ein neues Terminal auf Ihrem Host-System und verbinden Sie sich mit dem laufenden Container:

```bash
docker exec -it widowx250s_simulation bash
```

### Python-Skripte im Container testen

Im Container sind alle ROS 2 Umgebungsvariablen vorkonfiguriert. Sie können direkt Python-Skripte ausführen, die mit der `InterbotixManipulatorXS` API kommunizieren:

```bash
python3 -c "
from interbotix_xs_modules.xs_arm import InterbotixManipulatorXS
bot = InterbotixManipulatorXS('wx250s', 'arm', 'gripper')
bot.arm.go_to_home_pose()
"
```

---

## 🛑 Container stoppen

Um den Container zu beenden, drücken Sie `Ctrl+C` im Terminal von `docker compose` oder führen Sie aus:

```bash
docker compose down
```
