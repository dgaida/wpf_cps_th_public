# Nutzung der Docker-Simulationsumgebung (`docker_container/`)

Diese Anleitung beschreibt Schritt für Schritt, wie Sie die **WidowX-250s Treiber-Simulationsumgebung** im Docker-Container nutzen und darin das Interbotix Python SDK gefahrlos erproben.

---

## 📋 Übersicht & Eigenschaften

Der Container `docker_container/` stellt eine reine **Treiber- und RViz-Simulation** bereit:  
- **ROS 2 Treiber-Simulation**: Startet `xsarm_control.launch.py` mit `use_sim:=true`. Der Simulated Hardware Node (`xs_sdk`) stellt alle ROS 2 Services bereit.  
- **Python SDK Kompatibilität**: Vollständige Unterstützung der `InterbotixManipulatorXS` API (aus `interbotix_xs_modules`).  
- **Visualisierung**: RViz2 wird über eine **noVNC Web-Oberfläche** (Port `8080`) im Browser gerendert.  
- **Entwicklungsumgebung**: Integriertes **JupyterLab** (Port `8888`), das auf die Notebooks und Quellcodes im Repository zugreift.  

---

## 📌 Einstiegsaufgabe: Interbotix SDK gefahrlos im Simulator testen

Verwenden Sie diesen Container als Trockenübung ("Dry-Run"), um die Ansteuerung mit `InterbotixManipulatorXS` aus **Teil 1** kennenzulernen, bevor Sie mit dem physischen Roboterarm im Labor arbeiten.

### Aufgabenstellung

1. **Simulationsumgebung starten**:  
   ```bash
   cd praktikum/widowx250s/docker_container
   docker compose up --build
   ```

2. **Visualisierung und JupyterLab öffnen**:  
   - 🖥️ **noVNC GUI**: Rufen Sie [http://localhost:8080](http://localhost:8080) im Browser auf, um das RViz2-Fenster mit dem WidowX-250s Modell zu sehen.  
   - 📓 **JupyterLab**: Rufen Sie [http://localhost:8888/lab](http://localhost:8888/lab) auf und öffnen Sie das Notebook `1-widowx250s_erste_schritte.ipynb`.  

3. **Steuerungsbefehle im Simulator ausführen**:  
   Führen Sie im Notebook `1-widowx250s_erste_schritte.ipynb` (oder in einem eigenen Python-Skript im Container via `docker exec -it widowx250s_simulation bash`) folgende Aktionen aus und beobachten Sie die Bewegungen in RViz:  
   - Initialisieren Sie das Roboterobjekt:  
     ```python
     from interbotix_xs_modules.xs_arm import InterbotixManipulatorXS
     bot = InterbotixManipulatorXS("wx250s", "arm", "gripper")
     ```
   - Fahren Sie die Home-Position an: `bot.arm.go_to_home_pose()`  
   - Testen Sie Einzelgelenksbewegungen mit `bot.arm.set_single_joint_position("waist", 0.5)`  
   - Testen Sie kartesische Zielkoordinaten mit `bot.arm.set_ee_pose_components(x=0.3, z=0.2, pitch=0.5)`  
   - Öffnen und schließen Sie den Greifer: `bot.gripper.release()` und `bot.gripper.grasp()`  
   - Parken Sie den Arm in der Ruheposition: `bot.arm.go_to_sleep_pose()`  

---

## 💻 Interaktive Befehle im Container ausführen

Sie können sich auch über ein Terminal direkt mit dem laufenden Container verbinden:

```bash
docker exec -it widowx250s_simulation bash
```

Einzeiler zum Schnelltest:
```bash
python3 -c "
from interbotix_xs_modules.xs_arm import InterbotixManipulatorXS
bot = InterbotixManipulatorXS('wx250s', 'arm', 'gripper')
bot.arm.go_to_home_pose()
bot.arm.go_to_sleep_pose()
"
```

---

## 🛑 Container stoppen

Um den Container zu beenden, drücken Sie `Ctrl+C` im Terminal von `docker compose` oder führen Sie aus:

```bash
docker compose down
```
