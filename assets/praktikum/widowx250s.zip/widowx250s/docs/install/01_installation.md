# Installation & Systemanforderungen: WidowX-250s Roboterarm

Diese Anleitung beschreibt die Einrichtung der Entwicklungsumgebung für das Praktikum mit dem **WidowX-250s Roboterarm (6DOF)**.

---

## 📋 Systemvoraussetzungen

- **Betriebssystem:** Ubuntu 20.04 LTS (für ROS 2 Galactic auf dem Nvidia Jetson) oder Ubuntu 22.04 LTS (für ROS 2 Humble im Docker Container / Host).  
- **ROS 2 Version:** ROS 2 Galactic (auf dem Nvidia Jetson des WidowX-250s) bzw. ROS 2 Humble (im Docker Container / Host).  
- **Python Version:** Python 3.10 oder 3.11.  

---

## 🐍 1. Python-Umgebung einrichten (auf dem Jetson / ROS 2 System)

Auf dem Jetson sind ROS 2 und die ROS 2 Pakete (`rclpy`, `control_msgs`, `trajectory_msgs`, `sensor_msgs`) systemweit unter `/opt/ros/$ROS_DISTRO/` installiert.

### Option A: Mit Conda (Empfohlen)

Die mitgelieferte `environment.yml` installiert `python`, `numpy`, `jupyter` und `ipykernel`.

```bash
# 1. Conda-Umgebung aus environment.yml erstellen
conda env create -f environment.yml

# 2. Umgebung aktivieren
conda activate widowx250s

# 3. Einbindung der ROS 2 System-Pakete (rclpy, control_msgs etc.) in Conda:
# Sourcing von ROS 2 lädt die System-Pfade in PYTHONPATH:
source /opt/ros/$ROS_DISTRO/setup.bash

# Alternativ: ROS 2 site-packages direkt per .pth-Datei in die Conda-Umgebung verlinken:
echo "/opt/ros/$ROS_DISTRO/lib/python3.*/site-packages" > $CONDA_PREFIX/lib/python3.*/site-packages/ros2.pth
```

### Option B: Mit pip und Virtual Environment (venv)

```bash
# 1. Virtuelle Umgebung erstellen
python3 -m venv venv --system-site-packages

# 2. Virtuelle Umgebung aktivieren
source venv/bin/activate

# 3. Abhängigkeiten installieren
pip install -r requirements.txt

# 4. ROS 2 Umgebung sourcen
source /opt/ros/$ROS_DISTRO/setup.bash
```

---

## 🤖 2. ROS 2 & Interbotix XS Driver Installation

Für die Ansteuerung des realen Roboterarms oder der lokalen Simulation wird der **Interbotix ROS 2 Packages Stack** benötigt.

### A) Interbotix ROS 2 Installation Script

Interbotix bietet ein automatisiertes Installationsskript für ROS 2 Galactic an:

```bash
curl 'https://raw.githubusercontent.com/Interbotix/interbotix_ros_toolboxes/main/interbotix_xs_ros_control/file/xsarm_amd64_install.sh' > xsarm_amd64_install.sh
chmod +x xsarm_amd64_install.sh
./xsarm_amd64_install.sh -d galactic
```

### B) Interbotix Python SDK (`interbotix_xs_modules`)

Die Python-Klassen zur Ansteuerung (`InterbotixManipulatorXS`) werden im Zuge der ROS 2 Interbotix Stack Installation im Python-Pfad registriert.

Prüfen Sie die Installation in Python:

```python
from interbotix_xs_modules.xs_arm import InterbotixManipulatorXS
print("Interbotix SDK erfolgreich installiert!")
```

---

## 🐳 Alternative: Docker Container

Falls kein physisches Linux mit ROS 2 Galactic / Humble bereitsteht, nutzen Sie den mitgelieferten Docker Container.
Details hierzu finden Sie in der Anleitung [`02_docker_container.md`](../02_docker_container.md).
