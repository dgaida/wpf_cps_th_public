# Installation & Einrichtung der Intel RealSense Kamera & Interbotix Perception Stack

Diese Anleitung beschreibt die vollständige Installation und Einrichtung der **Intel RealSense SDK 2.0 (`librealsense2`)**, der ROS 2 Perception Pakete sowie der Interbotix Perception Repositories unter Ubuntu (20.04 / 22.04 LTS).

---

## 📋 Systemvoraussetzungen & Übersicht

Für das Tracking mit der Intel RealSense Kamera (z. B. Modell D415 oder D435) und dem Interbotix Perception Stack werden folgende Komponenten benötigt:  
- **Betriebssystem:** Ubuntu 20.04 LTS (Nvidia Jetson / ROS 2 Galactic) oder Ubuntu 22.04 LTS (ROS 2 Humble im Docker Container).  
- **Intel RealSense SDK 2.0 (`librealsense2`)**: Kernelmodule und Utilities.  
- **ROS 2 Perception & AprilTag Pakete**: `realsense2-camera`, `apriltag-ros`, `pcl-ros`, `image-proc`.  
- **Interbotix ROS Workspaces**: Packages `interbotix_xsarm_perception` und `interbotix_perception_modules`.  
- **Python-Bibliotheken:** `pyrealsense2`, `opencv-python`, `pillow`, `modern_robotics`, `pyyaml`, `numpy`.  

---

## 🛠️ 1. Intel RealSense SDK 2.0 & ROS 2 Kamera-Treiber

Registrieren Sie den GPG-Schlüssel von Intel, fügen Sie das Debian-Repository hinzu und installieren Sie die Treiber-Pakete:

```bash
# 1. GPG-Schlüssel und Intel Repository hinzufügen
sudo mkdir -p /etc/apt/keyrings
curl -sSf https://librealsense.intel.com/Debian/librealsense.pgp | sudo tee /etc/apt/keyrings/librealsense.pgp > /dev/null
echo "deb [signed-by=/etc/apt/keyrings/librealsense.pgp] https://librealsense.intel.com/Debian/apt-repo $(lsb_release -cs) main" | sudo tee /etc/apt/sources.list.d/librealsense.list
sudo apt-get update

# 2. RealSense SDK & Utilities installieren
sudo apt-get install -y librealsense2-dkms librealsense2-utils librealsense2-dev

# 3. ROS 2 RealSense Kamera-Treiber (z. B. für ROS 2 Galactic)
sudo apt-get install -y ros-galactic-realsense2-camera
```

> **Tipp zur Diagnose:** Mit dem Befehl `realsense-viewer` im Terminal können Sie testen, ob die angeschlossene Kamera vom System erkannt wird und Farbbild- sowie Tiefenbildstreams liefert.

---

## 📦 2. ROS 2 Perception, AprilTag & PCL Pakete

Installieren Sie die benötigten ROS 2 Bildverarbeitungs- und Punktwolkenpakete:

```bash
sudo apt-get update && sudo apt-get install -y \
    ros-galactic-apriltag-ros \
    ros-galactic-apriltag \
    ros-galactic-image-proc \
    ros-galactic-pcl-ros \
    ros-galactic-pcl-conversions \
    ros-galactic-rtabmap-ros \
    ros-galactic-rviz2 \
    ros-galactic-rviz-default-plugins
```

---

## 🤖 3. Interbotix ROS 2 Workspace Repositories

Klonen Sie die Interbotix ROS 2 Repositories in Ihren Workspace (`~/interbotix_ws/src`), installieren Sie Abhängigkeiten und kompilieren Sie die Pakete:

```bash
cd ~/interbotix_ws/src
git clone -b galactic https://github.com/Interbotix/interbotix_ros_core.git
git clone -b galactic https://github.com/Interbotix/interbotix_ros_manipulators.git
git clone -b galactic https://github.com/Interbotix/interbotix_ros_toolboxes.git

cd ~/interbotix_ws
rosdep update && rosdep install --from-paths src --ignore-src -r -y
colcon build --symlink-install
source install/setup.bash
```

---

## 🐍 4. Python-Abhängigkeiten installieren

Installieren Sie die Python-Schnittstelle `pyrealsense2` sowie weitere Bildverarbeitungs-Bibliotheken in Ihrer aktiviertem Python-Umgebung:

```bash
pip install pyrealsense2 opencv-python pillow modern_robotics pyyaml numpy
```

---

## 🔍 Funktionsprüfung in Python

Prüfen Sie nach der Installation in der Python-Konsole, ob `pyrealsense2` geladen werden kann:

```python
import pyrealsense2 as rs
print("pyrealsense2 Version:", rs.__version__)
```
