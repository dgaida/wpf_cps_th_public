# Fehlerbehebung: RealSense Pointcloud & Color-Stream Frame Drops

In der Roboter-Perception-Pipeline mit dem WidowX-250s und einer Intel RealSense Tiefenkamera (z. B. D435) kann ein Problem auftreten, bei dem der Farbbild-Stream (`/camera/color/image_raw`) und die Kamerainformationen (`/camera/color/camera_info`) fehlen oder nicht publiziert werden. Infolgedessen kann das AprilTag/ArmTag nicht erkannt werden und die Punktwolke bleibt leer.

---

## 🐛 Problembeschreibung

Beim Starten von `xsarm_perception.launch.py` wird intern der ROS 2 Kamera-Treiber (`rs_launch.py` / `realsense2_camera`) gestartet. Der entscheidende Unterschied zu normalen Kamera-Starts ist, dass dabei die Punktwolke aktiviert ist (`pointcloud.enable: true`).

Wenn die Punktwolkenberechnung aktiv ist, leitet der ROS 2 Treiber `realsense2_camera` (v4.51.1) alle Frames durch einen internen Synchronisierer (Syncer). Bei der Standard-Tieffenauflösung von **640×480** benötigt die Berechnung der Punktwolke auf dem eingebetteten Steuerungsrechner (z. B. Nvidia Jetson Orin) etwa 50 ms pro Frame.

Dadurch wird der Verarbeitungs-Thread auf ca. 15 Hz abgebremst. In der Folge werden fast alle Farbbilder (Color-Frames) verworfen. Im Debug-Log enthielten beispielsweise nur 12 von ca. 420 Framesets ein Farbbild. Der Kamera-Node publiziert daher weder `/camera/color/image_raw` noch `/camera/color/camera_info`, womit auch das AprilTag-Tracking nicht funktioniert und die Punktwolke leer bleibt.

---

## 📊 Messergebnisse (Vergleich der Konfigurationen)

Bei einer Testmessung (nur Kamera, alle ROS 2 Topics gleichzeitig über 20 Sekunden abonniert) ergaben sich folgende Frame-Raten:

| Konfiguration | `color_info` | `color_img` | `depth` | `points` |
| --- | --- | --- | --- | --- |
| **Interbotix-Default** (Depth 640×480, Pointcloud an) | 0 | 0 | 222 | 0 |
| **zusätzlich `enable_sync:=true`** | 0 | 0 | 222 | 0 |
| **Beide Profile auf 15 fps** | 0 | 0 | 222 | 0 |
| **Depth 424×240×30** (`rs_camera_depth_module_profile`) | **525** | **456** | **266** | **234** |
| **`decimation_filter.enable:=true`** | 525 | 418 | 266 | 234 |

*Hinweis:* Ohne aktive Punktwolke läuft der Color-Stream auch bei 640×480 problemlos.

---

## 💡 Lösung

Da das Skript `3-widowx250s_realsense_qr_tracking.py` sowohl den Color-Stream für das ArmTag (`InterbotixArmTagInterface`) als auch die Punktwolke für die Objekterkennung (`InterbotixPointCloudInterface`) benötigt, kann die Punktwolke nicht einfach komplett deaktiviert werden.

Die Lösung besteht darin, die Auflösung des Tiefenmoduls über den ROS 2 Launch-Parameter `rs_camera_depth_module_profile` auf **424×240×30** zu reduzieren:

```bash
ros2 launch interbotix_xsarm_perception xsarm_perception.launch.py robot_model:=wx250s \
    rs_camera_depth_module_profile:=424x240x30
```

### Warum funktioniert diese Lösung?  
- Der Farbbild-Stream bleibt bei **640×480**, sodass AprilTags / ArmTags weiterhin in hoher Auflösung und mit hoher Genauigkeit erkannt werden.  
- Die reduzierte Auflösung des Tiefenmoduls (424×240) verringert die Rechenlast der Punktwolkenberechnung drastisch. Der Syncer blockiert den Thread nicht mehr, Farbbilder werden stabil publiziert und für die 3D-Cluster-Erkennung reicht die gröbere Punktwolke völlig aus.  
