# Vergleich der Docker-Simulationsumgebungen für WidowX-250s

Dieses Dokument bietet einen strukturieren Vergleich der drei im Praktikum angebotenen Docker-Umgebungen für den **WidowX-250s Roboterarm (6DOF)**.

---

## 📊 Übersichtstabelle

| Parameter / Eigenschaft | `docker_container/` | `docker_container_gz/` | `docker_container_gz_cam/` *(in Entwicklung)* |
|-------------------------|---------------------|------------------------|-----------------------------------------------|
| **Hauptzweck** | SDK-Einstieg & Treiber-Simulation | Physiksimulation & MoveIt Trajektorien | Physiksimulation mit Overhead-Kamera |
| **ROS 2 Launchfile** | `xsarm_control.launch.py use_sim:=true` | `xsarm_moveit.launch.py hardware_type:=gz_classic` | `xsarm_moveit.launch.py world_filepath:=...` |
| **GUI & Visualisierung** | RViz2 (via noVNC) | Gazebo Classic + RViz2 (via noVNC) | Gazebo Classic + RViz2 (via noVNC) |
| **Simulationswelt** | Keine Physikwelt (nur Robotermodell) | `wx250s_blocks.world` (Tisch + 4 Blöcke) | `wx250s_pickplace.world` (Tisch + Blöcke + Kamera) |
| **Physik & Kollisionen** | ❌ Nein (reine Kinematik) | ✅ Ja (Masse, Gravitation, Reibung) | ✅ Ja (Masse, Gravitation, Reibung) |
| **Kamerasensor** | ❌ Nein | ❌ Nein | ⚠️ Ja (Gazebo ROS Camera Plugin) |
| **Python API** | `InterbotixManipulatorXS` | ROS 2 Action-Clients (`FollowJointTrajectory`) | ROS 2 Action-Clients + ROS Image Topic |
| **noVNC Port** | `8080` | `8081` | `8082` |
| **JupyterLab Port** | `8888` | `8889` | `8890` |
| **Entwicklungsstatus** | ✅ Voll einsatzfähig | ✅ Voll einsatzfähig | ⚠️ Experimentell / In Entwicklung |
| **Praktikumsbezug** | [Teil 1 Trockenübung](./02_docker_container.md) | [Teil 2 Gazebo & MoveIt](./02_aufgabe_gazebo_moveit.md) | Fortgeschrittene Sim-Entwicklung |

---

## 🔍 Detaillierte Analyse der einzelnen Umgebungen

### 1️⃣ `docker_container/` — Treiber- & RViz-Simulation (SDK-Einstieg)

- **Eigenschaften & Funktionsweise**:  
  Startet den Interbotix-Treiber-Node (`xs_sdk`) im Simulationsmodus (`use_sim:=true`). Die Gelenke werden ohne Physikberechnung direkt in RViz2 gerendert.  
- **Python API Support**:  
  Unterstützt zu 100 % die offizielle Interbotix-Highlevel-API `InterbotixManipulatorXS` (`interbotix_xs_modules`).  
- **Vorteile**:  
  - Sehr ressourcenschonend und schnell beim Starten.  
  - Vollständige Code-Kompatibilität zum realen Roboterarm im Labor.  
  - Ideal zum gefahrlosen Erlernen der Befehle (`go_to_home_pose()`, `set_ee_pose_components()`, `grasp()`).  
- **Nachteile**:  
  - Keine Physik simulation (keine Gravitation, keine Kollisionen mit Umgebungsobjekten, kein realistisches Greifen von Würfeln).  
- **Hauptanwendungsfall**:  
  Einstieg in Praktikum **Teil 1** ohne Zugriff auf die reale Hardware.

---

### 2️⃣ `docker_container_gz/` — Gazebo Physiksimulation + MoveIt 2

- **Eigenschaften & Funktionsweise**:  
  Nutzt **Gazebo Classic** als Physik-Engine und **MoveIt 2** zur Pfadplanung. Der Roboter befindet sich in der Welt `wx250s_blocks.world` vor einem Tisch mit vier farbigen Blöcken.  
- **Python API Support**:  
  Da kein `xs_sdk`-Node läuft, wird der Arm über das direkte ROS 2 Action-Interface (`FollowJointTrajectory` auf `/wx250s/arm_controller` und `/wx250s/gripper_controller`) gesteuert.  
- **Vorteile**:  
  - Realistische Physikberechnung (Masse, Trägheit, Gravitation und Reibung beim Greifen).  
  - Interaktives Positionieren des Endeffektors in RViz über MoveIt-Marker (Drag & Drop + *Plan & Execute*).  
  - Auslesen der realen Gelenkstellungen über `/wx250s/joint_states` für "Teach & Repeat" Pick-and-Place.  
- **Nachteile**:  
  - Höhere CPU- / RAM-Auslastung als reine RViz-Simulationen.  
  - Code aus Teil 1 (`InterbotixManipulatorXS`) kann nicht direkt wiederverwendet werden.  
- **Hauptanwendungsfall**:  
  Praktikum **Teil 2** (Physikbasiertes Pick-and-Place und Trajektoriensteuerung).

---

### 3️⃣ `docker_container_gz_cam/` — Gazebo Classic + MoveIt 2 + Overhead-Kamera (Experimentell)

- **Eigenschaften & Funktionsweise**:  
  Erweitert `docker_container_gz/` um ein virtuelles Gazebo ROS Kamera-Plugin (`/overhead_camera/image_raw`), das ein RGB-Videobild des Arbeitsbereichs von oben bereitstellt.  
- **Aktueller Entwicklungsstatus**:  
  **Experimentell / In Entwicklung**. Unter reinen Headless-Docker-Setups (Xvfb mit Software-Rasterizer ohne GPU-Passthrough) kann das Kamera-Plugin kein volatiles 3D-Rendering erzeugen oder liefert leere Bilder. Daher ist dieser Container aktuell nicht im öffentlichen Praktikums-Zip-Paket (`widowx250s.zip`) enthalten.  
- **Vorteile (Ziel)**:  
  - Ermöglicht künftige visuelle Objekterkennungs-Aufgaben (z. B. Farbsegmentierung von Würfeln) vollständig in der Simulation, ohne reale RealSense-Kamera.  
- **Nachteile**:  
  - Hohe Rechenlast und Abhängigkeit von GPU-OpenGL-Treibern im Container.  

---

## 💡 Entscheidungshilfe: Welche Umgebung soll verwendet werden?

1. **Für Teil 1 (Erste Schritte & Interbotix Python SDK)**:  
   👉 Nutzen Sie **`docker_container/`**, falls keine physische Hardware zur Verfügung steht.  
2. **Für Teil 2 (Gazebo, MoveIt & Teach-and-Repeat)**:  
   👉 Nutzen Sie **`docker_container_gz/`** zum Greifen der Blöcke in der Physikwelt.  
3. **Für Teil 3 (RealSense Kamera, AprilTags & Perception Stack)**:  
   👉 Arbeiten Sie direkt auf dem **Jetson-Laborrechner** mit der realen RealSense D435 Tiefenkamera.
