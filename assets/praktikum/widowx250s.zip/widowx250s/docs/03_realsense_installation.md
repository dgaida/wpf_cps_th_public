# Installation & Einrichtung der Intel RealSense Kamera

Diese Anleitung beschreibt die Installation und Einrichtung der **Intel RealSense SDK 2.0 (`librealsense2`)** sowie der zugehörigen Python-Anbindungen unter Ubuntu (20.04 / 22.04 LTS).

---

## 📋 Systemvoraussetzungen & Übersicht

Für das Tracking mit der Intel RealSense Kamera (z. B. Modell D415 oder D435) werden folgende Komponenten benötigt:  
- **Betriebssystem:** Ubuntu 20.04 / 22.04 LTS  
- **Intel RealSense SDK 2.0 (`librealsense2`)**: Kernelmodule und Bibliotheken  
- **Python-Bibliotheken:** `pyrealsense2`, `opencv-python`  

---

## 🛠️ Schritt 1: Intel RealSense APT-Repository hinzufügen

Registrieren Sie den GPG-Schlüssel von Intel und fügen Sie das Debian-Repository zu den Systempaketquellen hinzu:

```bash
# 1. GPG-Schlüssel des Intel RealSense Repositories registrieren
sudo mkdir -p /etc/apt/keyrings
curl -sSf https://librealsense.intel.com/Debian/librealsense.pgp | sudo tee /etc/apt/keyrings/librealsense.pgp > /dev/null

# 2. Repository zur APT-Quellenliste hinzufügen
echo "deb [signed-by=/etc/apt/keyrings/librealsense.pgp] https://librealsense.intel.com/Debian/apt-repo $(lsb_release -cs) main" | sudo tee /etc/apt/sources.list.d/librealsense.list
sudo apt-get update
```

---

## 📦 Schritt 2: Intel RealSense Pakete installieren

Installieren Sie die DKMS-Kernelmodule, Utility-Tools und Entwicklerpakete:

```bash
sudo apt-get install -y librealsense2-dkms librealsense2-utils librealsense2-dev
```

> **Tipp zur Diagnose:** Mit dem Befehl `realsense-viewer` im Terminal können Sie testen, ob die angeschlossene Kamera vom System erkannt wird und Farbbild- sowie Tiefenbildstreams liefert.

---

## 🐍 Schritt 3: Python-Pakete installieren

Installieren Sie die Python-Schnittstelle `pyrealsense2` sowie `opencv-python` in Ihrer aktivierten Python-Umgebung:

```bash
pip install pyrealsense2 opencv-python pillow
```

---

## 🔍 Funktionsprüfung in Python

Prüfen Sie nach der Installation in der Python-Konsole, ob `pyrealsense2` geladen werden kann:

```python
import pyrealsense2 as rs
print("pyrealsense2 Version:", rs.__version__)
```
