# Docker-Container für WidowX-250s-Simulation – Gazebo + MoveIt Variante (ROS 2 Humble)

Dieses Verzeichnis ist die **zweite Variante** des WidowX-250s-Docker-Setups: Sie nutzt eine echte **Gazebo-Physiksimulation** (Kollisionen, Schwerkraft) zusammen mit **MoveIt** (Motion Planning).

Eine ausführliche Erklärung aller Dateien und der Unterschiede zur anderen Variante (`docker_container/`) findest du in [`DOCKER_SETUP_GZ.md`](./DOCKER_SETUP_GZ.md).

---

## Welche Variante soll ich nutzen?

| | `docker_container/` (xs_sdk-Simulation) | `docker_container_gz/` (diese Variante) |
|---|---|---|
| Physik-Simulation (Gazebo) | ❌ | ✅ |
| Visualisierung | RViz (kinematisch) | Gazebo + RViz/MoveIt |
| Steuerung über `InterbotixManipulatorXS` (Python) | ✅ | ❌ (nicht kompatibel) |
| Steuerung über `FollowJointTrajectory` (Python) | ❌ | ✅ |
| Steuerung ganz ohne Code (Drag & Drop in RViz) | ❌ | ✅ (MoveIt-Interaktivmarker) |
| Empfohlen für | Einstieg in die Interbotix-Python-API, echtes Roboterverhalten nachbilden | Motion Planning, Kollisionsvermeidung, realistischere Physik |

Beide Varianten können parallel installiert sein (unterschiedliche Ports, unterschiedliche Container-Namen) – Studierende entscheiden selbst, welche sie nutzen.

---

## 🛠️ Voraussetzungen

Wie in der Basis-Variante: Docker Engine (≥ 20.10) und Docker Compose (≥ 2.0). Siehe [`docker_container/README.md`](../docker_container/README.md) für Installationslinks.

---

## 📁 Projektstruktur

```
projekt/
├── 1-widowx250s_erste_schritte.ipynb       # Notebook für docker_container/ (xs_sdk)
├── 2-widowx250s_gazebo_moveit.ipynb        # Notebook für docker_container_gz/ (diese Variante)
├── src/
│   └── widowx_pick_and_place.py
├── docker_container/                       # Variante 1: xs_sdk-Simulation
└── docker_container_gz/                    # Variante 2: Gazebo + MoveIt (diese hier)
    ├── Dockerfile
    ├── docker-compose.yml
    ├── supervisord.conf
    ├── README.md
    └── DOCKER_SETUP_GZ.md
```

---

## 🚀 Schnellstart

```bash
cd docker_container_gz
docker compose up --build
```

- **MoveIt / RViz2 (Browser-GUI):** [http://localhost:8081](http://localhost:8081)  
- **JupyterLab:** [http://localhost:8889/lab](http://localhost:8889/lab)  

> Beachte die abweichenden Ports (8081/8889 statt 8080/8888) – so kollidiert diese Variante nicht mit einer parallel laufenden `docker_container/`-Instanz.

Im Browser unter Port 8081 siehst du die RViz2-Oberfläche mit dem MoveIt-"Motion Planning"-Panel und dem 3D-Modell des Roboterarms. Die Physikberechnung (`gzserver`) läuft im Hintergrund. Die Interaktion erfolgt komfortabel über RViz (Drag & Drop Interaktivmarker für Endeffektor) oder programmatisch via Python.

Für die programmatische Steuerung öffne in JupyterLab das Notebook `2-widowx250s_gazebo_moveit.ipynb`.

---

## 💻 Steuerung aus dem Container heraus (Terminal)

```bash
docker exec -it widowx250s_simulation_gz bash
```

### Manuelles Starten der Simulation (falls nötig)

```bash
ros2 launch interbotix_xsarm_moveit xsarm_moveit.launch.py robot_model:=wx250s hardware_type:=gz_classic
```

---

## 🧯 Troubleshooting

Siehe [`DOCKER_SETUP_GZ.md`](./DOCKER_SETUP_GZ.md#troubleshooting) sowie die allgemeine Troubleshooting-Tabelle in [`docker_container/DOCKER_SETUP.md`](../docker_container/DOCKER_SETUP.md#bekannte-stolpersteine--troubleshooting) (viele Build-Fehler betreffen beide Varianten gleichermaßen, da beide denselben Workspace bauen).
