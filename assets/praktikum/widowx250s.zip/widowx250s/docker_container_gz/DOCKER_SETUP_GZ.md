# Docker-Setup im Detail – Gazebo + MoveIt Variante

Diese Datei ergänzt [`docker_container/DOCKER_SETUP.md`](../docker_container/DOCKER_SETUP.md) um die Besonderheiten dieser Variante. Grundlagen (Zweck von `docker-compose.yml`, `Dockerfile`-Aufbau, `supervisord`-Prinzip) werden dort ausführlich erklärt und hier nicht wiederholt.

---

## Architektur-Entscheidung: Warum nicht `interbotix_xsarm_ros_control`?

Ursprünglich war angedacht, für die Kombination "Gazebo-Physik + `InterbotixManipulatorXS`-Python-API" das Paket `interbotix_xsarm_ros_control` zu nutzen. Ein genauerer Blick in die offizielle Interbotix-Dokumentation zeigt jedoch: Dieses Paket bridged `FollowJointTrajectory`-Kommandos (typischerweise von MoveIt) **direkt mit dem `xs_sdk`-Node** – also mit echter oder simulierter (Fake-Modus, ohne Physik) **Hardware**, nicht mit Gazebo. Es gibt in der offiziellen Interbotix-Toolchain **keine** dokumentierte Brücke, die `xs_sdk`-Services mit einer laufenden Gazebo-Physiksimulation verbindet.

Der offiziell dokumentierte, unterstützte Weg zu einer echten Gazebo-Physiksimulation ist stattdessen:

```
ros2 launch interbotix_xsarm_moveit xsarm_moveit.launch.py robot_model:=wx250s hardware_type:=gz_classic
```

Dieses eine Launch-File aus dem Paket `interbotix_xsarm_moveit` startet:  
- **Gazebo Classic** (über das darunterliegende `interbotix_xsarm_sim`-Paket, inkl. `gazebo_ros2_control` und Controllern wie `arm_controller`/`gripper_controller`)  
- **MoveIt 2** (`move_group`-Node für Motion Planning)  
- **RViz2** mit dem MoveIt-"Motion Planning"-Plugin  

**Konsequenz für die Steuerung:** Da hier kein `xs_sdk`-Node läuft, funktioniert `InterbotixManipulatorXS` (aus `interbotix_xs_modules`) **nicht**. Stattdessen wird direkt über das `FollowJointTrajectory`-Action-Interface gesteuert – entweder programmatisch (siehe Notebook `2-widowx250s_gazebo_moveit.ipynb`) oder komplett ohne Code über die interaktiven Marker in RViz.

---

## Unterschiede zu `docker_container/` im Detail

### `Dockerfile`
**Inhaltlich identisch** zur Basis-Variante. Der Grund: Der `colcon build`-Schritt baut bereits den **kompletten** Workspace, inklusive `interbotix_xsarm_sim` (Gazebo) und `interbotix_xsarm_moveit` – unabhängig davon, welche Variante später tatsächlich genutzt wird. Ein separates Image wäre also nicht nötig gewesen; es existiert trotzdem als eigene Kopie in `docker_container_gz/`, damit beide Varianten als vollständig unabhängige, in sich geschlossene Projekte funktionieren (kein gemeinsamer Build-Kontext, den Studierende verstehen müssten).

### `docker-compose.yml`
Drei Unterschiede zur Basis-Variante:  
1. **Service-/Container-Name:** `widowx250s_simulation_gz` statt `widowx250s_simulation` – verhindert Namenskonflikte, falls beide Varianten gleichzeitig laufen sollen.  
2. **Ports:** `8081` (statt `8080`) für noVNC und `8889` (statt `8888`) für JupyterLab – aus demselben Grund.  
3. **Volume:** mountet `2-widowx250s_gazebo_moveit.ipynb` statt `1-widowx250s_erste_schritte.ipynb`, da dieses Notebook das zur Gazebo-Variante passende Steuerungsbeispiel (`FollowJointTrajectory` statt `InterbotixManipulatorXS`) enthält. Der `src/`-Ordner wird weiterhin geteilt genutzt.  

### `supervisord.conf`
Nur das `[program:ros]`-Kommando unterscheidet sich:

```ini
command=/bin/bash -c "source /opt/ros/humble/setup.bash && source /root/interbotix_ws/install/setup.bash && ros2 launch interbotix_xsarm_moveit xsarm_moveit.launch.py robot_model:=wx250s hardware_type:=gz_classic"
```

Alle anderen Programme (`xvfb`, `fluxbox`, `x11vnc`, `novnc`, `jupyter`) sind unverändert – sie kümmern sich um die Browser-GUI-Bereitstellung bzw. JupyterLab und sind unabhängig davon, welche ROS-2-Simulation im `ros`-Programm läuft.

---

## Notebook `2-widowx250s_gazebo_moveit.ipynb`

Statt `InterbotixManipulatorXS` verwendet dieses Notebook einen `rclpy`-`ActionClient`, der direkt mit den `FollowJointTrajectory`-Action-Servern der Controller spricht:

- Arm: `/wx250s/arm_controller/follow_joint_trajectory`  
- Greifer: `/wx250s/gripper_controller/follow_joint_trajectory`  

Das ist bewusst low-level gehalten (keine Umkehrkinematik, keine Kollisionsprüfung – reine Gelenkwinkel-Trajektorien) und eignet sich daher besonders gut, um Studierenden zu zeigen, *wie* MoveIt/`ros2_control` unter der Haube tatsächlich kommunizieren. Für Motion Planning mit Umkehrkinematik und Kollisionsvermeidung ist die MoveIt-RViz-Oberfläche (Drag & Drop) der einfachere Einstieg; eine vollständige Python-Anbindung an MoveIts Planungspipeline (`moveit_py`) wäre ein möglicher nächster Ausbauschritt, ist aber deutlich aufwändiger einzurichten und hier nicht enthalten.

> **Hinweis zu den Gelenknamen des Greifers:** Je nach genauer MoveIt-/`ros2_control`-Konfiguration kann der Gripper-Controller einen anderen Joint-Namen als `"gripper"` erwarten (z. B. bei Mimic-Joint-Setups). Prüfe im Zweifel im Container mit `ros2 control list_controllers` bzw. `ros2 control list_hardware_interfaces`, welche Joint-Namen tatsächlich erwartet werden, und passe die entsprechende Codezelle im Notebook an.

---

## Troubleshooting

Da diese Variante denselben Workspace baut wie `docker_container/`, gelten **alle** Build-bezogenen Einträge aus der [Troubleshooting-Tabelle dort](../docker_container/DOCKER_SETUP.md#bekannte-stolpersteine--troubleshooting) unverändert (z. B. `--symlink-install`-Konsistenz, `interbotix_xs_driver`-Branch, Slate-/`catkin`-Pakete überspringen, `tornado`-Pin für JupyterLab).

Zusätzlich, spezifisch für diese Variante:

| Fehler / Symptom | Ursache | Lösung |
|---|---|---|
| `InterbotixManipulatorXS(...)` hängt beim Verbinden bzw. wirft Service-Timeout-Fehler | Es läuft kein `xs_sdk`-Node in dieser Variante. | `InterbotixManipulatorXS` hier nicht verwenden – stattdessen `FollowJointTrajectory` (siehe Notebook) oder die MoveIt-RViz-Oberfläche nutzen. |
| Gazebo startet, aber `move_group`/MoveIt lädt nie fertig bzw. der Arm reagiert nicht | Gazebo-Physik ist standardmäßig pausiert (ähnlich wie in der ROS-1-Variante), bis die Controller vollständig geladen sind. | Kurz warten, bis in den Logs `Configured and activated arm_controller` erscheint, bevor Planungsanfragen gesendet werden. |
| Port-Konflikt beim gleichzeitigen Start beider Varianten (`address already in use`) | Beide `docker-compose.yml`-Dateien mappen versehentlich dieselben Host-Ports. | Sicherstellen, dass `docker_container/` Port 8080/8888 und `docker_container_gz/` Port 8081/8889 verwendet (siehe oben) – bereits so vorkonfiguriert. |
| `ros2 action send_goal` / `ActionClient.wait_for_server()` im Notebook hängt endlos | Der `arm_controller`/`gripper_controller` ist noch nicht vollständig hochgefahren (Gazebo braucht nach dem Container-Start einige Sekunden). | Vor dem Ausführen der Notebook-Zellen kurz warten, bis der Arm in der noVNC-Oberfläche sichtbar und stabil steht. |
