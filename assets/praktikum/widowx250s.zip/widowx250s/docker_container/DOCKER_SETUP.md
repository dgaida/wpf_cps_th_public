# Docker-Setup im Detail

Diese Datei erklärt jede Docker-relevante Datei im Ordner `docker_container/`, was sie tut und wie sie mit den anderen Dateien zusammenspielt. Sie richtet sich an alle, die das Setup verstehen, erweitern oder debuggen möchten.

---

## Überblick: Das Zusammenspiel der Dateien

```
docker-compose.yml
   │
   ├─▶ baut Image aus ──▶ Dockerfile
   │                         │
   │                         └─▶ COPY supervisord.conf ─▶ /etc/supervisor/conf.d/supervisord.conf
   │                                                            │
   │                                                            └─▶ startet beim Container-Start
   │                                                                 5 Prozesse parallel (siehe unten)
   │
   ├─▶ mountet Volumes ──▶ Notebook + src/ (vom Host in den Container)
   │
   └─▶ mappt Ports ──▶ 8080 (noVNC) und 8888 (JupyterLab)
```

Kurz gesagt:  
1. **`docker-compose.yml`** ist der Einstiegspunkt (`docker compose up --build`). Es sagt Docker, *wie* das Image gebaut wird (über das `Dockerfile`), *welche Ports* nach außen freigegeben werden und *welche Host-Ordner* in den Container gespiegelt werden.  
2. **`Dockerfile`** beschreibt Schritt für Schritt, wie das Container-Image aufgebaut wird: Betriebssystem, ROS 2, alle Interbotix-Pakete, JupyterLab. Am Ende kopiert es die `supervisord.conf` hinein.  
3. **`supervisord.conf`** definiert, welche Prozesse beim Start des Containers laufen sollen (Simulation, JupyterLab, VNC-Server etc.) – und hält sie am Laufen.  

---

## `docker-compose.yml`

Diese Datei orchestriert den Container von außen (auf dem Host).

```yaml
services:
  widowx250s_simulation:
    build:
      context: .
      dockerfile: Dockerfile
    container_name: widowx250s_simulation
    restart: unless-stopped
    ports:
      - "8080:8080"   # noVNC (Browser-basiertes Desktop-GUI)
      - "8888:8888"   # JupyterLab
    volumes:
      - ../1-widowx250s_erste_schritte.ipynb:/root/interbotix_ws/notebooks/1-widowx250s_erste_schritte.ipynb
      - ../src:/root/interbotix_ws/notebooks/src
```

| Schlüssel | Bedeutung |
|---|---|
| `build.context: .` | Das Verzeichnis, aus dem der Build-Kontext (alle für `docker build` sichtbaren Dateien) stammt – hier `docker_container/` selbst. Deshalb muss `docker compose up --build` **aus diesem Ordner heraus** aufgerufen werden. |
| `build.dockerfile: Dockerfile` | Name der zu verwendenden Dockerfile innerhalb des Kontexts. |
| `container_name` | Fester Name des laufenden Containers (statt eines von Docker generierten Zufallsnamens) – wird z. B. für `docker exec -it widowx250s_simulation bash` gebraucht. |
| `restart: unless-stopped` | Der Container startet automatisch neu (z. B. nach einem Absturz oder Host-Neustart), außer du hast ihn manuell gestoppt. |
| `ports` | Bildet Container-Ports auf Host-Ports ab (`Host:Container`). `8080` liefert die noVNC-Oberfläche, `8888` JupyterLab. |
| `volumes` | Bindet Dateien/Ordner vom Host direkt in den Container ein (bidirektional – Änderungen in beide Richtungen wirken sofort, kein erneuter Build nötig). Hier: das Notebook und der `src/`-Ordner, jeweils **eine Ebene über** `docker_container/` (daher `../`). |

**Warum Notebook und `src/` als Volume statt fest ins Image kopiert?**
Würde man sie stattdessen per `COPY` im `Dockerfile` ins Image backen, müsste bei **jeder** Änderung am Notebook oder an `src/widowx_pick_and_place.py` das komplette Image neu gebaut werden (mehrere Minuten, da der gesamte ROS-2-Workspace mitgebaut würde). Über ein Volume sind Änderungen sofort sichtbar, ganz ohne Rebuild.

---

## `Dockerfile`

Definiert das Container-Image Schritt für Schritt. Die Reihenfolge ist bewusst gewählt, damit Docker möglichst viele Layer cachen kann (unveränderte frühere Schritte müssen bei einem erneuten Build nicht neu ausgeführt werden).

### 1. Basis-Image & Umgebungsvariablen
```dockerfile
FROM osrf/ros:humble-desktop
ENV ROS_WS=/root/interbotix_ws
...
```
Startpunkt ist das offizielle ROS-2-Humble-Desktop-Image (Ubuntu 22.04 + ROS 2 vorinstalliert). `ROS_WS` definiert den Pfad zum ROS-Workspace, der im Rest der Datei mehrfach wiederverwendet wird.

### 2. System- und GUI-Abhängigkeiten
```dockerfile
RUN apt-get update && apt-get install -y \
    python3-pip python3-rosdep python3-colcon-common-extensions \
    ros-humble-gazebo-ros-pkgs ros-humble-ros2-control ros-humble-ros2-controllers \
    ros-humble-xacro ros-humble-moveit \
    build-essential git supervisor xvfb x11vnc fluxbox novnc net-tools \
    && rm -rf /var/lib/apt/lists/*
```
Installiert Build-Werkzeuge (`colcon`, `rosdep`, `git`, `build-essential`), ROS-2-Zusatzpakete sowie alles für die GUI-Bereitstellung über den Browser: `xvfb` (virtueller Display-Server, da der Container keinen echten Bildschirm hat), `x11vnc` (VNC-Server, überträgt diesen virtuellen Display), `fluxbox` (minimaler Fenstermanager), `novnc` (VNC-Client fürs Web) und `supervisor` (Prozessmanager, siehe unten).

### 3. Interbotix-Workspace: Repositories klonen
```dockerfile
RUN git clone -b humble https://github.com/Interbotix/interbotix_ros_core.git
RUN git clone -b humble https://github.com/Interbotix/interbotix_ros_manipulators.git
RUN git clone -b humble https://github.com/Interbotix/interbotix_ros_toolboxes.git
RUN git clone -b ros2 https://github.com/Interbotix/interbotix_xs_driver.git
RUN git clone -b ros2 https://github.com/Interbotix/dynamixel-workbench.git
```
Die drei ersten Repos sind der eigentliche Interbotix-ROS-2-Stack (Branch `humble`). `interbotix_xs_driver` und `dynamixel-workbench` sind zusätzliche Abhängigkeiten der Motor-Treiber-Schicht (`interbotix_xs_sdk`) und werden bewusst vom Branch `ros2` geklont – dieser Branch liefert ein Ament/ROS-2-kompatibles CMake-Paket, das `colcon` zusammen mit dem restlichen Workspace bauen kann (im Gegensatz zum `main`-Branch, der eine eigenständige, nicht-Ament-kompatible C++-Bibliothek ist).

Jedes `git clone` steht bewusst in einer eigenen `RUN`-Zeile: Ändert sich nur ein Repository (z. B. weil es upstream aktualisiert wurde), muss Docker beim nächsten Build nur diesen einzelnen Layer neu ausführen, nicht alle vorherigen.

### 4. Legacy-Marker entfernen
```dockerfile
RUN find $ROS_WS/src -name COLCON_IGNORE -delete
```
Manche Pakete in den geklonten Repos enthalten von Haus aus eine `COLCON_IGNORE`-Datei, die `colcon` anweist, sie zu überspringen. Diese Zeile entfernt alle solchen Marker, damit zunächst *alle* Pakete für den Build in Betracht gezogen werden. (Ironischerweise ist genau das später der Grund, warum bestimmte inkompatible Pakete wieder aktiv ausgeschlossen werden müssen – siehe Schritt 6.)

### 5. Abhängigkeiten auflösen
```dockerfile
WORKDIR $ROS_WS
RUN rosdep update || true
RUN apt-get update && rosdep install --from-paths src --ignore-src -r -y && rm -rf /var/lib/apt/lists/*
```
`rosdep` scannt alle `package.xml`-Dateien im Workspace und installiert die dort deklarierten System-Abhängigkeiten (z. B. weitere `apt`-Pakete) automatisch.

### 6. Inkompatible Legacy-Pakete ausschließen
```dockerfile
RUN for f in $(grep -rl "find_package(catkin" --include=CMakeLists.txt $ROS_WS/src); do \
        touch "$(dirname "$f")/COLCON_IGNORE"; \
    done
```
Einige der geklonten Pakete (z. B. `interbotix_xsarm_pid`, `interbotix_xsarm_diagnostic_tool`) sind noch ROS-1-Pakete (`catkin`-basiert) und lassen sich mit `colcon`/ROS 2 grundsätzlich nicht bauen. Dieser Schritt durchsucht automatisch alle `CMakeLists.txt`-Dateien nach `find_package(catkin` und markiert die entsprechenden Paketordner mit einer leeren `COLCON_IGNORE`-Datei, damit `colcon` sie überspringt – ohne dass jedes betroffene Paket einzeln von Hand aufgelistet werden muss.

### 7. Workspace bauen
```dockerfile
RUN /bin/bash -c "source /opt/ros/humble/setup.bash && colcon build --packages-select interbotix_xs_msgs --symlink-install && colcon build --symlink-install --packages-skip-regex '.*slate.*'"
```
Zwei Build-Schritte:  
1. `interbotix_xs_msgs` (die Nachrichtendefinitionen) wird **zuerst und isoliert** gebaut, damit die davon abhängigen CMake-Exporte beim nachfolgenden Gesamt-Build bereits vorliegen.  
2. Der restliche Workspace wird gebaut. `--packages-skip-regex '.*slate.*'` schließt alle Pakete für die **Slate-Mobilplattform** aus (eine andere Hardware-Produktlinie von Interbotix, die die – hier nicht installierte – Bibliothek `trossen_slate` benötigt und für den wx250s-Arm irrelevant ist).  

Beide Aufrufe verwenden konsequent `--symlink-install`, damit keine widersprüchlichen Installationslayouts entstehen (Mischung aus kopierten Dateien und Symlinks führt sonst zu Build-Fehlern).

### 8. Shell-Umgebung einrichten
```dockerfile
RUN echo "source /opt/ros/humble/setup.bash" >> /root/.bashrc
RUN echo "source $ROS_WS/install/setup.bash" >> /root/.bashrc
```
Sorgt dafür, dass in jeder interaktiven Shell im Container (z. B. via `docker exec -it ... bash`) automatisch sowohl die ROS-2-Basisumgebung als auch der eigene Workspace-Overlay gesourced sind.

### 9. JupyterLab installieren
```dockerfile
RUN pip3 install --no-cache-dir jupyterlab ipykernel modern_robotics "tornado<6.5.9"
```
Installiert JupyterLab **in demselben Python-Environment**, das auch ROS 2 nutzt (`python3`/`pip3` des Basis-Images) – nur so können Notebooks `rclpy` und die Interbotix-Python-Module (`interbotix_xs_modules`) direkt importieren. `modern_robotics` ist eine zusätzliche reine Python-Abhängigkeit von `interbotix_xs_modules`, die nicht über `rosdep` aufgelöst wird. `tornado<6.5.9` pinnt eine bekannte, kompatible Version (siehe [Bekannte Stolpersteine](#bekannte-stolpersteine--troubleshooting)).

### 10. Supervisor-Konfiguration einbinden & Start
```dockerfile
COPY supervisord.conf /etc/supervisor/conf.d/supervisord.conf
CMD ["/usr/bin/supervisord", "-c", "/etc/supervisor/conf.d/supervisord.conf"]
```
Kopiert die unten beschriebene `supervisord.conf` ins Image und definiert `supervisord` als den Prozess, der beim Start des Containers (`docker compose up`) ausgeführt wird.

---

## `supervisord.conf`

[Supervisor](http://supervisord.org/) ist ein Prozessmanager, der mehrere unabhängige Programme innerhalb **eines** Containers startet, überwacht und bei Bedarf neu startet. Das ist nötig, weil ein Docker-Container eigentlich für **einen** Hauptprozess gedacht ist – hier brauchen wir aber gleichzeitig einen virtuellen Display-Server, einen VNC-Server, den Webzugriff darauf, die ROS-2-Simulation und JupyterLab.

```ini
[supervisord]
nodaemon=true
user=root
```
`nodaemon=true` sorgt dafür, dass `supervisord` im Vordergrund läuft (Voraussetzung dafür, dass Docker den Container am Leben hält, solange dieser Prozess läuft).

Die fünf verwalteten Programme, in Startreihenfolge relevant für ihr Zusammenspiel:

| Programm | Aufgabe | Abhängig von |
|---|---|---|
| `xvfb` | Startet einen virtuellen (unsichtbaren) X11-Display unter `:0` mit Auflösung 1920×1080. | – |
| `fluxbox` | Minimaler Fenstermanager, der auf `xvfb`s Display `:0` läuft und RViz-Fenster korrekt darstellt. | `xvfb` |
| `x11vnc` | Überträgt den Inhalt von Display `:0` per VNC-Protokoll auf Port 5900 (containerintern). | `xvfb` |
| `novnc` | Ein Webserver (`websockify`), der VNC über HTTP/WebSocket verfügbar macht – das ist die Brücke zwischen `x11vnc` (Port 5900) und dem extern erreichbaren Port 8080. | `x11vnc` |
| `ros` | Startet `ros2 launch interbotix_xsarm_control xsarm_control.launch.py robot_model:=wx250s use_sim:=true` – die eigentliche Simulation (`xs_sdk`-Node im Simulationsmodus + RViz). | `xvfb`, `fluxbox` (für die RViz-Anzeige) |
| `jupyter` | Startet JupyterLab auf Port 8888, mit Arbeitsverzeichnis `/root/interbotix_ws/notebooks` (dorthin sind Notebook und `src/` per Volume gemountet, siehe `docker-compose.yml`). | – (unabhängig von den anderen Prozessen startbar) |

Jeder Eintrag folgt demselben Muster, hier am Beispiel `ros`:

```ini
[program:ros]
command=/bin/bash -c "source /opt/ros/humble/setup.bash && source /root/interbotix_ws/install/setup.bash && ros2 launch interbotix_xsarm_control xsarm_control.launch.py robot_model:=wx250s use_sim:=true"
redirect_stderr=true
stdout_logfile=/dev/stdout
stdout_logfile_maxbytes=0
```
- `command`: sourced zuerst die ROS-2-Umgebung (`setup.bash`), dann den eigenen Workspace-Overlay – erst danach ist `ros2 launch ...` überhaupt verfügbar.  
- `redirect_stderr=true` + `stdout_logfile=/dev/stdout`: leitet alle Log-Ausgaben des Prozesses auf die Standardausgabe des Containers um, damit sie mit `docker compose up` (bzw. `docker logs`) sichtbar sind, statt in einer separaten Datei zu verschwinden.  
- `stdout_logfile_maxbytes=0`: deaktiviert die Log-Rotation von Supervisor (überlässt das Log-Management Docker).  

`jupyter` folgt demselben Muster, zusätzlich mit `directory=/root/interbotix_ws/notebooks` (Arbeitsverzeichnis) und `autorestart=true` (startet automatisch neu, falls der Prozess abstürzt).

<a name="warum-kein-gazebo"></a>
### Warum `xsarm_control.launch.py` statt Gazebo?

Es gibt bei Interbotix zwei unterschiedliche Simulationswege für ROS 2:

1. **`interbotix_xsarm_sim` → `xsarm_gz_classic.launch.py`**: startet eine vollständige **Gazebo-Physiksimulation** über `gazebo_ros2_control`. Die Robotersteuerung läuft dabei über einen `controller_manager` mit `FollowJointTrajectory`-Controllern.  
2. **`interbotix_xsarm_control` → `xsarm_control.launch.py` mit `use_sim:=true`**: startet den `xs_sdk`-Node im Simulationsmodus – eine reine Software-Simulation **ohne Physik**, die aber exakt dieselben ROS-Services bereitstellt wie die echte Hardware (`/wx250s/set_operating_modes`, `/wx250s/get_robot_info` usw.).  

Die Python-API `InterbotixManipulatorXS` (aus `interbotix_xs_modules`) spricht ausschließlich mit dem **`xs_sdk`-Interface** (Weg 2). Mit der Gazebo-Simulation (Weg 1) lässt sie sich **nicht** direkt steuern, da dort kein `xs_sdk`-Node läuft. Dieses Setup verwendet deshalb bewusst Weg 2: Der Arm ist vollständig über Python/Jupyter steuerbar, seine Bewegung wird live in RViz angezeigt – es gibt aber keine Kollisions- oder Schwerkraftsimulation.

Wer zusätzlich echte Gazebo-Physik **und** Steuerung über `InterbotixManipulatorXS` braucht, müsste das `interbotix_xsarm_ros_control`-Paket einbinden, das den `xs_sdk`-Node über eine `xs_hardware_interface`-Brücke mit `ros2_control`/Gazebo verbindet (typischerweise im Zusammenspiel mit MoveIt genutzt) – ein deutlich umfangreicherer Aufbau, der hier (noch) nicht implementiert ist.

---

## Bekannte Stolpersteine & Troubleshooting

Diese Probleme sind während der Entwicklung dieses Setups aufgetreten und wurden gelöst – falls du das Setup veränderst und ähnliche Fehler siehst, hilft dir das Verständnis der Ursache:

| Fehler | Ursache | Lösung |
|---|---|---|
| `failed to create symbolic link ... because existing path cannot be removed: Is a directory` | Zwei aufeinanderfolgende `colcon build`-Aufrufe mit unterschiedlichem Install-Modus (einer ohne, einer mit `--symlink-install`) erzeugen widersprüchliche Verzeichnisstrukturen. | Beide `colcon build`-Aufrufe konsequent mit `--symlink-install`. |
| `Could not find a package configuration file provided by "interbotix_xs_driver"` | `interbotix_xs_driver` wurde als eigenständige C++-Bibliothek (Branch `main`) statt als ROS-2-Ament-Paket gebaut. | Branch `ros2` klonen und als Teil des `colcon`-Workspace mitbauen (siehe Dockerfile-Abschnitt 3). |
| `git clone -b humble ...` schlägt für `interbotix_xs_driver` fehl (`Remote branch humble not found`) | Dieses Repo wird nicht pro ROS-Distribution gebrancht. | Branch `ros2` (bzw. `main` für die Standalone-Variante) verwenden, nicht `humble`. |
| `Could not find a package configuration file provided by "trossen_slate"` | `interbotix_slate_driver` (Slate-Mobilplattform-Treiber) wird mitgebaut, obwohl die dafür nötige Bibliothek nicht installiert ist. | Slate-Pakete per `--packages-skip-regex '.*slate.*'` ausschließen. |
| `CMake Error ... Findcatkin.cmake` | Einzelne Pakete (z. B. `interbotix_xsarm_pid`) sind ROS-1/`catkin`-Pakete, die `colcon` nicht bauen kann. | Automatisch per `grep`/`COLCON_IGNORE` ausschließen (siehe Dockerfile-Abschnitt 6). |
| `file 'xsarm_sim.launch.py' was not found` | Der Dateiname wurde im aktuellen `humble`-Branch zu `xsarm_gz_classic.launch.py` geändert. | Aktuellen Launch-Dateinamen verwenden (bzw. hier: `xsarm_control.launch.py`, siehe [oben](#warum-kein-gazebo)). |
| `ModuleNotFoundError: No module named 'modern_robotics'` | Reine Python-Abhängigkeit von `interbotix_xs_modules`, die nicht über `rosdep` installiert wird. | Per `pip3 install modern_robotics` ergänzen. |
| Browserseite bei JupyterLab bleibt weiß, `AttributeError: 'FileFindHandler' object has no attribute 'allowed_symlink_directory'` | Breaking Change in `tornado` Version 6.5.9 (Änderung an `StaticFileHandler`), mit dem Jupyters `FileFindHandler` noch nicht kompatibel ist. | `tornado` auf eine Version vor 6.5.9 pinnen (`"tornado<6.5.9"`). |
| `Failed to find services under namespace '/wx250s'. Is the xs_sdk running under that namespace?` | Es lief die Gazebo-Simulation (`xsarm_gz_classic.launch.py`), die keinen `xs_sdk`-Node startet – `InterbotixManipulatorXS` braucht aber genau diesen. | `xsarm_control.launch.py robot_model:=wx250s use_sim:=true` statt der Gazebo-Simulation verwenden (siehe [oben](#warum-kein-gazebo)). |

### Allgemeine Debugging-Tipps

- **Logs ansehen:** `docker compose logs -f` (bzw. ohne `-f` für einen einmaligen Snapshot) zeigt die zusammengeführte Ausgabe aller von `supervisord` verwalteten Prozesse.  
- **In den laufenden Container:** `docker exec -it widowx250s_simulation bash` – danach ist die ROS-2-Umgebung dank der `.bashrc`-Einträge (Dockerfile-Abschnitt 8) automatisch aktiv.  
- **Ohne Cache neu bauen:** Falls ein geänderter Layer aus unklaren Gründen nicht neu gebaut wird, hilft `docker compose build --no-cache` gefolgt von `docker compose up`.  
- **Einzelne ROS-Nodes/Services prüfen:** Im Container (`docker exec -it ...`) helfen `ros2 node list`, `ros2 service list` und `ros2 topic list`, um zu sehen, ob der `xs_sdk`-Node und seine Services unter dem erwarteten Namespace (`/wx250s/...`) tatsächlich laufen.  
