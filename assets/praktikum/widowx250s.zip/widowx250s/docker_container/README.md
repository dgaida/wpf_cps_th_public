# Docker-Container für WidowX-250s-Simulation (ROS 2 Humble)

Dieses Verzeichnis enthält die Konfiguration für einen Docker-Container, der eine vollständige ROS 2 Humble Umgebung für den **WidowX-250s Roboterarm (`wx250s`)** bereitstellt – inklusive einer per Python/Jupyter steuerbaren Simulation.

Eine detaillierte Erklärung aller Docker-relevanten Dateien und wie sie zusammenspielen findest du in [`DOCKER_SETUP.md`](./DOCKER_SETUP.md).

---

## 🛠️ Voraussetzungen

### Software & Installation

- **Docker Engine** (v20.10 oder neuer)  
- **Docker Compose** (v2.0 oder neuer, in modernen Docker Desktop Installationen direkt enthalten)  

#### Bezugsquellen & Installation

Docker und Docker Compose können über die offizielle Docker-Dokumentation bezogen und installiert werden:  
- **Docker Desktop (Windows & macOS):** [https://docs.docker.com/desktop/](https://docs.docker.com/desktop/)  
- **Docker Engine & Docker Compose Plugin (Linux):** [https://docs.docker.com/get-docker/](https://docs.docker.com/get-docker/)  

---

## 📁 Projektstruktur

Das Projekt geht von folgender Ordnerstruktur aus:

```
projekt/
├── 1-widowx250s_erste_schritte.ipynb   # Jupyter-Notebook zur Robotersteuerung
├── src/                                 # Eigene Python-Module (z. B. widowx_pick_and_place.py)
│   └── widowx_pick_and_place.py
└── docker_container/                    # Alle Docker-relevanten Dateien
    ├── Dockerfile
    ├── docker-compose.yml
    ├── supervisord.conf
    └── README.md
```

Notebook und `src/`-Ordner liegen als Geschwister von `docker_container/` und werden per Volume in den Container gemountet (siehe [`DOCKER_SETUP.md`](./DOCKER_SETUP.md)).

---

## 🛠️ Komponenten des Containers

- **ROS 2 Humble Desktop** auf Ubuntu 22.04 Basis.  
- **Interbotix ROS 2 Packages** (`interbotix_ros_core`, `interbotix_ros_manipulators`, `interbotix_ros_toolboxes`, `interbotix_xs_driver`, `dynamixel-workbench`).  
- **RViz2** zur 3D-Visualisierung der Gelenkstellungen des Roboterarms.  
- **xs_sdk (Simulationsmodus)**: simulierter Treiber-Node, der dieselben ROS-Services wie die echte Hardware bereitstellt – dadurch lässt sich der Arm mit derselben Python-API steuern wie ein echter WidowX-250s.  
- **JupyterLab**: läuft direkt im ROS-2-Python-Environment des Containers, sodass Notebooks `rclpy` und `interbotix_xs_modules` importieren können.  
- **noVNC & x11vnc**: Zugriff auf das grafische Desktop-Interface (inkl. RViz) direkt über den Webbrowser (Port 8080).  

> **Hinweis:** Diese Konfiguration nutzt den `xs_sdk`-Node im Simulationsmodus (`use_sim:=true`), **keine** Gazebo-Physiksimulation. Das bedeutet: Der Arm lässt sich vollständig über die `InterbotixManipulatorXS`-Python-API steuern und seine Bewegung live in RViz mitverfolgen – es gibt aber keine Kollisions- oder Schwerkraftsimulation. Details und der Grund dafür stehen in [`DOCKER_SETUP.md`](./DOCKER_SETUP.md#warum-kein-gazebo).

---

## 🚀 Schnellstart

### 1. Docker Container bauen und starten

Navigiere in den Ordner `docker_container/` und führe Docker Compose aus:

```bash
cd docker_container
docker compose up --build
```

Der erste Build dauert je nach Rechner mehrere Minuten (ROS-2-Workspace wird komplett aus dem Quellcode gebaut).

### 2. Simulations-Oberfläche (RViz) im Browser öffnen

Öffne einen Webbrowser und rufe folgende Adresse auf:

[http://localhost:8080](http://localhost:8080)

Klicke auf **Connect**, um die grafische Oberfläche (RViz) mit dem simulierten WidowX-250s Roboterarm zu sehen.

### 3. JupyterLab im Browser öffnen

Öffne einen zweiten Tab und rufe folgende Adresse auf:

[http://localhost:8888/lab](http://localhost:8888/lab)

Hier findest du das Notebook `1-widowx250s_erste_schritte.ipynb` sowie den `src/`-Ordner, beide direkt aus dem Projekt-Root gemountet. Änderungen, die du im Notebook speicherst, werden auch auf deinem Host gespeichert (und umgekehrt).

### 4. Roboter über das Notebook steuern

Führe die Zellen im Notebook `1-widowx250s_erste_schritte.ipynb` nacheinander aus. Die `InterbotixManipulatorXS`-Klasse verbindet sich automatisch mit dem im Container laufenden `xs_sdk`-Node; Bewegungen sind live in RViz (Schritt 2) sichtbar.

---

## 💻 Steuerung aus dem Container heraus (Terminal)

Um zusätzlich interaktiv Befehle oder Python-Skripte im laufenden Container auszuführen:

```bash
docker exec -it widowx250s_simulation bash
```

### Manuelles Starten der Simulation (falls nötig)

Falls du die Simulation manuell neu starten möchtest (z. B. nach einem Absturz), kannst du im Container Folgendes ausführen:

```bash
ros2 launch interbotix_xsarm_control xsarm_control.launch.py robot_model:=wx250s use_sim:=true
```

---

## 🧯 Troubleshooting

Eine Übersicht über bereits gelöste Build- und Laufzeitprobleme (und deren Ursachen) findest du in [`DOCKER_SETUP.md`](./DOCKER_SETUP.md#bekannte-stolpersteine--troubleshooting).
