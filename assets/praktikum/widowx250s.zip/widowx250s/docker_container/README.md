# Docker Container für WidowX-250s Simulation (ROS 2 Humble)

Dieses Verzeichnis enthält die Konfiguration für einen Docker-Container, der eine vollständige ROS 2 Humble Simulationsumgebung für den **WidowX-250s Roboterarm (`wx250s`)** bereitstellt.

---

## 🛠️ Komponenten des Containers

- **ROS 2 Humble Desktop** auf Ubuntu 22.04 Basis.  
- **Interbotix ROS 2 Packages** (`interbotix_ros_manipulators` und `interbotix_ros_toolboxes`).  
- **Gazebo & RViz2** zur 3D-Visualisierung und Physik-Simulation des Roboterarms.  
- **noVNC & x11vnc**: Zugriff auf das grafische Desktop-Interface direkt über den Webbrowser (Port 8080).  

---

## 🚀 Schnellstart

### 1. Docker Container bauen und starten

Navigieren Sie in dieses Verzeichnis und führen Sie Docker Compose aus:

```bash
docker compose up --build
```

### 2. Simulations-Oberfläche im Browser öffnen

Öffnen Sie einen Webbrowser und rufen Sie folgende Adresse auf:

[http://localhost:8080](http://localhost:8080)

Klicken Sie auf **Connect**, um die grafische Oberfläche (Gazebo / RViz) mit dem simulierten WidowX-250s Roboterarm zu sehen.

---

## 💻 Steuerung aus dem Container heraus

Um interaktiv Befehle oder Python-Skripte im laufenden Container auszuführen:

```bash
docker exec -it widowx250s_simulation bash
```

### Manuelles Starten der Simulation (falls nötig)

```bash
ros2 launch interbotix_xsarm_sim xsarm_sim.launch.py robot_model:=wx250s use_sim:=true
```
