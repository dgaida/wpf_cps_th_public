# Docker-Setup im Detail – Gazebo + MoveIt Variante

Diese Datei ergänzt [`docker_container/DOCKER_SETUP.md`](../docker_container/DOCKER_SETUP.md) um die Besonderheiten dieser Variante. Grundlagen (Zweck von `docker-compose.yml`, `Dockerfile`-Aufbau, `supervisord`-Prinzip) werden dort ausführlich erklärt und hier nicht wiederholt.

---

## Architektur-Entscheidung: Warum nicht `interbotix_xsarm_ros_control`?

Ursprünglich war angedacht, für die Kombination "Gazebo-Physik + `InterbotixManipulatorXS`-Python-API" das Paket `interbotix_xsarm_ros_control` zu nutzen. Ein genauerer Blick in die offizielle Interbotix-Dokumentation zeigt jedoch: Dieses Paket bridged `FollowJointTrajectory`-Kommandos (typischerweise von MoveIt) **direkt mit dem `xs_sdk`-Node** – also mit echter oder simulierter (Fake-Modus, ohne Physik) **Hardware**, nicht mit Gazebo. Es gibt in der offiziellen Interbotix-Toolchain **keine** dokumentierte Brücke, die `xs_sdk`-Services mit einer laufenden Gazebo-Physiksimulation verbindet.

Der offiziell dokumentierte, unterstützte Weg zu einer echten Gazebo-Physiksimulation ist stattdessen:

```
ros2 launch interbotix_xsarm_moveit xsarm_moveit.launch.py robot_model:=wx250s hardware_type:=gz_classic
```

Dieses eine Launch-File aus dem Paket `interbotix_xsarm_moveit` startet:  
- **Gazebo Classic** (über das darunterliegende `interbotix_xsarm_sim`-Paket, inkl. `gazebo_ros2_control` und Controllern wie `arm_controller`/`gripper_controller`)  
- **MoveIt 2** (`move_group`-Node für Motion Planning)  
- **RViz2** mit dem MoveIt-"Motion Planning"-Plugin  

**Konsequenz für die Steuerung:** Da hier kein `xs_sdk`-Node läuft, funktioniert `InterbotixManipulatorXS` (aus `interbotix_xs_modules`) **nicht**. Stattdessen wird direkt über das `FollowJointTrajectory`-Action-Interface gesteuert – entweder programmatisch (siehe Notebook `2-widowx250s_gazebo_moveit.ipynb`) oder komplett ohne Code über die interaktiven Marker in RViz.

---

## Unterschiede zu `docker_container/` im Detail

### `Dockerfile`
**Inhaltlich identisch** zur Basis-Variante. Der Grund: Der `colcon build`-Schritt baut bereits den **kompletten** Workspace, inklusive `interbotix_xsarm_sim` (Gazebo) und `interbotix_xsarm_moveit` – unabhängig davon, welche Variante später tatsächlich genutzt wird. Ein separates Image wäre also nicht nötig gewesen; es existiert trotzdem als eigene Kopie in `docker_container_gz/`, damit beide Varianten als vollständig unabhängige, in sich geschlossene Projekte funktionieren (kein gemeinsamer Build-Kontext, den Studierende verstehen müssten).

### `docker-compose.yml`
Drei Unterschiede zur Basis-Variante:  
1. **Service-/Container-Name:** `widowx250s_simulation_gz` statt `widowx250s_simulation` – verhindert Namenskonflikte, falls beide Varianten gleichzeitig laufen sollen.  
2. **Ports:** `8081` (statt `8080`) für noVNC und `8889` (statt `8888`) für JupyterLab – aus demselben Grund.  
3. **Volume:** mountet `2-widowx250s_gazebo_moveit.ipynb` statt `1-widowx250s_erste_schritte.ipynb`, da dieses Notebook das zur Gazebo-Variante passende Steuerungsbeispiel (`FollowJointTrajectory` statt `InterbotixManipulatorXS`) enthält. Der `src/`-Ordner wird weiterhin geteilt genutzt.  

### `supervisord.conf`
Nur das `[program:ros]`-Kommando unterscheidet sich:

```ini
command=/bin/bash -c "source /opt/ros/humble/setup.bash && source /root/interbotix_ws/install/setup.bash && ros2 launch interbotix_xsarm_moveit xsarm_moveit.launch.py robot_model:=wx250s hardware_type:=gz_classic"
```

Alle anderen Programme (`xvfb`, `fluxbox`, `x11vnc`, `novnc`, `jupyter`) sind unverändert – sie kümmern sich um die Browser-GUI-Bereitstellung bzw. JupyterLab und sind unabhängig davon, welche ROS-2-Simulation im `ros`-Programm läuft.

---

## Notebook `2-widowx250s_gazebo_moveit.ipynb`

Statt `InterbotixManipulatorXS` verwendet dieses Notebook einen `rclpy`-`ActionClient`, der direkt mit den `FollowJointTrajectory`-Action-Servern der Controller spricht:

- Arm: `/wx250s/arm_controller/follow_joint_trajectory`  
- Greifer: `/wx250s/gripper_controller/follow_joint_trajectory`  

Das ist bewusst low-level gehalten (keine Umkehrkinematik, keine Kollisionsprüfung – reine Gelenkwinkel-Trajektorien) und eignet sich daher besonders gut, um Studierenden zu zeigen, *wie* MoveIt/`ros2_control` unter der Haube tatsächlich kommunizieren. Für Motion Planning mit Umkehrkinematik und Kollisionsvermeidung ist die MoveIt-RViz-Oberfläche (Drag & Drop) der einfachere Einstieg; eine vollständige Python-Anbindung an MoveIts Planungspipeline (`moveit_py`) wäre ein möglicher nächster Ausbauschritt, ist aber deutlich aufwändiger einzurichten und hier nicht enthalten.

> **Hinweis zu den Gelenknamen des Greifers:** Je nach genauer MoveIt-/`ros2_control`-Konfiguration kann der Gripper-Controller einen anderen Joint-Namen als `"gripper"` erwarten (z. B. bei Mimic-Joint-Setups). Prüfe im Zweifel im Container mit `ros2 control list_controllers` bzw. `ros2 control list_hardware_interfaces`, welche Joint-Namen tatsächlich erwartet werden, und passe die entsprechende Codezelle im Notebook an.

---

## Troubleshooting

Da diese Variante denselben Workspace baut wie `docker_container/`, gelten **alle** Build-bezogenen Einträge aus der [Troubleshooting-Tabelle dort](../docker_container/DOCKER_SETUP.md#bekannte-stolpersteine--troubleshooting) unverändert (z. B. `--symlink-install`-Konsistenz, `interbotix_xs_driver`-Branch, Slate-/`catkin`-Pakete überspringen, `tornado`-Pin für JupyterLab).

Zusätzlich, spezifisch für diese Variante:

| Fehler / Symptom | Ursache | Lösung |
|---|---|---|
| `InterbotixManipulatorXS(...)` hängt beim Verbinden bzw. wirft Service-Timeout-Fehler | Es läuft kein `xs_sdk`-Node in dieser Variante. | `InterbotixManipulatorXS` hier nicht verwenden – stattdessen `FollowJointTrajectory` (siehe Notebook) oder die MoveIt-RViz-Oberfläche nutzen. |
| Gazebo startet, aber `move_group`/MoveIt lädt nie fertig bzw. der Arm reagiert nicht | Gazebo-Physik ist standardmäßig pausiert (ähnlich wie in der ROS-1-Variante), bis die Controller vollständig geladen sind. | Kurz warten, bis in den Logs `Configured and activated arm_controller` erscheint, bevor Planungsanfragen gesendet werden. |
| Port-Konflikt beim gleichzeitigen Start beider Varianten (`address already in use`) | Beide `docker-compose.yml`-Dateien mappen versehentlich dieselben Host-Ports. | Sicherstellen, dass `docker_container/` Port 8080/8888 und `docker_container_gz/` Port 8081/8889 verwendet (siehe oben) – bereits so vorkonfiguriert. |
| `ros2 action send_goal` / `ActionClient.wait_for_server()` im Notebook hängt endlos | Der `arm_controller`/`gripper_controller` ist noch nicht vollständig hochgefahren (Gazebo braucht nach dem Container-Start einige Sekunden). | Vor dem Ausführen der Notebook-Zellen kurz warten, bis der Arm in der noVNC-Oberfläche sichtbar und stabil steht. |

---

## Der Arbeitsbereich: `worlds/wx250s_pickplace.world`

Diese Datei ersetzt die von `xsarm_moveit.launch.py` standardmäßig geladene Welt (`interbotix_common_sim/worlds/interbotix.world`) über den offiziell dokumentierten Launch-Parameter `world_filepath` (siehe `supervisord.conf`). Sie baut auf derselben Basis auf (Sonne + Bodenebene) und ergänzt:

| Element | Beschreibung |
|---|---|
| `workspace_table` | Eine flache, statische Plattform (0,30 m × 0,30 m) bei x=0,20–0,50 m, y=−0,15–0,15 m relativ zur Roboterbasis – markiert visuell den Greif-Arbeitsbereich. |
| `cube_red`, `cube_green`, `cube_blue`, `cube_yellow` | Vier 2,5 cm große, 20 g schwere Würfel auf der Plattform, mit realistischer Reibung (`mu=1.0`) für einen sicheren Griff durch den Parallelgreifer. |
| `overhead_camera` | Eine statische RGB-Kamera (`libgazebo_ros_camera.so`-Plugin) bei Pose `0.10 0 0.55 0 0.85 0` (x y z roll pitch yaw), die von oben, leicht schräg von vorne, auf den Arbeitsbereich blickt. Veröffentlicht auf `/overhead_camera/image_raw` (`sensor_msgs/Image`, `rgb8`) und `/overhead_camera/camera_info`. |

**Positionen/Pose anpassen:** Alle Koordinaten sind in der Datei als Klartext-Werte hinterlegt und lassen sich direkt bearbeiten (Docker-Image danach neu bauen, da die Datei per `COPY` ins Image kopiert wird, nicht als Volume gemountet ist). Die Kamera-Pose ist besonders empfindlich – nutze die `get_camera_image()`-Zelle im Notebook, um Anpassungen schnell zu überprüfen, ohne jedes Mal neu zu bauen (bei reinen Pose-Änderungen reicht oft ein Container-Neustart mit `docker compose restart`, da die World-Datei beim Container-Start neu geparst wird – ein Rebuild ist nur nötig, wenn sich der Dateiinhalt selbst geändert hat und das Image aktualisiert werden muss).

**Warum kein `<mimic>`-Tag-Problem wie beim Robotergreifer?** Die Würfel sind eigenständige, frei bewegliche Starrkörper (kein `<mimic>` involviert) – das Problem aus der Troubleshooting-Tabelle betrifft ausschließlich die Finger-Kopplung des Robotergreifers, nicht die Würfel selbst.

---

## Pick & Place im Notebook: Teach & Repeat statt inverser Kinematik

Der neue Abschnitt "Step 7" im Notebook verwendet bewusst **keine** automatische inverse Kinematik (Zielkoordinate → Gelenkwinkel), da MoveIts Python-Bindings (`moveit_py`) für ROS 2 Humble nicht als fertiges Binärpaket existieren (Stand: siehe [offener GitHub-Issue](https://github.com/moveit/moveit2/issues/3454); nur per Sourcebuild verfügbar, was den Container erheblich komplexer machen würde).

Stattdessen: `record_pose(name)` liest die aktuelle Gelenkstellung aus `/wx250s/joint_states` aus und speichert sie unter einem Namen; `pick_and_place(...)` fährt eine Sequenz aus vier solchen gespeicherten Posen (über Objekt → am Objekt greifen → über Ablage → an Ablage loslassen) automatisch ab. Die Posen selbst werden interaktiv aufgenommen (per `move_arm(...)`-Zelle **oder** per Drag & Drop in der MoveIt-RViz-Oberfläche) – das Notebook rät hier nichts, sondern zeichnet auf, was die Studierenden tatsächlich ausprobiert und für gut befunden haben.

**Möglicher Ausbau:** Wer eine automatische, koordinatenbasierte Lösung möchte, könnte `moveit_py` aus dem Quellcode bauen (zusätzlicher `colcon build`-Schritt im Dockerfile, deutlich längere Build-Zeit) oder alternativ eine einfache, selbst geschriebene analytische inverse Kinematik für den 6-DOF-Arm implementieren. Beides ist ein eigenständiges, größeres Vorhaben und hier bewusst nicht umgesetzt.

---

## Troubleshooting (Ergänzung: Arbeitsbereich & Kamera)

| Fehler / Symptom | Ursache | Lösung |
|---|---|---|
| `get_camera_image()` gibt `None` zurück / Timeout | Kamera-Topic noch nicht verfügbar (Gazebo braucht nach Start ein paar Sekunden) oder falscher Topic-Name. | Kurz warten und erneut versuchen; Topic-Existenz prüfen mit `ros2 topic list \| grep camera` im Container. |
| Würfel liegen nach dem Start nicht exakt auf der Plattform / fallen leicht durch | Physik-Engine braucht nach dem Spawnen einen Moment zum "Einschwingen" (typisch bei frisch platzierten Starrkörpern in Gazebo). | Kurz warten, bevor die erste Notebook-Zelle ausgeführt wird; bei Bedarf `z`-Startposition der Würfel in der World-Datei geringfügig erhöhen. |
| `record_pose(...)` speichert offensichtlich falsche Werte | `get_current_arm_joint_positions()` hat auf eine `joint_states`-Nachricht reagiert, die noch alte/übergangsweise Werte enthielt (während sich der Arm noch bewegt hat). | Vor dem Aufruf von `record_pose(...)` kurz warten, bis die Bewegung sichtbar abgeschlossen ist. |
| Würfel werden gegriffen, rutschen aber beim Anheben aus dem Greifer | Reibungskoeffizient/Greifkraft reicht nicht aus, oder die `grasp`-Pose ist nicht mittig genug am Würfel. | `grasp`-Pose in der Höhe/Ausrichtung feinjustieren (neu mit `record_pose(...)` überschreiben); alternativ `mu`/`mu2` in der World-Datei erhöhen (z. B. auf 1.5–2.0) und Image neu bauen. |

---

## Bekannter, ungelöster Punkt: `gzclient`-Fenster & Kamera funktionieren nicht (Stand: aktuell)

**Symptom:** `gzclient` (das 3D-Anzeigefenster von Gazebo) stürzt beim Start ab (`Assertion 'px != 0' failed`), und die Kamera aus `wx250s_pickplace.world` liefert keine Bilder (`ros2 topic list | grep camera` bleibt leer). **Alles andere funktioniert einwandfrei:** `gzserver` (Physik), MoveIt, Roboter- und Greifersteuerung, Pick & Place.

### Grundursache

`Xvfb`, der virtuelle Displayserver in diesem Container, ist eine **reine Software-Implementierung** ohne jede GPU-Anbindung. Jedes OpenGL/GLX-Rendering (sowohl `gzclient`s Fenster als auch die interne Kamera-Sensor-Berechnung in `gzserver`) läuft dadurch ausschließlich über Mesas Software-Rasterizer (`llvmpipe`), was in dieser Kombination zuverlässig zum oben genannten Absturz bzw. zu fehlschlagender Kamera-Initialisierung führt – unabhängig davon, ob eine echte GPU im Host-System vorhanden ist.

### Versuchte Lösungswege (chronologisch, mit Ergebnis)

1. **`LIBGL_ALWAYS_SOFTWARE=1`** – kein Effekt, `gzclient` stürzte weiterhin ab.  
2. **Zusätzlich `libgl1-mesa-dri`, `libglx-mesa0`, `mesa-utils` installieren + `GALLIUM_DRIVER=llvmpipe`** – kein Effekt.  
3. **`OGRE_RTT_MODE=Copy`** (alternativer Render-to-Texture-Modus für Kamera-Sensoren) – kein Effekt.  
4. **GPU-Passthrough via NVIDIA Container Toolkit** (`docker-compose.yml`: `deploy.resources.reservations.devices` mit `driver: nvidia`) – Grundvoraussetzung erfolgreich eingerichtet (`nvidia-smi` läuft im Container), **löst das Rendering-Problem aber allein nicht**, da `Xvfb` die GPU trotzdem nicht ansteuern kann (siehe Grundursache oben).  
5. **VirtualGL im transparenten Modus** (`LD_PRELOAD=/usr/lib/libvglfaker.so`, `VGL_DISPLAY=egl`) – lief durch, ohne sichtbaren Effekt; vermutlich griff der globale `LD_PRELOAD` in der `ros2 launch`-Prozesskette nicht wie erhofft.  
6. **Gezielter Test mit `vglrun -d egl +v glxinfo`** – zeigte den ersten konkreten Fehler: `EGL_BAD_MATCH` bei `eglCreateContext()`, danach sichtbarer Fallback auf `llvmpipe`.  
7. **`/dev/dri` fehlte komplett im Container** (`ls /dev/dri/` → "No such file or directory"), obwohl `NVIDIA_DRIVER_CAPABILITIES=all` gesetzt war. Fix: `/dev/dri:/dev/dri` explizit in `docker-compose.yml` unter `devices:` durchreichen. **Das brachte `/dev/dri` mit den Render-Nodes (`renderD128`, `renderD129`, `card1`, `card2`) tatsächlich in den Container.**  
8. **Test gegen die einzelnen Render-Nodes:** `card2` erwies sich als die **Intel-iGPU** (funktioniert einwandfrei mit Mesa) – dieses System hat also sowohl eine Intel-iGPU als auch die NVIDIA-Karte. `card1`, `renderD128`, `renderD129` (vermutlich die NVIDIA-Karte) scheiterten alle identisch mit `libEGL warning: egl: failed to create dri2 screen` → `ERROR: in init3D-- 245: Invalid EGL device`.  
9. **Root Cause gefunden:** NVIDIAs eigene EGL-Bibliotheken (`libEGL_nvidia.so.0`, exakt passend zur Host-Treiberversion `565.57.01`) **waren im Container vorhanden** (vom NVIDIA Container Toolkit korrekt injiziert) – aber es fehlte die zugehörige **Vendor-JSON-Datei** unter `/usr/share/glvnd/egl_vendor.d/`, über die `libglvnd` (der EGL-Loader) NVIDIA überhaupt als verfügbaren Treiber registriert. Nur Mesas eigene Vendor-Datei (`50_mesa.json`) war vorhanden.  
10. **Fix: Vendor-JSON manuell im Dockerfile erzeugt** (`/usr/share/glvnd/egl_vendor.d/10_nvidia.json`, Inhalt: `{"file_format_version":"1.0.0","ICD":{"library_path":"libEGL_nvidia.so.0"}}`). **Das brachte den Loader tatsächlich einen Schritt weiter** – mit `EGL_LOG_LEVEL=debug` war zu sehen: `libEGL debug: using driver nvidia-drm for 10` (NVIDIA wird jetzt gefunden und ausgewählt!). Der `vglrun`-Test scheiterte aber weiterhin am selben `dri2 screen`-Fehler wie zuvor.  

### Aktueller Stand

An diesem Punkt wurde die Fehlersuche abgebrochen: Die verbleibende Ursache liegt vermutlich in einem noch spezifischeren Detail der EGL-Kontext-Erstellung zwischen `libglvnd`, VirtualGL und dem NVIDIA-Treiber in dieser exakten Kombination (Ubuntu 22.04 im Container, Treiberversion 565.57.01, VirtualGL 3.1.1) – eine weitere Eingrenzung würde interaktives Debugging mit detaillierten EGL-Traces direkt auf der Zielmaschine erfordern, was im Rahmen eines Chat-gestützten Debuggings nicht mehr sinnvoll leistbar ist.

**Für wen relevant:** Dieses Setup läuft testweise nur auf einem einzigen Rechner mit einer bestimmten NVIDIA-Treiberversion. Selbst wenn der Fehler behoben würde, wäre die Lösung sehr wahrscheinlich **nicht portabel** auf andere Studierenden-Rechner mit anderen GPUs/Treiberversionen – ein zusätzlicher Grund, warum die aktuelle, robuste Software-Rendering-Basis (ohne `gzclient`-Fenster und Kamera) für den Lehrbetrieb die pragmatischere Wahl ist.

**Falls jemand das später weiterverfolgen möchte**, wären die nächsten sinnvollen Schritte:  
- `EGL_LOG_LEVEL=debug` mit vollständiger (nicht gefilterter) Ausgabe analysieren, um die exakte Stelle des `dri2`-Fallbacks zu finden.  
- Prüfen, ob Mesas eigene generische Device-Enumeration (die offenbar *auch* die NVIDIA-Render-Nodes als "ihre" auflistet) mit der NVIDIA-ICD kollidiert, z. B. durch temporäres Entfernen/Umbenennen von `50_mesa.json`, um zu testen, ob VirtualGL dann eindeutig auf NVIDIA trifft.  
- Alternativ einen komplett anderen Architekturansatz testen: echter, GPU-gebundener, headless laufender `Xorg` mit NVIDIA-Treiber statt `Xvfb` + VirtualGL (deutlich invasiver, aber der von NVIDIA offiziell dokumentierte Weg für volles OpenGL-Rendering in Docker).  
