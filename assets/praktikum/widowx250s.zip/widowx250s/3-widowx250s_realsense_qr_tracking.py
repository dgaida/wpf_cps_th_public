#!/usr/bin/env python3
"""WidowX-250s Perception & Pick-and-Place Demo using Interbotix Perception Modules.

This script demonstrates camera-based object detection, AprilTag calibration, and
automated pick-and-place using a depth camera (e.g., Intel RealSense D435) with the
WidowX-250s (6DOF) robot arm.

Original Source:
    Interbotix Pick and Place Demo (`pick_place.py`):
    https://github.com/Interbotix/interbotix_ros_manipulators/blob/main/interbotix_ros_xsarms/interbotix_xsarm_perception/scripts/pick_place.py

Demonstration / Video Tutorial:
    Interbotix Perception & Camera Calibration / AprilTag Tracking Demo:
    https://www.youtube.com/watch?v=03BZ6PLFOac

Prerequisites:
    Before running this script, start the Interbotix perception launch file:
        ros2 launch interbotix_xsarm_perception xsarm_perception.launch.py robot_model:=wx250s
"""

import time
from typing import Any, Dict, List, Tuple

try:
    from interbotix_xs_modules.xs_arm import InterbotixManipulatorXS
except ImportError:
    try:
        from interbotix_xs_modules.arm import InterbotixManipulatorXS  # type: ignore
    except ImportError:
        InterbotixManipulatorXS = Any  # type: ignore

try:
    from interbotix_perception_modules.armtag import InterbotixArmTagInterface
except ImportError:
    InterbotixArmTagInterface = Any  # type: ignore

try:
    from interbotix_perception_modules.pointcloud import InterbotixPointCloudInterface
except ImportError:
    InterbotixPointCloudInterface = Any  # type: ignore


def main() -> None:
    """Executes camera calibration with ArmTag and automated Pick-and-Place for detected objects.

    Returns:
        None
    """
    robot_model = "wx250s"
    ref_frame = f"{robot_model}/base_link"

    print("==================================================================")
    print(f"   WidowX-250s Perception Pick-and-Place Demo ({robot_model})")
    print("==================================================================")
    print("Quelle: https://github.com/Interbotix/interbotix_ros_manipulators/blob/main/interbotix_ros_xsarms/interbotix_xsarm_perception/scripts/pick_place.py")
    print("Video:  https://www.youtube.com/watch?v=03BZ6PLFOac")
    print("==================================================================\n")

    print("Initialisiere Interbotix Manipulator & Perception Interface...")
    bot = InterbotixManipulatorXS(
        robot_model=robot_model,
        moving_time=1.5,
        accel_time=0.75,
    )
    pcl = InterbotixPointCloudInterface()
    armtag = InterbotixArmTagInterface()

    try:
        # 1. Startposition anfahren und Greifer öffnen
        print("Fahre in Ausgangsposition und oeffne den Greifer...")
        bot.arm.set_ee_pose_components(x=0.3, z=0.2)
        if hasattr(bot.gripper, "release"):
            bot.gripper.release()
        elif hasattr(bot.gripper, "open"):
            bot.gripper.open()

        # 2. ArmTag-Kalibrierung: Fahre zur AR-Tag Sichtposition und berechne Transformation
        print("Fahre zur ArmTag-Sichtposition (y=-0.3m, z=0.2m) zur Kamerakalibrierung...")
        bot.arm.set_ee_pose_components(y=-0.3, z=0.2)
        time.sleep(0.5)

        print("Bestimme Transformation zwischen Kamera und Roboterbasis...")
        armtag.find_ref_to_arm_base_transform()

        print("Rückkehr zur Bereitschaftsposition (x=0.3m, z=0.2m)...")
        bot.arm.set_ee_pose_components(x=0.3, z=0.2)

        # 3. Objekt-Cluster aus Pointcloud abrufen
        print(f"Erfasse Objekt-Cluster aus Punktwolke im Bezugssystem '{ref_frame}'...")
        result = pcl.get_cluster_positions(
            ref_frame=ref_frame,
            sort_axis="x",
            reverse=True,
        )

        clusters: List[Dict[str, Any]] = []
        if isinstance(result, tuple) and len(result) == 2:
            success, clusters = result
            if not success:
                print("Warnung: Punktwolken-Cluster konnten nicht erfolgreich abgerufen werden.")
        elif isinstance(result, list):
            clusters = result

        print(f"{len(clusters)} Objekt-Cluster gefunden.")

        # 4. Objekte nacheinander greifen und ablegen (Pick-and-Place)
        for idx, cluster in enumerate(clusters, start=1):
            pos = cluster.get("position", (0.0, 0.0, 0.0))
            x, y, z = pos[0], pos[1], pos[2]
            print(f"\n[Objekt {idx}/{len(clusters)}] Anfahren von Cluster-Position: x={x:.3f}m, y={y:.3f}m, z={z:.3f}m")

            # Vorposition oberhalb des Objekts
            bot.arm.set_ee_pose_components(x=x, y=y, z=z + 0.05, pitch=0.5)

            # Abstieg zum Objekt
            bot.arm.set_ee_pose_components(x=x, y=y, z=z, pitch=0.5)

            # Objekt greifen
            print("Greife Objekt...")
            if hasattr(bot.gripper, "grasp"):
                bot.gripper.grasp()
            elif hasattr(bot.gripper, "close"):
                bot.gripper.close()
            time.sleep(0.5)

            # Anheben des Objekts
            bot.arm.set_ee_pose_components(x=x, y=y, z=z + 0.05, pitch=0.5)

            # Transport zur Ablageposition
            print("Fahre zur Ablageposition...")
            bot.arm.set_ee_pose_components(x=0.3, z=0.2)

            # Objekt ablegen
            print("Legen Objekt ab...")
            if hasattr(bot.gripper, "release"):
                bot.gripper.release()
            elif hasattr(bot.gripper, "open"):
                bot.gripper.open()
            time.sleep(0.5)

        print("\nPick-and-Place Vorgang erfolgreich abgeschlossen!")

    except KeyboardInterrupt:
        print("\nProgrammabbruch durch Benutzer.")
    except Exception as e:
        print(f"\nFehler beim Ausfuehren der Perception Pick-and-Place Demo: {e}")
    finally:
        # 5. Sicheres Parken in Sleep-Position
        print("Parke Roboterarm in Sleep-Position...")
        try:
            bot.arm.go_to_sleep_pose()
        except Exception as e:
            print(f"Warnung beim Anfahren der Sleep-Pose: {e}")
        print("Skript beendet.")


if __name__ == "__main__":
    main()
