#!/usr/bin/env python3
"""WidowX-250s Roboterarm (6DOF) — Kameraeinbindung & QR-Code Tracking.

Wichtig: Vor Ausführung dieses Skripts muss der ROS 2 Treiber gestartet werden:
    ros2 launch interbotix_xsarm_control xsarm_control.launch.py robot_model:=wx250s
"""

import sys
import time
from typing import List, Tuple
import numpy as np

try:
    import cv2
except ImportError:
    cv2 = None

from interbotix_xs_modules.xs_robot.arm import InterbotixManipulatorXS
from src.realsense_qr_tracker import CameraStreamHandler, capture_and_log_pose


def main() -> None:
    """Executes camera alignment, moves robot along waypoints, tracks QR codes, and logs poses."""
    window_name = "Camera Stream / QR Tracking"

    # 1. Kamerastream initialisieren
    print("Initialisiere Kamerastream...")
    camera = CameraStreamHandler()

    # 2. Vorschau & Kameraausrichtung vor Roboterbewegung
    print("\n--- Kameraausrichtung ---")
    print("Der Kamera-Frame wird im Fenster angezeigt.")
    print("Richten Sie die Kamera aus. Druecken Sie 'q' oder Enter im Fenster (oder Ctrl+C im Terminal), um fortzufahren.")

    try:
        while True:
            frame = camera.get_frame()
            if frame is None:
                frame = np.zeros((480, 640, 3), dtype=np.uint8)
                if cv2 is not None:
                    cv2.putText(
                        frame,
                        "Kamera-Stream nicht verfuegbar",
                        (50, 240),
                        cv2.FONT_HERSHEY_SIMPLEX,
                        0.8,
                        (255, 255, 255),
                        2,
                    )
                annotated_frame = frame
            else:
                annotated_frame, qr_text, _ = camera.process_qr_code(frame)

            if cv2 is not None:
                overlay_text = "Kamera ausrichten - 'q' oder Enter zum Starten"
                cv2.rectangle(annotated_frame, (10, 10), (630, 45), (0, 0, 0), -1)
                cv2.putText(
                    annotated_frame,
                    overlay_text,
                    (15, 35),
                    cv2.FONT_HERSHEY_SIMPLEX,
                    0.5,
                    (0, 255, 255),
                    1,
                )
                cv2.imshow(window_name, annotated_frame)
                key = cv2.waitKey(30) & 0xFF
                if key in (ord("q"), 13, 10, 27):  # 'q', Enter, ESC
                    print("Kameraausrichtung abgeschlossen.")
                    break
            else:
                # Fallback, falls kein GUI-Support vorhanden ist
                time.sleep(2.0)
                break
    except KeyboardInterrupt:
        print("\nAbbruch der Ausrichtung durch Benutzer.")

    # 3. Roboterarm initialisieren
    print("\nInitialisiere WidowX-250s Roboterarm...")
    try:
        bot = InterbotixManipulatorXS(
            robot_model="wx250s",
            group_name="arm",
            gripper_name="gripper",
        )
        print("Roboterarm erfolgreich initialisiert.")
    except Exception as e:
        print(f"Fehler bei der Roboterinitialisierung: {e}")
        camera.release()
        if cv2 is not None:
            cv2.destroyAllWindows()
        sys.exit(1)

    try:
        # 4. Roboter in Auskunftsposition (Home) bewegen
        print("\nFahre in Home-Position...")
        bot.arm.go_to_home_pose()
        time.sleep(2.0)

        # Ziel-Positionen (x, y, z) im Weltkoordinatensystem
        target_waypoints: List[Tuple[float, float, float]] = [
            (0.30, 0.00, 0.20),
            (0.35, 0.10, 0.25),
            (0.35, -0.10, 0.25),
            (0.25, 0.00, 0.15),
        ]

        print("\n--- Start der Roboterbewegung mit QR-Tracking & Positions-Logging ---")
        for idx, (x_target, y_target, z_target) in enumerate(target_waypoints, start=1):
            print(
                f"\n[Schritt {idx}/{len(target_waypoints)}] Anfahren von Ziel-Pose: "
                f"x={x_target:.2f}m, y={y_target:.2f}m, z={z_target:.2f}m"
            )

            # Bewegungskommando absetzen
            bot.arm.set_ee_pose_components(
                x=x_target, y=y_target, z=z_target, pitch=0.5
            )

            # Während der Roboter sich stabilisiert, kontinuierlich Kameraframes lesen & Pose protokollieren
            for sub_step in range(15):
                qr_found, current_pose = capture_and_log_pose(
                    camera_handler=camera,
                    bot=bot,
                    window_name=window_name,
                )
                if qr_found and current_pose is not None:
                    print(
                        f"   -> QR-Code erkannt: '{qr_found}' bei Position "
                        f"({current_pose[0, 3]:.3f}, {current_pose[1, 3]:.3f}, {current_pose[2, 3]:.3f})"
                    )
                time.sleep(0.1)

            time.sleep(1.0)

        print("\nTrajektorie erfolgreich abgeschlossen!")

    except KeyboardInterrupt:
        print("\nProgrammabbruch durch Benutzer.")
    finally:
        # 5. Sicheres Parken & Aufräumen
        print("\nParke Roboterarm in Sleep-Position...")
        try:
            bot.arm.go_to_sleep_pose()
        except Exception as e:
            print(f"Warnung beim Anfahren der Sleep-Pose: {e}")

        camera.release()
        if cv2 is not None:
            cv2.destroyAllWindows()
        print("Uebung erfolgreich beendet.")


if __name__ == "__main__":
    main()
