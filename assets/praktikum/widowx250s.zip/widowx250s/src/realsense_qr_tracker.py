"""RealSense and camera QR code tracking module for WidowX-250s."""

import time
from typing import Any, Optional, Tuple
import numpy as np

try:
    import cv2
except ImportError:
    cv2 = None  # type: ignore

try:
    import pyrealsense2 as rs
    REALSENSE_AVAILABLE = True
except ImportError:
    rs = None  # type: ignore
    REALSENSE_AVAILABLE = False


class CameraStreamHandler:
    """Handler for capturing camera frames (RealSense or USB webcam) and detecting QR codes.

    Attributes:
        width (int): Frame width in pixels.
        height (int): Frame height in pixels.
        fps (int): Frame rate per second.
        is_realsense (bool): Whether an active RealSense pipeline is used.
        pipeline (Optional[Any]): The RealSense pipeline instance if available.
        cap (Optional[Any]): The OpenCV VideoCapture instance if standard webcam is used.
        qr_detector (Optional[Any]): OpenCV QRCodeDetector instance.
    """

    def __init__(self, width: int = 640, height: int = 480, fps: int = 30) -> None:
        """Initializes the camera stream handler and starts the camera stream.

        Args:
            width (int): Video frame width. Defaults to 640.
            height (int): Video frame height. Defaults to 480.
            fps (int): Frame rate. Defaults to 30.
        """
        self.width: int = width
        self.height: int = height
        self.fps: int = fps
        self.is_realsense: bool = False
        self.pipeline: Optional[Any] = None
        self.cap: Optional[Any] = None
        self.qr_detector: Optional[Any] = cv2.QRCodeDetector() if cv2 is not None else None

        self._initialize_camera()

    def _initialize_camera(self) -> None:
        """Initializes the RealSense camera or falls back to an OpenCV webcam."""
        if REALSENSE_AVAILABLE and rs is not None:
            try:
                self.pipeline = rs.pipeline()
                config = rs.config()
                config.enable_stream(
                    rs.stream.color, self.width, self.height, rs.format.bgr8, self.fps
                )
                self.pipeline.start(config)
                self.is_realsense = True
                print("Intel RealSense Kamera erfolgreich gestartet.")
                return
            except Exception as e:
                print(f"RealSense konnte nicht gestartet werden ({e}). Versuche OpenCV VideoCapture...")
                self.pipeline = None

        if cv2 is not None:
            self.cap = cv2.VideoCapture(0)
            if self.cap.isOpened():
                print("Standard USB-Kamera via OpenCV gestartet.")
            else:
                print("Warnung: Keine physikalische Kamera gefunden.")

    def get_frame(self) -> Optional[np.ndarray]:
        """Captures the current color frame from the active camera as a BGR NumPy array.

        Returns:
            Optional[np.ndarray]: Current frame array, or None if frame capture fails.
        """
        if self.is_realsense and self.pipeline:
            try:
                frames = self.pipeline.wait_for_frames()
                color_frame = frames.get_color_frame()
                if not color_frame:
                    return None
                return np.asanyarray(color_frame.get_data())
            except Exception as e:
                print(f"Fehler beim Abrufen des RealSense-Frames: {e}")
                return None
        elif self.cap and self.cap.isOpened():
            ret, frame = self.cap.read()
            return frame if ret else None
        return None

    def process_qr_code(
        self, frame: np.ndarray
    ) -> Tuple[np.ndarray, Optional[str], Optional[np.ndarray]]:
        """Detects and decodes QR codes, ArUco, or AprilTag markers in the given frame and draws bounding boxes.

        Args:
            frame (np.ndarray): Input BGR image frame.

        Returns:
            Tuple[np.ndarray, Optional[str], Optional[np.ndarray]]:
                - Annotated image frame with bounding box and label if code/marker is detected.
                - Decoded QR code text payload or ArUco/AprilTag ID string, or None if no code found.
                - Bounding box corner points array, or None if no code found.
        """
        annotated_frame = frame.copy()
        if cv2 is None:
            return annotated_frame, None, None

        # 1. Standard QR code detector
        if self.qr_detector is not None:
            data, bbox, _ = self.qr_detector.detectAndDecode(frame)

            if bbox is not None and len(bbox) > 0 and data:
                pts = bbox.astype(int)
                n = len(pts[0])
                for i in range(n):
                    cv2.line(
                        annotated_frame,
                        tuple(pts[0][i]),
                        tuple(pts[0][(i + 1) % n]),
                        (0, 255, 0),
                        3,
                    )
                cv2.putText(
                    annotated_frame,
                    f"QR: {data}",
                    (pts[0][0][0], max(10, pts[0][0][1] - 10)),
                    cv2.FONT_HERSHEY_SIMPLEX,
                    0.6,
                    (0, 255, 0),
                    2,
                )
                return annotated_frame, data, pts

        # 2. ArUco / AprilTag marker detector (Fallback)
        if hasattr(cv2, "aruco"):
            aruco_dicts = [
                ("AprilTag 36h11", cv2.aruco.DICT_APRILTAG_36h11),
                ("ArUco 4x4", cv2.aruco.DICT_4X4_50),
                ("AprilTag 16h5", cv2.aruco.DICT_APRILTAG_16h5),
                ("ArUco 6x6", cv2.aruco.DICT_6X6_250),
                ("ArUco Original", cv2.aruco.DICT_ARUCO_ORIGINAL),
            ]
            for name, dict_id in aruco_dicts:
                try:
                    dictionary = cv2.aruco.getPredefinedDictionary(dict_id)
                    if hasattr(cv2.aruco, "ArucoDetector"):
                        detector = cv2.aruco.ArucoDetector(
                            dictionary, cv2.aruco.DetectorParameters()
                        )
                        corners, ids, _ = detector.detectMarkers(frame)
                    else:
                        corners, ids, _ = cv2.aruco.detectMarkers(frame, dictionary)

                    if ids is not None and len(ids) > 0:
                        tag_ids = ids.flatten()
                        detected_text = f"{name} ID: {tag_ids[0]}"
                        pts = corners[0].astype(int)
                        n = len(pts[0])
                        for i in range(n):
                            cv2.line(
                                annotated_frame,
                                tuple(pts[0][i]),
                                tuple(pts[0][(i + 1) % n]),
                                (0, 255, 0),
                                3,
                            )
                        cv2.putText(
                            annotated_frame,
                            detected_text,
                            (pts[0][0][0], max(10, pts[0][0][1] - 10)),
                            cv2.FONT_HERSHEY_SIMPLEX,
                            0.6,
                            (0, 255, 0),
                            2,
                        )
                        return annotated_frame, detected_text, pts
                except Exception:
                    continue

        return annotated_frame, None, None

    def release(self) -> None:
        """Releases camera resources and stops active pipelines."""
        if self.is_realsense and self.pipeline:
            try:
                self.pipeline.stop()
            except Exception as e:
                print(f"Fehler beim Stoppen des RealSense-Streams: {e}")
        if self.cap:
            self.cap.release()
        print("Kamera erfolgreich freigegeben.")


def capture_and_log_pose(
    camera_handler: CameraStreamHandler,
    bot: Any,
    window_name: str = "Camera Stream / QR Tracking",
) -> Tuple[Optional[str], Optional[np.ndarray]]:
    """Captures a camera frame, performs QR code detection, logs the end-effector pose, and updates OpenCV window.

    Args:
        camera_handler (CameraStreamHandler): Initialized camera handler instance.
        bot (Any): Initialized InterbotixManipulatorXS robot instance.
        window_name (str): Name of the OpenCV window to render image in. Defaults to "Camera Stream / QR Tracking".

    Returns:
        Tuple[Optional[str], Optional[np.ndarray]]:
            - Decoded QR code text if detected, otherwise None.
            - 4x4 homogeneous matrix T_w_ee representing end-effector pose, or None if query fails.
    """
    frame = camera_handler.get_frame()
    qr_text = None

    if frame is None:
        frame = np.zeros((480, 640, 3), dtype=np.uint8)
        if cv2 is not None:
            cv2.putText(
                frame,
                "Kamera-Stream nicht verfuegbar",
                (50, 240),
                cv2.FONT_HERSHEY_SIMPLEX,
                0.8,
                (255, 255, 255),
                2,
            )
        annotated_frame = frame
    else:
        annotated_frame, qr_text, _ = camera_handler.process_qr_code(frame)

    T_w_ee = None
    if bot is not None and hasattr(bot, "arm") and hasattr(bot.arm, "get_ee_pose"):
        try:
            T_w_ee = bot.arm.get_ee_pose()
            x_m = T_w_ee[0, 3]
            y_m = T_w_ee[1, 3]
            z_m = T_w_ee[2, 3]

            if cv2 is not None:
                info_str = f"EE-Pos: X={x_m:.3f}m | Y={y_m:.3f}m | Z={z_m:.3f}m"
                cv2.rectangle(annotated_frame, (10, 10), (630, 45), (0, 0, 0), -1)
                cv2.putText(
                    annotated_frame,
                    info_str,
                    (15, 35),
                    cv2.FONT_HERSHEY_SIMPLEX,
                    0.5,
                    (0, 255, 255),
                    1,
                )
        except Exception as e:
            print(f"Fehler beim Auslesen der Pose: {e}")

    if cv2 is not None:
        try:
            cv2.imshow(window_name, annotated_frame)
            cv2.waitKey(1)
        except cv2.error:
            pass

    return qr_text, T_w_ee
