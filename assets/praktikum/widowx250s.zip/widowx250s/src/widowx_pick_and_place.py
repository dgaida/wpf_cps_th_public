"""Pick-and-place controller module for WidowX-250s robot arm."""

import time
from typing import Any, Tuple

try:
    from interbotix_xs_modules.xs_arm import InterbotixManipulatorXS
except ImportError:
    InterbotixManipulatorXS = Any  # type: ignore


class WidowXPickAndPlace:
    """Controller for executing Pick-and-Place operations with WidowX-250s robot arm.

    Attributes:
        bot (InterbotixManipulatorXS): The initialized Interbotix robot arm instance.
        hover_offset (float): Vertical offset in meters for safe pre-pick and pre-place poses.
    """

    def __init__(
        self,
        robot_instance: InterbotixManipulatorXS,
        hover_offset: float = 0.1,
    ) -> None:
        """Initializes the Pick-and-Place controller.

        Args:
            robot_instance (InterbotixManipulatorXS): Configured robot arm instance.
            hover_offset (float): Safe approach height above pick/place positions in meters.
        """
        self.bot: InterbotixManipulatorXS = robot_instance
        self.hover_offset: float = hover_offset

    def pick(
        self,
        x: float,
        y: float,
        z: float,
        pitch: float = 0.5,
    ) -> bool:
        """Executes the pick sequence at the given target coordinates.

        The pick sequence must be performed in the following step-by-step order:
        1. Open the gripper before approaching (via `self.bot.gripper.release()`).
        2. Approach the pre-pick pose hovering at a safe height above the target:
           `(x, y, z + self.hover_offset)` with the given `pitch` angle using
           `self.bot.arm.set_ee_pose_components()`. If this pose cannot be reached,
           return False.
        3. Descend vertically to the target pick pose `(x, y, z)` with `pitch`.
           If this pose cannot be reached, return False.
        4. Grasp the object (via `self.bot.gripper.grasp()`).
        5. Retract back up to the hover pose `(x, y, z + self.hover_offset)` with `pitch`.
        6. Return True upon successful completion.

        Args:
            x (float): Target X coordinate in WCS meters (relative to base_link).
            y (float): Target Y coordinate in WCS meters (relative to base_link).
            z (float): Target Z coordinate in WCS meters (relative to base_link).
            pitch (float): Pitch orientation of end-effector in radians.

        Returns:
            bool: True if the pick operation succeeded, False otherwise.
        """
        raise NotImplementedError("Soll von den Studierenden implementiert werden.")

    def place(
        self,
        x: float,
        y: float,
        z: float,
        pitch: float = 0.5,
    ) -> bool:
        """Executes the place sequence at the given target coordinates.

        The place sequence must be performed in the following step-by-step order:
        1. Approach the pre-place pose hovering at a safe height above the target:
           `(x, y, z + self.hover_offset)` with the given `pitch` angle using
           `self.bot.arm.set_ee_pose_components()`. If this pose cannot be reached,
           return False.
        2. Descend vertically to the target place pose `(x, y, z)` with `pitch`.
           If this pose cannot be reached, return False.
        3. Release the object (via `self.bot.gripper.release()`).
        4. Retract back up to the hover pose `(x, y, z + self.hover_offset)` with `pitch`.
        5. Return True upon successful completion.

        Args:
            x (float): Target X coordinate in WCS meters (relative to base_link).
            y (float): Target Y coordinate in WCS meters (relative to base_link).
            z (float): Target Z coordinate in WCS meters (relative to base_link).
            pitch (float): Pitch orientation of end-effector in radians.

        Returns:
            bool: True if the place operation succeeded, False otherwise.
        """
        raise NotImplementedError("Soll von den Studierenden implementiert werden.")

    def execute_pick_and_place(
        self,
        pick_pos: Tuple[float, float, float],
        place_pos: Tuple[float, float, float],
    ) -> bool:
        """Runs a full Pick-and-Place sequence from pick_pos to place_pos.

        Args:
            pick_pos (Tuple[float, float, float]): Coordinates (x, y, z) for object pickup.
            place_pos (Tuple[float, float, float]): Coordinates (x, y, z) for object placement.

        Returns:
            bool: True if entire sequence completed, False otherwise.
        """
        # Step 1: Move to home pose first
        self.bot.arm.go_to_home_pose()

        # Step 2: Execute pick
        success_pick: bool = self.pick(
            x=pick_pos[0], y=pick_pos[1], z=pick_pos[2]
        )
        if not success_pick:
            print("Pick failed! Aborting process.")
            return False

        # Step 3: Execute place
        success_place: bool = self.place(
            x=place_pos[0], y=place_pos[1], z=place_pos[2]
        )
        if not success_place:
            print("Place failed!")
            return False

        # Step 4: Return safely to home pose
        self.bot.arm.go_to_home_pose()
        print("Full Pick-and-Place process completed successfully!")
        return True
