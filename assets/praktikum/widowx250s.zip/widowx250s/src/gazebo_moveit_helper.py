"""Helper module for controlling WidowX-250s in Gazebo and MoveIt via ROS 2 action interfaces."""

from typing import Any, List

try:
    import rclpy
    from control_msgs.action import FollowJointTrajectory
    from trajectory_msgs.msg import JointTrajectoryPoint
except ImportError:
    rclpy = Any  # type: ignore

    class FollowJointTrajectory:  # type: ignore
        """Fallback class when ROS 2 control_msgs is not available in non-ROS environment."""

        class Goal:
            """Fallback Goal class."""

            def __init__(self) -> None:
                """Initializes dummy goal trajectory."""

                class Trajectory:
                    joint_names: List[str] = []
                    points: List[Any] = []

                self.trajectory = Trajectory()

    class JointTrajectoryPoint:  # type: ignore
        """Fallback class when ROS 2 trajectory_msgs is not available in non-ROS environment."""

        def __init__(self) -> None:
            """Initializes dummy trajectory point."""
            self.positions: List[float] = []

            class TimeFromStart:
                sec: int = 0
                nanosec: int = 0

            self.time_from_start = TimeFromStart()


ARM_JOINTS: List[str] = [
    "waist",
    "shoulder",
    "elbow",
    "forearm_roll",
    "wrist_angle",
    "wrist_rotate",
]


def move_arm(
    arm_client: Any,
    node: Any,
    joint_positions: List[float],
    duration_sec: float = 3.0,
) -> Any:
    """Moves the arm to the specified joint angles (radians) via the arm_controller action client.

    Args:
        arm_client (Any): ROS 2 ActionClient for FollowJointTrajectory (/wx250s/arm_controller).
        node (Any): ROS 2 Node instance for spin_until_future_complete.
        joint_positions (List[float]): Target angles in radians in the same order as ARM_JOINTS.
        duration_sec (float): Motion trajectory duration in seconds. Defaults to 3.0.

    Returns:
        Any: Result object from the ROS 2 action call.
    """
    goal = FollowJointTrajectory.Goal()
    goal.trajectory.joint_names = ARM_JOINTS

    point = JointTrajectoryPoint()
    point.positions = joint_positions
    point.time_from_start.sec = int(duration_sec)
    point.time_from_start.nanosec = int((duration_sec % 1) * 1e9)
    goal.trajectory.points = [point]

    future = arm_client.send_goal_async(goal)
    rclpy.spin_until_future_complete(node, future)
    goal_handle = future.result()

    result_future = goal_handle.get_result_async()
    rclpy.spin_until_future_complete(node, result_future)
    return result_future.result()


def move_gripper(
    gripper_client: Any,
    node: Any,
    left_finger_position: float,
    duration_sec: float = 1.0,
) -> Any:
    """Opens or closes the gripper via the gripper_controller action client.

    Args:
        gripper_client (Any): ROS 2 ActionClient for FollowJointTrajectory (/wx250s/gripper_controller).
        node (Any): ROS 2 Node instance for spin_until_future_complete.
        left_finger_position (float): Target position of the left finger in meters
            (e.g., 0.037 for open, 0.015 for closed). The right finger automatically
            moves in the opposite direction (-left_finger_position).
        duration_sec (float): Motion trajectory duration in seconds. Defaults to 1.0.

    Returns:
        Any: Result object from the ROS 2 action call.
    """
    goal = FollowJointTrajectory.Goal()
    goal.trajectory.joint_names = ["left_finger", "right_finger"]

    point = JointTrajectoryPoint()
    point.positions = [left_finger_position, -left_finger_position]
    point.time_from_start.sec = int(duration_sec)
    point.time_from_start.nanosec = int((duration_sec % 1) * 1e9)
    goal.trajectory.points = [point]

    future = gripper_client.send_goal_async(goal)
    rclpy.spin_until_future_complete(node, future)
    goal_handle = future.result()

    result_future = goal_handle.get_result_async()
    rclpy.spin_until_future_complete(node, result_future)
    return result_future.result()
