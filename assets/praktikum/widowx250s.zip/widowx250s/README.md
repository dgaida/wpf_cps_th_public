# WidowX-250s Roboterarm (6DOF) — Praktikum Cyber-physische Systeme (CPS)

Dieses Verzeichnis enthält die Praktikumsunterlagen, Anleitungen und Codebeispiele für den **WidowX-250 Robot Arm 6DOF (`wx250s`)** von Interbotix / Trossen Robotics.

---

## 🤖 Roboter-Informationen & Spezifikationen

Der WidowX-250s ist ein hochpräziser 6-Achs-Roboterarm (6 Degrees of Freedom) mit Dynamixel-Servomotoren der X-Serie und einem elektrischen Parallelgreifer.

| Parameter | Wert / Spezifikation |
|-----------|----------------------|
| **Modellbezeichnung** | WidowX-250 Robot Arm 6DOF |
| **Modell-Codename** | `wx250s` |
| **Freiheitsgrade (DOF)** | 6 Gelenke + 1 Greifer |
| **Gelenke** | `waist`, `shoulder`, `elbow`, `forearm_roll`, `wrist_angle`, `wrist_rotate` |
| **Reichweite** | ca. 650 mm |
| **Nutzlast (Payload)** | 250 g |
| **Steuerung** | ROS 2 (Humble) via Interbotix XS Driver & Python API |

> **Hinweis zur Hardware:** Der Roboter hat keinen eigenen Ein-/Ausschalter. Sobald er per USB-Kabel an den PC angeschlossen ist, ist er eingeschaltet.

---

## 📚 Dokumentation & Installation

Ausführliche Anleitungen befinden sich im Ordner [`docs/`](./docs/):

- 🛠️ [**`docs/01_installation.md`**](./docs/01_installation.md): Installation & Einrichtung der Python-Umgebung und ROS 2 Interbotix SDK.  
- 🐳 [**`docs/02_docker_container.md`**](./docs/02_docker_container.md): Nutzung der vorgefertigten Docker-Simulationsumgebung (ROS 2 Humble / Gazebo / noVNC).  

---

## 🐳 Docker Container Simulation

Für die Arbeit ohne reale Roboter-Hardware oder lokale ROS 2 Installation steht ein Docker-Container bereit:

```bash
cd docker_container
docker compose up --build
```

Greifen Sie anschließend im Browser auf **[http://localhost:8080](http://localhost:8080)** zu, um die Gazebo/RViz2-Simulation über noVNC zu bedienen.

---

## 🚀 Steuerung & ROS 2 Launch Commands

Vor der Ausführung von Python-Skripten muss der ROS 2 Treiber gestartet werden.

### 1. Starten der Robotersteuerung

**A) Realer Roboter im Labor:**
```bash
ros2 launch interbotix_xsarm_control xsarm_control.launch.py robot_model:=wx250s
```

**B) Simulation (Gazebo & RViz):**
```bash
ros2 launch interbotix_xsarm_sim xsarm_sim.launch.py robot_model:=wx250s use_sim:=true
```

> **Wichtiger Hinweis:** Bevor man die Konsole schließt, in der `ros2 launch ...` ausgeführt wurde, bzw. bevor man diesen Aufruf beendet, unbedingt den Roboter in die Sleep-Position (`bot.arm.go_to_sleep_pose()`) zurückfahren, da sonst der Greifer/Arm herunterfällt.

---

## ⚡ Drehmomentsteuerung (Torque Enable / Disable)

Über den ROS 2 Service `/wx250s/torque_enable` können die Motoren stromlos geschaltet werden, um den Arm manuell zu führen oder im Notfall freizugeben.

### Drehmoment deaktivieren (Freilauf)
```bash
ros2 service call /wx250s/torque_enable interbotix_xs_msgs/srv/TorqueEnable "{cmd_type: 'group', name: 'all', enable: false}"
```

### Drehmoment aktivieren
```bash
ros2 service call /wx250s/torque_enable interbotix_xs_msgs/srv/TorqueEnable "{cmd_type: 'group', name: 'all', enable: true}"
```

> *Tipp:* Um nur die Armgelenke ohne den Greifer stromlos zu schalten, ersetzen Sie `'all'` durch `'arm'`.

---

## 📓 Praktikumsaufgabe: Jupyter Notebook

Das Hauptpraktikum befindet sich im nachfolgenden Jupyter Notebook:

- [📄 `1-widowx250s_erste_schritte.ipynb`](./1-widowx250s_erste_schritte.ipynb)  

### Themenbereiche des Notebooks  
1. **Initialisierung der Python API**: Einrichten der `InterbotixManipulatorXS` Instanz.  
2. **Vorwärtskinematik (Forward Kinematics)**: Anfahren von Home- und Sleep-Posen sowie gezielte Bewegung einzelner Gelenke (`waist`, `elbow`, etc.).  
3. **Inverse Kinematik (Inverse Kinematics)**: Kartesische Positionierung des Endeffektors im 3D-Raum ($x, y, z, \text{pitch}$).  
4. **Greifersteuerung**: Öffnen (`release()`), Schließen (`grasp()`) und Druckeinstellung des Parallelgreifers.  
5. **Pick-and-Place Aufgabenstellung**: Implementierung einer strukturierten Klasse `WidowXPickAndPlace` zur automatisierten Objekthandhabung.  

---

## 💻 Python Code-Beispiel

Ein minimales Skript zur Ansteuerung des WidowX-250s mit der Interbotix Python SDK:

```python
from interbotix_xs_modules.xs_arm import InterbotixManipulatorXS
import time

# 1. Roboter-Instanz initialisieren
bot = InterbotixManipulatorXS(
    robot_model="wx250s",
    group_name="arm",
    gripper_name="gripper"
)

# 2. In Home-Position fahren
bot.arm.go_to_home_pose()

# 3. Kartesische Zielposition anfahren (x=0.3m, y=0.0m, z=0.2m)
bot.arm.set_ee_pose_components(x=0.3, y=0.0, z=0.2, pitch=0.5)

# 4. Greifer bedienen
bot.gripper.release()
time.sleep(1.0)
bot.gripper.grasp()

# 5. Sichere Ruheposition anfahren
bot.arm.go_to_sleep_pose()
```

---

## 🧪 Unittests

Tests für das Modul `src/widowx_pick_and_place.py` befinden sich im Ordner `tests/`.

Ausführen der Tests:

```bash
pytest tests/
```
