# WidowX-250s Roboterarm (6DOF) — Praktikum Cyber-physische Systeme (CPS)

Dieses Verzeichnis enthält die Praktikumsunterlagen, Anleitungen und Codebeispiele für den **WidowX-250 Robot Arm 6DOF (`wx250s`)** von Interbotix / Trossen Robotics.

---

## 🤖 Roboter-Informationen & Spezifikationen

Der WidowX-250s ist ein hochpräziser 6-Achs-Roboterarm (6 Degrees of Freedom) mit Dynamixel-Servomotoren der X-Serie und einem elektrischen Parallelgreifer.

| Parameter | Wert / Spezifikation |
|-----------|----------------------|
| **Modellbezeichnung** | WidowX-250 Robot Arm 6DOF |
| **Modell-Codename** | `wx250s` |
| **Freiheitsgrade (DOF)** | 6 Gelenke + 1 Greifer |
| **Gelenke** | `waist`, `shoulder`, `elbow`, `forearm_roll`, `wrist_angle`, `wrist_rotate` |
| **Reichweite** | ca. 650 mm |
| **Nutzlast (Payload)** | 250 g |
| **Steuerung** | ROS 2 (Galactic auf Nvidia Jetson / Humble im Docker) via Interbotix XS Driver & Python API |

> **Hinweis zur Hardware:** Der Roboter hat keinen eigenen Ein-/Ausschalter. Sobald er per USB-Kabel an den PC angeschlossen ist, ist er eingeschaltet.

---

## 📚 Dokumentation & Installation

Ausführliche Anleitungen befinden sich im Ordner [`docs/`](./docs/):

- 🛠️ [**`docs/01_installation.md`**](./docs/01_installation.md): Installation & Einrichtung der Python-Umgebung und ROS 2 Interbotix SDK (ROS 2 Galactic auf Nvidia Jetson).  
- 🐳 [**`docs/02_docker_container.md`**](./docs/02_docker_container.md): Nutzung der vorgefertigten Docker-Simulationsumgebung (ROS 2 Humble / Gazebo / noVNC).  
- 📷 [**`docs/03_realsense_installation.md`**](./docs/03_realsense_installation.md): Installation & Einrichtung der Intel RealSense Kamera & Treiber (`librealsense2`, `pyrealsense2`).  
- 📝 [**`docs/04_aufgabe_realsense_qr_tracking.md`**](./docs/04_aufgabe_realsense_qr_tracking.md): Aufgabenstellung & Demonstration zur Kameraeinbindung, ArmTag-Kalibrierung & Perception Pick-and-Place.  

---

## 📷 Perception & Vision-Module (Interbotix Stack)

Für fortgeschrittene Bildverarbeitungs- und Wahrnehmungsaufgaben (wie 3D-Objekterkennung, AprilTag/AR-Tag-Tracking, Punktwolken-Filterung und kameragestütztes Pick-and-Place) bietet Interbotix spezialisierte ROS 2 Packages und Python-Bibliotheken:

- 📦 [**`interbotix_xsarm_perception` Package**](https://github.com/Interbotix/interbotix_ros_manipulators/tree/main/interbotix_ros_xsarms/interbotix_xsarm_perception): ROS 2 Perception-Paket für Interbotix X-Series Arme zur 3D-Pose-Schätzung von Objekten/Blöcken, AprilTag-Erkennung und Integration von Tiefenkameras (z. B. Intel RealSense D435).  
- 🐍 [**`interbotix_perception_modules` Toolbox**](https://github.com/Interbotix/interbotix_ros_toolboxes/tree/main/interbotix_perception_toolbox/interbotix_perception_modules): Python-Module für Kamerakalibrierung, Transformationen zwischen Kamera- und Roboter-Koordinatensystem sowie Punktwolkenverarbeitung (`ArmGraspPoseServer`, `ArmTagPoseServer`).  
- 🎬 [**Interbotix Tutorials: Perception Pipeline Tuning (Video)**](https://www.youtube.com/watch?v=UesfMYM4qcc): Video-Demonstration der visuellen Objekterkennung, Filterung und des automatisierten Sortierens mit Kalibrier-GUIs.  
- 🎬 [**Interbotix Tutorials: Python Perception (Video)**](https://www.youtube.com/watch?v=03BZ6PLFOac): Video-Demonstration der 3D-Kamerakalibrierung und Pose-Bestimmung mittels AprilTags / AR Tag Plate (Walkthrough für das Skript `3-widowx250s_realsense_qr_tracking.py`).  
- 💻 [**Original Interbotix Pick-and-Place Script (`pick_place.py`)**](https://github.com/Interbotix/interbotix_ros_manipulators/blob/main/interbotix_ros_xsarms/interbotix_xsarm_perception/scripts/pick_place.py): Vorlage des Herstellers Trossen Robotics für die Wahrnehmungs- und Greif-Demo.  

---

## 🐳 Docker Container Simulation

Für die Arbeit ohne reale Roboter-Hardware oder lokale ROS 2 Installation steht ein Docker-Container bereit:

```bash
cd docker_container
docker compose up --build
```

Greifen Sie anschließend im Browser auf **[http://localhost:8080](http://localhost:8080)** zu, um die Gazebo/RViz2-Simulation über noVNC zu bedienen.

---

## 🚀 Steuerung & ROS 2 Launch Commands

Vor der Ausführung von Python-Skripten muss der ROS 2 Treiber gestartet werden.

### 1. Starten der Robotersteuerung

**A) Realer Roboter im Labor:**
```bash
ros2 launch interbotix_xsarm_control xsarm_control.launch.py robot_model:=wx250s
```

**B) Simulation (Gazebo & RViz):**
```bash
ros2 launch interbotix_xsarm_sim xsarm_sim.launch.py robot_model:=wx250s use_sim:=true
```

**C) Perception Stack (Kamera, ArmTag & Punktwolken-Cluster):**
```bash
ros2 launch interbotix_xsarm_perception xsarm_perception.launch.py robot_model:=wx250s
```

**D) Perception Stack mit Kalibrier- & Tuning-GUIs:**
```bash
ros2 launch interbotix_xsarm_perception xsarm_perception.launch.py robot_model:=wx250s use_pointcloud_tuner_gui:=true use_armtag_tuner_gui:=true
```

> **Wichtiger Hinweis:** Bevor man die Konsole schließt, in der `ros2 launch ...` ausgeführt wurde, bzw. bevor man diesen Aufruf beendet, unbedingt den Roboter in die Sleep-Position (`bot.arm.go_to_sleep_pose()`) zurückfahren, da sonst der Greifer/Arm herunterfällt.

---

## ⚡ Drehmomentsteuerung (Torque Enable / Disable)

Über den ROS 2 Service `/wx250s/torque_enable` können die Motoren stromlos geschaltet werden, um den Arm manuell zu führen oder im Notfall freizugeben.

### Drehmoment deaktivieren (Freilauf)
```bash
ros2 service call /wx250s/torque_enable interbotix_xs_msgs/srv/TorqueEnable "{cmd_type: 'group', name: 'all', enable: false}"
```

### Drehmoment aktivieren
```bash
ros2 service call /wx250s/torque_enable interbotix_xs_msgs/srv/TorqueEnable "{cmd_type: 'group', name: 'all', enable: true}"
```

> *Tipp:* Um nur die Armgelenke ohne den Greifer stromlos zu schalten, ersetzen Sie `'all'` durch `'arm'`.

---

## 📓 Praktikumsaufgaben & Python-Skripte

Die Praktikumsaufgaben gliedern sich in folgende Materialien:

- [📄 `1-widowx250s_erste_schritte.ipynb`](./1-widowx250s_erste_schritte.ipynb): Grundlagen, Kinematik & Pick-and-Place  
- [🐍 `3-widowx250s_realsense_qr_tracking.py`](./3-widowx250s_realsense_qr_tracking.py): Perception & Pick-and-Place Demo mit Kamerakalibrierung (ArmTag), Punktwolken-Erkennung und automatischem Greifen  

### Themenbereiche des Hauptnotebooks (`1-widowx250s_erste_schritte.ipynb`)  
1. **Initialisierung der Python API**: Einrichten der `InterbotixManipulatorXS` Instanz.  
2. **Vorwärtskinematik (Forward Kinematics)**: Anfahren von Home- und Sleep-Posen sowie gezielte Bewegung einzelner Gelenke (`waist`, `elbow`, etc.).  
3. **Inverse Kinematik (Inverse Kinematics)**: Kartesische Positionierung des Endeffektors im 3D-Raum ($x, y, z, \text{pitch}$).  
4. **Greifersteuerung**: Öffnen (`release()`), Schließen (`grasp()`) und Druckeinstellung des Parallelgreifers.  
5. **Pick-and-Place Aufgabenstellung**: Implementierung einer strukturierten Klasse `WidowXPickAndPlace` zur automatisierten Objekthandhabung.  

---

## 💻 Python Code-Beispiel

Ein minimales Skript zur Ansteuerung des WidowX-250s mit der Interbotix Python SDK:

```python
from interbotix_xs_modules.xs_arm import InterbotixManipulatorXS
import time

# 1. Roboter-Instanz initialisieren
bot = InterbotixManipulatorXS(
    robot_model="wx250s",
    group_name="arm",
    gripper_name="gripper"
)

# 2. In Home-Position fahren
bot.arm.go_to_home_pose()

# 3. Kartesische Zielposition anfahren (x=0.3m, y=0.0m, z=0.2m)
bot.arm.set_ee_pose_components(x=0.3, y=0.0, z=0.2, pitch=0.5)

# 4. Greifer bedienen
bot.gripper.release()
time.sleep(1.0)
bot.gripper.grasp()

# 5. Sichere Ruheposition anfahren
bot.arm.go_to_sleep_pose()
```

---

## 🧪 Unittests

Tests für das Modul in `src/` (`widowx_pick_and_place.py`) befinden sich im Ordner `tests/`.

Ausführen der Tests:

```bash
pytest tests/
```

---

## 🛠️ Entwurfsstand / Entwicklungsstatus (Gazebo + Kamera)

- **`docker_container_gz_cam/` & `2-widowx250s_gazebo_moveit_cam.ipynb`**:  
  Diese Ordner bzw. Notebooks befinden sich noch in der Entwicklung und sind aktuell nicht voll funktionsfähig (Kamera-Rendering-/Display-Probleme unter Xvfb/Software-Rasterizer).  
  - **TODO:** Beheben des Kamera-Rendering-Fehlers im Docker-Container `docker_container_gz_cam/` (siehe `DOCKER_SETUP_GZ.md` in diesem Ordner für Detailanalysen zum GLX/Software-Rendering).  
  - **Zip-Export:** `docker_container_gz_cam/` und `2-widowx250s_gazebo_moveit_cam.ipynb` werden daher vorerst **nicht** in die zum Download bereitgestellte Zip-Datei (`widowx250s.zip`) gepackt.  
