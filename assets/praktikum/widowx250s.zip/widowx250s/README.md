# WidowX-250s Roboterarm (6DOF) — Praktikum Cyber-physische Systeme (CPS)

Dieses Verzeichnis enthält die Praktikumsunterlagen, Anleitungen und Codebeispiele für den **WidowX-250 Robot Arm 6DOF (`wx250s`)** von Interbotix / Trossen Robotics.

---

## 🤖 Roboter-Informationen & Spezifikationen

Der WidowX-250s ist ein hochpräziser 6-Achs-Roboterarm (6 Degrees of Freedom) mit Dynamixel-Servomotoren der X-Serie und einem elektrischen Parallelgreifer.

| Parameter | Wert / Spezifikation |
|-----------|----------------------|
| **Modellbezeichnung** | WidowX-250 Robot Arm 6DOF |
| **Modell-Codename** | `wx250s` |
| **Freiheitsgrade (DOF)** | 6 Gelenke + 1 Greifer |
| **Gelenke** | `waist`, `shoulder`, `elbow`, `forearm_roll`, `wrist_angle`, `wrist_rotate` |
| **Reichweite** | ca. 650 mm |
| **Nutzlast (Payload)** | 250 g |
| **Steuerung** | ROS 2 (Galactic auf Nvidia Jetson / Humble im Docker) via Interbotix XS Driver & Python API |

> **Hinweis zur Hardware:** Der Roboter hat keinen eigenen Ein-/Ausschalter. Sobald er per USB-Kabel an den PC angeschlossen ist, ist er eingeschaltet.

---

## 📓 Praktikumsaufgaben (Übersicht)

Das Praktikum gliedert sich in drei aufbauende Teilaufgaben:

### 1️⃣ [Teil 1: Erste Schritte, Kinematik & Pick-and-Place](./docs/01_aufgabe_erste_schritte.md)  
- **Materialien:** 📓 [`1-widowx250s_erste_schritte.ipynb`](./1-widowx250s_erste_schritte.ipynb) & 🐍 [`src/widowx_pick_and_place.py`](./src/widowx_pick_and_place.py)  
- **Inhalte:** Grundlagen der Interbotix Python API (`InterbotixManipulatorXS`), Vorwärts- und Inverse Kinematik, Greifersteuerung und Implementierung einer Pick-and-Place Klasse zur automatisierten Objekthandhabung.  
- **Anleitung & Details:** 📄 [Aufgabenbeschreibung Teil 1](./docs/01_aufgabe_erste_schritte.md)  

### 2️⃣ [Teil 2: Simulation in Gazebo & MoveIt](./docs/02_aufgabe_gazebo_moveit.md)  
- **Materialien:** 📓 [`2-widowx250s_gazebo_moveit.ipynb`](./2-widowx250s_gazebo_moveit.ipynb) & 🐍 [`src/gazebo_moveit_helper.py`](./src/gazebo_moveit_helper.py)  
- **Inhalte:** Trajektoriensteuerung in der Physiksimulation Gazebo und MoveIt über ROS 2 Action Interfaces (`FollowJointTrajectory`). Aufzeichnen von Posen ("Teach & Repeat") und automatische Pick-and-Place Ausführung.  
- **Anleitung & Details:** 📄 [Aufgabenbeschreibung Teil 2](./docs/02_aufgabe_gazebo_moveit.md)  

### 3️⃣ [Teil 3: RealSense Kamera, ArmTag & Perception Pick-and-Place](./docs/03_aufgabe_realsense_qr_tracking.md)  
- **Materialien:** 🐍 [`3-widowx250s_realsense_qr_tracking.py`](./3-widowx250s_realsense_qr_tracking.py)  
- **Inhalte:** Einbindung der Intel RealSense D435 Tiefenkamera, automatische Kamera-Roboter-Kalibrierung über ArmTags (`InterbotixArmTagInterface`), 3D-Punktwolken-Objekterkennung (`InterbotixPointCloudInterface`) und visuelles Pick-and-Place.  
- **Anleitung & Details:** 📄 [Aufgabenbeschreibung Teil 3](./docs/03_aufgabe_realsense_qr_tracking.md)  

---

## ⚠️ Wichtige Sicherheitshinweise & Drehmomentsteuerung

### ⚡ Drehmomentsteuerung (Torque Enable / Disable)
Über den ROS 2 Service `/wx250s/torque_enable` können die Motoren stromlos geschaltet werden, um den Arm manuell zu bewegen:

```bash
# Drehmoment aller Motoren deaktivieren (Freilauf)
ros2 service call /wx250s/torque_enable interbotix_xs_msgs/srv/TorqueEnable "{cmd_type: 'group', name: 'all', enable: false}"

# Drehmoment aller Motoren wieder aktivieren
ros2 service call /wx250s/torque_enable interbotix_xs_msgs/srv/TorqueEnable "{cmd_type: 'group', name: 'all', enable: true}"
```

> **WARNUNG (SEHR WICHTIG):**
> Bevor Sie das Drehmoment auf `enable: false` schalten, **müssen Sie den Roboterarm zwingend mit der Hand festhalten und abstützen!**
> Sobald das Drehmoment deaktiviert wird, schalten die Servomotoren ab und der Arm stürzt durch sein Eigengewicht ungebremst nach unten. Dies kann zu schweren Beschädigungen der Mechanik führen.

### 💤 Sleep-Position vor dem Beenden
Bevor Sie das Terminal schließen, in dem der ROS 2 Treiber läuft, fahren Sie den Roboterarm **immer** in die Ruheposition (`bot.arm.go_to_sleep_pose()`). Wenn das Terminal ohne Sleep-Position beendet wird, schalten die Motoren ab und der Arm fällt herab.

---

## 🚀 ROS 2 Launch Commands (Übersicht nach Teilaufgabe)

Je nach Teilaufgabe wird ein spezifisches ROS 2 Launchfile benötigt.

| Teilaufgabe | Zielumgebung | ROS 2 Launch Command | Beschreibung / Funktion |
|-------------|--------------|----------------------|-------------------------|
| **Teil 1** | Realer Roboter | `ros2 launch interbotix_xsarm_control xsarm_control.launch.py robot_model:=wx250s` | Startet den Hardware-Treiber-Node (`xs_sdk`) und ROS 2 Controllers für den physischen Roboterarm. |
| **Teil 1** | Simulation (RViz) | `ros2 launch interbotix_xsarm_sim xsarm_sim.launch.py robot_model:=wx250s use_sim:=true` | Startet den Treiber im Simulationsmodus und öffnet RViz zur Visualisierung. |
| **Teil 2** | Gazebo + MoveIt | `cd docker_container_gz && docker compose up --build` | Startet den Docker Container mit Gazebo-Physiksimulation, MoveIt und noVNC Web-Oberfläche. |
| **Teil 3** | Perception Stack | `ros2 launch interbotix_xsarm_perception xsarm_perception.launch.py robot_model:=wx250s rs_camera_depth_module_profile:=424x240x30` | Startet Kamera-Treiber, AprilTag-Erkennung, Punktwolken-Verarbeitung **UND** die Robotersteuerung. |

> **Wichtiger Hinweis zu Teil 3:**
> Das Perception-Launchfile `xsarm_perception.launch.py` startet den Roboterarm-Treiber (`xsarm_control`) bereits automatisch mit.
> **Achtung:** Es darf **kein** zusätzliches `xsarm_control.launch.py` im Hintergrund laufen! Falls `xsarm_control.launch.py` bereits aktiv ist, muss es vor dem Start von `xsarm_perception.launch.py` beendet werden.

---

## 📚 Dokumentation & Anleitungen

Auf dem Jetson-Steuerungsrechner im Labor ist die gesamte Software bereits vorinstalliert.

### 📄 Aufgaben- & Simulations-Dokumentationen (in [`docs/`](./docs/))  
- 📄 [**`docs/01_aufgabe_erste_schritte.md`**](./docs/01_aufgabe_erste_schritte.md): Aufgabenbeschreibung & Anleitung für Teil 1.  
- 📄 [**`docs/02_aufgabe_gazebo_moveit.md`**](./docs/02_aufgabe_gazebo_moveit.md): Aufgabenbeschreibung & Anleitung für Teil 2.  
- 📄 [**`docs/03_aufgabe_realsense_qr_tracking.md`**](./docs/03_aufgabe_realsense_qr_tracking.md): Aufgabenbeschreibung & Perception-Anleitung für Teil 3.  
- 🐳 [**`docs/02_docker_container.md`**](./docs/02_docker_container.md): Nutzung der vorgefertigten Docker-Simulationsumgebung.  

### 🛠️ Installations- & Setup-Guides (in [`docs/install/`](./docs/install/))  
- 🛠️ [**`docs/install/01_installation.md`**](./docs/install/01_installation.md): Installation & Einrichtung der Python-Umgebung und des Interbotix SDKs.  
- 📷 [**`docs/install/03_realsense_installation.md`**](./docs/install/03_realsense_installation.md): Treibereinrichtung für die Intel RealSense D435 Tiefenkamera.  
- 🛠️ [**`docs/install/05_realsense_pointcloud_fps_troubleshooting.md`**](./docs/install/05_realsense_pointcloud_fps_troubleshooting.md): Fehlerbehebung bei Pointcloud-Rechenlast & verdrängtem RealSense Color-Stream.  

---

## 💻 Python Code-Beispiel

Ein minimales Skript zur Ansteuerung des WidowX-250s mit der Interbotix Python SDK (Teil 1):

```python
from interbotix_xs_modules.xs_arm import InterbotixManipulatorXS
import time

# 1. Roboter-Instanz initialisieren
bot = InterbotixManipulatorXS(
    robot_model="wx250s",
    group_name="arm",
    gripper_name="gripper"
)

# 2. In Home-Position fahren
bot.arm.go_to_home_pose()

# 3. Kartesische Zielposition anfahren (x=0.3m, y=0.0m, z=0.2m)
bot.arm.set_ee_pose_components(x=0.3, y=0.0, z=0.2, pitch=0.5)

# 4. Greifer bedienen
bot.gripper.release()
time.sleep(1.0)
bot.gripper.grasp()

# 5. Sichere Ruheposition anfahren
bot.arm.go_to_sleep_pose()
```

---

## 🧪 Unittests

Tests für die Module in `src/` (`widowx_pick_and_place.py` & `gazebo_moveit_helper.py`) befinden sich im Ordner `tests/`.

Ausführen der Tests:

```bash
pytest tests/
```

---

## 🛠️ Entwurfsstand / Entwicklungsstatus (Gazebo + Kamera)

- **`docker_container_gz_cam/` & `2-widowx250s_gazebo_moveit_cam.ipynb`**:  
  Diese Ordner bzw. Notebooks befinden sich noch in der Entwicklung und sind aktuell nicht voll funktionsfähig (Kamera-Rendering-/Display-Probleme unter Xvfb/Software-Rasterizer).  
  - **Zip-Export:** `docker_container_gz_cam/` und `2-widowx250s_gazebo_moveit_cam.ipynb` werden daher vorerst **nicht** in die zum Download bereitgestellte Zip-Datei (`widowx250s.zip`) gepackt.  
