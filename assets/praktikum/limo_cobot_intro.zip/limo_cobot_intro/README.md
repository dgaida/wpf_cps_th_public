# LIMO Cobot – Einführendes Praktikum (Grundlagen & Demos)

Willkommen zum einführenden Praktikum für den **AgileX LIMO Cobot**!
Der LIMO Cobot besteht aus dem Fahrgestell LIMO Pro mit 2D-LiDAR und RGB-D-Kamera (Orbbec Dabai) sowie dem 6-Achs-Arm myCobot 280. Auf dem Onboard-PC laufen Ubuntu 20.04 mit **ROS 1 Noetic** und **ROS 2 Foxy**. Dieses Praktikum führt Sie schrittweise in die Inbetriebnahme, die Bedienung und erste Anwendungen (SLAM, Bildverarbeitung, Arm) ein.

---

## 🎯 Ziel des Praktikums

Sie machen sich mit der Hardware- und Softwareumgebung des LIMO Cobot vertraut. Sie bauen von einem Labor-PC eine Remote-Desktop-Verbindung (NoMachine) auf, steuern den Roboter mit der Tastatur über ROS, erstellen eine Karte mit dem LiDAR (SLAM), führen Farb- und Texterkennung mit der Kamera aus und bewegen den Roboterarm.

---

## 📺 Einsteigervideo & Offizielle Dokumentation

- 📄 **[LIMO Pro ROS 2 Foxy User Manual](<https://github.com/elephantrobotics/LIMO-Cobot-docs/blob/main/limo_pro/Limo%20Pro%20Ros2%20Foxy%20user%20manual(EN).md>)** (Elephant Robotics / AgileX): Befehle für ROS 2 (`ros2 launch`, `ros2 run`). Die Abschnittsnummern *(ROS 2)* unten beziehen sich darauf.  
- 📄 **[LIMO Pro User Manual (ROS 1)](<https://github.com/elephantrobotics/LIMO-Cobot-docs/blob/main/limo_pro/Limo%20Pro%20user%20manual(EN).md>)**: dieselben Demos für ROS 1 (`roslaunch`, `rosrun`), Abschnittsnummern *(ROS 1)*.  
- 🎥 **[AgileX Limo Getting Started Guide (YouTube, Trossen Robotics)](https://www.youtube.com/watch?v=7kkFirkSqE8)**  
- 🔗 **[AgileX LIMO Documentation (Trossen Robotics)](https://docs.trossenrobotics.com/agilex_limo_docs/index.html)**: gut bebilderte Tutorials zum LIMO. Die Befehle dort sind für ROS 1. Pfade und Zugangsdaten können abweichen, da sie für den LIMO mit Jetson Nano geschrieben sind.  

---

## ⚠️ Sicherheit

- Eine Person bleibt am Roboter, solange er fährt oder der Arm sich bewegt.  
- Fahren Sie langsam und nur auf freier Fläche. Niemand greift in den Arbeitsbereich des Arms, solange ein Programm läuft.  
- Akku beobachten: Leuchtet an der Akkuanzeige nur noch die letzte rote LED, Roboter laden.  
- Fahrgestell sofort stoppen:  

  ```bash
  ros2 topic pub /cmd_vel geometry_msgs/msg/Twist "{linear: {x: 0.0}, angular: {z: 0.0}}" --once   # ROS 2
  rostopic pub -1 /cmd_vel geometry_msgs/Twist "{linear: {x: 0.0}, angular: {z: 0.0}}"              # ROS 1
  ```

---

## 📋 Aufgabenstellung

### 1. Inbetriebnahme & Remote Access

- **Einschalten:** Power-Taste lange drücken. Die Farbe der Frontbeleuchtung zeigt den Fahrmodus (gelb: Differentialantrieb, grün: Ackermann, blau: Mecanum).  
  📖 *Manual:* Abschnitte 1.8 und 1.9 · *Trossen:* [First Time Use](https://docs.trossenrobotics.com/agilex_limo_docs/getting_started/first_time_use.html)  
- **Mit NoMachine verbinden:** Nutzen Sie einen Labor-PC, auf dem NoMachine installiert ist (z. B. PC DL1, Jetson GPU Cluster oder Jetson CPS 1242). Verbinden Sie sich von dort mit dem LIMO (Protokoll NX, Port 4000). IP-Adresse und Zugangsdaten finden sie auf Discord. Alternativ per SSH: `ssh -X <benutzer>@<ip>`.  
  📖 *Manual:* Abschnitt 1.10 · *Trossen:* [Remote Development](https://docs.trossenrobotics.com/agilex_limo_docs/getting_started/remote_dev.html)  
- **ROS 1 oder ROS 2 wählen:** Auf dem LIMO sind beide installiert. Jedes neue Terminal fragt nach `1` (ROS 1) oder `2` (ROS 2). Wählen Sie `2` für `ros2`-Befehle und `1` für `roscore`, `roslaunch` und `rosrun` (ROS 1 Manual, Trossen-Tutorials). ROS 1 und ROS 2 tauschen keine Topics aus, starten Sie deshalb alle Terminals einer Aufgabe mit derselben Auswahl.  

### 2. Steuerung mit der Tastatur

Öffnen Sie über NoMachine oder SSH drei Terminals auf dem LIMO (Auswahl `2`).

1. Fahrgestell und Sensorik starten (Terminal 1):  

   ```bash
   ros2 launch limo_bringup limo_start.launch.py
   ```

2. Tastatursteuerung starten (Terminal 2):  

   ```bash
   ros2 run teleop_twist_keyboard teleop_twist_keyboard
   ```

   Das Terminal mit der Tastatursteuerung muss aktiv sein (hineinklicken). `i` fährt vorwärts, `,` rückwärts, `j`/`l` drehen, `k` hält an. Mit `z` verringern und mit `q` erhöhen Sie die Geschwindigkeit. Fahren Sie zuerst langsam.  
3. Sehen Sie sich in Terminal 3 die gesendeten Kommandos und die Odometrie an:  

   ```bash
   ros2 topic echo /cmd_vel
   ros2 topic echo /odom --no-arr
   ```

Mit ROS 1 (Auswahl `1`): `roslaunch limo_base limo_base.launch` und `roslaunch limo_bringup limo_teletop_keyboard.launch`.
📖 *Manual:* Abschnitt 4.1 (ROS 2 und ROS 1)

### 3. LiDAR & SLAM (Kartierung mit Cartographer)

1. Fahrgestell und Sensorik starten (Terminal 1):  

   ```bash
   ros2 launch limo_bringup limo_start.launch.py
   ```

2. LiDAR-Daten ansehen (Terminal 2): `rviz2` starten, die Laserpunkte erscheinen in Grün. Danach RViz wieder schließen.  
3. Kartierung starten (Terminal 2):  

   ```bash
   ros2 launch limo_bringup cartographer.launch.py
   ```

4. Tastatursteuerung starten (Terminal 3, siehe Aufgabe 2) und den Roboter **langsam** durch das Testfeld fahren, bis die Karte in RViz vollständig ist.  
5. Karte speichern (Terminal 4), mit eigenem Namen statt `karte_team1`:  

   ```bash
   cd ~
   ros2 run nav2_map_server map_saver_cli -f karte_team1
   ```

   Es entstehen `karte_team1.pgm` (Bild) und `karte_team1.yaml` (Auflösung und Ursprung).

📖 *Manual:* Abschnitte 5.1 und 5.2 (ROS 2)

**Alternative mit ROS 1 (GMapping):** Terminals mit `1` starten, dann `roslaunch limo_bringup limo_start.launch pub_odom_tf:=false` und `roslaunch limo_bringup limo_gmapping.launch`, fahren mit `roslaunch limo_bringup limo_teletop_keyboard.launch`. Karte speichern mit `rosrun map_server map_saver -f karte_team1`.
📖 *Manual:* Abschnitt 5.2 (ROS 1) · *Trossen:* [Mapping using GMapping](https://docs.trossenrobotics.com/agilex_limo_docs/demos/slam_nav/gmapping.html)

### 4. Kamera & Bildverarbeitung (Farb- und Texterkennung)

Beenden Sie zuerst alle Programme aus Aufgabe 3 mit `Strg+C`.

1. Kamera starten (Terminal 1):  

   ```bash
   ros2 launch orbbec_camera dabai.launch.py
   ```

   Falls das nicht funktioniert: `ros2 launch astra_camera dabai.launch.py`. Warnungen zu nicht unterstützten Parametern können ignoriert werden.  
2. Bilder ansehen (Terminal 2): `rviz2` starten, *Fixed Frame* `camera_link`, eine *Image*-Anzeige mit dem Farbbild-Topic hinzufügen und *Reliability* auf *Best Effort* stellen. Fügen Sie zusätzlich eine *DepthCloud*-Anzeige hinzu. Die verfügbaren Topics zeigt `ros2 topic list | grep camera`.  
3. Farberkennung starten (Terminal 2, nach dem Schließen von RViz):  

   ```bash
   ros2 run limo_visions recognition
   ```

   Halten Sie farbige Gegenstände vor die Kamera und beobachten Sie, welche Farbbereiche markiert werden.

📖 *Manual:* Abschnitte 7.1, 7.2 und 8.1 (ROS 2)

**Texterkennung (ROS 1):** Beenden Sie alle Programme und öffnen Sie neue Terminals mit Auswahl `1`. Die Demo liest Buchstaben und Ziffern mit `pytesseract` aus dem Kamerabild.

```bash
roscore                            # Terminal 1
rosrun vision detect_node.py       # Terminal 2
rostopic echo /detect_word_reslut  # Terminal 3: erkannter Text
```

Halten Sie ein Blatt mit großer, gut lesbarer Schrift vor die Kamera.

📖 *Manual:* Abschnitt 8.1 (ROS 1) · *Trossen:* [Vision: Text Recognition](https://docs.trossenrobotics.com/agilex_limo_docs/demos/vision/text.html)

### 5. Roboterarm (myCobot 280)

Beenden Sie zuerst alle anderen Programme. Der Arm hängt an `/dev/ttyACM0`, kein anderes Programm darf den Port belegen.

1. **Modell folgt dem Arm:** Der Arm wird stromlos und lässt sich von Hand bewegen, das Modell in RViz bewegt sich mit. Halten Sie den Arm beim Start fest, er sackt dabei ab.  

   ```bash
   ros2 launch mycobot_280 mycobot_follow.launch.py port:=/dev/ttyACM0 baud:=115200
   ```

2. **Arm mit Schiebereglern steuern:** Bringen Sie den Arm vorher von Hand in eine aufrechte Position und bewegen Sie die Regler langsam.  

   ```bash
   ros2 launch mycobot_280 slider_control.launch.py port:=/dev/ttyACM0 baud:=115200
   ```

📖 *Manual:* Abschnitte 9.1 und 9.2 (ROS 2) bzw. 10.1 bis 10.3 (ROS 1, `roslaunch mycobot_280 ...`)

---

## 📑 Abgabe & Nachweis

Dokumentieren Sie die erfolgreiche Durchführung des Praktikums in Ihrem Praktikumsbericht:

- Screenshot der LiDAR-Daten in RViz und Bild der gespeicherten Karte (`.pgm`).  
- Screenshot von Farbbild und DepthCloud in RViz, der laufenden Farberkennung und des erkannten Texts.  
- Foto oder Screenshot des Arms mit dem mitbewegten Modell in RViz.  
