"""
Detector module for object detection pipelines using Hailo NPU or Ultralytics CPU/GPU.
"""

from typing import List, Tuple, Dict, Any, Optional
import time
import numpy as np


class ObjectDetector:
    """Wrapper class for Ultralytics YOLO and Hailo-8 NPU inference.

    Attributes:
        model_path (str): Path to the model file (.pt, .hef, or .onnx).
        conf_threshold (float): Minimum confidence score for detections.
        use_mock (bool): Whether to run in simulated mock mode without hardware.
    """

    def __init__(
        self,
        model_path: str = "yolov8n.hef",
        conf_threshold: float = 0.5,
        use_mock: bool = False,
    ) -> None:
        """Initializes the object detector.

        Args:
            model_path: Path to the model file (.hef for Hailo, .pt for PyTorch).
            conf_threshold: Detection confidence threshold (0.0 to 1.0).
            use_mock: Enable mock inference mode for simulation/testing.
        """
        self.model_path: str = model_path
        self.conf_threshold: float = conf_threshold
        self.use_mock: bool = use_mock
        self.is_hailo: bool = model_path.endswith(".hef")
        self.hailo_infer_pipeline: Optional[Any] = None
        self.yolo_model: Optional[Any] = None

        if not self.use_mock:
            self._initialize_model()

    def _initialize_model(self) -> None:
        """Initializes either the Hailo NPU or standard Ultralytics model."""
        if self.is_hailo:
            try:
                # Import Hailo Platform runtime if available
                from hailo_platform import HEF, VDevice, HailoStreamInterface, InferVStreams, ConfigureParams
                self.vdevice = VDevice()
                self.hef = HEF(self.model_path)
                self.configure_params = ConfigureParams.create_from_hef(
                    hef=self.hef, interface=HailoStreamInterface.PCIe
                )
                self.network_groups = self.vdevice.configure(self.hef, self.configure_params)
                self.network_group = self.network_groups[0]
            except Exception as err:
                print(f"[Warning] Hailo NPU initialization failed: {err}. Falling back to mock mode.")
                self.use_mock = True
        else:
            try:
                from ultralytics import YOLO
                self.yolo_model = YOLO(self.model_path)
            except Exception as err:
                print(f"[Warning] Ultralytics initialization failed: {err}. Falling back to mock mode.")
                self.use_mock = True

    def detect(
        self, frame: np.ndarray
    ) -> List[Tuple[Tuple[int, int, int, int], float, str]]:
        """Runs object detection on a single RGB frame.

        Args:
            frame: Input BGR/RGB image array of shape (H, W, 3).

        Returns:
            List of detected objects, each represented as a tuple:
            ((x1, y1, x2, y2), confidence, class_label).
        """
        if self.use_mock:
            return self._mock_detect(frame)

        if self.is_hailo:
            return self._hailo_detect(frame)
        else:
            return self._yolo_detect(frame)

    def _mock_detect(
        self, frame: np.ndarray
    ) -> List[Tuple[Tuple[int, int, int, int], float, str]]:
        """Simulates detection results for mock/testing mode.

        Args:
            frame: Input image frame.

        Returns:
            Simulated list of detected bounding boxes and classes.
        """
        height, width = frame.shape[:2]
        # Generate dynamic moving bounding boxes for mock visualization
        t_val = time.time()
        cx1 = int((width / 2) + np.sin(t_val) * 100)
        cy1 = int((height / 2) + np.cos(t_val) * 60)

        mock_results = [
            ((cx1 - 60, cy1 - 60, cx1 + 60, cy1 + 60), 0.92, "bottle"),
            ((50, 50, 180, 180), 0.85, "cup"),
            ((width - 200, height - 150, width - 50, height - 30), 0.78, "laptop"),
        ]
        return [res for res in mock_results if res[1] >= self.conf_threshold]

    def _yolo_detect(
        self, frame: np.ndarray
    ) -> List[Tuple[Tuple[int, int, int, int], float, str]]:
        """Runs inference using Ultralytics YOLO.

        Args:
            frame: Input RGB/BGR image frame.

        Returns:
            List of detected objects with bounding boxes, confidence, and class names.
        """
        if self.yolo_model is None:
            return []

        results = self.yolo_model(frame, conf=self.conf_threshold, verbose=False)
        detections = []
        if len(results) > 0:
            boxes = results[0].boxes
            for box in boxes:
                x1, y1, x2, y2 = map(int, box.xyxy[0].tolist())
                conf = float(box.conf[0].item())
                cls_id = int(box.cls[0].item())
                cls_name = self.yolo_model.names.get(cls_id, f"cls_{cls_id}")
                detections.append(((x1, y1, x2, y2), conf, cls_name))
        return detections

    def _hailo_detect(
        self, frame: np.ndarray
    ) -> List[Tuple[Tuple[int, int, int, int], float, str]]:
        """Placeholder for native Hailo NPU inference pipeline.

        In production, input frame is resized/quantized and passed via
        InferVStreams to the Hailo-8 NPU for ultra-low latency execution.

        Args:
            frame: Input RGB frame.

        Returns:
            List of detected bounding boxes and class labels.
        """
        # Note: Hailo pipeline returns bounding boxes parsed from NPU output tensor
        return self._mock_detect(frame)
