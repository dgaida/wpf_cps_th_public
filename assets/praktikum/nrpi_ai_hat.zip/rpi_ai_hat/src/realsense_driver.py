"""
Camera module for acquiring RGB streams from Intel RealSense D415 or OpenCV capture.
"""

from typing import Tuple, Optional
import numpy as np


class RealSenseCamera:
    """Wrapper class for Intel RealSense D415 camera stream.

    Attributes:
        width (int): Frame width in pixels.
        height (int): Frame height in pixels.
        fps (int): Target frame rate.
        use_mock (bool): Whether to simulate frame capture.
    """

    def __init__(
        self,
        width: int = 1280,
        height: int = 720,
        fps: int = 30,
        use_mock: bool = False,
    ) -> None:
        """Initializes the RealSense camera driver or mock capture.

        Args:
            width: Stream resolution width.
            height: Stream resolution height.
            fps: Frames per second.
            use_mock: Enable mock mode for testing without hardware.
        """
        self.width: int = width
        self.height: int = height
        self.fps: int = fps
        self.use_mock: bool = use_mock
        self.pipeline: Optional[Any] = None

        if not self.use_mock:
            self._initialize_realsense()

    def _initialize_realsense(self) -> None:
        """Initializes the pyrealsense2 pipeline."""
        try:
            import pyrealsense2 as rs
            self.rs = rs
            self.pipeline = rs.pipeline()
            config = rs.config()
            config.enable_stream(
                rs.stream.color, self.width, self.height, rs.format.bgr8, self.fps
            )
            self.pipeline.start(config)
        except Exception as err:
            print(f"[Warning] RealSense D415 camera initialization failed: {err}. Falling back to mock mode.")
            self.use_mock = True

    def get_frame(self) -> Tuple[bool, np.ndarray]:
        """Captures the next RGB frame from the camera stream.

        Returns:
            Tuple of (success_flag, image_array).
        """
        if self.use_mock or self.pipeline is None:
            return True, self._generate_mock_frame()

        try:
            frames = self.pipeline.wait_for_frames(timeout_ms=2000)
            color_frame = frames.get_color_frame()
            if not color_frame:
                return False, np.zeros((self.height, self.width, 3), dtype=np.uint8)
            color_image = np.asanyarray(color_frame.get_data())
            return True, color_image
        except Exception as err:
            print(f"[Error] RealSense frame read error: {err}")
            return False, np.zeros((self.height, self.width, 3), dtype=np.uint8)

    def _generate_mock_frame(self) -> np.ndarray:
        """Generates a synthetic color frame with background gradient.

        Returns:
            Generated image numpy array of shape (height, width, 3).
        """
        img = np.zeros((self.height, self.width, 3), dtype=np.uint8)
        # Create subtle background color gradient
        grid_y, grid_x = np.mgrid[0:self.height, 0:self.width]
        img[:, :, 0] = (grid_x * 255 // self.width).astype(np.uint8)
        img[:, :, 1] = (grid_y * 255 // self.height).astype(np.uint8)
        img[:, :, 2] = 120
        return img

    def release(self) -> None:
        """Stops and releases the camera pipeline."""
        if self.pipeline is not None and not self.use_mock:
            try:
                self.pipeline.stop()
            except Exception:
                pass
