# Praktikum: Edge-AI Modell-Ausführung mit Raspberry Pi 5 & AI HAT+ 2 (Objektdetektion & LLM)

> **Einführendes Praktikum (CPS)**

Willkommen zur einführenden Praktikumsaufgabe „Edge-AI Modell-Ausführung mit Raspberry Pi 5 und AI HAT+ 2 (26 TOPS Hailo-8 NPU)“. In diesem Praktikum lernen Sie die Grundlagen modernster Edge-AI-Hardwarebeschleunigung kennen. Sie führen zwei grundlegende Klassen von KI-Modellen direkt auf eingebetteter Hardware aus und evaluieren deren Performanz:  
1. **Aufgabe 1: Live-Objektdetektion (Computer Vision)** – Latenzarme Objekterkennung im Videostream einer Intel RealSense D415 Kamera mittels Ultralytics YOLO (YOLOv8 / YOLOE / YOLO26).  
2. **Aufgabe 2: Lokale Generative KI & LLMs (Large Language Models)** – Ausführung und Benchmarking kompakter Sprachmodelle (z. B. `Llama-3.2-1B`, `Qwen2.5-1.5B`) auf der NPU/CPU-Architektur via Hailo GenAI.  

---

## 🎯 Überblick & Zielsetzung

In eingebetteten cyber-physischen Systemen (CPS) wie mobilen Robotern, autonomen Drohnen oder Smart-Factory-Zellen gewinnt die lokale Ausführung von KI-Modellen an der Kante (*Edge AI*) stark an Bedeutung. Sowohl die Auswertung von Kamerasignalen (Computer Vision) als auch das Verständnis natürlicher Sprache und Handlungsplanung durch Sprachmodelle (Generative AI / LLMs) müssen direkt auf dem System effizient, latenzarm und ohne ständige Cloud-Verbindung ablaufen.

In diesem Praktikum nutzen Sie ein leistungsfähiges Edge-AI-System bestehend aus:

1. **Raspberry Pi 5 (8 GB RAM):** Als zentraler Host-Computer für Systemsteuerung, Datenakquisition und Ablauflogik.  
2. **Raspberry Pi AI HAT+ 2 (Hailo-10, 40 TOPS, 8GB RAM):** Als PCIe-basierte NPU-Erweiterungskarte zur Hardwarebeschleunigung von Inferenz-Pipelines in HEF-Modellformat.  
3. **Intel RealSense D415:** Als USB 3.0 RGB-D Kamerasystem zur Bereitstellung von Live-Videostreams für Computer-Vision-Aufgaben.  
4. **Ultralytics YOLO & Hailo GenAI:** Als Software-Frameworks für Echtzeit-Objektdetektion und generative Sprachmodellierung auf der NPU.  

---

## 🏗 Systemarchitektur & Inferenz-Pipelines

```text
+-------------------------------------------------------------------+
|                        System-Eingaben                            |
|   - Kamera-Stream: Intel RealSense D415 (RGB Video @ 30 FPS)      |
|   - Text-Prompts: Benutzeranfragen für Sprachmodellierung         |
+---------------------------------+---------------------------------+
                                  |
                                  v
+-------------------------------------------------------------------+
|                        Raspberry Pi 5                             |
|  - Frame-Capture / Text-Preprocessing                             |
|  - Host-Ablaufsteuerung & Ressourcen-Monitoring (CPU/RAM/NPU)     |
+---------------------------------+---------------------------------+
                                  |
                                  | PCIe Gen 3.0 x1 Bus
                                  v
+-------------------------------------------------------------------+
|               Raspberry Pi AI HAT+ 2 (Hailo-8 NPU)                |
|  - 26 TOPS Inferenz-Beschleunigung                                |
|  - Pipeline A (Vision): HEF-Modellausführung (YOLOv8/YOLOE/YOLO26)|
|  - Pipeline B (GenAI): Hailo GenAI LLM Execution                  |
+---------------------------------+---------------------------------+
                                  |
                                  v
+-------------------------------------------------------------------+
|                        System-Ausgaben                            |
|  - Vision Output: Bounding Boxes, Klassen-Labels, Live-FPS        |
|  - LLM Output: Generierter Text, Token-Rate (Tokens/s), TTFT      |
+-------------------------------------------------------------------+
```

---

## 📂 Detaillierte Setup-Anleitungen

Kopiert den Inhalt der [config](./config) in eure ssh config. Schickt per Discord euren public ssh key an: .nicoh. Ich hinterlege den dann auf dem Raspberry Pi.

Kopiert mit scp . rpi-ai-hat:/home/raspberry/[euer projektname] die Dateien aus dem Ordner aus den Raspberry Pi

Per [VS Code Remote Plugin](https://marketplace.visualstudio.com/items?itemName=ms-vscode-remote.remote-ssh) könnt ihr euch dann auf den Raspberry Pi verbinden. Für das X11 Forwarding muss auf eurem System ein X11 Server laufen. Auf Linux läuft der meist standardmäßig für MacOS und Windows müsst ihr entsprechende Programme einrichten. Auf dem Raspberry Pi könnt ihr dann euren Projektordner öffnen und Dateien editieren.

Da das X11 Forwarding mit dem VS Code Remote Plugin nicht zuverlässig funktioniert solltet ihr noch in einem Terminal eine ssh Verbindung aufbauen und von dort aus mit docker compose run -it rpi-ai-hat in eurem Projektordner in den Entwicklungs-Container und Pythondateien ausführen. Durch das X11 Forwarding kann es zu geringen Latenzen bei GUI Anwendungen kommen.

## 📋 Praktikumsaufgaben & Ausführung

Das Praktikum gliedert sich in zwei gleichwertige Hauptaufgaben:

### 1️⃣ Aufgabe 1: Live-Objektdetektion im Kamerastream (Computer Vision)

In der ersten Aufgabe führen Sie Echtzeit-Objektdetektion mit Ultralytics YOLO auf der Hailo-10 NPU im Live-Kamerastream durch.

Die Musterlösung dazu ist in [`object_detection_realsense.py`](./object_detection_realsense.py) implementiert.

#### Ausführung im Mock-Modus (Ohne angeschlossene Hardware)

Wenn weder der AI HAT+ 2 noch die RealSense D415 Kamera angeschlossen sind, kann das Skript im Simulationsmodus getestet werden:

```bash
python3 object_detection_realsense.py --mock
```

#### Ausführung an der echten Hardware (Raspberry Pi 5 + AI HAT+ 2 + RealSense D415)

```bash
python3 object_detection_realsense.py --model yolov8n.hef --conf 0.5
```

#### Evaluierungsaufgaben (Aufgabe 1)

- Vergleichen Sie die Bildverarbeitungsrate (FPS) und Inferenzlatenz bei der Ausführung auf der Hailo-8 NPU im Vergleich zur Ausführung auf der Raspberry Pi 5 Host-CPU (`--mock` vs. `--model yolov8n.hef`).  
- Testen Sie unterschiedliche YOLO-Modellvarianten (`yolov8n.hef`, `yoloe.hef`, `yolo26.hef`) und bewerten Sie den Trade-off zwischen Erkennungsgenauigkeit (mAP / Konfidenz) und Bildrate (FPS).  

---

### 2️⃣ Aufgabe 2: Generative KI & Lokale LLM-Inferenz (Large Language Models)

In der zweiten Aufgabe führen Sie generative Sprachmodelle (LLMs) lokal auf der Raspberry Pi 5 + AI HAT+ 2 Hardware aus.

#### Einrichtung der LLM-Inferenzumgebung

Allgemeine Infos zum Einsatz von LLMs auf dem Raspberry Pi finden sich in der [offiziellen Raspberry Pi AI-Dokumentation zu LLMs](https://www.raspberrypi.com/documentation/computers/ai.html#LLMs). Unser spiegelt das offizielle Raspberry Pi Setup nur bedingt wieder, deswegen werden nicht alle Befehle wie angegeben funktionieren. Die LLM-Modelle für den Hailo 10H sind bereits heruntergeladen, sind auf dem Pi unter ~/.local/share/hailo-ollama/models/blob/ zu finden und werden im rpi-ai-hat service automatisch unter /workspace/llm-models eingehangen.

Weitere Infos zu unterstützten Modellen finden Sie unter [Hailo Model Zoo GenAI Repository](https://github.com/hailo-ai/hailo_model_zoo_genai) und die darin bereitgestellten [Model Manifests](https://github.com/hailo-ai/hailo_model_zoo_genai/tree/main/models/manifests).

#### Durchführung & Benchmarking (Aufgabe 2)

1. **Modellauswahl & Downloads:** Wählen Sie mindestens zwei unterschiedliche Sprachmodelle aus den unterstützten Manifesten aus (z. B. ein allgemeines Sprachmodell wie `Llama-3.2-1B` und ein spezialisiertes Modell wie `Qwen2.5-Coder-1.5B`).  
2. **Inferenz-Start & Interaktion:** Starten Sie die Modelle interaktiv und testen Sie verschiedene Prompts (z. B. einfache Textgenerierung, logische Aufgabenstellungen oder Code-Erzeugung).  
3. **Performanz-Analyse & Benchmarking:**  
   - Messen Sie die Generierungsgeschwindigkeit in **Tokens pro Sekunde (Tokens/s)**.  
   - Ermitteln Sie die Zeit bis zum ersten generierten Token (**Time To First Token / TTFT**).  
   - Analysieren Sie die Systemauslastung (CPU-Auslastung, RAM-Verbrauch sowie NPU-Auslastung via System-Monitoring).  
4. **Vergleich & Reflexion:** Vergleichen Sie die Performanz kompakter LLMs auf dem AI HAT+ 2 mit reiner CPU-Ausführung (z. B. via Ollama) und diskutieren Sie die Eignung kompakter Sprachmodelle für autonomes Agieren in cyber-physischen Systemen.  
