"""
Main entry point for real-time object detection on Raspberry Pi 5 with AI HAT+ 2 and Intel RealSense D415.
"""

from typing import List, Tuple
import argparse
import time
import cv2
import numpy as np

from src.realsense_driver import RealSenseCamera
from src.detector import ObjectDetector


def draw_overlay(
    frame: np.ndarray,
    detections: List[Tuple[Tuple[int, int, int, int], float, str]],
    fps: float,
    device_info: str,
) -> np.ndarray:
    """Draws bounding boxes, labels, confidence scores, and FPS on the image frame.

    Args:
        frame: BGR image numpy array.
        detections: List of detected objects ((x1, y1, x2, y2), conf, class_name).
        fps: Current frames per second value.
        device_info: Text label indicating NPU / CPU execution mode.

    Returns:
        Annotated BGR image frame.
    """
    output_frame = frame.copy()

    # Draw detection bounding boxes and labels
    for (x1, y1, x2, y2), conf, cls_name in detections:
        # Bounding box
        cv2.rectangle(output_frame, (x1, y1), (x2, y2), (0, 255, 0), 2)

        # Label background box
        label_text = f"{cls_name} {conf:.2f}"
        (w, h), _ = cv2.getTextSize(label_text, cv2.FONT_HERSHEY_SIMPLEX, 0.6, 1)
        cv2.rectangle(
            output_frame, (x1, y1 - 22), (x1 + w + 8, y1), (0, 255, 0), -1
        )
        # Label text
        cv2.putText(
            output_frame,
            label_text,
            (x1 + 4, y1 - 6),
            cv2.FONT_HERSHEY_SIMPLEX,
            0.6,
            (0, 0, 0),
            1,
            cv2.LINE_AA,
        )

    # Info overlay header
    cv2.putText(
        output_frame,
        f"FPS: {fps:.1f} | Hardware: {device_info}",
        (15, 35),
        cv2.FONT_HERSHEY_SIMPLEX,
        0.8,
        (255, 255, 255),
        2,
        cv2.LINE_AA,
    )

    return output_frame


def main() -> None:
    """Main execution loop for RealSense camera capture and NPU object detection."""
    parser = argparse.ArgumentParser(
        description="Live Object Detection on Raspberry Pi 5 with AI HAT+ 2 and RealSense D415"
    )
    parser.add_argument(
        "--model",
        type=str,
        default="yolov8n.hef",
        help="Path to model file (.hef for Hailo-8 NPU or .pt for PyTorch/Ultralytics)",
    )
    parser.add_argument(
        "--conf",
        type=float,
        default=0.5,
        help="Confidence threshold for detections (0.0 to 1.0)",
    )
    parser.add_argument(
        "--mock",
        action="store_true",
        help="Run in mock mode without physical RealSense camera or Hailo NPU",
    )
    parser.add_argument(
        "--headless",
        action="store_true",
        help="Run in headless mode without displaying OpenCV GUI window",
    )
    args = parser.parse_args()

    print("==================================================================")
    print(" Raspberry Pi 5 & AI HAT+ 2 Live Objektdetektion (Intel RealSense)")
    print("==================================================================")
    print(f" Modus: {'Mock/Simulation' if args.mock else 'Echte Hardware'}")
    print(f" Modell: {args.model}")
    print(f" Konfidenz-Schwelle: {args.conf}")
    print("==================================================================")

    camera = RealSenseCamera(width=1280, height=720, fps=30, use_mock=args.mock)
    detector = ObjectDetector(
        model_path=args.model, conf_threshold=args.conf, use_mock=args.mock
    )

    device_label = "AI HAT+ 2 (Hailo-8 26 TOPS)" if detector.is_hailo else "Host CPU"
    if args.mock:
        device_label += " [MOCK]"

    prev_time = time.time()
    frame_count = 0
    fps = 0.0

    try:
        while True:
            ret, frame = camera.get_frame()
            if not ret:
                print("[Warning] No frame received from camera stream.")
                break

            # Perform object detection
            detections = detector.detect(frame)

            # Calculate FPS
            frame_count += 1
            curr_time = time.time()
            elapsed = curr_time - prev_time
            if elapsed >= 1.0:
                fps = frame_count / elapsed
                frame_count = 0
                prev_time = curr_time

            # Annotate frame
            annotated_frame = draw_overlay(frame, detections, fps, device_label)

            if not args.headless:
                cv2.imshow("Raspberry Pi 5 + AI HAT+ 2 Live Detection", annotated_frame)
                key = cv2.waitKey(1) & 0xFF
                if key == 27 or key == ord("q"):
                    print("Beende Live-Stream...")
                    break
            else:
                # Log detection counts in headless mode
                if frame_count % 30 == 0:
                    print(f"[FPS: {fps:.1f}] Detected {len(detections)} objects.")

            # Stop after 100 frames in mock mode testing
            if args.mock and frame_count >= 100:
                print("Mock-Test erfolgreich abgeschlossen (100 Frames verarbeitet).")
                break

    except KeyboardInterrupt:
        print("\nAbbruch durch Benutzer.")
    finally:
        camera.release()
        cv2.destroyAllWindows()


if __name__ == "__main__":
    main()
