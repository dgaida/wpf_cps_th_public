# Installation & Einrichtung: Raspberry Pi AI HAT+ 2 (Hailo-8 NPU)

> **Praktikum: Live-Objektdetektion mit Raspberry Pi 5, AI HAT+ 2 & Intel RealSense D415**

In dieser Anleitung erfahren Sie, wie Sie das Raspberry Pi AI HAT+ 2 (26 TOPS Hailo-8 AI-Beschleuniger) auf dem Raspberry Pi 5 montieren, den PCIe-Bus konfigurieren und die notwendigen Hailo-Treiber sowie das HailoRT Framework installieren und testen.

---

## 1. Hardware-Montage

1. **Vorbereitung:** Stellen Sie sicher, dass der Raspberry Pi 5 ausgeschaltet und vom Netzteil getrennt ist.  
2. **Spacer & Stiftleiste:** Befestigen Sie die mitgelieferten Abstandshalter (Abstandsbolzen) auf der Platinenoberseite des Raspberry Pi 5. Stecken Sie den GPIO-Extension-Header vorsichtig auf die 40-Pin GPIO-Leiste.  
3. **PCIe-Flachbandkabel:**  
   - Öffnen Sie die Verriegelung des FPC/PCIe-Anschlusses auf dem Raspberry Pi 5 vorsichtig nach oben.  
   - Führen Sie das PCIe-Flachbandkabel ein (Kontakte zeigen nach innen bzw. gemäß der Raspberry Pi Markierung).  
   - Drücken Sie die Verriegelung wieder fest zu.  
   - Schließen Sie das andere Ende des Flachbandkabels an den PCIe-Anschluss der AI HAT+ 2 Platine an.  
4. **Fixierung:** Platzieren Sie das AI HAT+ 2 auf den Abstandshaltern und verschrauben Sie es vorsichtig.  

---

## 2. PCIe Gen 3 Aktivierung in Raspberry Pi OS

Das AI HAT+ 2 kommuniziert über den PCIe 2.0 / 3.0 Bus des Raspberry Pi 5. Um die volle Bandbreite und maximale Inferenzleistung (26 TOPS) zu erreichen, wird die PCIe Gen 3 Schnittstelle aktiviert.

1. Öffnen Sie die Konfigurationsdatei `/boot/firmware/config.txt` im Texteditor:  

   ```bash
   sudo nano /boot/firmware/config.txt
   ```

2. Fügen Sie am Ende der Datei folgende Zeilen hinzu:  

   ```text
   # PCIe Gen 3 Schnittstelle für AI HAT+ 2 aktivieren
   dtparam=pciex1
   dtparam=pciex1_gen=3
   ```

3. Speichern Sie mit `Ctrl+O`, `Enter` und beenden Sie mit `Ctrl+X`.  
4. Starten Sie den Raspberry Pi neu:  

   ```bash
   sudo reboot
   ```

---

## 3. Installation der Hailo-Treiber & Software-Pakete

Nach dem Neustart installieren Sie den Treiber-Stack und die Verwaltungswerkzeuge für die Hailo-8 NPU via `apt`:

```bash
sudo apt update
sudo apt install -y hailo-all
```

Das Paket `hailo-all` installiert unter anderem:  
- `hailort`: HailoRT C++/Python Runtime Driver  
- `hailo-t faint`: Firmware für den Hailo-8 Coprozessor  
- `hailortcli`: Command-Line Interface zur Hardwarediagnose  

---

## 4. Funktionsprüfung der NPU Hardware

Um zu verifizieren, dass das AI HAT+ 2 vom System erkannt wurde und korrekt arbeitet, führen Sie den Befehl `hailortcli fw-control identify` aus:

```bash
hailortcli fw-control identify
```

### Erwartete Ausgabe (Beispiel)

```text
Executing on device: 0000:01:00.0
Identifying board...
Device Architecture: HAILO8
Board Name: Hailo-8 M.2 Module / AI HAT+ 2
Firmware Version: 4.18.0 (release)
Device Serial Number: HLD...
PCIe Vendor ID: 0x1e60
```

Sollte hier ein Fehler ausgegeben werden (z. B. `Device not found`), prüfen Sie die Steckverbindung des PCIe-Flachbandkabels und kontrollieren Sie `dmesg | grep -i hailo`.
