# Software-Setup: Ultralytics, Intel RealSense & Hailo Runtime

> **Praktikum: Live-Objektdetektion mit Raspberry Pi 5, AI HAT+ 2 & Intel RealSense D415**

In dieser Anleitung richten Sie die benötigte Python-Entwicklungsumgebung ein, installieren den Treiber für die Intel RealSense D415 Kamera, installieren Ultralytics YOLO und lernen, wie Modelle für den Hailo-8 AI-Beschleuniger kompiliert werden.

---

## 1. Intel RealSense SDK & `librealsense2` Treiber

Die Intel RealSense D415 wird über das `librealsense2` Framework angesteuert. Unter Raspberry Pi OS Bookworm installieren Sie die Laufzeitbibliotheken:

```bash
sudo apt update
sudo apt install -y \
    librealsense2-dkms \
    librealsense2-utils \
    librealsense2-dev \
    python3-pip \
    python3-opencv \
    python3-venv \
    git
```

### Funktionsprüfung der Kamera

Schließen Sie die Intel RealSense D415 an einen **USB 3.0 Port (blaue Buchse)** des Raspberry Pi 5 an und testen Sie die Erkennung mit:

```bash
rs-enumerate-devices -s
```

Sie sollten Informationen zur Kamera (Seriennummer, Firmware-Version und unterstützte Streams wie RGB 1920x1080 / Depth 1280x720) sehen.

---

## 2. Python Virtual Environment & Abhängigkeiten

Erstellen Sie eine isolierte Python-Umgebung für das Praktikum:

```bash
cd praktikum/rpi_ai_hat
python3 -m venv venv
source venv/bin/activate
pip install --upgrade pip
```

Inhalt der Datei `requirements.txt`:

```text
opencv-python>=4.8.0
numpy>=1.24.0
ultralytics>=8.1.0
pyrealsense2>=2.54.0
```

Installieren Sie die Abhängigkeiten in der virtuellen Umgebung:

```bash
pip install -r requirements.txt
```

*Hinweis zu Hailo Python Bindings:*
Die Python-Schnittstelle `hailo_platform` wird bei der Installation des Systempakets `hailo-all` in der System-Python-Umgebung abgelegt. Falls Sie im Virtual Environment darauf zugreifen möchten, installieren Sie die passenden Wheels oder nutzen Sie `python3 -m venv --system-site-packages venv`.

---

## 3. Modellkonvertierung: Ultralytics YOLO zu Hailo HEF Format

Die Hailo-8 NPU führt keine rohen `.pt` (PyTorch) oder `.onnx` Dateien direkt aus. Stattdessen werden die Gewichte in das proprietäre **Hailo Executable Format (`.hef`)** kompiliert.

Ultralytics bietet eine direkte Export-Schnittstelle zur Hailo-Compiler-Pipeline:

```python
from ultralytics import YOLO

# 1. Standard PyTorch-Modell laden (z.B. YOLOv8n, YOLOE oder YOLO26)
model = YOLO("yolov8n.pt")

# 2. Exportieren in das Hailo-Format (.hef)
# Setzt installierten Hailo Dataflow Compiler (HDFC) voraus
model.export(format="hailo", imgsz=640)
```

In der Praxis stellt der Dozent vorab kompilierte `.hef`-Dateien (`yolov8n.hef`, `yoloe_s.hef`) im Kurs-Repository bereit, um lange Kompilierzeiten auf dem Raspberry Pi zu vermeiden.

---

## 4. Test der Pipeline

Zum Testen der Software-Pipeline ohne Live-Kamera oder NPU führt die Musterlösung ein synthetisches Testbild aus:

```bash
python3 object_detection_realsense.py --mock
```

Wenn sowohl die RealSense D415 Kamera als auch das AI HAT+ 2 betriebsbereit sind, starten Sie die Live-Erkennung mit:

```bash
python3 object_detection_realsense.py --model yolov8n.hef --conf 0.5
```
