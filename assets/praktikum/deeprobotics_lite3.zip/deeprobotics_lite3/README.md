# Deep Robotics Lite3 LiDAR – Einführendes Praktikum (Getting Started)

Willkommen zum einführenden Praktikum für den vierbeinigen Laufroboter **Deep Robotics Lite3 LiDAR**!
Der Lite3 hat einen LiDAR (Livox Mid-360) und eine Tiefenkamera (Intel RealSense). In diesem Praktikum lernen Sie die sichere Inbetriebnahme, die Steuerung mit dem Handheld, die Verbindung zum Roboter über WLAN, SSH und NoMachine sowie das Starten und Auslesen der Sensor-Topics mit ROS 2 kennen.

---

## 🎯 Ziel des Praktikums

1. Sicherer Umgang mit dem Roboter: Regeln, Ein- und Ausschalten, STOP-Knopf und Steuerung mit dem Handheld.  
2. Verbindung zum Roboter: Roboter-WLAN, Route ins Roboternetz, SSH und NoMachine.  
3. Sensoren starten und die Topics `/rslidar_points`, `/imu/data` und `/camera/depth/...` mit der ROS 2 CLI und einem eigenen Python-Skript ([`src/topic_reader.py`](./src/topic_reader.py)) auslesen.  

---

## ⚠️ Immer beachten

* **Nur mit Mitarbeiter im Labor:** Der Roboter darf nur benutzt werden, wenn ein Mitarbeiter im Labor ist. Sprechen Sie vorher @.nicoh. oder @tyn_yago an.  
* **Hinsetzen, wenn er nicht bewegt wird:** Steht der Roboter nur herum, bringen Sie ihn in die Sitzposition. Bricht die WLAN-Verbindung des Handhelds ab, während er steht, **bricht er zusammen**.  
* **Akku:** Nur mit mindestens 40 % bewegen. Bei niedrigem Akku kann er ohne Vorwarnung einknicken, dabei fallen auch beide Rechner aus.  
* **STOP-Knopf:** Der Not-Aus am Handheld ist immer griffbereit. Eine Person ist dafür zuständig, solange der Roboter läuft.  
* **Auto Mode:** ROS-Befehle (`/cmd_vel`) befolgt er nur, wenn er steht und der Auto Mode in der App aktiv ist. Bei Fehlverhalten **zuerst STOP drücken**, dann den Fehler suchen.  

---

## 📋 Ablauf & Aufgabenstellung

### 1. Inbetriebnahme & Fernsteuerung

Stellen Sie den Roboter in einem freien Bereich (mindestens $2\times 2\,\text{m}$) auf dem Boden ab.

1. **Akkustand prüfen:** Power-Taste kurz drücken, die vier LEDs zeigen den Ladestand. Unter 40 % nicht bewegen.  
2. **Einschalten:** Power-Taste einmal kurz drücken und dann gedrückt halten.  
3. **Handheld verbinden:** Warten, bis der Roboter hochgefahren ist und sich die App auf dem Handheld verbunden hat. Leuchten die Augen abwechselnd **gelb/rot**, ist die App getrennt.  
4. **Bewegen:** Roboter aufstehen lassen, mit den Joysticks vorwärts/rückwärts, seitlich und um die eigene Achse bewegen. Die für den STOP-Knopf zuständige Person steht daneben.  
5. **Hinsetzen:** Roboter wieder in die Sitzposition bringen, sobald er nicht mehr bewegt wird.  
6. **Ausschalten** (am Ende des Praktikums): Roboter hinlegen, dann wie beim Einschalten die Power-Taste drücken.  

---

### 2. Mit dem Roboter verbinden

Der Roboter hat **zwei Rechner**:

| Rechner | IP-Adresse | Aufgabe |
|---------|------------|---------|
| **Perception Host** | `192.168.1.103` | LiDAR, Kamera, ROS 2 Foxy, NoMachine. **Hier arbeiten Sie.** |
| **Motion Host** | `192.168.1.120` | Bewegungssteuerung und WLAN-Hotspot. Normalerweise nicht anfassen. |

1. **Roboter-WLAN verbinden:**  
   * **SSID:** `YSC-JYML-ra6vtx-5G`  
   * **Passwort:** `12345678`  
2. **Route setzen:** Das WLAN nutzt das Netz `192.168.2.x`, die Rechner im Roboter liegen in `192.168.1.x`. Ihr Rechner braucht deshalb eine Route. Ermitteln Sie den Namen Ihrer WLAN-Schnittstelle (z. B. `wlan0`, `wlp2s0`):  

   ```bash
   ip a
   ```

   und setzen Sie ihn ein:

   ```bash
   sudo ip route add 192.168.1.0/24 via 192.168.2.1 dev <wlan>
   ```

   Die Route geht bei Neustart oder WLAN-Wechsel verloren und muss dann neu gesetzt werden.  
3. **Verbindung testen:**  

   ```bash
   ping 192.168.1.103
   ```

4. **SSH** (Benutzer `ysc`, das Passwort ist nur das Hochkomma `'`):  

   ```bash
   ssh ysc@192.168.1.103   # Perception Host
   ssh ysc@192.168.1.120   # Motion Host
   ```

5. **Grafische Oberfläche mit NoMachine:**  
   * **NoMachine Version 9 oder kleiner** verwenden.  
   * Verbinden mit `192.168.1.103`, Port `4000`, Protokoll NX, Benutzer `ysc`.  
   * **Nicht** mit `192.168.1.120`: Der Motion Host hat keinen Desktop.  
   * Alternative ohne NoMachine: `ssh -X ysc@192.168.1.103`  

---

### 3. Sensoren starten & ROS 2 Topics untersuchen

Auf dem Perception Host läuft **ROS 2 Foxy**. Die Treiber starten **nicht** automatisch, Sie müssen sie nach jedem Einschalten selbst starten. Alle folgenden Befehle werden auf dem Perception Host ausgeführt (SSH oder NoMachine).

1. **Kamera** (RealSense, Dienst):  

   ```bash
   sudo systemctl start realsense_ros2
   ```

2. **LiDAR** (Livox Mid-360), in einem eigenen Terminal, das offen bleibt:  

   ```bash
   cd ~/lite_cog_ros2/system/scripts/lidar
   ./start_livox.sh
   ```

3. **Topics kontrollieren:**  

   ```bash
   ros2 topic list
   ros2 topic hz /rslidar_points   # ca. 10 Hz
   ros2 topic hz /imu/data         # ca. 200 Hz
   ```

   Wichtige Topics: `/rslidar_points` (LiDAR, Frame `rslidar`), `/imu/data` (IMU), `/camera/depth/...` (Tiefenbild). Suchen Sie mit `ros2 topic list | grep depth` den genauen Namen des Tiefenbild-Topics heraus.  
4. **Nachrichten ansehen:**  

   ```bash
   ros2 topic echo /imu/data --no-arr
   ros2 topic info /rslidar_points -v
   ```

   Neigen Sie den Roboter im Sitzen leicht von Hand und beobachten Sie, wie sich `linear_acceleration` ändert.

---

### 4. Python Topic Reader ausführen

Das Skript [`src/topic_reader.py`](./src/topic_reader.py) abonniert `/rslidar_points`, `/imu/data`, das Tiefenbild und `/cmd_vel` und gibt einmal pro Sekunde die gemessene Rate und den Inhalt der letzten Nachricht jedes Topics aus (Anzahl LiDAR-Punkte, Beschleunigung und Gierrate, Abstand in der Bildmitte, Geschwindigkeitskommando).

1. Skript von Ihrem Rechner auf den Perception Host kopieren:  

   ```bash
   scp src/topic_reader.py ysc@192.168.1.103:~/
   ```

2. Auf dem Perception Host starten (Sensoren müssen laufen, siehe Abschnitt 3):  

   ```bash
   source /opt/ros/foxy/setup.bash
   python3 ~/topic_reader.py
   ```

   Weicht der Name des Tiefenbild-Topics ab, übergeben Sie ihn als Parameter:

   ```bash
   python3 ~/topic_reader.py --ros-args -p depth_topic:=/camera/depth/image_rect_raw
   ```

3. Halten Sie die Hand vor die Kamera und beobachten Sie den Abstand in der Bildmitte. Vergleichen Sie die angezeigten Raten mit `ros2 topic hz`.  
4. **Optional, nur mit Mitarbeiter:** Roboter aufstehen lassen, Auto Mode in der App aktivieren und in einem zweiten Terminal ein langsames Drehkommando senden. Die für den STOP-Knopf zuständige Person steht bereit.  

   ```bash
   ros2 topic pub --rate 10 /cmd_vel geometry_msgs/msg/Twist "{angular: {z: 0.2}}"
   ```

   Mit Strg+C beenden. Der Topic Reader zeigt das Kommando unter `/cmd_vel` an, die Gierrate der IMU folgt der Drehung.

---

## 🛠️ Probleme

* **SSH-Timeout:** Route fehlt oder keine IP im Roboter-WLAN. `ip a` und `ip route` prüfen.  
* **WLAN nicht sichtbar:** Roboter fährt noch hoch. 1 bis 2 Minuten warten, sonst neu starten.  
* **`Cannot create a new display`:** Falscher Host, `192.168.1.103` nehmen.  
* **`Wrong session type`:** NoMachine-Client zu neu, Version 9 oder kleiner verwenden.  
* **Keine Kamera-Topics:** `sudo systemctl start realsense_ros2`  
* **Keine LiDAR-Topics:** `./start_livox.sh` läuft nicht mehr, Terminal prüfen und neu starten.  
* **Keine Reaktion auf `/cmd_vel`:** Steht er, und ist der Auto Mode an?  
* **Roboter knickt ein, beide Rechner weg:** Meist Akku zu niedrig oder Not-Aus. Laden, neu starten, Treiber neu starten.  

---

## 💻 Quellcode & Skripte

* [`src/topic_reader.py`](./src/topic_reader.py): ROS 2 Node in Python, der LiDAR (`/rslidar_points`), IMU (`/imu/data`), Tiefenbild und Geschwindigkeitskommandos (`/cmd_vel`) abonniert und einmal pro Sekunde zusammenfasst.  

---

## 📚 Offizielle Links & Dokumentation

* 🔗 **[Deep Robotics Lite3 Produktseite](https://www.deeprobotics.us/products/lite-3/)**  
* 🔗 **[DeepRoboticsLab GitHub Organization](https://github.com/DeepRoboticsLab)**  
* 📄 **[Deep Robotics Lite3 LiDAR User Manual (PDF)](https://www.deeprobotics.us/wp-content/uploads/2025/08/Jueying-Lite3-LiDAR-User-Manual-CE-V1.0.7-0.pdf)**  
