"""ROS 2 topic reader for the Deep Robotics Lite3 LiDAR quadruped robot.

Runs on the perception host (192.168.1.103, ROS 2 Foxy) after the camera and LiDAR drivers have
been started. Subscribes to the LiDAR point cloud (/rslidar_points), the IMU (/imu/data), the depth
image of the RealSense camera and velocity commands (/cmd_vel). Instead of logging every message
(the IMU publishes at about 200 Hz), it prints a summary with the measured rate of every topic once
per second.

Usage:
    python3 topic_reader.py
    python3 topic_reader.py --ros-args -p depth_topic:=/camera/depth/image_rect_raw
"""

import math
import sys
import time
from typing import Any, Dict, List, Optional

import numpy as np

try:
    import rclpy
    from geometry_msgs.msg import Twist
    from rclpy.node import Node
    from rclpy.qos import qos_profile_sensor_data
    from sensor_msgs.msg import Image, Imu, PointCloud2

    ROS2_AVAILABLE = True
except ImportError:
    ROS2_AVAILABLE = False
    Node = object  # type: ignore[misc, assignment]

LIDAR_TOPIC = "/rslidar_points"
IMU_TOPIC = "/imu/data"
DEPTH_TOPIC = "/camera/depth/image_rect_raw"
CMD_VEL_TOPIC = "/cmd_vel"


class Lite3TopicReader(Node):
    """ROS 2 node that subscribes to the Lite3 sensor topics and prints a summary once per second.

    Attributes:
        counts: Number of messages received per topic since the last summary.
        latest: Text describing the most recent message per topic.
    """

    def __init__(self) -> None:
        """Declares the topic parameters, creates the subscriptions and the summary timer."""
        super().__init__("lite3_topic_reader")

        topics = {}
        for name, default in (("lidar_topic", LIDAR_TOPIC), ("imu_topic", IMU_TOPIC),
                              ("depth_topic", DEPTH_TOPIC), ("cmd_vel_topic", CMD_VEL_TOPIC)):
            self.declare_parameter(name, default)
            topics[name] = self.get_parameter(name).get_parameter_value().string_value

        self.topic_names: List[str] = list(topics.values())
        self.counts: Dict[str, int] = {topic: 0 for topic in self.topic_names}
        self.latest: Dict[str, str] = {topic: "keine Nachricht" for topic in self.topic_names}
        self._last_summary = time.monotonic()

        # Sensor data QoS (best effort) also receives from reliable publishers.
        self.create_subscription(PointCloud2, topics["lidar_topic"],
                                 self._make_callback(topics["lidar_topic"], self._describe_cloud),
                                 qos_profile_sensor_data)
        self.create_subscription(Imu, topics["imu_topic"],
                                 self._make_callback(topics["imu_topic"], self._describe_imu),
                                 qos_profile_sensor_data)
        self.create_subscription(Image, topics["depth_topic"],
                                 self._make_callback(topics["depth_topic"], self._describe_depth),
                                 qos_profile_sensor_data)
        self.create_subscription(Twist, topics["cmd_vel_topic"],
                                 self._make_callback(topics["cmd_vel_topic"], self._describe_twist), 10)
        self.create_timer(1.0, self._print_summary)

        self.get_logger().info(f"Abonnierte Topics: {', '.join(self.topic_names)}")

    def _make_callback(self, topic: str, describe: Any) -> Any:
        """Creates a callback that counts the messages of a topic and stores a description.

        Args:
            topic: Name of the topic.
            describe: Function turning a message into a short text.

        Returns:
            The subscription callback.
        """
        def callback(msg: Any) -> None:
            self.counts[topic] += 1
            self.latest[topic] = describe(msg)

        return callback

    @staticmethod
    def _describe_cloud(msg: Any) -> str:
        """Describes a sensor_msgs/PointCloud2 message.

        Args:
            msg: The point cloud.

        Returns:
            Number of points and frame.
        """
        return f"{msg.width * msg.height} Punkte, Frame '{msg.header.frame_id}'"

    @staticmethod
    def _describe_imu(msg: Any) -> str:
        """Describes a sensor_msgs/Imu message.

        Args:
            msg: The IMU message.

        Returns:
            Acceleration, its magnitude and the yaw rate.
        """
        a = msg.linear_acceleration
        norm = math.sqrt(a.x ** 2 + a.y ** 2 + a.z ** 2)
        return (f"a=({a.x:.2f}, {a.y:.2f}, {a.z:.2f}) m/s² |a|={norm:.2f} m/s², "
                f"Gierrate={msg.angular_velocity.z:.3f} rad/s")

    @staticmethod
    def _describe_depth(msg: Any) -> str:
        """Describes a sensor_msgs/Image depth image including the distance at the image centre.

        Args:
            msg: The depth image (16UC1 in millimetres or 32FC1 in metres).

        Returns:
            Resolution, encoding and the centre distance.
        """
        text = f"{msg.width}x{msg.height} {msg.encoding}"
        dtypes = {"16UC1": np.uint16, "mono16": np.uint16, "32FC1": np.float32}
        if msg.encoding not in dtypes or msg.width == 0 or msg.height == 0:
            return text
        dtype = np.dtype(dtypes[msg.encoding]).newbyteorder(">" if msg.is_bigendian else "<")
        row = np.frombuffer(bytes(msg.data), dtype=dtype, count=msg.width,
                            offset=(msg.height // 2) * msg.step)
        value = float(row[msg.width // 2])
        distance = value if msg.encoding == "32FC1" else value / 1000.0
        return f"{text}, Abstand Bildmitte={distance:.2f} m"

    @staticmethod
    def _describe_twist(msg: Any) -> str:
        """Describes a geometry_msgs/Twist velocity command.

        Args:
            msg: The velocity command.

        Returns:
            Linear and angular velocity.
        """
        return (f"vx={msg.linear.x:.2f} m/s vy={msg.linear.y:.2f} m/s "
                f"wz={msg.angular.z:.2f} rad/s")

    def _print_summary(self) -> None:
        """Prints the measured rate and the latest message of every topic, then resets the counts."""
        now = time.monotonic()
        elapsed = max(now - self._last_summary, 1e-6)
        self._last_summary = now
        lines = ["-" * 72]
        for topic in self.topic_names:
            lines.append(f"{topic:32s} {self.counts[topic] / elapsed:6.1f} Hz | {self.latest[topic]}")
            self.counts[topic] = 0
        print("\n".join(lines), flush=True)


def main(args: Optional[list] = None) -> None:
    """Initializes rclpy, spins the Lite3TopicReader node and shuts down cleanly.

    Args:
        args: Command-line arguments passed to rclpy.
    """
    if not ROS2_AVAILABLE:
        print(
            "[Warnung] rclpy bzw. die ROS 2 Nachrichtentypen sind nicht installiert. "
            "Führen Sie das Skript auf dem Perception Host (192.168.1.103) aus, "
            "nachdem Sie 'source /opt/ros/foxy/setup.bash' ausgeführt haben."
        )
        sys.exit(0)

    rclpy.init(args=args)
    node = Lite3TopicReader()

    try:
        print("Lite3 Topic Reader läuft. Beenden mit Strg+C.")
        rclpy.spin(node)
    except KeyboardInterrupt:
        print("\nLite3 Topic Reader beendet.")
    finally:
        node.destroy_node()
        rclpy.shutdown()


if __name__ == "__main__":
    main()
